با استفاده از  سند D:\.YT-vault\Script Structure\Script Structure (Template).md یک اسکیل بنویس
به زبان انگلیسی بنویس
در مسیر D:\.YT-vault\Skills\solo-script-structure ذخیره کن
 سند D:\.YT-vault\Script Structure\Script Structure (Template).md را به عنوان یک سند جداگانه در اسکیل قرار بده و در اسکیل بنویس که  از  سند  D:\.YT-vault\Script Structure\Script Structure (Template).md به عنوان الگو استفاده شود .
 ---
 تمرکز اسکیل را بر کیفیت و جذابیت ساختار اسکریپت قرار بده .
 با استفاده از این اسکیل ساختار ویدئو های (ویدئو مقاله) نوشته خواهد شد 
 D:\.YT-vault\Knowledge\Video Essay.md
 نمونه نریشن ها را در مسیر  D:\.YT-vault\Narration بررسی کن
برخی موضوعات را در D:\.YT-vault\Topics بررسی کن