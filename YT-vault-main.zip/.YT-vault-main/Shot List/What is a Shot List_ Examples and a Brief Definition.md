---
title: "What is a Shot List? Examples and a Brief Definition"
source: "https://www.studiobinder.com/blog/what-is-a-shot-list-example/"
---
ن چه یک فیلمساز مشتاق باشید و چه به داستان‌سرایی بصری علاقه داشته باشید، داشتن برنامه‌ای برای زنده کردن داستانتان بسیار مهم است. اسپایک لی، فیلمساز، گفته است: «من مارتین لوتر کینگ نیستم. من به رویا نیاز ندارم. من یک برنامه دارم.» یکی از مهم‌ترین برنامه‌ریزی‌هایی که یک کارگردان می‌تواند انجام دهد، ایجاد یک **فهرست نما** برای انتقال دیدگاه خود از ذهن به دوربین است.

خب، فهرست برداشت‌ها چیست؟ و به طور خاص‌تر، فهرست برداشت‌ها برای فیلم چیست؟ ما قصد داریم این اصطلاح را تعریف کنیم، چرا برای فیلمسازان ضروری است و چگونه می‌توان فهرستی ایجاد کرد که تولید شما را برای موفقیت آماده کند.

![شات لیست چیست؟ مثال‌ها و تعریف مختصر ۱](https://s.studiobinder.com/wp-content/uploads/2018/07/series-color.svg?resolution=1920,1)

شات لیست چیست؟ مثال‌ها و تعریف مختصر ۱

## نحوه تهیه لیست عکس در StudioBinder

![](https://www.youtube.com/watch?v=4oYvFcp7TOs)

[لیست شات‌های رایگان خود را ایجاد کنید](https://www.studiobinder.com/shot-list-storyboard/)

## فیلم شات لیست چیست؟

### اصول اولیه لیست کردن عکس‌ها

هر زمان که در حال فیلمبرداری چیزی هستید - چه یک سریال تلویزیونی، [فیلم سینمایی](https://www.studiobinder.com/blog/what-is-a-feature-film-definition/) یا حتی یک [تیزر تبلیغاتی](https://www.studiobinder.com/blog/spec-commercial-with-spec-ad-examples/) کوتاه باشد ، موارد زیادی برای بررسی وجود دارد. [نورپردازی](https://www.studiobinder.com/blog/film-lighting/) ، [صدا](https://www.studiobinder.com/blog/film-sound-effect-techniques/) ، [بازیگران](https://www.studiobinder.com/blog/directing-actors/) ، صحنه‌ها... این لیست ادامه دارد. در واقع، برنامه‌ریزی ضعیف بر بودجه تأثیر می‌گذارد و تولید را برای ۹۳٪ از [فیلمسازان مستقل](https://www.studiobinder.com/blog/what-is-an-indie-film-definition/) به تأخیر می‌اندازد. داشتن یک لیست فیلمبرداری بخش جدایی‌ناپذیری از پایبندی به برنامه به عنوان یک [کارگردان](https://www.studiobinder.com/blog/what-does-a-director-do/) است.

اما فهرست نماها در فیلم چیست؟ بیایید تعریف آن را بررسی کنیم:

## تعریف فهرست عکس‌ها

### لیست عکس چیست؟

فهرست **نماها** سندی است که با توصیف هر نما در یک صحنه از یک فیلم یا ویدئو، تمام اتفاقات آن صحنه را ترسیم می‌کند. این فهرست به عنوان نوعی چک لیست عمل می‌کند و به گروه فیلمبرداری جهت و آمادگی لازم را برای پروژه می‌دهد.

این فهرست معمولاً با همکاری کارگردان، فیلمبردار و حتی دستیار اول کارگردان تهیه می‌شود. فهرست نماها به ویژه در مدیریت و آماده‌سازی صحنه‌های *فیلم* بسیار مهم هستند. ساخت یک فیلم نیاز به دانش در مورد نوع نما، حرکت دوربین، نورپردازی، صحنه‌پردازی بازیگران و موارد دیگر دارد. ثبت این اطلاعات در فهرست نماها به فیلمسازان کمک می‌کند تا از آنچه مورد نیاز است و نحوه ثبت آن در روز فیلمبرداری مطلع باشند.

با وجود این همه اجزای متحرک، داشتن یک سند مشخص که نشان دهد هر نما به چه تجهیزاتی نیاز دارد و تنظیمات هر نما چقدر طول می‌کشد، بخش زیادی از برنامه و بودجه را تعیین می‌کند.

## چه چیزهایی در لیست شات (Shot List) قرار می‌گیرد؟

- شرح مختصری از صحنه - اکشن، شخصیت‌ها
- شماره صحنه و شماره نما
- نوع نما (کلوزآپ، واید و غیره)
- زاویه دوربین
- حرکت دوربین
- تجهیزات دوربین
- قاب‌بندی (نسبت ابعاد)
- مکان (داخلی/خارجی)
- زمان‌های راه‌اندازی
- گاهی اوقات یادداشت‌های صوتی، یا اشارات مربوط به صحنه

از آنجا که [برنامه](https://www.studiobinder.com/blog/shooting-schedule-format/) و حتی [بودجه](https://www.studiobinder.com/blog/average-movie-budget/) به آنچه در فهرست نماها اتفاق می‌افتد وابسته است، مهم است که فهرست نماهای خود را با [اعضای کلیدی گروه](https://www.studiobinder.com/blog/film-crew-positions/) ، به خصوص [دستیاران کارگردان](https://www.studiobinder.com/blog/what-does-an-assistant-director-do/) که در حال تهیه برنامه فیلمبرداری هستند، به اشتراک بگذارید.

[تهیه‌کنندگان](https://www.studiobinder.com/blog/what-does-a-producer-do/) نیاز به دسترسی سریع به تصمیماتی دارند که کارگردانان می‌گیرند، زیرا همکاری آنها برای ساخت فیلم ضروری است. [درباره نحوه همکاری تهیه‌کننده و کارگردان بیشتر بدانید](https://www.studiobinder.com/blog/producer-vs-director/).

[به همین دلیل است که فهرست‌های شات قدیمی‌تر، مانند نمونه‌ی زیر، به اندازه‌ی قالب‌های فهرست شات](https://www.studiobinder.com/blog/shot-list-template-free-download/) قابل اشتراک‌گذاری مفید نیستند و ممکن است باعث شوند آنها به این فکر کنند که «فهرست شات برای فیلم چیست؟»

![شات لیست چیست - مثال شات لیست](https://s.studiobinder.com/wp-content/uploads/2019/08/What-is-a-Shot-List-Shot-List-Example.jpg.webp?resolution=2048,2)

شات لیست چیست - مثال شات لیست

#### مثال لیست شات قدیمی

حال، اگرچه شکی نیست که این اطلاعات قبل از روز فیلمبرداری فوق‌العاده مفید هستند، اما ایجاد تغییرات سریع دشوار است، و وقتی این کار را می‌کنید، «به اشتراک گذاشتن» در واقع به معنای ارسال و دریافت ایمیل است که روشی مفید و بصری برای تبادل ایده‌ها نیست. همچنین این خطر وجود دارد که تغییرات مهم در لیست عکس‌ها در میان انبوهی از پیام‌ها گم شوند.

نقشه‌های مفیدتری به صحنه آمده‌اند که هم از نظر بصری آموزنده هستند و هم به راحتی قابل اشتراک‌گذاری. به جای اسناد ثابت که در ایمیل‌ها دفن شده‌اند، قالب‌های مدرن لیست عکس به شما این امکان را می‌دهند که لیست عکس خود را به صورت آنی با عوامل فیلم خود به‌روزرسانی، سازماندهی و به اشتراک بگذارید.

بیایید نگاهی به [لیست شات‌های StudioBinder](https://www.studiobinder.com/storyboard-creator/) در زیر بیندازیم.

![مثالی از استوری‌بورد آستین پاورز برای فهرست شات‌ها چیست؟ نرم‌افزار استوری‌بورد StudioBinder](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Austin-Powers-Storyboard-Example-StudioBinder-Storyboarding-Software.jpg)

مثالی از استوری‌بورد آستین پاورز برای فهرست شات‌ها چیست؟ نرم‌افزار استوری‌بورد StudioBinder

#### برای مشاهده لیست شات ها کلیک کنید

به تمام گزینه‌هایی که دارید توجه کنید. آن‌ها با تعریف شات لیست بالا مطابقت دارند و به وضوح نشان می‌دهند [که چه چیزهایی در یک شات لیست قرار می‌گیرند](https://www.studiobinder.com/blog/how-to-make-a-shot-list-software/).

می‌توانید شرح نما، شماره نما، [نوع نما](https://www.studiobinder.com/blog/ultimate-guide-to-camera-shots/) ، [زاویه دوربین](https://www.studiobinder.com/blog/types-of-camera-shot-angles-in-film/) ، [حرکت](https://www.studiobinder.com/blog/different-types-of-camera-movements-in-film/) و [تجهیزات](https://www.studiobinder.com/camera-shots/camera-equipment/) را اضافه کنید. همچنین می‌توانید [کادربندی](https://www.studiobinder.com/blog/types-of-camera-shot-frames-in-film/) یا [نسبت ابعادی](https://www.studiobinder.com/blog/what-is-aspect-ratio-definition/) که قصد فیلم‌برداری با آن را دارید، تعیین کنید.

<video controls=""><source type="video/mp4" src="https://s.studiobinder.com/wp-content/uploads/2026/02/Shot-Lists-Video-Loops-Looped-video-of-shot-size-added.mp4"></video>

#### انتخاب اندازه نما | نرم‌افزار لیست نما StudioBinder

همین امر در مورد اضافه کردن [حرکت دوربین](https://www.studiobinder.com/camera-shots/camera-movements/) نیز صدق می‌کند...

<video controls=""><source type="video/mp4" src="https://s.studiobinder.com/wp-content/uploads/2026/02/Shot-Lists-Video-Loops-Looped-video-of-camera-movement-added.mp4"></video>

#### اضافه شدن دالی به عنوان حرکت دوربین | نرم‌افزار فهرست نما StudioBinder

***...** و جزئیات **لنز***. نمی‌دانید کدام [لنز دوربین](https://www.studiobinder.com/camera-shots/camera-lenses/) ؟ StudioBinder با نمایش رایج‌ترین گزینه‌های لنز (برحسب میلی‌متر) این کار را آسان می‌کند.

<video controls=""><source type="video/mp4" src="https://s.studiobinder.com/wp-content/uploads/2026/02/Shot-Lists-Video-Loops-Looped-video-of-lens-added.mp4"></video>

#### انتخاب لنز دوربین | نرم‌افزار فهرست عکس StudioBinder

یک شات‌لیست ممکن است بسته به نوع تولید و الزامات آن، ستون‌های مختلفی داشته باشد. در زیر ستون‌های مختلف شات‌لیست که می‌توانند در نظر گرفته شوند، آورده شده است. در این حالت، می‌توانید در صورت نیاز آنها را تغییر دهید.

![لیست نما چیست؟ مثال مشخصات نما نرم افزار لیست نما StudioBinder](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Shot-Specs-Example-StudioBinder-Shot-Listing-Software.jpg)

لیست نما چیست؟ مثال مشخصات نما نرم افزار لیست نما StudioBinder

#### تنظیم ستون‌هایی مانند حرکت دوربین، نورپردازی و غیره | مشاهده لیست نمونه عکس‌ها

زمان‌های آماده‌سازی و تنظیم را فراموش نکنید. بنرهای مربوط به زمان استراحت و صرف غذا می‌توانند به تیم شما اطلاع دهند که در ادامه‌ی برنامه چه برنامه‌ای در پیش است.

The [storyboards](https://www.studiobinder.com/blog/what-is-a-storyboard/) you draw can be easily dropped into the shot list. So now you have more of an understanding of what the shot needs to actually look like and what is a shot list in film.

In [StudioBinder’s shot list](https://www.studiobinder.com/shot-list-storyboard/), you can also add the real shots in as you go. You can then use the shot list to determine if you need any reshoots.

What would that look like?

![لیست شات چیست؟ مثال لیست شات فیلم زن شگفت‌انگیز نرم‌افزار لیست شات StudioBinder](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Wonder-Woman-Shot-List-Example-StudioBinder-Shot-Listing-Software.jpg)

لیست شات چیست؟ مثال لیست شات فیلم زن شگفت‌انگیز نرم‌افزار لیست شات StudioBinder

#### Click to view the shot list

What’s equally powerful is that you can share all of this with one click.

Your team can leave comments in real time, keeping [producers](https://www.studiobinder.com/blog/what-does-a-producer-do/), assistant directors, and department heads aligned without the confusion of endless email chains.

When you circulate a shot list during [pre-production](https://www.studiobinder.com/blog/what-is-pre-production-definition/), collaborators can build upon it in specific, practical ways:

- **Director of Photography (DP)**: Refines the visual strategy by selecting lenses, designing lighting setups, planning camera movement, and identifying equipment needs.
- **1st Assistant Director** **(1st AD)**: Evaluates shot complexity and estimates setup times to build a realistic shooting schedule.
- **Film Producer**: Anticipate location demands, prep requirements, crew needs, and budget implications.

Can shots change on set? Absolutely.

A shot list is not set in stone. However, having a structured, shareable shot list ensures alignment. It gives your crew a clear game plan for the day, even if adjustments are necessary. When changes happen, they happen from a place of preparation rather than confusion.

A shot list does not limit creativity. It gives it structure.

Trusted by over 1M creatives

Shot lists that turn vision into action

From first draft to final take, plan, organize, and execute every shot with confidence.

[**Try for free**](https://app.studiobinder.com/register)

[Explore Features](https://www.studiobinder.com/shot-list-storyboard/)

![نرم‌افزار ساخت لیست عکس StudioBinder در پست CTA](https://s.studiobinder.com/wp-content/uploads/2026/03/In-Post-CTA-StudioBinder-Shot-List-Creator-Software-1.png)

نرم‌افزار ساخت لیست عکس StudioBinder در پست CTA

## Anatomy of a shotlist

### What does a shot list look like?

With so many elements to keep track of, it’s easy to get overwhelmed by all of the moving parts a shot list is supposed to help you track.

Here's a table provides exactly what goes on a [shot list](https://www.studiobinder.com/download-free-shot-list-template/) for a film project:

<table><thead><tr><th><p><strong><strong>Shot #</strong></strong></p></th><th><p><strong><strong>Description</strong></strong></p></th><th><p>Shot Type</p></th><th colspan="1" rowspan="1"><p>Movement</p></th><th colspan="1" rowspan="1"><p>Equipment</p></th><th colspan="1" rowspan="1"><p>Time</p></th></tr></thead><tbody><tr><td><p><strong>12A</strong></p></td><td><p>Character enters the room</p></td><td><p>Wide Shot</p></td><td colspan="1" rowspan="1"><p>Dolly In</p></td><td colspan="1" rowspan="1"><p>Tripod + Dolly</p></td><td colspan="1" rowspan="1"><p>20 min</p></td></tr><tr><td><p><strong>12B</strong></p></td><td><p>Reaction<br>close-up</p></td><td><p>Close-Up</p></td><td colspan="1" rowspan="1"><p>Static</p></td><td colspan="1" rowspan="1"><p>50mm Lens</p></td><td colspan="1" rowspan="1"><p>10 min</p></td></tr><tr><td><p><strong>12C</strong></p></td><td><p>Two characters converse</p></td><td><p>Medium Shot</p></td><td colspan="1" rowspan="1"><p>Handheld</p></td><td colspan="1" rowspan="1"><p>DSLR + Gimbal</p></td><td colspan="1" rowspan="1"><p>15 min</p></td></tr><tr><td><p><strong>13A</strong></p></td><td><p>Character looks out the window</p></td><td><p>Wide Shot</p></td><td colspan="1" rowspan="1"><p>Static</p></td><td colspan="1" rowspan="1"><p>35mm Lens</p></td><td colspan="1" rowspan="1"><p>10 min</p></td></tr></tbody></table>

If you’re confused by any terminology or what type of shots to include, check out the video below that breaks down [every type of camera shot](https://www.studiobinder.com/blog/ultimate-guide-to-camera-shots/):

Knowing what you want to shoot and how you want to shoot it on your shot list makes for a smooth, enjoyable filmmaking process.

## What is a Shot List in Film

### How to make a shot list in 5 steps

There’s plenty of [filmmaking software and tools](https://www.studiobinder.com/blog/best-filmmaking-software-and-tools/) to help a director make their shot list, but the process of compiling a shot list is the same for all filmmakers. It consists of **five major steps**: breaking down the script, selecting shot types, organizing scenes in shooting order, budgeting in equipment and timing, then sharing and amending the list as needed.

For an in-depth walkthrough of the shotlisting process, you can watch the video below, and then follow along to the steps below:

#### Learn how to make a shot list in StudioBinder

The following tutorial will break down all of your questions regarding what is a shot list in filmmaking:

##### 1\. Create your script breakdown

While you may have read the [script](https://www.studiobinder.com/blog/what-is-screenplay-definition/) several times already for dramatic potential, themes, and characters, now it’s time to read to break it down for technical purposes.

First, identify key moments in the story that require specific shots. For instance, where is a [close up](https://www.studiobinder.com/blog/close-up-shot/) necessary? Where do you need wider, [establishing shots](https://www.studiobinder.com/camera-shots/framing/establishing-shot/)?

Next, go scene-by-scene and make notes on the action, emotional [tone](https://www.studiobinder.com/blog/what-is-tone-in-literature-definition/), and what needs to be captured visually.

This step can be an arduous, tedious process, but [StudioBinder script breakdown software](https://www.studiobinder.com/script-breakdown-software/) can help you create [script breakdowns](https://www.studiobinder.com/blog/free-script-breakdown-sheet/) easily.

#### Learn how to break down scripts in StudioBinder

Filmmaker [Christopher Nolan](https://www.studiobinder.com/blog/christopher-nolan-directing-visual-style/) has said, “the screen is the same size for every story. A shot of a teacup is the same size as an army coming over the hill. It’s all [storytelling](https://www.studiobinder.com/blog/dan-harmon-story-circle/).” What shots do you need to tell your story effectively and compellingly?

Next, visit the **Shot List** page and use the **Shot Tagger** feature to highlight other key camera movements or shots needed. Simply highlight the script line, and click **Add Shot.**

![فهرست نماها چیست؟ ایجاد تجزیه فیلمنامه برای فهرست نماها](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Creating-a-Script-Breakdown-for-Shot-List.png)

فهرست نماها چیست؟ ایجاد تجزیه فیلمنامه برای فهرست نماها

##### 2\. Pick your shot sizes and shot types

Now that you know what needs to be captured on camera in your scene breakdowns, it’s time to decide how to shoot it. For every scene on your shot list, decide what type of shot fits each moment.

![شات لیست چیست؟ انتخاب انواع شات](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Choosing-a-shot-types.png)

شات لیست چیست؟ انتخاب انواع شات

Common shot types include:

- **Wide Shot (WS)**: [Wide Shot](https://www.studiobinder.com/blog/wide-shot-camera-angles-movements-examples/) establishes the [scene](https://www.studiobinder.com/blog/what-is-a-scene-definition/), showing the environment.
- **Medium Shot (MS)**: [Medium Shot](https://www.studiobinder.com/blog/medium-shot-examples/) shows characters from the waist up, often used for [dialogue](https://www.studiobinder.com/blog/what-is-dialogue-definition/).
- **Close-Up (CU)**: [Close Up](https://www.studiobinder.com/blog/close-up-shot/) focuses on a character or an object, highlighting emotional moments.
- **Over-the-Shoulder (OTS)**: [Over the Shoulder](https://www.studiobinder.com/blog/over-the-shoulder-shot/) often used in conversations to show the perspective of one character.

Follow along in the tutorial below to learn how to add, edit, and organize custom shot types inside StudioBinder.

##### 3\. Organize scenes in shooting order

Knowing when you’re shooting each scene is just as important as knowing what and how you’re shooting it. That’s why when making a shot list, it’s imperative to organize the scenes on your shot list in shooting order, not [narrative](https://www.studiobinder.com/blog/what-is-a-narrative-definition/) order.

![فهرست نما چیست؟ صحنه‌ها را به ترتیب فیلمبرداری مرتب کنید](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Organize-Scenes-in-Shooting-Order.png)

فهرست نما چیست؟ صحنه‌ها را به ترتیب فیلمبرداری مرتب کنید

Organizing your shots in shooting order on your list allows you to streamline the shooting schedule, minimizes unnecessary setups, and makes the most of your locations and actors.

##### 4\. Add equipment and camera setups

Time is literally money on a film set, and staying on budget is harder than it seems. For instance, over the past fifteen years, only [1 out of 51 Disney films came in under budget](https://www.forbes.com/sites/carolinereid/2025/09/06/new-analysis-reveals-disney-overspent-on-almost-half-its-movies-and-shows/?utm_source=chatgpt.com), and only half of those films stayed in line with their budgets. So it’s important to not only know what is a shot list, film producers and [financiers](https://www.studiobinder.com/blog/what-is-film-financing-definition/) will also expect you to adhere to it.

Therefore, adding in the duration of setups for each shot, along with [budgeting](https://www.studiobinder.com/blog/the-essential-guide-for-crafting-film-budgets-with-free-film-budget-template/) extra time for any special requirements like [props](https://www.studiobinder.com/blog/what-is-a-movie-prop-definition/) or [special effects](https://www.studiobinder.com/blog/what-are-special-effects-in-movies/) is crucial to include on your shot list. This step allows you and your crew to gauge if your vision for the scene is feasible within your [shooting schedule](https://www.studiobinder.com/blog/what-is-a-shooting-schedule/) and [budget](https://www.studiobinder.com/blog/the-essential-guide-for-crafting-film-budgets-with-free-film-budget-template/).

![لیست عکس چیست؟ تنظیمات دوربین را اضافه کنید](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Add-Camera-Setups.png)

لیست عکس چیست؟ تنظیمات دوربین را اضافه کنید

![اشتراک‌گذاری شات لیست با تیمتان چیست؟](https://s.studiobinder.com/wp-content/uploads/2026/02/What-is-a-Shot-List-Share-with-Your-Team.png)

اشتراک‌گذاری شات لیست با تیمتان چیست؟

Having key players look over the shot list will help you catch any mistakes and allow for adjustments to be made if necessary.

After you've collaborated to finalize your shot list, watch the video below to learn how to export, print, and share your shot list inside StudioBinder.

## Effective shot listing

### 5 tips for creating effective shot lists

A strong shot list does more than organize your day. It helps translate story into execution. Use these tips to make sure your shot list is both creative and practical.

1. **Start with the script**, not the camera. Break down the scene for [emotional beats](https://www.studiobinder.com/blog/story-beat-in-screenplay/) and story purpose before deciding on shot types.
2. **Think in** **coverage**, not just hero shots. Make sure you have enough angles and [inserts](https://www.studiobinder.com/blog/insert-shot-film-example/) to protect the [edit](https://www.studiobinder.com/blog/what-is-film-editing-definition/).
3. **Organize by shooting order**. Build your shot list around location, [lighting setups](https://www.studiobinder.com/blog/film-lighting-techniques/), and actor availability to save time on set.
4. **Be specific with technical details**. Include lens choices, [movement](https://www.studiobinder.com/blog/different-types-of-camera-movements-in-film/), equipment, and estimated setup time so your crew can prepare properly.
5. **Leave room for flexibility**. Plan thoroughly, but allow space for adjustments once you are on set.

Trusted by over 1M creatives

Shot lists that turn vision into action

From first draft to final take, plan, organize, and execute every shot with confidence.

[**Try for free**](https://app.studiobinder.com/register)

[Explore Features](https://www.studiobinder.com/shot-list-storyboard/)

![نرم‌افزار ساخت لیست عکس StudioBinder در پست CTA](https://s.studiobinder.com/wp-content/uploads/2026/03/In-Post-CTA-StudioBinder-Shot-List-Creator-Software-1.png)

نرم‌افزار ساخت لیست عکس StudioBinder در پست CTA

## Common mistakes with shot lists

### 5 common shot listing mistakes to avoid

Even experienced filmmakers can misuse a shot list. Avoid these common mistakes to keep your [production](https://www.studiobinder.com/blog/what-is-film-production-definition/) efficient and aligned.

1. **Being too vague**. Writing “ [medium shot](https://www.studiobinder.com/blog/medium-shot-examples/) ” without context can create confusion about framing, movement, or purpose.
2. **Overshooting unnecessary coverage**. Adding too many shots can slow down production and inflate your schedule.
3. **Ignoring setup time**. Failing to account for lighting changes, camera builds, or location resets can derail your day.
4. **Forgetting collaboration**. Not reviewing your shot list with the DP, 1st AD, or producer can lead to logistical surprises.
5. **Treating it as static**. A shot list should evolve as production evolves. Update it and share changes with your team.

## What is a Shot List in Film?

### What’s the difference between a shot list and storyboard?

While a shot list and storyboarding serve similar purposes for a filmmaker, they’re different tools. Understanding their differences and how they can work together will optimize your pre-production planning.

If you’re still asking what is a shot list for film, a shot list organizes both the **technical** and **creative** details of every shot in a table or list format, and is used for day-to-day planning of your shoot.

On the other hand, a [storyboard’s](https://www.studiobinder.com/storyboard-creator/) chief purpose is to **visualize the shots** in each scene to plan [framing](https://www.studiobinder.com/blog/types-of-camera-shot-frames-in-film/) and [composition](https://www.studiobinder.com/blog/rules-of-shot-composition-in-film/). They’re a series of illustrations or images roughly depicting each shot for camera angles and blocking actors.

Basically, a shot list is more about logistics, a storyboard helps you visualize how the shots will actually look. But incorporating storyboards into your shotlists is a handy way to enhance clarity and optimize efficiency on set.

## سوالات متداول

### سوالات رایج در مورد لیست عکس‌ها

#### لیست عکس چیست؟

فهرست نماها سندی است که هر نما در یک پروژه فیلم یا ویدیو را مشخص می‌کند تا نقشه راهی برای فیلمبرداری ارائه دهد. این فهرست، جنبه‌های فنی - مانند زوایای دوربین، حرکات و تجهیزات - را در کنار عناصر خلاقانه مانند حرکات شخصیت‌ها و تنظیمات صحنه شرح می‌دهد تا یک فرآیند تولید شفاف، به موقع و مقرون به صرفه را تضمین کند.  
  
اگر کنجکاو هستید که فهرست نما در عکاسی چیست، باید بگویم که بسیار شبیه به آن است، اما بدون تأکید بر حرکت دوربین.

#### چطور یک لیست عکس تهیه کنیم؟

برای ایجاد یک فهرست نما، صحنه به صحنه پیش بروید و انواع نماها، زوایا و سایر جنبه‌های فنی مورد نظر خود را که می‌خواهید هر صحنه شامل شود، انتخاب کنید. سپس صحنه‌ها را به ترتیب فیلمبرداری مرتب کنید، نه به ترتیبی که در فیلمنامه آمده است. از آنجا، فهرستی از تجهیزات و زمان‌بندی مورد نیاز برای اجرای نماها در هر صحنه تهیه کنید.

#### یک لیست عکس چه شکلی است؟

یک فهرست نما می‌تواند مانند یک جدول، صفحه گسترده یا ابزار دیجیتالی باشد که شماره نماها، استوری‌بوردها، توضیحات، جزئیات دوربین و زمان‌بندی را نشان می‌دهد.

#### شات ۵ ثانیه‌ای چیست؟

نمای ۵ ثانیه‌ای به نمایی با مدت زمان برنامه‌ریزی‌شده‌ی پنج ثانیه روی صفحه اشاره دارد که اغلب در تصمیم‌گیری‌های مربوط به سرعت و تدوین استفاده می‌شود.

#### چرا لیست عکس‌ها مهم است؟

فهرست نماها مهم هستند زیرا احتمال اشتباه را کاهش می‌دهند، در زمان فیلمبرداری صرفه‌جویی می‌کنند، ارتباطات سر صحنه را بهبود می‌بخشند و در طول فیلمبرداری از بودجه تولید محافظت می‌کنند.

## بعدی

### نحوه تهیه لیست عکس در StudioBinder

شما می‌دانید که فهرست عکس چیست، هدف از تهیه آن چیست و اهمیت آن چیست، بنابراین اکنون زمان آن رسیده است که یکی برای خودتان تهیه کنید. پست بعدی ما به جزئیات هر یک از ملاحظات و نحوه استفاده کارآمد از این فهرست در الگوی ما می‌پردازد.

##### بعدی: چگونه یک فهرست عکس تهیه کنیم →

![آیکون راهکار - فهرست نماها و استوری‌بورد]()

آیکون راهکار - فهرست نماها و استوری‌بورد

## دیدگاه خود را با فهرست‌های نما و استوری‌بوردهای زیبا به اشتراک بگذارید.

لیست‌های شات قوی و قابل تنظیم ایجاد کنید. تصاویر را برای ساخت استوری‌بورد و اسلایدشو آپلود کنید.

[یادگیری زبان انگلیسی ➜](https://www.studiobinder.com/shot-list-storyboard/)

![دکمه پخش بنفش]()

دکمه پخش بنفش