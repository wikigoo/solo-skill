---
title: "StudioBinder App : Film & TV Production Management Software & Call Sheet Templates"
source: "https://app.studiobinder.com/company/580e85847e7982164664e844/collab/6667eacb67bc7d39d85bda22/projects/6654fcef2dac248bf8851dc5/shots/689e70d10115b6c2e73d7b0b?utm_source=blog&utm_medium=sb-app-link&utm_campaign=shot-list&utm_content=asteroid-city&utm_term=what-is-shot-list"
---
> [!warning] Warning
> [Get Started Free](https://app.studiobinder.com/register)

1. All Shot Lists
	14
	1. Sc. 1 | EXT. SPACE
		6
		2. Sc. 2 | INT. BRIDGE - DAY
		8
		3. Sc. 3 | EXT. PLANET SURFACE - ALIEN BAZAAR - DAY
		0
		4. Sc. 4 | INT. ENGINEERING BAY - DAY
		0
		5. Sc. 5 | EXT. SPACEPORT DOCK - NIGHT
		0
		6. Sc. 6 | INT. CREW QUARTERS - NIGHT
		0
		7. Sc. 7 | EXT. PLANET SURFACE - RIDGE OUTLOOK - SUNSET
		0
		8. Sc. 8 | INT. DOCKING BAY - MAINTENANCE LEVEL - DAY
		0
		9. Sc. 9 | EXT. PLANET SURFACE - CRASH SITE - NIGHT
		0
		10. Sc. 10 | INT. MEDICAL BAY - DAY
		0
		11. Sc. 11 | EXT. DESERT WASTELAND - DAY
		0
		12. Sc. 12 | INT. SHUTTLE COCKPIT - NIGHT
		0
		13. Sc. 13 | EXT. ASTEROID FIELD - DEEP SPACE - NIGHT
		0
		14. Sc. 14 | INT. BRIEFING ROOM - DAY
		0
		15. Sc. 15 | EXT. MOUNTAIN PASS - DUSK
		0
		16. Sc. 16 | INT. ALIEN CANTINA - NIGHT
		0
		17. Sc. 17 | EXT. JUNGLE CLEARING - DAY
		0
		18. Sc. 18 | INT. LABORATORY - NIGHT
		0
		19. Sc. 19 | EXT. UNDERWATER RESEARCH STATION - DAY
		0
		20. Sc. 20 | INT. CONTROL ROOM - NIGHT
		0
		21. Sc. 21 | EXT. ORBIT ABOVE NEBULA - DAY
		0
		22. Sc. 22 | INT. ARMORY - DAY
		0
		23. Sc. 23 | EXT. CITY SKYLINE - NIGHT
		0

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/shots/sb6666baae9358addb1ccf1c92.png&w=200)

1

1

–

The Aurora and The Horizon approach.

EWS

Deep Focus

Pan

Sticks

Wide Angle

59.94 fps

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/shots/sb6666bae59358addb1ccf1cab.png&w=200)

1

2

–

The bustling activity inside the Aurora is visible.

EWS

Deep Focus

Static

Sticks

Wide Angle

120 fps

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/shots/sb6666bb059358addb1ccf1cb7.png&w=200)

1

3

–

The spacecraft hovers above the surface of Xandor.

WS

Deep Focus / HA

Static

Sticks

Wide Angle

59.94 fps

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/storyboards/sb68f4351a39fb205808260f0d.png&w=200)

1

4

–

A city rises from the planet's surface.

WS

Deep Focus / HA

Static

Sticks

Wide Angle

120 fps

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/storyboards/sb68f0327e055ad490ce98d0be.png&w=200)

1

5

–

COMMANDER ELENA, readies the crew for landing.

MS

Shoulder Level / Single / Shallow Focus

Pan

Gimbal

Normal

59.94 fps

![](https://imgs.studiobinder.com/580e85847e7982164664e844/resize-image?f=580e85847e7982164664e844/shots/sb6666bb2a9358addb1ccf1cd2.png&w=200)

1

6

–

Crew members look on in awe.

MCU

2-Shot / Eye Level / Deep Focus

Tracking

Sticks

Normal

59.94 fps