---
title: "Technical breakdown"
source: "https://www.cinecreatis.net/en/glossary/technical-breakdown/"
---
In the world of cinema, films are made using very specific technical skills. The basic script is, of course, the most important, but another technical document is also part of the success of a short film: the technical cut.

So what is its main function? This indispensable file details every aspect of every sequence in the film in the form of a table. Thanks to it, the producers know all the parameters involved in reproducing each shot to perfection for filming. As a result, the technical breakdown is by far the most important document in the final writing of a film.

## Technical breakdown: its characteristics

### The format used

![Tableau Decoupage Technique](https://www.cinecreatis.net/app/uploads/2020/07/tableau-decoupage-technique.jpg)

Technical cutting table (source Olivier FAZILLEAU)

The technical breakdown is a very specific stage in itself. The authors of this technical script (often the directors themselves) have several choices available to them for creating it, although one format takes precedence over the others. To fill in a blank technical breakdown, a text can be created for the occasion but, thanks to various experiments, this is not clear and concise enough to highlight the main information.

The paper format is entirely recommendable for making a technical breakdown of a film. **It is wiser to opt for a simple table with columns**, which will be much clearer overall. The same table can be drawn up digitally on the computer or on a large sheet of paper.

### Who makes the technical cut of a film?

The technical cut of a film is often designed by a single person. Generally, this is the director himself, who takes the initiative of creating it in order to have an overview of the shots and therefore the scenes to be shot on the set: a representation of the script in images. It’s a real piece of upstream work that guarantees the best cinematographic staging of a short film.

A technical cut for the cinema is therefore essential if the film is to be the perfect final product. This means that producers can plan for the corresponding costs and organise all the associated tasks correctly.

### Essential data

[While the storyboard](https://www.cinecreatis.net/en/glossary/storyboard/) is a representation of the screenplay in images/drawings, the technical layout of a film always meets very specific criteria. It is important to remember that two documents may be completely different, with different column names, but in the end the remaining information is always the same.

The technical breakdown provides the film crews and the producer with information on the following points:

- The reference of the sequence concerned.
- Description of the action.
- The shot number chosen.
- Duration of the sequence.
- Camera qualification.
- And the connections that will be made in the final edit.

All this essential information from the blank technical breakdown can sometimes be illustrated with storyboards to clarify certain more complex camera shots, for example.

## Technical breakdown for cinema: describe a sequence shot

### Focus on action

First of all, **a technical breakdown is a description of several sequences**. Each sequence must therefore be perfectly described in it. The main detail should concern the action that is at the very heart of the sequence. Everything must be described so that it can be visualised and carried out later.

So, in the technical breakdown of a film, the action must be described in a single sentence that acts as a summary. The location and the actors involved are also indicated. The location can be either indoors or outdoors. You also need to know what time of day the action takes place (morning or evening).

The description of the atmosphere is also important to help you project the scene. A sequence is always made up of several shots.

### Technical camera breakdown: detail the camera lenses

These shots are then directly linked to the camera. The camera has several functions. It is therefore essential that the sequence shot describes its particular features in relation to the action. Here, all the camera shots that will be seen on screen must be written down on paper.

The camera can be subjective, take a close-up, a close-up, a fixed shot or moving.

The technical breakdown of a film will show whether the sequence shot will be a low angle, zoom or American shot. Other specific features can be indicated, such as tracking shots or vertical pano shots, the position of the characters and the opening and closing of the shots.

The technical breakdown of a sequence shot therefore defines all the shots and framing involved. Sometimes, the director’s intentions will also be highlighted. This may be, for example, to show that a particular action is the trigger…

### Focus on duration and the main joins

Finally, when describing a sequence shot in a technical film breakdown, the time must be defined. On average, a sequence lasts from a few seconds to a few minutes maximum.

Connections should also be clearly specified:

- The type of lighting chosen. It can be subdued or darker if the action takes place at the end of the day, for example.
- Existing sounds and sound effects. An action may be accompanied by music or, on the contrary, by silence. The sound effects added will be the sound of footsteps, a door opening or the sound of a bell…

Thanks to all these details, the sequence shot will be well defined as a whole.

In conclusion, technical cutting is a methodical script that has its place in the meticulous preparation of a film, right through to editing. Between the various choices available during the making of a short or feature film, the technical document allows you to put down your markers definitively so that, afterwards, you can shoot a quality film without any hitches or hesitations. Its aim is to record everything so that all the producer has to do is stage it as realistically as possible. The technical document is therefore the final stage [in the film script](https://www.cinecreatis.net/en/glossary/scenario/). The technical breakdown in cinema is a real springboard for ensuring that the final result of the film is close to perfection.