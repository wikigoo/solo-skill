# YouTube  Script Structure — Master Template

## Project Overview

**Working Title:** [Title of the video essay]

**Format:** Analytical and critical video essay

**Suggested Duration:** [Target duration]

**Central Question:** [The main question the video seeks to answer]

**Central Argument:** [The central thesis the video will develop and support with evidence]

---

## Section 1 (00:00)

### Hook — [A Compelling Opening Question, Statement, or Contradiction]

**Purpose:**  
Capture the audience's attention by introducing a striking fact, contradiction, mystery, consequence, or unresolved question that establishes the central tension of the video.

**Argument:**  
[State the initial claim, paradox, or concern that makes the subject worth investigating. Introduce the central problem without presenting the entire argument or conclusion.]

**Topics:**

- A striking fact, event, example, or contradiction related to the subject.
    
- The central tension, mystery, or unresolved problem.
    
- The immediate human, social, historical, political, cultural, scientific, or ethical stakes.
    
- A surprising detail that challenges conventional assumptions.
    
- The main question the video will investigate.
    
- The reason the subject deserves closer examination.
    

---

## Section 2 (00:30)

### Introduction — [The Subject, Context, and Central Argument]

**Purpose:**  
Establish the subject, define the scope of the investigation, explain why it matters, and introduce the central question and argument.

**Argument:**  
[Present the main thesis in a concise, defensible statement. Explain the fundamental problem, contradiction, or risk the video will examine.]

**Topics:**

- Introduction to the subject and the specific aspect being investigated.
    
- Essential background information needed to understand the issue.
    
- Why the subject matters and what is at stake.
    
- The central question the video seeks to answer.
    
- The main argument or analytical perspective.
    
- Important definitions and distinctions needed to understand the subject.
    
- The principal dimensions of the problem that will be examined.
    
- The scope and limitations of the investigation.
    
- The primary sources, reports, studies, events, or evidence informing the analysis.
    
- A brief preview of the video's analytical progression.
    

---

## Section 3 (01:30)

### Background and Context — [How the Subject Works and Why the Problem Exists]

**Purpose:**  
Provide the historical, conceptual, technical, social, or institutional context necessary to understand the subject and the central problem.

**Argument:**  
[Explain the underlying conditions, mechanisms, or relationships that make the problem possible and establish the foundation for the subsequent analysis.]

**Topics:**

- The origins and development of the subject.
    
- The relevant historical, political, social, cultural, scientific, technical, or institutional context.
    
- The key individuals, organizations, systems, or institutions involved.
    
- The principal concepts, components, mechanisms, or processes.
    
- How the subject operates in practice.
    
- The relationship between different actors, systems, or contributing factors.
    
- The prevailing assumptions, incentives, objectives, or constraints.
    
- The difference between how the subject is intended to work and how it works in reality.
    
- Essential facts, terminology, and distinctions needed to understand the analysis.
    
- The initial conditions that make the central problem possible.
    

---

## Section 4 (03:00)

### First Major Problem — [The First Critical Finding, Failure, or Contradiction]

**Purpose:**  
Examine the first major dimension of the central argument and explain why it matters through evidence, causal analysis, and concrete examples.

**Argument:**  
[State the first major claim. Explain the problem, failure, risk, or contradiction and identify the mechanisms that produce or intensify it.]

**Topics:**

- The first major problem, failure, risk, or contradiction.
    
- The circumstances under which the problem emerges.
    
- The mechanisms and contributing factors behind the problem.
    
- The individuals, institutions, processes, or systems involved.
    
- The gap between intended outcomes and actual or documented outcomes.
    
- The relevant evidence demonstrating the existence and significance of the problem.
    
- A case study or concrete example illustrating the issue.
    
- The consequences for individuals, communities, institutions, or the wider system.
    
- Alternative explanations, counterarguments, or limitations in the available evidence.
    
- The implications of this finding for the central argument.
    

---

## Section 5 (05:00)

### Second Major Problem — [A Distinct Risk, Failure, or Consequence]

**Purpose:**  
Investigate a second major dimension of the problem and demonstrate how it operates in practice, produces consequences, or becomes more serious under particular conditions.

**Argument:**  
[State the second major claim. Explain how this problem differs from the first while contributing to the overall thesis.]

**Topics:**

- The second major risk, failure, contradiction, or consequence.
    
- The conditions that cause or amplify the problem.
    
- The mechanisms through which the problem develops.
    
- The role of scale, speed, complexity, institutional pressure, incentives, or other relevant factors.
    
- The relationship between intended benefits and observed or documented consequences.
    
- The practical effects on the people, organizations, or systems involved.
    
- A relevant case study, documented event, or investigative finding.
    
- The evidence supporting the analysis and any significant disagreements between sources.
    
- Alternative explanations and unresolved questions.
    
- The connection between this problem and the preceding section.
    
- The implications for the central argument.
    

---

## Section 6 (07:30)

### Third Major Problem — [A Deeper Mechanism, Human Consequence, or Systemic Contradiction]

**Purpose:**  
Move beyond describing the problem to examine its deeper mechanisms, human consequences, underlying assumptions, or institutional dynamics.

**Argument:**  
[Present a deeper analytical claim that explains why the problem persists, why existing safeguards may fail, or how the issue is more complex than it initially appears.]

**Topics:**

- The third major dimension of the central problem.
    
- The underlying mechanisms, incentives, assumptions, or structural conditions sustaining it.
    
- The role of human judgment, behavior, decision-making, or institutional pressure, where relevant.
    
- The gap between formal procedures and their practical implementation.
    
- The difference between nominal safeguards and safeguards that work effectively.
    
- Contradictions between stated principles and actual practices.
    
- A detailed case study or close examination of a revealing example.
    
- The documented human, institutional, or societal consequences.
    
- The distinction between established facts, reported claims, disputed interpretations, and uncertainties.
    
- Alternative perspectives and counterevidence.
    
- The deeper insight this analysis contributes to the overall thesis.
    

---

## Section 7 (10:00)

### Broader Implications — [Human Impact, Social Consequences, and Accountability]

**Purpose:**  
Connect the specific problems examined in the preceding sections to their wider human, social, political, cultural, ethical, legal, economic, or institutional implications.

**Argument:**  
[Explain why the issue matters beyond individual examples. Identify the wider consequences, the distribution of risks and responsibilities, and the questions of accountability or public interest raised by the analysis.]

**Topics:**

- The immediate and long-term consequences of the problem.
    
- The effects on individuals, communities, institutions, or society.
    
- The distribution of benefits, risks, costs, and responsibilities.
    
- The people or groups most affected, where relevant.
    
- The relationship between the problem and broader structural conditions.
    
- The implications for rights, fairness, public trust, institutional legitimacy, or social well-being.
    
- The distinction between individual responsibility and systemic responsibility.
    
- The roles of governments, organizations, companies, professionals, or other relevant actors.
    
- Obstacles to transparency, independent scrutiny, accountability, or effective remedies.
    
- Unintended consequences and potential long-term effects.
    
- Relevant competing perspectives and alternative interpretations.
    
- The broader significance of the findings for contemporary society or future developments.
    

---

## Section 8 (11:30)

### Conclusion — [Synthesis, Implications, and the Central Takeaway]

**Purpose:**  
Bring the analysis together, answer the central question as far as the evidence allows, and identify the most important implications of the findings.

**Argument:**  
[State the final conclusion that emerges from the investigation. Refine the initial thesis in light of the evidence rather than simply repeating the opening claim.]

**Topics:**

- Return to the central question introduced at the beginning.
    
- Summarize the most important findings from the analytical sections.
    
- Explain how the different problems, mechanisms, and case studies connect.
    
- Identify the strongest conclusion supported by the evidence.
    
- Revisit the central contradiction or paradox in light of the analysis.
    
- Explain what the investigation reveals that may not have been obvious at the outset.
    
- Distinguish established findings from interpretations and unresolved questions.
    
- Identify the principal implications for the people, institutions, or systems involved.
    
- Present relevant safeguards, reforms, responses, or alternative approaches, where appropriate.
    
- Address the limitations of possible solutions and questions requiring further investigation.
    
- End with a memorable insight that captures the significance of the argument.
    

---

## Section 9 (Final 10–20 seconds)

### Call to Action — [A Question or Invitation That Extends the Discussion]

**Purpose:**  
Encourage meaningful engagement with the subject and give viewers a natural next step for further exploration.

**Argument:**  
[Identify the unresolved question, broader implication, or practical consideration that makes continued discussion valuable.]

**Topics:**

- A specific question inviting viewers to respond to the central argument.
    
- An invitation to discuss a relevant disagreement, uncertainty, or alternative interpretation.
    
- A question about the broader implications of the findings.
    
- An invitation to consult the primary sources or evidence discussed.
    
- A recommendation for a related video or the next installment.
    
- A brief request to subscribe or follow the series, if appropriate.
    

---
