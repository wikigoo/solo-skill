
## Encyclopedias
https://www.wikipedia.org/
https://www.britannica.com/
https://www.encyclopedia.com/

## Official
https://www.icrc.org/en
https://www.un.org/en/
https://www.state.gov/
https://www.hrw.org/

## Article 
https://scholar.google.com/
https://www.researchgate.net/
https://www.jstor.org/

## News Agencies
https://apnews.com/
https://www.bbc.com/
https://www.nytimes.com/
https://www.theguardian.com/
https://www.washingtonpost.com/
https://www.dropsitenews.com/

## Magazine
https://www.ted.com/
https://ed.ted.com/
https://wire.com/en/
https://bigthink.com/
https://www.scientificamerican.com/

## History
https://ahf.nuclearmuseum.org/ahf/nuc-history/
https://www.worldhistory.org/

## Fact
https://www.factretriever.com/
https://kids.kiddle.co/
## war
https://autonomousweaponswatch.org/
https://www.militarytimes.com/
https://www.army.edu/
https://mwi.westpoint.edu/mwi-research/
https://www.war.gov/