- ### The Nazis Kidnapped Children To “Germanize” Them
    
    They thought that some Polish babies and children looked German and kidnapped about 50,000 of them.[10]