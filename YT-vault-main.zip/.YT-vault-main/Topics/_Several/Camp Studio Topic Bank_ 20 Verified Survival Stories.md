# Camp Studio Topic Bank: 20 Verified Survival Stories

This is a 20-topic bank of true, verifiable crisis stories. It is not the full 50 requested: the other 30 could not be checked against acceptable English-language sources in this research pass, so under your own rules they are left out rather than padded.

## TL;DR
- 20 topics are ready for production. Each has a verified source, a clear arc and a lesson an Iranian viewer can use. Nine are Iranian stories: Polish refugees, Sardari, the methanol rumour, Manjil, Plasco, the 2019 floods, Tabas, the 1918 influenza and the 1917–19 famine.
- The strongest picks are the Choctaw gift, Isfahan's Polish children, the Chilean miners, the methanol rumour and the 2019 tractor ambulances. They are hopeful, well documented and close to what Iranians face today.
- The bank does not yet meet the distribution targets. Pillars 7 (speeches) and 8 (rebuilding) have no topics, Africa is not covered, and several pillars have fewer than five. The Caveats section lists the next candidates to verify.

### 1. The Mayor Who Sold His Horse to Plant Potatoes
**Pillar:** 1. Livelihood in economic crisis | **Time & place:** 1893–1897, Detroit, USA

When the Panic of 1893 emptied Detroit's poor fund, Mayor Hazen S. Pingree proposed turning vacant city lots into vegetable gardens for jobless families. Pingree was a Civil War veteran and shoe manufacturer.\[1\] Newspapers mocked him, and the city's churches donated about $13.\[2\] Undeterred, Pingree sold his prize horse to buy tools and seed, and his "Potato Patch" plan opened some 430 acres to poor, mostly immigrant households.\[2\]\[3\] Cities from New York to Seattle copied it.\[2\] Period photographs show Polish families walking to their plots, and thousands of ordinary donors later paid for his statue.\[4\]\[5\] Lesson: idle local resources plus organised self-help can soften a recession.

**Sources:**
- [Pingree, Hazen S. – Encyclopedia of Detroit, Detroit Historical Society](https://www.detroithistorical.org/learn/online-research/encyclopedia-of-detroit/pingree-hazen-s)
- [Hazen Pingree: Quite possibly Detroit's finest mayor – The Detroit News](https://www.detroitnews.com/story/news/local/michigan-history/2020/02/08/hazen-pingree-quite-possibly-detroits-finest-mayor/4686854002/)

---

### 2. Havana's Gardens of Necessity
**Pillar:** 1. Livelihood in economic crisis | **Time & place:** 1990–2001, Havana, Cuba

When the Soviet Union collapsed, Cuba lost the imports, fuel and fertiliser its food system relied on. Researchers note that the average Cuban diet lost about 30% of its calories during the "Special Period."\[6\] Residents, and later the state, turned vacant lots and old construction sites into intensive organic gardens called organopónicos.\[6\] A Yale field study of 21 sites describes about 35,000 hectares converted in Havana and reports that food security in the capital was largely restored by 2001.\[7\] There is plenty of footage of oxen ploughing city plots.\[8\] Lesson: when imports collapse, neighbourhood food production buys resilience. Frame it as community ingenuity, not as praise for any government.

**Sources:**
- [Crisis of urban agriculture: Case studies in Cuba – Yale Tropical Resources Institute](https://tri.yale.edu/tropical-resources/tropical-resources-vol-36/crisis-urban-agriculture-case-studies-cuba)
- [Tess McNamara: Urban Agricultural Trends in Havana, Cuba – Yale Tropical Resources Institute](https://tri.yale.edu/news/tess-mcnamara-urban-agricultural-trends-havana-cuba)

---

### 3. When Cash Vanished, Neighbours Traded Trust
**Pillar:** 1. Livelihood in economic crisis | **Time & place:** 2001–2009, Buenos Aires region, Argentina

Argentina's 2001 economic meltdown froze bank accounts, wiped out jobs and drained cash from daily life. Barter clubs (clubes de trueque) exploded in response. Club officials told CNN that more than two million people took part regularly during 2002, trading food, clothes and services for club credits. Co-founder Rubén Ravera's golden rule was "an honest product for an honest price." The story has a second act years later: when the 2008–09 global crisis hit, organisers said the clubs were busier than ever. Sixty-six-year-old Deolindo Farias described bringing bananas every week to trade for flour and sugar.\[9\] Lesson: informal exchange can carry families through hard times, as long as honesty is the currency.

**Sources:**
- [Barter clubs expose Argentina's weakness – CNN](https://edition.cnn.com/2009/WORLD/americas/05/20/argentina.barter/index.html)

---

### 4. The Potato Revolution of Katerini
**Pillar:** 1. Livelihood in economic crisis | **Time & place:** 2012, Katerini and Thessaloniki, Greece

At the depth of Greece's debt crisis, farmers from Nevrokopi gave away more than ten tons of unsold potatoes in Thessaloniki on 5 February 2012.\[10\] Volunteers in Katerini then linked growers directly with households. They were led by Ilias Tsolakidis's Pieria Voluntary Action Group. According to New Internationalist, 24 tonnes were ordered online in less than a day at 25 cents a kilo, a third of supermarket prices.\[11\] Professor Christos Kamenidis organised sales at Aristotle University, and the "no middlemen" model spread to Athens.\[10\] AP photographs show queues and trucks full of sacks.\[12\] Lesson: cutting out middlemen can ease food inflation and keep farmers in business.

**Sources:**
- [Greece's 'potato movement' grows in power – Al Jazeera](https://www.aljazeera.com/features/2012/6/11/greeces-potato-movement-grows-in-power)
- [Greece: what the potato movement did next – New Internationalist](https://newint.org/features/2013/01/01/greece-potato-movement)

---

### 5. The Famine Without Heroes
**Pillar:** 9. Iranian experiences of surviving crises | **Time & place:** 1917–1919, Iran

During the First World War, neutral Iran was occupied by foreign armies, while drought, failed harvests, hoarding and requisitioning emptied the granaries.\[13\] On 19 April 1917 the chronicler Ain-ol-Saltaneh wrote that "famine and hunger prevail in all parts of Iran."\[14\] Death estimates vary widely.\[15\] A 2023 study in Third World Quarterly argues the catastrophe has been largely forgotten because it "lacks heroes."\[14\] A documentary could fill that gap by searching diaries, newspapers and memoirs for ordinary families and neighbours who shared what little they had. Lesson: remembering past scarcity helps guard against speculation and hoarding. Tell it without partisan blame.

**Sources:**
- [Imperial wars and the violence of hunger: remembering and forgetting the Great Persian Famine 1917–1919 – Third World Quarterly (Taylor & Francis)](https://www.tandfonline.com/doi/abs/10.1080/01436597.2023.2221183)

---

### 6. Sixty-Nine Days Under the Desert
**Pillar:** 2. Psychological resilience under prolonged stress | **Time & place:** August–October 2010, San José mine, Atacama, Chile

On 5 August 2010 a mine collapse trapped 33 men about 2,200 feet (670 metres) underground.\[16\] For 17 days nobody knew they were alive.\[17\] They stretched emergency rations meant for two days by eating only once every other day.\[16\] Once a drill broke through, psychologists helped the men keep routines, roles and morale while engineers built the Fénix capsule. They included Chile's Alberto Iturra and NASA's Albert Holland.\[18\] On 13 October all 33 were brought to the surface as the world watched.\[19\] There is plenty of live TV footage, and Héctor Tobar's book "Deep Down Dark" adds the inside story.\[20\] Lesson: structure, shared rules and small hopes carry people through long, uncertain waits.

**Sources:**
- [Chile mine rescue of 2010 – Britannica](https://www.britannica.com/event/Chile-mine-rescue-of-2010)
- [33 Chilean Miners Were Buried Alive. These Are the Tactics That Kept Them Sane – National Geographic](https://www.nationalgeographic.com/history/article/chilean-miners-rescue-psychological-strategy)
- [The Chilean Miner Rescue: NASA's Experience – NASA Goddard Scientific Colloquium](https://scicolloq.gsfc.nasa.gov/Duncan.html)

---

### 7. Anna Freud's Wartime Nurseries
**Pillar:** 2. Psychological resilience under war | **Time & place:** 1941–1945, Hampstead (London) and Essex, UK

As bombs fell on London, Anna Freud and Dorothy Burlingham opened three wartime nurseries in 1941, two in Hampstead and one in Essex. They took in children who had lost their homes or parents, or who spent every night in air-raid shelters. The founders noticed something surprising: the breakdown of family life hurt children more than the war itself. So they encouraged regular visits from mothers and kept siblings together.\[21\] Over the war they cared for 191 children and kept careful observation notes that later shaped child psychology.\[21\] Lesson: in a household frightened of war, a child's sense of safety depends less on the news than on staying close to trusted adults.

**Sources:**
- [Anna Freud – Sigmund Freud Museum, Vienna](https://www.freud-museum.at/en/details-anna)

---

### 8. The Rumour That Poisoned a Nation
**Pillar:** 3. Rumor and misinformation | **Time & place:** February–April 2020, Iran

In the first weeks of COVID-19, a rumour spread online that drinking alcohol could kill the virus.\[22\] In a country where bootleg liquor is often contaminated with toxic methanol, the result was a second epidemic.\[23\] A peer-reviewed study on PubMed Central records that between 7 March and 8 April 2020 every Iranian province reported methanol poisoning, and 471 deaths were directly linked to illicit alcohol.\[24\] Health ministry adviser Hossein Hassanian later told AP that more than 700 had died.\[25\] AP also reported a five-year-old boy left blind after his parents gave him methanol.\[26\] Lesson: when you are afraid, check health claims with doctors before sharing them, because a rumour can kill faster than the threat it claims to cure.

**Sources:**
- [Methanol poisoning outbreak in Iran during the COVID-19 pandemic – PubMed Central](https://pmc.ncbi.nlm.nih.gov/articles/PMC7368655)
- [In Iran, false belief a poison fights virus kills hundreds – AP via The Spokesman-Review](https://www.spokesman.com/stories/2020/mar/27/in-iran-false-belief-a-poison-fights-virus-kills-h/)

---

### 9. Letters by Balloon, Replies by Pigeon
**Pillar:** 3. Media and trusted communication | **Time & place:** September 1870–January 1871, Paris, France

When Prussian armies surrounded Paris in September 1870, the capital was cut off from the rest of France.\[27\] Within days the postal service began launching coal-gas balloons to carry mail out over enemy lines. According to the Smithsonian's National Postal Museum, 67 balloons went up during the siege, 55 of them authorised to carry mail, and most also carried homing pigeons.\[28\] Messages coming back into Paris were shrunk onto microfilm, tied to the pigeons, then projected and transcribed.\[29\] The Smithsonian still holds an original pigeon-post microfilm.\[30\] Surviving "ballon monté" letters and engravings make strong visuals.\[29\] Lesson: when normal channels break down, creative and reliable communication keeps a besieged society connected.

**Sources:**
- [Siege of Paris Mail – Smithsonian National Postal Museum](https://postalmuseum.si.edu/exhibition/international-philately-europe-western-europe-france/siege-of-paris-mail)
- [Pigeon post microfilm – Smithsonian National Postal Museum](https://postalmuseum.si.edu/object/npm_0.260305.10.36.3)

---

### 10. The Archive in the Milk Cans
**Pillar:** 3. Truth against propaganda | **Time & place:** 1939–1950, Warsaw, Poland

From October 1939 the historian Emanuel Ringelblum kept a chronicle of Jewish life under German occupation. After the ghetto was sealed in November 1940, the chronicle grew into a secret organisation called Oneg Shabbat, named for its Sabbath meetings. Dozens of contributors, including Hersh Wasser and Rabbi Shimon Huberband, gathered diaries, posters, reports and children's essays through soup kitchens and house committees.\[31\] They wanted an honest record of what daily life was really like. The archive was buried in three parts, and two were recovered after the war.\[31\] The surviving documents are powerful on screen. Lesson: keeping honest records is itself a way of resisting misinformation.

**Sources:**
- [The Oneg Shabbat Archive – USHMM Holocaust Encyclopedia](https://encyclopedia.ushmm.org/content/en/article/the-oneg-shabbat-archive)

---

### 11. The Secret Library of Daraya
**Pillar:** 4. Daily life and creativity under siege | **Time & place:** 2012–2016, Daraya, Syria

During the long siege of Daraya, a suburb of Damascus, young residents rescued books from abandoned and bombed homes. They hid them in a basement library five or six feet below streets exposed to snipers and shelling. Co-founder Anas Ahmad said it was "vital to create a library in order to continue our education." Volunteers built shelves from scavenged wood and made reading a lifeline in the middle of hunger and fear.\[32\] The BBC's Mike Thomson documented the story in his book "Syria's Secret Library," and photographs from inside survive.\[32\]\[33\] In 2016 the BBC's Mike Thomson reported that the volunteers had collected more than 14,000 books. Lesson: learning and imagination keep young people's futures alive. Tell it without taking sides in the war.

**Sources:**
- [Inside A Secret Library In Syria – NPR 1A](https://www.npr.org/2020/05/08/853192520/inside-a-secret-library-in-syria)
- [How a group of Syrian residents assembled a secret library – PBS NewsHour](https://www.pbs.org/newshour/show/how-a-group-of-syrian-residents-assembled-a-secret-library)

---

### 12. The Choctaw Gift
**Pillar:** 5. Social solidarity | **Time & place:** 1847–2018, Indian Territory (Oklahoma, USA) and Ireland

Just over a decade after their forced removal along the Trail of Tears, Choctaw people in Indian Territory heard about the famine devastating Ireland. On 23 March 1847 leaders and others met and collected $170 "for the relief of the starving poor in Ireland." The money went through the Memphis Irish Relief Committee to New York.\[34\] Ireland never forgot. In 1992 Irish walkers retraced the Trail of Tears and raised $170,000 for famine-stricken Somalia.\[34\] In 2018 Taoiseach Leo Varadkar thanked Chief Gary Batton in Oklahoma and announced scholarships for Choctaw students.\[35\]\[36\] Sculptures and ceremonies provide visuals.\[37\] Lesson: people who have suffered are often the first to help others.

**Sources:**
- [The Choctaw Nation's Gift to the Irish – Smithsonian Magazine](https://www.smithsonianmag.com/blogs/national-museum-american-indian/2018/03/16/choctaw-nations-gift-irish/)
- [Choctaw generosity to Famine Ireland saluted by Varadkar – The Irish Times](https://www.irishtimes.com/news/ireland/irish-news/choctaw-generosity-to-famine-ireland-saluted-by-varadkar-1.3424542)

---

### 13. Isfahan, City of Polish Children
**Pillar:** 5. Social solidarity (Iranian case) | **Time & place:** 1942–1945, Bandar Anzali, Tehran and Isfahan, Iran

In 1942, after deportation and starvation in Soviet camps, Polish soldiers and civilians crossed the Caspian to the port of Pahlevi, today Bandar Anzali. The port took in up to 2,500 refugees a day, and over 116,000 eventually reached Iran.\[38\] Many arrived gravely ill, and according to the USHMM several hundred, mostly children, died shortly after arriving from acute dysentery caused by overeating. The Iranian government helped them settle.\[39\] Isfahan took in so many orphans that it became known as the "City of Polish Children"; according to the Cosmopolitan Review, it became home to over 2,000 children housed in 17 residences. Some refugees stayed and married Iranians. Studio portraits, camp photographs and Polish cemeteries in Iran survive.\[40\]\[41\] Lesson: even a society under strain can make room for generosity.

**Sources:**
- [Polish Refugees in Iran during World War II – USHMM Holocaust Encyclopedia](https://encyclopedia.ushmm.org/content/en/article/polish-refugees-in-iran-during-world-war-ii)
- [Polish Refugees in Iran During World War II (PDF) – USHMM](https://www.ushmm.org/m/pdfs/Polish-Refugees-in-Iran-During-World-War-II.pdf)

---

### 14. The Consul Who Stayed in Paris
**Pillar:** 5. Solidarity and rescue (Iranian case) | **Time & place:** 1940–1944, Paris, France

When Germany occupied France, Iran's ambassador moved to Vichy and left consul Abdol Hossein Sardari in charge of Iranian affairs in Paris.\[42\] As anti-Jewish measures tightened, Sardari wrote to German officials in letters dated 29 September 1942 and 17 March 1943.\[42\] He argued that Iranian Jews ("Jugutis") should not be classed as racially Jewish, to protect them from arrest and deportation.\[43\] His nephew Fereydoun Hoveyda later said Sardari also issued around 1,500 passports, a figure no one has independently confirmed.\[42\] In 1978 Sardari told Yad Vashem simply that it had been "my duty to save all Iranians, including Iranian Jews."\[42\] Lesson: quiet professional courage saves lives.

**Sources:**
- [Abdol Hossein Sardari (1895–1981) – USHMM Holocaust Encyclopedia](https://encyclopedia.ushmm.org/content/en/article/abdol-hossein-sardari-1895-1981)
- [Abdol Hossein Sardari: An Iranian Hero of the Holocaust – USHMM](https://www.ushmm.org/antisemitism/holocaust-denial-and-distortion/holocaust-denial-antisemitism-iran/abdol-hossein-sardari-an-iranian-hero-of-the-holocaust)

---

### 15. Tractor Ambulances of the Nowruz Floods
**Pillar:** 6. Rescue and first response | **Time & place:** March–April 2019, Golestan, Lorestan and Khuzestan, Iran

Heavy rain began on 19 March 2019, in the middle of the Nowruz holidays, and flooded towns across Golestan before spreading to most of Iran's provinces.\[44\] With roads underwater, emergency medics in Golestan improvised "tractor ambulances" to reach stranded patients, as documented in Disaster Medicine and Public Health Preparedness.\[45\] The Iranian Red Crescent helped more than 156,000 people and sheltered over 50,000.\[44\] Strikingly, the UN's response plan noted that half of the humanitarian aid received came from people inside Iran.\[46\] There is plenty of footage and Red Crescent photography. Lesson: improvisation and citizen solidarity fill the gaps when infrastructure fails.

**Sources:**
- [Tractor Ambulance: An Initiative of Emergency Medical Services Response to the Flood of Golestan, Iran in 2019 – Cambridge University Press](https://www.cambridge.org/core/journals/disaster-medicine-and-public-health-preparedness/article/abs/tractor-ambulance-an-initiative-of-emergency-medical-services-response-to-the-flood-of-golestan-iran-in-2019/72FBB36A290803C0D714362F2185B50D)
- [Iran: Floods – Mar 2019 – ReliefWeb](https://reliefweb.int/disaster/fl-2019-000022-irn)
- [Iran Floods UN Response Plan, April 2019 (PDF) – United Nations Iran](https://iran.un.org/sites/default/files/2020-05/20190429-Iran_Floods_UN_Iran_Response_Plan.pdf)

---

### 16. The Morning Halifax Exploded
**Pillar:** 6. Composure and first response in disasters | **Time & place:** 6 December 1917, Halifax, Nova Scotia, Canada

On the morning of 6 December 1917, the French munitions ship Mont-Blanc, carrying 2,925 metric tons of explosives according to Britannica, collided with the Norwegian steamer Imo in Halifax Harbour and caught fire. Crowds gathered to watch the smoke. Minutes later the ship exploded and flattened more than a square mile of the city. Nearly 2,000 people died and about 9,000 were injured, overwhelming hospitals and morgues. Aid poured in from across Canada and the United States, and the disaster led to stricter rules on cargo identification and harbour traffic. Photographs and a memorial bell tower survive. Lesson: in an emergency, move away from danger, not towards the spectacle.

**Sources:**
- [Halifax explosion – Britannica](https://www.britannica.com/event/Halifax-explosion)

---

### 17. After the Shaking Stops: Manjil–Rudbar
**Pillar:** 6. Rescue and first response (Iranian case) | **Time & place:** June 1990, Gilan and Zanjan provinces, Iran

Just after midnight on 21 June 1990, a massive earthquake struck the Rudbar–Manjil area of northern Iran.\[47\] UN disaster reports estimated that about 90 percent of buildings collapsed in Manjil, 70 percent in Rudbar and 60 percent in Loushan. Landslides cut the roads, so relief had to come by air. Strong local winds tore at tents, forcing planners to look for wind-resistant shelter. The Iranian Red Crescent, UNICEF, WFP and WHO assessed the zone together.\[48\] A later study of orphaned child survivors found that support was often "transient" and faded once the houses were rebuilt.\[47\] Lesson: rescue ends quickly, but care for survivors has to last for years.

**Sources:**
- [Iran Earthquake Jun 1990 UNDRO Situation Reports 1–14 – ReliefWeb](https://reliefweb.int/report/iran-islamic-republic/iran-earthquake-jun-1990-undro-situation-reports-1-14)
- [The Life Process of Children Who Survived the Manjil Earthquake – PLOS Currents Disasters](https://currents.plos.org/disasters/article/the-life-process-of-children-who-survived-the-manjil-earthquake-a-decaying-or-renewing-process/)

---

### 18. The Firefighters of Plasco
**Pillar:** 6. Rescue and first response (Iranian case) | **Time & place:** 19 January 2017, Tehran, Iran

The Plasco building, completed in the early 1960s, was one of Tehran's first high-rises and housed a shopping centre and garment workshops.\[49\]\[50\] On the morning of 19 January 2017, fire spread through its upper floors.\[51\] According to an engineering study in ScienceDirect, the fire was reported at 7:58 a.m. and the building collapsed at 11:33 a.m.; in between, firefighters fought the blaze and tried to stop people from going back in for their goods. Then, live on state television, the tower collapsed.\[51\] Officials said they had repeatedly warned tenants about blocked stairwells and missing extinguishers.\[49\]\[51\] Early reports said dozens of firefighters had died, but Iran's parliamentary investigative commission later put the toll at 26 people, including 16 firefighters, and blamed "unauthorized and non-standard wiring." Hundreds of Tehranis queued to give blood.\[49\] Lesson: take safety warnings seriously, and honour first responders.

**Sources:**
- [Iran shocked by deadly fire, collapse of Tehran high-rise – AP via The Spokesman-Review](https://www.spokesman.com/stories/2017/jan/19/iran-shocked-by-deadly-fire-collapse-of-tehran-hig/)
- [Tehran fire: 20 dead in Plasco building collapse – Al Jazeera](https://www.aljazeera.com/news/2017/1/19/tehran-fire-20-dead-in-plasco-building-collapse)

---

### 19. The Oasis That Fell Silent: Tabas
**Pillar:** 9. Iranian experiences of surviving crises | **Time & place:** September 1978, Tabas, eastern Iran

On the evening of 16 September 1978, a magnitude 7.4 earthquake destroyed the desert oasis town of Tabas in eastern Iran.\[52\]\[53\]\[54\] According to Encyclopaedia Iranica, about 11,000 of the town's 13,000 inhabitants died, and total deaths across some 90 devastated villages passed 20,000.\[55\] The quake also broke 30 qanats, the ancient underground channels that kept the oasis alive.\[56\]\[57\] A documentary can explore how survivors carried on, how the town was rebuilt, and how Tabas remembers its loss. Seismological field reports, aerial photographs and survivors' memories remain.\[54\]\[56\] Lesson: a community can rebuild from water, kinship and patience, even after losing almost everything.

**Sources:**
- [Earthquakes iv. The Historical Record of Earthquakes in Persia – Encyclopaedia Iranica](https://www.iranicaonline.org/articles/earthquakes-iv-the-historical-record-of-earthquakes-in-persia/)
- [Significant Earthquake Information: Iran, Tabas, 1978 – NOAA NCEI](https://www.ngdc.noaa.gov/hazel/view/hazards/earthquake/event-more-info/4815)

---

### 20. "The Illness of the Wind": Iran's 1918 Pandemic
**Pillar:** 9. Iranian experiences of surviving crises | **Time & place:** 1918–1919, Mashhad, Tehran, Kermanshah and Kazerun, Iran

In August 1918 the influenza pandemic entered an Iran already weakened by famine, first through Mashhad and then through Caspian and Persian Gulf ports. It reached Tehran on 22 September. When a strong western wind blew two days later, people named it "the illness of the wind." Kermanshah, already crowded with some 60,000 hungry refugees, was overwhelmed. In Kazerun, doctors reportedly handed prescriptions through barely opened doors.\[58\] Historian Amir Afkhami estimates between 902,400 and 2.4 million deaths, among the highest rates anywhere.\[13\]\[58\] Lesson: in an epidemic, accurate information and care for the vulnerable matter as much as medicine, and Iran has come back from such darkness before.

**Sources:**
- [Influenza – Encyclopaedia Iranica](https://www.iranicaonline.org/articles/influenza/)

---

## Caveats
- **Gaps against the brief:** the bank holds 20 topics, not 50. Pillars 7 (speeches) and 8 (rebuilding) are empty. Pillars 2, 3 and 4 each have fewer than five topics, and there is no African story yet. These are research-budget limits, not a judgement that good stories don't exist.
- **Next candidates to verify:** Mandela's April 1993 address after Chris Hani's assassination; RFK's Indianapolis speech of 4 April 1968; FDR's first fireside chat (March 1933); Havel's 1990 New Year address; Hiroshima's streetcars running again days after the bomb; Mostar's Old Bridge rebuilt (2004); Kobe's 1995 volunteer movement; the Christchurch Student Volunteer Army; Gander on 9/11; Le Chambon-sur-Lignon; Albanian Besa; Sierra Leone's Ebola burial teams; Myra Hess's National Gallery concerts; Friedl Dicker-Brandeis in Terezín; Kharkiv's metro schools; the Wörgl stamp scrip; and the Toyokawa bank-run rumour (1973).\[59\] For Iran's 1988 "War of the Cities," only a Wilson Center source has turned up so far, and that is not on the approved list.
- **Source notes:** AP stories are cited through syndicating newspapers because the AP originals did not come up in search. Death tolls for Plasco and the 1917–19 famine are disputed, so present them as ranges.\[15\] Sardari's passport figure is a family claim that has not been confirmed. Before scripting, open every link again and check it against the claims made on screen.

## Sources

1. [Pingree, Hazen S.](https://www.detroithistorical.org/learn/online-research/encyclopedia-of-detroit/pingree-hazen-s)
2. [Hazen Pingree: Quite possibly Detroit's finest mayor](https://www.detroitnews.com/story/news/local/michigan-history/2020/02/08/hazen-pingree-quite-possibly-detroits-finest-mayor/4686854002/)
3. [Hazen S. Pingree](https://en.wikipedia.org/wiki/Hazen_S._Pingree)
4. [Hazen Pingree, Detroit's superstar mayor of the 1890s](https://www.detroitnews.com/picture-gallery/news/local/michigan-history/2014/12/17/hazen-pingree-detroits-superstar-mayor-of-the-1890s/20441163/)
5. [Hazen S. Pingree Monument — Historic Detroit](https://historicdetroit.org/buildings/hazen-s-pingree-monument)
6. [Tess McNamara: Urban Agricultural Trends in Havana, Cuba](https://tri.yale.edu/news/tess-mcnamara-urban-agricultural-trends-havana-cuba)
7. [Crisis of urban agriculture: Case studies in Cuba](https://tri.yale.edu/tropical-resources/tropical-resources-vol-36/crisis-urban-agriculture-case-studies-cuba)
8. [Havana: World Capital of Urban Farming? - Dwell](https://www.dwell.com/article/havana-world-capital-of-urban-farming-659b65ad)
9. [Barter clubs expose Argentina's weakness - CNN.com](https://edition.cnn.com/2009/WORLD/americas/05/20/argentina.barter/index.html)
10. [Greece's 'Potato Movement' Grows in Power](https://www.commondreams.org/news/2012/06/11/greeces-potato-movement-grows-power)
11. [Greece: what the potato movement did next](https://newint.org/features/2013/01/01/greece-potato-movement)
12. [Greek farmers offload crops at cost price](https://www.deseret.com/2012/2/25/20395768/greek-farmers-offload-crops-at-cost-price/)
13. [Persian famine of 1917%E2%80%931919](https://en.wikipedia.org/wiki/Persian_famine_of_1917%E2%80%931919)
14. [Full article: Imperial wars and the violence of hunger: remembering and forgetting the Great Persian Famine 1917–1919](https://www.tandfonline.com/doi/abs/10.1080/01436597.2023.2221183)
15. [(PDF) The Great Persian Famine (1917-1919): Causes, Consequences, and Legal Reflections on Historical Responsibility](https://www.researchgate.net/publication/393777888_The_Great_Persian_Famine_1917-1919_Causes_Consequences_and_Legal_Reflections_on_Historical_Responsibility)
16. [kids.britannica.com](https://kids.britannica.com/kids/article/Chile-mine-rescue-of-2010/543402)
17. [Journalist given exclusive access shares stories of trapped Chilean miners](https://www.pbs.org/newshour/show/chilean-miners)
18. [33 Chilean Miners Were Buried Alive. These Are the Tactics That Kept Them Sane.](https://www.nationalgeographic.com/history/article/chilean-miners-rescue-psychological-strategy)
19. [Chile mine rescue of 2010](https://www.britannica.com/event/Chile-mine-rescue-of-2010)
20. [The Incredible Story Of Chilean Miners Rescued From The 'Deep Down Dark' : NPR](https://www.npr.org/2014/10/29/359839104/the-incredible-story-of-chilean-miners-rescued-from-the-deep-down-dark)
21. [Anna Freud - Sigmund Freud Museum](https://www.freud-museum.at/en/details-anna)
22. [Social Media Misinformation That Led to 300 Deaths in Iran Claimed That Drinking Methanol was a Cure for COVID-19](https://www.techtimes.com/articles/248428/20200329/social-media-misinformation-that-led-to-300-deaths-in-iran-claimed-drinking-methanol-was-a-cure-for-covid-19.htm)
23. [In Iran, false belief a poison fights virus kills hundreds](https://www.washingtontimes.com/news/2020/mar/27/in-iran-false-belief-a-poison-fights-virus-kills-h/)
24. [pmc.ncbi.nlm.nih.gov](https://pmc.ncbi.nlm.nih.gov/articles/PMC7368655)
25. [False belief poison cures coronavirus kills over 700 in Iran](https://fox59.com/news/coronavirus/false-belief-poison-cures-coronavirus-kills-over-700-in-iran/)
26. [In Iran, false belief a poison fights virus kills hundreds](https://www.spokesman.com/stories/2020/mar/27/in-iran-false-belief-a-poison-fights-virus-kills-h/)
27. [René Dagron Operates the Pigeon Post into Paris](https://www.historyofinformation.com/detail.php?id=2072)
28. [Siege of Paris Mail](https://postalmuseum.si.edu/exhibition/international-philately-europe-western-europe-france/siege-of-paris-mail)
29. [Ballons MontÃ©s of the Paris siege](https://www.warwickandwarwick.com/news/ballons-monts-of-the-paris-siege)
30. [Pigeon post microfilm](https://postalmuseum.si.edu/object/npm_0.260305.10.36.3)
31. [The Oneg Shabbat Archive | Holocaust Encyclopedia](https://encyclopedia.ushmm.org/content/en/article/the-oneg-shabbat-archive)
32. [inside a secret library in syria](https://www.npr.org/2020/05/08/853192520/inside-a-secret-library-in-syria)
33. [how a group of syrian residents assembled a secret library](https://www.pbs.org/newshour/show/how-a-group-of-syrian-residents-assembled-a-secret-library)
34. [The Choctaw Nation's Gift to the Irish](https://www.smithsonianmag.com/blogs/national-museum-american-indian/2018/03/16/choctaw-nations-gift-irish/)
35. [The Irish are sending relief to Native Americans, inspired by a donation from a tribe during the Great Famine](https://www.cnn.com/2020/05/06/world/ireland-native-americans-choctaw-gift-trnd)
36. [Choctaw generosity to Famine Ireland saluted by Varadkar](https://www.irishtimes.com/news/ireland/irish-news/choctaw-generosity-to-famine-ireland-saluted-by-varadkar-1.3424542)
37. [Irish Return Historic Favor by Donating to Native Americans During Pandemic](https://www.smithsonianmag.com/smart-news/irish-donate-native-americans-hit-hard-covid-19-and-return-old-favor-180974817/)
38. [Abdol Hossein Sardari - United States Holocaust Memorial Museum](https://www.ushmm.org/antisemitism/holocaust-denial-and-distortion/holocaust-denial-antisemitism-iran/abdol-hossein-sardari-an-iranian-hero-of-the-holocaust)
39. [IRAN DURING WORLD WAR II 1 POLISH REFUGEES IN IRAN DURING WORLD WAR II](https://www.ushmm.org/m/pdfs/Polish-Refugees-in-Iran-During-World-War-II.pdf)
40. [Polish Refugees in Iran](https://www.printmag.com/daily-heller/polish-refugees-in-iran/)
41. [Echoes of Polish Isfahan](https://iranian.com/main/2012/apr/echoes-polish-isfahan.html)
42. [Abdol Hossein Sardari (1895–1981)](https://encyclopedia.ushmm.org/content/en/article/abdol-hossein-sardari-1895-1981)
43. [Abdol Hossein Sardari (1895–1981)](https://usc.ushmm.org/wlc/en/article.php?ModuleId=10007452)
44. [Iran: Floods - Mar 2019](https://reliefweb.int/disaster/fl-2019-000022-irn)
45. [www.cambridge.org](https://www.cambridge.org/core/journals/disaster-medicine-and-public-health-preparedness/article/abs/tractor-ambulance-an-initiative-of-emergency-medical-services-response-to-the-flood-of-golestan-iran-in-2019/72FBB36A290803C0D714362F2185B50D)
46. [20190429 Iran Floods UN Iran Response Plan](https://iran.un.org/sites/default/files/2020-05/20190429-Iran_Floods_UN_Iran_Response_Plan.pdf)
47. [The Life Process of Children Who Survived the Manjil Earthquake: A Decaying or Renewing Process](https://currents.plos.org/disasters/article/the-life-process-of-children-who-survived-the-manjil-earthquake-a-decaying-or-renewing-process/)
48. [Iran Earthquake Jun 1990 UNDRO Situation Reports 1 - 14 - Iran (Islamic Republic of)](https://reliefweb.int/report/iran-islamic-republic/iran-earthquake-jun-1990-undro-situation-reports-1-14)
49. [Tehran fire: 20 dead in Plasco building collapse](https://www.aljazeera.com/news/2017/1/19/tehran-fire-20-dead-in-plasco-building-collapse)
50. [Watch CBS News](https://cbsnews.com/news/iran-collapse-kills-tehran-firefighters-battling-plasco-building-fire)
51. [Iran shocked by deadly fire, collapse of Tehran high-rise](https://www.spokesman.com/stories/2017/jan/19/iran-shocked-by-deadly-fire-collapse-of-tehran-hig/)
52. [An updated study on near-fault ground motions of the 1978 Tabas, Iran, earthquake (Mw=7.4) - ScienceDirect](https://www.sciencedirect.com/science/article/pii/S1026309811001428)
53. [Major magnitude 7.4 earthquake - eastern Iran on Saturday, Sep 16, 1978, at 08:05 pm (Tehran time)](https://www.volcanodiscovery.com/earthquakes/quake-info/3039922/mag7quake-Sep-16-1978-eastern-Iran.html)
54. [1978 Tabas earthquake](https://en.wikipedia.org/wiki/1978_Tabas_earthquake)
55. [(PDF) The 1978 Tabas, Iran, earthquake: An interpretation of the strong motion records](https://www.researchgate.net/publication/279319177_The_1978_Tabas_Iran_earthquake_An_interpretation_of_the_strong_motion_records)
56. [The Tabas Earthquake of September 16, 1978 in east-central Iran, A preliminary field report - ADS](https://ui.adsabs.harvard.edu/abs/1979GeoRL...6..689M/abstract)
57. [EARTHQUAKES iv. THE HISTORICAL RECORD OF EARTHQUAKES IN PERSIA](https://www.iranicaonline.org/articles/earthquakes-iv-the-historical-record-of-earthquakes-in-persia/)
58. <https://www.iranicaonline.org/articles/influenza/>
59. [We don't control the conversation](https://www.campaignlive.co.uk/article/dont-control-conversation/1749514)
