---
title: "Nanjing Massacre"
source: "https://en.wikipedia.org/wiki/Nanjing_Massacre"
---
The **Nanjing Massacre** [^2] or the **Rape of Nanjing** (formerly [romanized](https://en.wikipedia.org/wiki/Chinese_postal_romanization "Chinese postal romanization") as *Nanking* **[^3]**) was the [mass rape](https://en.wikipedia.org/wiki/Mass_sexual_assault "Mass sexual assault") and murder, between December 1937 and March 1938, of Chinese civilians, noncombatants, and prisoners of war by the [Imperial Japanese Army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army") in [Nanjing](https://en.wikipedia.org/wiki/Nanjing "Nanjing"), the capital of the [Republic of China](https://en.wikipedia.org/wiki/Nationalist_government "Nationalist government"). It took place immediately after the [Battle of Nanjing](https://en.wikipedia.org/wiki/Battle_of_Nanjing "Battle of Nanjing") and retreat of the [National Revolutionary Army](https://en.wikipedia.org/wiki/National_Revolutionary_Army "National Revolutionary Army") during the [Second Sino-Japanese War](https://en.wikipedia.org/wiki/Second_Sino-Japanese_War "Second Sino-Japanese War").[^9] [^10] [^11] [^12]

After the outbreak of the war in July 1937, the Japanese had pushed quickly through China after [capturing Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai") in November. As the Japanese marched on Nanjing, they committed violent atrocities in a terror campaign, including [killing contests](https://en.wikipedia.org/wiki/Hundred_man_killing_contest "Hundred man killing contest") and massacres of entire villages.[^13]

By early December, the Japanese [Central China Area Army](https://en.wikipedia.org/wiki/Central_China_Area_Army "Central China Area Army") under the command of General [Iwane Matsui](https://en.wikipedia.org/wiki/Iwane_Matsui "Iwane Matsui") reached the outskirts of the city. The Japanese had also planned to use mustard gas and incendiary bombs to annihilate the capital and its population should the fighting have grown too intense.[^14]

[Prince Yasuhiko Asaka](https://en.wikipedia.org/wiki/Prince_Yasuhiko_Asaka "Prince Yasuhiko Asaka") was installed as temporary commander in the campaign, and he issued an order to "kill all captives" before the city's capture. Matsui and Asaka took no action to stop the massacre after it began.

The massacre began on December 13 after Japanese troops entered the city after days of intense fighting and continued to rampage through it unchecked. Japanese soldiers murdered civilians, including children, women, and the elderly. Japanese units also [summarily executed](https://en.wikipedia.org/wiki/Summarily_executed "Summarily executed") thousands of captured Chinese soldiers in violation of the laws of war, as well as male civilians falsely accused of being soldiers. They raped women and girls, their ages ranging from infants to the elderly, and destroyed one third of the city with arson. Rape victims were often murdered afterward. In addition to civilians, Japanese units indiscriminately murdered tens of thousands of Chinese [POWs](https://en.wikipedia.org/wiki/Prisoner_of_war "Prisoner of war") and men who looked of military age.

Many scholars support the validity of the [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East") (IMTFE), which estimated that more than 200,000 people were killed,[^7] while newer estimates adhere to a death toll between 100,000 and 200,000.[^5] Other estimates of the death toll vary from a low of 40,000 (confined just to the city itself) to a high of over 340,000 (encompassing the entire Shanghai-Nanjing region), and estimates of rapes range from 4,000 to over 80,000 (with estimates around 20,000 being most common).[^15] Other crimes included torture, looting, and arson. The massacre is considered one of the worst [wartime atrocities](https://en.wikipedia.org/wiki/Wartime_atrocities "Wartime atrocities") in history.[^16] [^17] [^18]

Traditional historiography dates the massacre as unfolding over a period of six weeks beginning on December 13, 1937, following the city's capture, and as being spatially confined to within Nanjing and its immediate vicinity.[^1] However, the Nanjing Massacre was far from an isolated case, and fit into a pattern of Japanese atrocities along the [Lower Yangtze River](https://en.wikipedia.org/wiki/Yangtze "Yangtze"), with Japanese forces routinely committing massacres since the [Battle of Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai"). Furthermore, Japanese atrocities in the Nanjing area did not end in January 1938, but instead persisted in the region until late March 1938.[^4]

An [International Committee](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone") of Westerners, including Nazi German citizen [John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe"), created the [Nanking Safety Zone](https://en.wikipedia.org/wiki/Nanking_Safety_Zone "Nanking Safety Zone") in an attempt to protect civilians. The Safety Zone was mostly a success, and is credited with saving at least 200,000 lives.

After the war, Matsui and several other commanders at Nanjing were found guilty of war crimes and executed. Some other Japanese military leaders in charge at the time of the Nanjing Massacre were not tried only because by the time of the tribunals they had either already been killed or committed [ritual suicide](https://en.wikipedia.org/wiki/Seppuku "Seppuku"). Asaka was granted immunity as a member of the imperial family and never tried. The massacre remains a contentious topic in [Sino-Japanese relations](https://en.wikipedia.org/wiki/Sino-Japanese_relations "Sino-Japanese relations"), as Japanese nationalists and historical revisionists, including top government officials, have either denied or minimized the massacre.

## Military situation

The [Second Sino-Japanese War](https://en.wikipedia.org/wiki/Second_Sino-Japanese_War "Second Sino-Japanese War") commenced on July 7, 1937, following the [Marco Polo Bridge incident](https://en.wikipedia.org/wiki/Marco_Polo_Bridge_incident "Marco Polo Bridge incident"), and rapidly escalated into a full-scale war in northern China between the Chinese and Japanese armies.[^20] The [National Revolutionary Army](https://en.wikipedia.org/wiki/National_Revolutionary_Army "National Revolutionary Army"), however, wanted to avoid a decisive conflict in the northern region and instead opened a second front by launching offensives against Japanese forces in [Shanghai](https://en.wikipedia.org/wiki/Shanghai "Shanghai").[^20] In response, Japan deployed an army led by General [Iwane Matsui](https://en.wikipedia.org/wiki/Iwane_Matsui "Iwane Matsui"), to fight the Chinese forces in Shanghai.[^21]

In August 1937, the Japanese army [invaded Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai"), where they met strong resistance and suffered heavy casualties. The battle was bloody as both sides faced attrition in urban [hand-to-hand combat](https://en.wikipedia.org/wiki/Hand-to-hand_combat "Hand-to-hand combat").[^22] Although the Japanese forces succeeded in forcing the Chinese forces into retreat, the General Staff Headquarters in Tokyo initially decided not to expand the war because they wanted the war to end.[^23] However, there was a significant disagreement between the Japanese government and its army in China.[^24] Matsui had expressed his intention to advance on Nanjing even before departing for Shanghai. He firmly believed that capturing Nanjing, the Chinese capital, would lead to the collapse of the entire Nationalist Government of China, thereby securing a swift and decisive victory for Japan.[^23] [^24] The General Staff Headquarters in Tokyo eventually relented to the demands of the Imperial Japanese Army in China by approving the operation to attack and capture Nanjing.[^25]

### Strategy for the defense of Nanjing

In a press release to foreign reporters, [Tang Shengzhi](https://en.wikipedia.org/wiki/Tang_Shengzhi "Tang Shengzhi") announced the city would not surrender and would fight to the death. Tang gathered a garrison force of some 81,500 soldiers,[^26] many of whom were untrained conscripts, or troops exhausted from the [Battle of Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai"). The Chinese government left for relocation on December 1, and the president left on December 7, leaving the administration of Nanjing to an International Committee led by [John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe"), a German national and [Nazi Party](https://en.wikipedia.org/wiki/Nazi_Party "Nazi Party") member.

In an attempt to secure permission for this ceasefire from [Chiang Kai-shek](https://en.wikipedia.org/wiki/Chiang_Kai-shek "Chiang Kai-shek"), Rabe, who was living in Nanjing and had been acting as the Chairman of the [Nanking International Safety Zone](https://en.wikipedia.org/wiki/Nanking_International_Safety_Zone "Nanking International Safety Zone") Committee, boarded the [USS *Panay* (PR-5)](https://en.wikipedia.org/wiki/USS_Panay_\(PR-5\) "USS Panay (PR-5)") on December 9.

On December 11, Rabe found that Chinese soldiers were still residing in areas of the Safety Zone, meaning that it became an intended target for Japanese attacks despite the majority being innocent civilians. Rabe commented on how efforts to remove these Chinese troops failed and Japanese soldiers began to lob grenades into the refugee zone.[^27]

## March to Nanjing and atrocities

![](https://en.wikipedia.org/wiki/File:Contest_To_Cut_Down_100_People.jpg)

An article on the " Contest to kill 100 people using a sword " published in the Tokyo Nichi Nichi Shimbun. The headline reads, " ' Incredible Record' (in the Contest to Cut Down 100 People) – Mukai 106–105 Noda – Both 2nd Lieutenants Go into Extra Innings". 28

Although the massacre is generally described as having occurred over a six-week period after the fall of Nanjing, the crimes committed by the Japanese army were not limited to that period. Numerous atrocities were committed as the Japanese army advanced from Shanghai to Nanjing, including rape, torture, arson, and murder. Many were committed as part of a systemic [terror campaign](https://en.wikipedia.org/wiki/State_terrorism "State terrorism") meant to undermine the will to resist amongst the Chinese population.[^29]

### Japanese war crimes in the countryside

Japanese commanders ordered their troops to treat all Chinese outside Shanghai as belligerents, to kill them, and to destroy their homes.[^30] Advancing Japanese forces transformed the 170 miles between Shanghai and Nanjing into "a nightmarish zone of death and destruction". Japanese aircraft frequently strafed unarmed farmers and refugees "for fun".[^31] Civilians were subjected to extreme violence and brutality in a foreshadowing of the upcoming massacre.[^13]

In one example on November 23, the Nanqiantou hamlet near [Wuxi](https://en.wikipedia.org/wiki/Wuxi "Wuxi") was set on fire, with many of its inhabitants locked within the burning houses. Two women, one a 17-year-old girl and the other pregnant, were raped repeatedly until they could not walk. Afterwards, the soldiers rammed a broom into the teenager's vagina and stabbed her with a bayonet, then "cut open the belly of the pregnant woman and gouged out the fetus". A crying two-year-old boy was wrestled from his mother's arms and thrown into the flames, while the hysterically sobbing mother was bayoneted and thrown into a creek. The remaining thirty villagers were bayoneted, disemboweled, and also thrown into the creek.[^32] [^13]

In another case on November 29, the Japanese 3rd Battalion from [the 16th Division](https://en.wikipedia.org/wiki/16th_Division_\(Imperial_Japanese_Army\) "16th Division (Imperial Japanese Army)") rounded up eighty civilians in the village of Changzhou. The Japanese then massacred the villagers with heavy machine guns. According to army doctor Hosaka Akira, "The people were all gathered in one place. They were all praying, crying, and begging for help. I just couldn't bear watching such a pitiful spectacle. Soon the heavy machine guns opened fire and the sight of those people screaming and falling to the ground is one I could not face even if I had had the heart of a monster." [^33]

According to Kurosu Tadanobu of the [13th Division](https://en.wikipedia.org/wiki/13th_Division_\(Imperial_Japanese_Army\) "13th Division (Imperial Japanese Army)"):[^34]

> "We'd take all the men behind the houses and kill them with bayonets and knives. Then we'd lock up the women and children in a single house and rape them at night... Then, before we left the next morning, we'd kill all the women and children, and to top it off, we'd set fire to the houses, so that even if anyone came back, they wouldn't have a place to live."

Chinese civilians often committed suicide, such as two girls who deliberately drowned themselves near [Pinghu](https://en.wikipedia.org/wiki/Pinghu "Pinghu"), an event witnessed by Japanese First Lieutenant Nishizawa Benkichi.[^35]

### Japanese war crimes in urban areas

As early as November, Japanese forces had been committing atrocities against urban regions and cities. [Jiading](https://en.wikipedia.org/wiki/Jiading "Jiading") was shelled by Japanese forces, then 8,000 of its civilian residents murdered. Half of [Taicang](https://en.wikipedia.org/wiki/Taicang "Taicang") was razed to the ground, and then half the salt and grain stores looted.[^36]

On December 8, the Japanese Shanghai Expeditionary Army captured the city of [Zhenjiang](https://en.wikipedia.org/wiki/Zhenjiang "Zhenjiang") between Shanghai and Nanjing. They then set Zhenjiang on fire and executed anyone attempting to douse the flames. Zhenjiang burned for ten days. The Japanese also burned wounded Chinese soldiers alive and raped women and children. According to a city resident who survived the blaze, the city was burned as a deliberate attempt to destroy civilian property.[^29]

According to one Japanese journalist embedded with Imperial forces at the time:[^37]

> The reason that the \[10th Army\] is advancing to Nanjing quite rapidly is due to the tacit consent among the officers and men that they could loot and rape as they wish.

In his novel *Ikiteiru Heitai* ('Living Soldiers'), [Tatsuzō Ishikawa](https://en.wikipedia.org/wiki/Tatsuz%C5%8D_Ishikawa "Tatsuzō Ishikawa") vividly describes how the 16th Division of the [Shanghai Expeditionary Force](https://en.wikipedia.org/wiki/Shanghai_Expeditionary_Force "Shanghai Expeditionary Force") committed atrocities on the march between Shanghai and Nanjing. The novel itself was based on interviews that Ishikawa conducted with troops in Nanjing in January 1938.[^38]

### Massacre contest

![](https://en.wikipedia.org/wiki/File:%E6%97%A5%E6%9C%AC%E4%BA%BA%E6%8B%BF%E4%BA%BA%E9%A0%AD.jpg)

A Japanese soldier poses with the severed head of one of his victims

Perhaps the most notorious atrocity was a [killing contest between two Japanese officers](https://en.wikipedia.org/wiki/Contest_to_kill_100_people_using_a_sword "Contest to kill 100 people using a sword") as reported in the *[Tokyo Nichi Nichi Shimbun](https://en.wikipedia.org/wiki/Tokyo_Nichi_Nichi_Shimbun "Tokyo Nichi Nichi Shimbun")* and the English-language *Japan Advertiser*. The contest—a race between the two officers to see who could kill 100 people first using only a sword—was covered much like a sporting event with regular updates on the score over a series of days.[^39] [^40] In Japan, the veracity of the newspaper article about the contest was the subject of ferocious debate for several decades starting in 1967.[^41]

In 1937, the *[Osaka Mainichi Shimbun](https://en.wikipedia.org/wiki/Osaka_Mainichi_Shimbun "Osaka Mainichi Shimbun")* and its sister newspaper, the *[Tokyo Nichi Nichi Shimbun](https://en.wikipedia.org/wiki/Tokyo_Nichi_Nichi_Shimbun "Tokyo Nichi Nichi Shimbun")*, covered a contest between two Japanese officers, Toshiaki Mukai and Tsuyoshi Noda of the Japanese 16th Division. The two men were described as vying to be the first to kill 100 people with a sword before the capture of Nanjing. From [Jurong, Jiangsu](https://en.wikipedia.org/wiki/Jurong,_Jiangsu "Jurong, Jiangsu") to [Tangshan](https://en.wikipedia.org/wiki/Tangshan "Tangshan"), Mukai had killed 89 people while Noda had killed 78. The contest continued because neither had killed 100 people. By the time they had arrived at [Purple Mountain](https://en.wikipedia.org/wiki/Purple_Mountain_\(Nanjing\) "Purple Mountain (Nanjing)"), Noda had killed 105 people while Mukai had killed 106 people. Both officers supposedly surpassed their goal during the heat of battle, making it impossible to determine which officer had actually won the contest. Therefore, according to journalists Asami Kazuo and Suzuki Jiro, writing in the *Tokyo Nichi Nichi Shimbun* of December 13, they decided to begin another contest to kill 150 people.[^42]

In 2000, historian Bob Tadashi Wakabayashi concurred with certain Japanese scholars who had argued that the contest was a [concocted story](https://en.wikipedia.org/wiki/Urban_legend "Urban legend") by the Japanese army, with the collusion of the soldiers themselves for the purpose of raising their [national fighting spirit](https://en.wikipedia.org/wiki/Yamato-damashii "Yamato-damashii").[^43]

In 2005, a Tokyo district judge dismissed a suit by the families of the lieutenants, stating that "the lieutenants admitted the fact that they raced to kill 100 people" and that the story cannot be proven to be clearly false.[^44] The judge also ruled against the [civil claim](https://en.wikipedia.org/wiki/Civil_claim "Civil claim") of the [plaintiffs](https://en.wikipedia.org/wiki/Plaintiff "Plaintiff") because the original article was more than 60 years old.[^45] The historicity of the event remains disputed in Japan.[^46]

### Chinese scorched-earth policy

The Nanjing [garrison](https://en.wikipedia.org/wiki/Garrison "Garrison") set fire to buildings and houses in the areas close to Xiaguan to the north as well as in the environs of the eastern and southern city gates. Targets within and outside of the city walls—such as military barracks, private homes, the Ministry of Communication, forests, and entire villages—were completely burnt down, at an estimated value of US$20–30 million (1937).[^47] [^48] [^49]

### Establishment of the Nanking Safety Zone

![](https://en.wikipedia.org/wiki/File:Some_members_of_the_International_Committee_for_Nanking_Safety_Zone_on_Dec_13,_1937.jpg)

Members of the International Committee for the Nanking Safety Zone, including John Rabe (center) and John Magee (center right)

Many Westerners were living in the city at that time, conducting trade or on missionary trips. As the Japanese army approached Nanjing, most of them fled the city, leaving 27 foreigners. Five of these were journalists who remained in the city a few days after it was captured, leaving the city on December 16. Fifteen of the remaining 22 foreigners formed a committee, called the [International Committee for the Nanking Safety Zone](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone") in the western quarter of the city.[^50]

German businessman [John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe") was elected as its leader, in part because of his status as a member of the [Nazi Party](https://en.wikipedia.org/wiki/Nazi_Party "Nazi Party") and the existence of the [German-Japanese](https://en.wikipedia.org/wiki/Germany%E2%80%93Japan_relations "Germany–Japan relations") bilateral [Anti-Comintern Pact](https://en.wikipedia.org/wiki/Anti-Comintern_Pact "Anti-Comintern Pact"). The Japanese government had previously agreed not to attack parts of the city that did not contain Chinese military forces, and the members of the Committee managed to persuade the Chinese government to move their troops out of the area. The Nanking Safety Zone was demarcated through the use of [Red Cross Flags](https://en.wikipedia.org/wiki/International_Red_Cross_and_Red_Crescent_Movement "International Red Cross and Red Crescent Movement").[^51]

[Minnie Vautrin](https://en.wikipedia.org/wiki/Minnie_Vautrin "Minnie Vautrin") was a Christian missionary who established [Ginling Girls College](https://en.wikipedia.org/wiki/Ginling_Girls_College "Ginling Girls College") in Nanjing, which was within the established Safety Zone. During the massacre, she worked tirelessly in welcoming thousands of female refugees to stay in the college campus, sheltering up to 10,000 women.[^52]

### Bernhard Sindberg's refugee camp

![](https://en.wikipedia.org/wiki/File:Sindberg_on_inspection_in_the_refugee_camp,_Nanjing_Massacre.jpg)

Bernhard Sindberg holding a Danish flag with Chinese refugees in his refugee camp.

At the age of 26, a [Dane](https://en.wikipedia.org/wiki/Danes "Danes") named [Bernhard Arp Sindberg](https://en.wikipedia.org/wiki/Bernhard_Arp_Sindberg "Bernhard Arp Sindberg") began his role as a guard at a cement factory in Nanjing in December 1937, days before the Japanese invasion of Nanjing.[^53] As the massacre began, Sindberg and [Karl Gunther](https://en.wikipedia.org/wiki/Karl_G%C3%BCnther_\(engineer\) "Karl Günther (engineer)"), a German colleague, converted the cement factory into a makeshift refugee camp where they offered refuge and medical assistance to approximately 6,000 to 10,000 Chinese civilians.[^54] [^55]

Knowing that Imperial Japan was not hostile towards [Denmark](https://en.wikipedia.org/wiki/Denmark "Denmark") or [Nazi Germany](https://en.wikipedia.org/wiki/Nazi_Germany "Nazi Germany"), thus showing respect for their flags, Sindberg painted a large [Danish flag](https://en.wikipedia.org/wiki/Danish_flag "Danish flag") on the cement factory roof to deter the Japanese army from bombing the factory.[^54] To keep Japanese troops away from the factory, he and Gunther strategically placed the Danish flag and the German [swastika](https://en.wikipedia.org/wiki/Swastika "Swastika") around the site.[^54] Whenever the Japanese approached the gate, Sindberg would display the Danish flag and step out to converse with them, and eventually, they would leave.[^53]

### Prince Asaka appointment as commander and the order to "kill all captives"

![](https://en.wikipedia.org/wiki/File:Prince_Asaka_Yasuhiko_01.jpg)

Prince Yasuhiko Asaka in 1935, who would issue orders to "kill all captives" in the Nanjing area.

In a memorandum for the palace rolls, Hirohito singled [Prince Yasuhiko Asaka](https://en.wikipedia.org/wiki/Prince_Yasuhiko_Asaka "Prince Yasuhiko Asaka") out for [censure](https://en.wikipedia.org/wiki/Censure "Censure") as the one imperial kinsman whose attitude was "not good". He assigned Asaka to Nanjing as an opportunity to make amends.[^56]

On December 5, Asaka left Tokyo by plane and arrived at the front three days later. He met with division commanders, lieutenant-generals [Kesago Nakajima](https://en.wikipedia.org/wiki/Kesago_Nakajima "Kesago Nakajima") and [Heisuke Yanagawa](https://en.wikipedia.org/wiki/Heisuke_Yanagawa "Heisuke Yanagawa"), who informed him that the Japanese troops had almost completely surrounded 300,000 Chinese troops in the vicinity of Nanjing and that preliminary negotiations suggested that the Chinese were ready to surrender.[^57]

Prince Asaka issued an order to "kill all captives", thus providing official sanction for the crimes which took place during and after the battle.[^58] Some authors record that Prince Asaka signed the order for Japanese soldiers in Nanjing to "kill all captives".[^57] Others assert that lieutenant colonel [Isamu Chō](https://en.wikipedia.org/wiki/Isamu_Ch%C5%8D "Isamu Chō"), Asaka's [aide-de-camp](https://en.wikipedia.org/wiki/Aide-de-camp "Aide-de-camp"), sent this order under the Prince's [sign-manual](https://en.wikipedia.org/wiki/Sign-manual "Sign-manual") without the Prince's knowledge or assent.[^59] Nevertheless, even if Chō took the initiative, Asaka was nominally the officer in charge and gave no orders to stop the carnage. While the extent of Prince Asaka's responsibility for the massacre remains a matter of debate, the ultimate sanction for the massacre and the crimes committed during the invasion of China were issued in Emperor [Hirohito](https://en.wikipedia.org/wiki/Hirohito "Hirohito") 's ratification of the Japanese army's proposition to remove the constraints of [international law](https://en.wikipedia.org/wiki/International_law "International law") on the treatment of Chinese prisoners on August 5, 1937.[^60]

A detailed analysis of wartime materials and documents by Japanese researcher Ono Kenji has directly implicated Prince Asaka in issuing the order to illegally execute Chinese captives in the Nanjing Area.[^61]

## Civilian population and evacuation

With the relocation of the capital of China, constant bombing raids, and reports of Japanese brutality, much of Nanjing's civilian population had fled out of fear. Wealthy families were the first to flee, leaving Nanjing in automobiles, followed by the evacuation of the middle class and then the poor. Those that remained were mainly the destitute lowest class such as the ethnic [Tanka boat people](https://en.wikipedia.org/wiki/Tanka_people "Tanka people"), and those with assets that could not be easily moved, like shopkeepers.[^17]

Of Nanjing's population, estimated to be over one million before the Japanese invasion, a large proportion had already fled Nanjing before the Japanese advance, estimated to be between half (500,000) to three-quarters (750,000) of the pre-war population.[^62] [^63]

## "Plan B": the intended use of poison gas and incendiary bombing in Nanjing

On November 30, the Japanese Tenth Army drew up two plans for attacking Nanjing. Plan A outlined a headlong rush for the city. Should this have failed, Plan B outlined the use of [incendiary bombs](https://en.wikipedia.org/wiki/Firebombing "Firebombing") and [mustard gas](https://en.wikipedia.org/wiki/Mustard_gas "Mustard gas") canisters to "reduce the city to rubble".[^64] Specifically, Plan B read:

> Surround Nanking completely and bomb it from the air thoroughly for about a week—with special attention to incendiary bombs and mustard-gas canisters—to reduce the city to rubble. Should the enemy resist and defend the walled fortress to the bitter end, the Tenth Army will use the smallest force possible to maintain the siege; 2.5 divisions should do. It will keep up air attacks to destroy the enemy while refusing to storm the city by force... Poison gas is imperative in this assault. It is totally unacceptable to sustain the same losses we did at Shanghai owing to qualms about poison gas here.

Had the fighting approached the intensity of the Battle of Shanghai, Japanese commanders had planned to use mustard gas and incendiaries on the Chinese capital. The implementation of such a plan would have resulted in "a holocaust for one city", as historian Bob Wakabayashi comments.[^64] [^14]

## Battle of Nanjing

![](https://en.wikipedia.org/wiki/File:Iwane_Matsui_rides_into_Nanjing.jpg)

Iwane Matsui enters Nanjing.

The Japanese military continued to move forward, breaching several lines of Chinese resistance, and arrived outside the city gates of Nanjing on December 9. Despite resisting the assault fiercely, the Chinese defenders were hampered by rising casualties and Japanese strengths in firepower and numbers. Combined with fatigue and a breakdown in communications, the garrison was gradually overwhelmed in the four day battle for the city, and finally collapsed on the night of December 12.[^65]

![](https://en.wikipedia.org/wiki/File:Nanjinggatebattle.jpg)

Japanese soldiers attack one of Nanjing's gates in the final assault

On December 12, under heavy artillery fire and aerial bombardment, General Tang Sheng-chi ordered his men to retreat. Conflicting orders and a breakdown in discipline turned the events that followed into a disaster. While some Chinese units managed to escape across the river, many more were caught up in the general chaos erupting across the city. Some Chinese soldiers stripped civilians of their clothing in a desperate attempt to blend in, and many others were shot by the Chinese supervisory unit as they tried to flee.[^47] Other Chinese units dissipated into the countryside, often colliding with Japanese units.

On December 13, the 6th and the 114th Divisions of the Japanese Army were the first to enter the city. Simultaneously, the 9th Division entered nearby Guanghua Gate, and the 16th Division entered the Zhongshan and Taiping gates. That same afternoon, two small [Japanese Navy](https://en.wikipedia.org/wiki/Imperial_Japanese_Navy "Imperial Japanese Navy") fleets arrived on both sides of the Yangtze River.

## The Nanjing Massacre

As early as December 4, the Japanese Army had been engaging in random murder, [torture](https://en.wikipedia.org/wiki/Torture "Torture"), [wartime rape](https://en.wikipedia.org/wiki/Wartime_rape "Wartime rape"), [looting](https://en.wikipedia.org/wiki/Looting "Looting"), [arson](https://en.wikipedia.org/wiki/Arson "Arson"), and other [war crimes](https://en.wikipedia.org/wiki/War_crime "War crime") in the Nanjing area. These crimes skyrocketed after the Nanjing's capture on December 13, and continued for several weeks depending on the types of crime. The first three weeks were the most intense.[^1] Atrocities persisted in the Nanjing area for several months, both within the walled city and in the surrounding countryside, until the establishment of the new ruling government on March 28, 1938.[^4]

A group of foreign [expatriates](https://en.wikipedia.org/wiki/Expatriate "Expatriate") headed by Rabe had formed a 15-man [International Committee for the Nanking Safety Zone](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone") on November 22 and mapped out the [Nanking Safety Zone](https://en.wikipedia.org/wiki/Nanking_Safety_Zone "Nanking Safety Zone") in order to safeguard civilians in the city.[^67]

![](https://en.wikipedia.org/wiki/File:Photo_12_(The_%22Shame%22_Album).jpg)

Chinese children murdered by Japanese soldiers, their bodies dumped into a pond

In a diary entry from Minnie Vautrin on December 15, 1937, she wrote about her experiences in the Safety Zone:

> The Japanese have looted widely yesterday and today, have destroyed schools, have killed citizens, and raped women. One thousand disarmed Chinese soldiers, whom the International Committee hoped to save, were taken from them and by this time are probably shot or bayoneted. In our South Hill House Japanese broke the panel of the storeroom and took out some old fruit juice and a few other things.[^52]

### Organized massacres of Chinese prisoners of war and male civilians

#### "Mopping-up operations"

The fighting in Nanjing continued beyond the night of December 12–13, following the Japanese Army's capture of the remaining gates and entrance into the city. The Japanese army continued to encounter sporadic resistance from the remaining Chinese forces for several days, as many units were attempting to break out of the Japanese lines.[^68] The Japanese military determined that they needed to eliminate any remaining Chinese soldiers hidden within the city. However, the search process used an arbitrary criteria for identifying former Chinese soldiers. Chinese males who were deemed to be in good health were automatically presumed to be a soldier. During this operation, Japanese forces committed atrocities against the Chinese population.[^69]

![](https://en.wikipedia.org/wiki/File:Check_of_Chinese_soldiers_in_Nanking01.jpg)

Japanese Kempeitai inspect Chinese men for weapons

The criteria used in identifying former soldiers was often arbitrary, as was the case with one Japanese company which apprehended all men with "shoe sores, callouses on the face, extremely good posture, and/or sharp-looking eyes". For this reason many civilians were taken at the same time.[^70]

According to George Fitch, head of Nanjing's YMCA, " [rickshaw](https://en.wikipedia.org/wiki/Rickshaw "Rickshaw") coolies, carpenters, and other laborers are frequently taken".[^71] Chinese police officers and firefighters were also targeted, with even street sweepers and Buddhist burial workers from the [Red Swastika Society](https://en.wikipedia.org/wiki/Red_Swastika_Society "Red Swastika Society") being marched away on suspicion of being soldiers.[^72] Those who fled at the approach of any Japanese soldiers risked being shot.[^73]

![](https://en.wikipedia.org/wiki/File:Chinese_captives_in_Nanking.jpg)

Chinese prisoners captured near Mufu Mountain. All of them would be murdered within a few days.

The rounding-up and mass killings of male civilians and captured POWs were referred to euphemistically as "mopping-up operations" in Japanese communiqués, in a manner "just like the Germans were to talk about 'processing' or 'handling' Jews".[^74]

#### Mass executions

The massacres were organized to kill as many people within a short timeframe, which usually meant rows of unarmed prisoners being mowed down by machine gun fire before being finished off with bayonets or revolvers. The massacres were usually conducted on the banks of the Yangtze River to facilitate the mass disposal of corpses.[^75]

![](https://en.wikipedia.org/wiki/File:A_waterpond_filled_with_the_bodies_of_executed_Chinese_soldiers_who_got_safety_promise_by_Japanese_(b),_Nanjing_Massacre.jpg)

Chinese POWs who were executed by the Japanese army after false promises of clemency

In one of the largest massacres, on December 15–17, Japanese troops from the Yamada Detachment including the 65th Infantry Regiment systemically led 17,000 to 20,000 Chinese prisoners to the banks of the Yangtze River near Mufushan and machine-gunned them to death. They then disposed of the corpses by burning or flushing them downstream. Recent research by Ono Kenji has found that the mass killings were pre-planned and executed in a systemic manner in accordance with orders issued directly by Prince Asaka.[^61]

A soldier from the IJA's 13th Division described killing wounded survivors of the Mufushan massacre in his diary:[^76]

> I figured that I'd never get another chance like this, so I stabbed thirty of the damned Chinks. Climbing atop the mountain of corpses, I felt like a real devil-slayer, stabbing again and again, with all my might. 'Ugh, ugh,' the Chinks groaned. There were old folks as well as kids, but we killed them lock, stock, and barrel. I also borrowed a buddy's sword and tried to decapitate some. I've never experienced anything so unusual.

The Straw String Gorge Massacre occurred along the banks of the Yangtze River on December 18. For most of the morning, Japanese soldiers tied the POWs' hands together. At dusk, the soldiers divided POWs into four columns and opened fire. Unable to escape, the POWs could only scream and thrash desperately. It took an hour for the sounds of death to stop and even longer for the Japanese to bayonet each individual. The majority of the bodies were dumped directly into the Yangtze River.[^77]

In many other instances, prisoners were decapitated, used for bayonet practice, or tied together, doused in gasoline and set on fire. Wounded Chinese soldiers who remained in the city were killed in their hospital beds, bayonetted, clubbed, or dragged outside and burned alive.[^78]

The Japanese also extended their "search-and-destroy" operations to the Nanjing countryside. During the Battle of Nanjing, one of the Cantonese ([Guangdong](https://en.wikipedia.org/wiki/New_Guangxi_clique "New Guangxi clique")) armies had broken out of the Japanese encirclement and formed guerrilla bands that harassed Japanese forces whilst retreating south. In retaliation, Japanese units systemically wiped out towns and villages spread out in the outlying regions, perpetrating rapes, arson and indiscriminate massacres which "added up to an enormous number" of deaths.[^79]

![](https://en.wikipedia.org/wiki/File:Chinese_to_be_beheaded_in_Nanking_Massacre.jpg)

A Chinese POW about to be beheaded by a Japanese officer using a shin-guntō

Japanese troops gathered 1,300 Chinese soldiers and civilians at [Taiping Gate](https://en.wikipedia.org/wiki/Taiping_Gate?action=edit&redlink=1 "Taiping Gate (page does not exist)") and murdered them. The victims were blown up with [landmines](https://en.wikipedia.org/wiki/Landmine "Landmine"), then doused with petrol and set on fire. The survivors were killed with bayonets.[^80]

U.S. news correspondents [F. Tillman Durdin](https://en.wikipedia.org/wiki/F._Tillman_Durdin "F. Tillman Durdin") and [Archibald Steele](https://en.wikipedia.org/wiki/Archibald_Steele "Archibald Steele") reported seeing corpses of massacred Chinese soldiers forming mounds six feet high at the Nanjing Yijiang gate in the north. Durdin, who worked for *[The New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times")*, toured Nanjing before his departure from the city. He heard waves of machine-gun fire and witnessed the Japanese soldiers gun down some two hundred Chinese within ten minutes. He would later state that he had seen tank guns used on bound soldiers.

Two days later, in his report to *[The New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times")*, Durdin stated that the alleys and streets were filled with the dead, among them women and children. Durdin stated "\[i\]t should be said that certain Japanese units exercised restraint and that certain Japanese officers tempered power with generosity and commission", but continued "the conduct of the Japanese army as a whole in Nanjing was a blot on the reputation of their country".[^81] [^82]

![](https://en.wikipedia.org/wiki/File:Photo_11_(The_%22Shame%22_Album).jpg)

Japanese soldiers behead a Chinese man

Ralph L. Phillips, a [missionary](https://en.wikipedia.org/wiki/Missionary "Missionary"), testified to the U.S. State Assembly Investigating Committee, that he was "forced to watch while the Japs [disemboweled](https://en.wikipedia.org/wiki/Disemboweled "Disemboweled") a Chinese soldier" and "roasted his heart and liver and [ate them](https://en.wikipedia.org/wiki/Human_cannibalism "Human cannibalism") ".[^83]

Just after Christmas, the Japanese set up public stages where they called upon former Chinese soldiers to confess, claiming they would not be harmed. When over 200 former soldiers did come forward, they were promptly executed. When former soldiers stopped identifying themselves, the Japanese began rounding up groups of young men who "aroused suspicion".[^84]

#### Death toll

Based on the dutiful records of the Safety Zone committee, the post-war International Military Tribunal found that some 20,000 civilian men were killed on false accusations of being soldiers, while 30,000 former combatants were executed, and their bodies thrown into the river.[^85]

Durdin, who had left Nanjing on December 17 on the USS *Oahu*, had borne witness to the mass execution of captured Nationalist soldiers and suspected soldiers. He reported in early January that the Japanese had admitted to rounding up around 15,000 Chinese men in the first three days, and that they had captured another 25,000 Chinese soldiers who were systemically rounded up and executed.[^73]

Canadian historian Bob Wakabayashi's analysis of Japanese wartime records implicates Japanese forces in the illegal and "unjustifiable" mass murder of 46,215 men whom they considered Chinese military personnel, including men they had rounded up in civilian clothing.[^86]

Of these numbers, the IJA 16th Division executed between 4,000 and 12,000 prisoners near Xiaguan, then shoved the corpses into the Yangtze to transform it into a "river of dead bodies". The Mufu Mountains massacre, the deadliest of these mass killing incidents, saw the execution of between 17,000 and 20,000 male prisoners by the 65th Infantry Regiment of the IJA 13th Division. The 9th Division reported executing around 6,700 Chinese prisoners of war during their "mopping up operations".[^73]

### Mass rape

![](https://en.wikipedia.org/wiki/File:Killednanjing.jpg)

Photo taken in Xuzhou, showing the body of a woman who was profaned in a way similar to the teenager described in case 5 of John Magee 's film

The [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East") estimated that in the first month of the occupation, Japanese soldiers committed approximately 20,000 cases of rape in the city.[^87] Some estimates conclude there were 80,000 rapes.[^10] **[^88]**<sup><span title="Page: 155">: 155</span> </sup> According to the International Military Tribunal for the Far East, rapes of all ages, including children and elderly women, were commonplace, and there were many instances of sadistic and violent behavior related to these rapes. Following the rapes, many women were killed and their bodies were mutilated.[^87] A large number of rapes were done [systematically](https://en.wikipedia.org/wiki/Wartime_sexual_violence "Wartime sexual violence") by the Japanese soldiers as they went from door to door, searching for girls, with many women being captured and gang-raped.[^89]

Japanese soldier Takokoro Kozo recalled:

> Women suffered most. No matter how young or old, they all could not escape the fate of being raped. We sent out coal trucks to the city streets and villages to seize a lot of women. And then each of them was allocated to fifteen to twenty soldiers for sexual intercourse and abuse. After raping we would also kill them.[^90]

The women were often killed immediately after being raped, often through explicit [mutilation](https://en.wikipedia.org/wiki/Mutilation "Mutilation"),[^91] such as by penetrating vaginas with [bayonets](https://en.wikipedia.org/wiki/Bayonet "Bayonet"), long sticks of [bamboo](https://en.wikipedia.org/wiki/Bamboo "Bamboo"), or other objects. For example, a six-months pregnant woman was stabbed sixteen times in the face and body, one stab piercing and killing her unborn child. A young woman had a beer bottle rammed up her vagina after being raped, and was then shot. Edgar Snow wrote how "discards were often bayoneted by drunken Japanese soldiers".[^92]

![](https://en.wikipedia.org/wiki/File:Horrible_death,_Nanking_Massacre.jpg)

Case 5 of John Magee 's film: on December 13, 1937, about 30 Japanese soldiers murdered all but two of 11 Chinese in the house at No. 5 Xinlukou. A woman and her two teenaged daughters were raped, and Japanese soldiers rammed a bottle and a cane into her vagina. An eight-year-old girl was stabbed, but she and her younger sister survived. They were found alive two weeks after the killings by the elderly woman shown in the photo. Bodies of the victims can also be seen in the photo. 93 94

On December 19, 1937, the [Reverend](https://en.wikipedia.org/wiki/Reverend "Reverend") James M. McCallum wrote in his diary:[^95]

> I know not where to end. Never I have heard or read such brutality. Rape! Rape! Rape! We estimate at least 1,000 cases a night and many by day. In case of resistance or anything that seems like disapproval, there is a bayonet stab or a bullet... People are hysterical... Women are being carried off every morning, afternoon and evening. The whole Japanese army seems to be free to go and come as it pleases, and to do whatever it pleases.

A fifteen-year-old girl was locked naked in a barracks housing two hundred to three hundred Japanese soldiers and raped multiple times daily. American correspondent Edgar Snow wrote how "Frequently mothers had to watch their babies beheaded, and then submit to raping." YMCA head Fitch reported that a woman "had her five-months infant deliberately smothered by the brute to stop it crying while he raped her".[^92]

![](https://en.wikipedia.org/wiki/File:A_seven-year-old_child_bayoneted_dead_by_Japanese_in_Nanjing_Massacre.jpg)

Original caption by John Magee: "This is the corpse of a boy about seven years old who died three days after his admission into the University Hospital. He had received five bayonet wounds in the abdomen, one of them perforating the stomach."

![](https://en.wikipedia.org/wiki/File:A_16-year-old_girl_raped_by_Japanese_soldiers_during_the_Nanjing_Massacre.jpg)

A girl who was raped by Japanese soldiers

On March 7, 1938, [Robert O. Wilson](https://en.wikipedia.org/wiki/Robert_O._Wilson "Robert O. Wilson"), a surgeon at the university hospital in the Safety Zone administrated by the United States, wrote in a letter to his family, "a conservative estimate of people slaughtered in cold blood is somewhere about 100,000, including of course thousands of soldiers that had thrown down their arms".[^96] Here are two excerpts from his letters of December 15 and 18, 1937 to his family:[^97]

> The slaughter of civilians is appalling. I could go on for pages telling of cases of rape and brutality almost beyond belief. Two bayoneted corpses are the only survivors of seven street cleaners who were sitting in their headquarters when Japanese soldiers came in without warning or reason and killed five of their number and wounded the two that found their way to the hospital. Let me recount some instances occurring in the last two days. Last night, the house of one of the Chinese staff members of the university was broken into and two of the women, his relatives, were raped. Two girls, about 16, were raped to death in one of the refugee camps. In the University Middle School where there are 8,000 people the Japs came in ten times last night, over the wall, stole food, clothing, and raped until they were satisfied. They bayoneted one little boy of eight who \[had\] five bayonet wounds including one that penetrated his stomach, a portion of [omentum](https://en.wikipedia.org/wiki/Greater_omentum "Greater omentum") was outside the [abdomen](https://en.wikipedia.org/wiki/Abdomen "Abdomen"). I think he will live.

In his diary kept during the aggression against the city and its occupation by the [Imperial Japanese Army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army"), the leader of the Safety Zone, [John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe"), wrote many comments about Japanese atrocities. For December 17:[^98]

> Two Japanese soldiers have climbed over the garden wall and are about to break into our house. When I appear they give the excuse that they saw two Chinese soldiers climb over the wall. When I show them my party badge, they return the same way. In one of the houses in the narrow street behind my garden wall, a woman was raped, and then wounded in the neck with a bayonet. I managed to get an ambulance so we can take her to Kulou Hospital... Last night up to 1,000 women and girls are said to have been raped, about 100 girls at [Ginling College](https://en.wikipedia.org/wiki/Ginling_College "Ginling College")...alone. You hear nothing but rape. If husbands or brothers intervene, they're shot. What you hear and see on all sides is the brutality and bestiality of the Japanese soldiers.

In a documentary film about the Nanjing Massacre, *In the Name of the Emperor*, a former Japanese soldier named [Shiro Azuma](https://en.wikipedia.org/wiki/Shiro_Azuma "Shiro Azuma") spoke candidly about their treatment of women in Nanjing, telling that they would first expose the women's intimate parts:

> At first we used some kinky words like Pikankan. Pi means "hip", kankan means "look". Pikankan means, "Let's see a woman open up her legs." Chinese women didn't wear under-pants. Instead, they wore trousers tied with a string. There was no belt. As we pulled the string, the buttocks were exposed. We "pikankan". We looked.[^99]

Afterwards, rape and even murder would often follow: "We took turns raping them. It would be all right if we only raped them. I shouldn't say all right. But we always stabbed and killed them. Because dead bodies don't talk." [^99]

[Iris Chang](https://en.wikipedia.org/wiki/Iris_Chang "Iris Chang") wrote *[The Rape of Nanking](https://en.wikipedia.org/wiki/The_Rape_of_Nanking_\(book\) "The Rape of Nanking (book)")*, one of the most comprehensive accounts of Japanese war atrocities in China.[^100] Chang estimates that the number of Chinese women raped by Japanese soldiers ranged from 20,000 to 80,000. She also states that not all rape victims were women. Some Chinese men were [sodomized](https://en.wikipedia.org/wiki/Sodomized "Sodomized") and forced to perform "repulsive sex acts".[^101] [^103] Japanese soldiers also raped teenage boys.[^107]

There are also accounts of Japanese troops coercing families into committing incestuous acts; sons were forced to rape their mothers, fathers their daughters, and brothers their sisters. Other family members would be forced to look on.[^108] [^102] Instead of punishing the Japanese troops who were responsible for wholesale rape, "'The Japanese expeditionary Force in Central China issued an order to set up [comfort houses](https://en.wikipedia.org/wiki/Comfort_women "Comfort women") during this period of time,' [Yoshimi Yoshiaki](https://en.wikipedia.org/wiki/Yoshimi_Yoshiaki "Yoshimi Yoshiaki"), a prominent history professor at Chuo University, observes, 'because Japan was afraid of criticism from China, the United States of America and Europe following the case of massive rapes between battles in Shanghai and Nanjing.'" [^110]

### Massacres of civilians

![](https://en.wikipedia.org/wiki/File:Boy_killed_in_Nanking_massacre.jpg)

A boy killed by a Japanese soldier with the butt of a rifle, reportedly because he did not take off his hat

For about three weeks since December 13, 1937,[^19] the [Imperial Japanese Army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army") entered the [Nanking Safety Zone](https://en.wikipedia.org/wiki/Nanking_Safety_Zone "Nanking Safety Zone") to search for former Chinese soldiers hidden among refugees. Many innocent men were misidentified and murdered.[^19]

![](https://en.wikipedia.org/wiki/File:Chinese_burned_by_Japanese_in_Nanjing.jpg)

The corpse of a Chinese man burned to death by kerosene

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e3/Japanese_looting_near_a_gate%2C_Nanking_massacre.JPG/250px-Japanese_looting_near_a_gate%2C_Nanking_massacre.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Dead civilians by one of Nanjing's gates

John Rabe summarized the behavior of Japanese troops in Nanjing in his diaries:

> I've written several times in this diary about the body of the Chinese soldier who was shot while tied to his bamboo bed and who is still lying unburied near my house. My protests and pleas to the Japanese embassy finally to get this corpse buried, or give me permission to bury it, have thus far been fruitless. The body is still lying in the same spot as before, except that the ropes have been cut and the bamboo bed is now lying about two yards away. I am totally puzzled by the conduct of the Japanese in this matter. On the one hand, they want to be recognized and treated as a great power on a par with European powers, on the other, they are currently displaying a crudity, brutality, and bestiality that bears no comparison except with the hordes of Genghis Khan. I have stopped trying to get the poor devil buried, but I hereby record that he, though very dead, still lies above the earth![^104]

The death toll of civilians is difficult to precisely calculate due to the many bodies deliberately burnt, buried in mass graves, or dumped into the [Yangtze](https://en.wikipedia.org/wiki/Yangtze "Yangtze") River.[^105] [^106] [Robert O. Wilson](https://en.wikipedia.org/wiki/Robert_O._Wilson "Robert O. Wilson"), a physician, testified that cases of gun wounds "continued to come in \[to the hospital of [University of Nanjing](https://en.wikipedia.org/wiki/University_of_Nanking "University of Nanking")\] for a matter of some six or seven weeks following the fall of the city on December 13, 1937. The capacity of the hospital was normally one hundred and eighty beds, and this was kept full to overflowing during this entire period.[^114]

Sociologist Bradley Campbell described the Nanjing Massacre as a [genocide](https://en.wikipedia.org/wiki/Genocide "Genocide"), given the fact that residents were still killed in large numbers during the aftermath, despite the successful and certain outcome in battle.[^115] Historian [Jean-Louis Margolin](https://en.wikipedia.org/wiki/Jean-Louis_Margolin "Jean-Louis Margolin") wrote that while the executions of prisoners of war in Nanjing were systematic and tolerated by higher officers, the killings of civilians were individual acts not ordered by command. He therefore argued that the massacre did not reflect a centrally directed genocidal policy.[^116] Historian [Yuki Tanaka](https://en.wikipedia.org/wiki/Yuki_Tanaka_\(historian\) "Yuki Tanaka (historian)") argues that while the Japanese government did not endorse a clear policy of genocide, the military campaign in China was "undoubtedly genocidal", with Nanjing being a typical example of a genocidal massacre.[^117] On December 13, 1937, John Rabe wrote in his diary:

> It is not until we tour the city that we learn the extent of destruction. We come across corpses every 100 to 200 yards. The bodies of civilians that I examined had bullet holes in their backs. These people had presumably been fleeing and were shot from behind. The Japanese march through the city in groups of ten to twenty soldiers and loot the shops... I watched with my own eyes as they looted the café of our German baker Herr Kiessling. Hempel's hotel was broken into as well, as \[was\] almost every shop on Chung Shang and Taiping Road.[^118]

American vice consul James Espy arrived in Nanjing on January 6, 1938, to reopen the American embassy. He gave a summarized description of what happened in the city:

> The picture that they painted of Nanking was one of a reign of terror that befell the city upon its occupation by the Japanese military forces. Their stories and those of the German residents tell of the city having fallen into the hands of the Japanese as captured prey, not merely taken in the course of organized warfare but seized by an invading army whose members seemed to have set upon the prize to commit unlimited depredations and violence. Fuller data and our own observations have not brought out facts to discredit their information. The civilian Chinese population remaining in the city crowded the streets of the so-called "safety zone" as refugees, many of whom are destitute. Physical evidences are almost everywhere to the killing of men, women and children, of the breaking into and looting of property and of the burning and destruction of houses and buildings.
> 
> It remains, however, the Japanese soldiers swarmed over the city in thousands and committed untold depredations and atrocities. It would seem according to stories told us by foreign witnesses that the soldiers were let loose like a barbarian horde to desecrate the city. Men, women and children were killed in uncounted numbers throughout the city. Stories are heard of civilians being shot or bayoneted for no apparent reason.[^119]

On February 10, 1938, [Legation](https://en.wikipedia.org/wiki/Legation "Legation") Secretary of the German Embassy, [Georg Rosen](https://en.wikipedia.org/wiki/Georg_Rosen_\(1895%E2%80%931961\) "Georg Rosen (1895–1961)"), wrote to his Foreign Ministry about a film made in December by Reverend [John Magee](https://en.wikipedia.org/wiki/John_Magee_\(missionary\) "John Magee (missionary)") to recommend its purchase.

> During the Japanese reign of terror in Nanjing—which, by the way, continues to this day to a considerable degree—the Reverend John Magee, a member of the American Episcopal Church Mission who has been here for almost a quarter of a century, took motion pictures that eloquently bear witness to the atrocities committed by the Japanese... One will have to wait and see whether the highest officers in the Japanese army succeed, as they have indicated, in stopping the activities of their troops, which continue even today.[^118] On December 13, about 30 soldiers came to a Chinese house at No. 5 Hsing Lu Koo in the southeastern part of Nanjing and demanded entrance. The door was open\[ed\] by the landlord, a [Mohammedan](https://en.wikipedia.org/wiki/Islam_in_China "Islam in China") named Ha. They killed him immediately with a revolver and also Mrs. Ha, who knelt before them after Ha's death, begging them not to kill anyone else. Mrs. Ha asked them why they killed her husband and they shot her. Mrs. Hsia was dragged out from under a table in the guest hall where she had tried to hide with her 1-year-old baby. After being stripped and raped by one or more men, she was bayoneted in the chest and then had a bottle thrust into her vagina. The baby was killed with a bayonet. Some soldiers then went to the next room, where Mrs. Hsia's parents, aged 76 and 74, and her two daughters aged 16 and 14 \[were\]. They were about to rape the girls when the grandmother tried to protect them. The soldiers killed her with a revolver. The grandfather grasped the body of his wife and was killed. The two girls were then stripped, the elder being raped by 2–3 men and the younger by 3. The older girl was stabbed afterwards and a cane was rammed in her vagina. The younger girl was bayoneted also but was spared the horrible treatment that had been meted out to her sister and mother. The soldiers then bayoneted another sister of between 7–8, who was also in the room. The last murders in the house were of Ha's two children, aged 4 and 2 respectively. The older was bayoneted and the younger split down through the head with a sword.[^118]

![](https://en.wikipedia.org/wiki/File:LI_Xiuying_in_hospital,_Nanking_massacre.jpg)

Original caption by John Magee: "This nineteen-year-old woman was a refugee at the American School in the Refugee Zone. She was six and one-half months pregnant with her first child. She resisted rape and was therefore stabbed many times by a Japanese soldier. She has nineteen cuts on her face, eight on her legs, and a cut two inches deep in her abdomen. This caused a miscarriage the day after her entrance into the University Hospital. She recovered from her wounds."

![](https://en.wikipedia.org/wiki/File:Bodies_of_Chinese_massacred_by_Japanese_troops_along_a_river_in_Nanjing_(Murase_Moriyasa's_photo)_01.jpg)

Bodies of Chinese massacred by Japanese troops along a river in Nanjing

Pregnant women were targeted for murder, as their stomachs were often bayoneted, sometimes after rape. Tang Junshan, survivor and witness to one of the Japanese army's systematic mass killings, testified:[^120]

> The seventh and last person in the first row was a pregnant woman. The soldier thought he might as well rape her before killing her, so he pulled her out of the group to a spot about ten meters away. As he was trying to rape her, the woman resisted fiercely... The soldier abruptly stabbed her in the belly with a bayonet. She gave a final scream as her intestines spilled out. Then the soldier stabbed the fetus, with its umbilical cord clearly visible, and tossed it aside.

According to Navy veteran Sho Mitani, "The Army used a trumpet sound that meant 'Kill all Chinese who run away'." [^121] Thousands were led away and mass-executed in an excavation known as the "Ten-Thousand-Corpse Ditch", a trench measuring about 300 m long and 5 m wide. Since records were not kept, estimates regarding the number of victims buried in the ditch range from 4,000 to 20,000.

The [Hui people](https://en.wikipedia.org/wiki/Hui_people "Hui people"), a minority Chinese group, the majority of them Muslim, suffered as well during the massacre. One mosque was found destroyed and others found to be "filled with dead bodies". Hui volunteers and [imams](https://en.wikipedia.org/wiki/Imam "Imam") buried over a hundred of their dead following Muslim ritual.[^122]

The Japanese massacred [Hui Muslims](https://en.wikipedia.org/wiki/Hui_Muslims "Hui Muslims") in their mosques in Nanjing and destroyed Hui mosques in other parts of China.[^123] [^124] [^125]

### Looting and arson

Stationed in Nanjing, an eyewitness, journalist Frank Tillman Durdin, of *[The New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times")*, sent an article to his newspaper where he described the [Imperial Japanese Army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army") 's entry into Nanjing in December 1937: "The plunder carried out by the Japanese reached almost the entire city. Almost all buildings were entered by Japanese soldiers, often in the sight of their officers, and the men took whatever they wanted. Japanese soldiers often forced Chinese to carry the loot." [^126]

One-third of the city was destroyed as a result of arson. According to reports, Japanese troops torched newly built government buildings as well as the homes of many civilians. There was considerable destruction to areas outside the city walls. Soldiers pillaged from the poor and the wealthy alike. The lack of resistance from Chinese troops and civilians in Nanjing meant that the Japanese soldiers were free to divide up the city's valuables as they saw fit. This resulted in widespread looting and burglary.[^127]

On December 17, chairman [John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe") wrote a complaint to Kiyoshi Fukui, second secretary of the Japanese Embassy. The following is an excerpt:

> In other words, on the 13th when your troops entered the city, we had nearly all the civilian population gathered in a Zone in which there had been very little destruction by stray shells and no looting by Chinese soldiers even in full retreat... All 27 Occidentals in the city at that time and our Chinese population were totally surprised by the reign of robbery, raping and killing initiated by your soldiers on the 14th. All we are asking in our protest is that you restore order among your troops and get the normal city life going as soon as possible. In the latter process we are glad to cooperate in any way we can. But even last night between 8 and 9 p.m. when five Occidental members of our staff and Committee toured the Zone to observe conditions, we did not find any single Japanese patrol either in the Zone or at the entrances![^128]

### Nanking Safety Zone and the role of foreigners

The Japanese troops did respect the Zone to an extent; until the Japanese occupation, no shells entered that part of the city except a few stray shots. During the chaos following the attack of the city, some were killed in the Safety Zone, but the crimes that occurred in the rest of the city were far greater by all accounts.[^129]

Rabe wrote that, from time to time, the Japanese would enter the Safety Zone at will, carry off a few hundred men and women, and either summarily execute them or rape and then kill them.[^130]

By February 5, 1938, the [International Committee for the Nanking Safety Zone](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone") had forwarded to the Japanese embassy a total of 450 cases of murder, rape, torture and general disorder by Japanese soldiers that had been reported after the American, British and German diplomats had returned to their embassies:[^131]

- "Case 5 – On the night of December 14th, there were many cases of Japanese soldiers entering houses and raping women or taking them away. This created panic in the area and hundreds of women moved into the Ginling College campus yesterday."
- "Case 10 – On the night of December 15th, a number of Japanese soldiers entered the University of Nanjing buildings at Tao Yuen and raped 30 women on the spot, some by six men."
- "Case 13 – December 18, 4 p.m., at No. 18 I Ho Lu, Japanese soldiers wanted a man's cigarette case and when he hesitated, one of the soldier crashed in the side of his head with a bayonet. The man is now at the University Hospital and is not expected to live."
- "Case 14 – On December 16, seven girls (ages ranged from 16 to 21) were taken away from the Military College. Five returned. Each girl was raped six or seven times daily – reported December 18th."
- "Case 15 – There are about 540 refugees crowded in No. 83 and 85 on Canton Road... More than 30 women and girls have been raped. The women and children are crying all nights. Conditions inside the compound are worse than we can describe. Please give us help."
- "Case 16 – A Chinese girl named Loh, who, with her mother and brother, was living in one of the Refugee Centers in the Refugee Zone, was shot through the head and killed by a Japanese soldier. The girl was 14 years old. The incident occurred near the Kuling Ssu, a noted temple on the border of the Refugee zone..." [^131]
- "Case 19 – January 30th, about 5 p.m. [Mr. Sone](https://en.wikipedia.org/wiki/Hubert_Lafayette_Sone "Hubert Lafayette Sone") (of the [Nanjing Theological Seminary](https://en.wikipedia.org/wiki/Nanjing_Theological_Seminary "Nanjing Theological Seminary")) was greeted by several hundred women pleading with him that they would not have to go home on February 4th. They said it was no use going home they might just as well be killed for staying at the camp as to be raped, robbed or killed at home... One old woman 62 years old went home near Hansimen and Japanese soldiers came at night and wanted to rape her. She said she was too old. So the soldiers rammed a stick up her. But she survived to come back."

It is said that Rabe rescued between 200,000 and 250,000 Chinese people.[^132] [^133]

- ![Photo in the album taken in Nanjing by Itou Kaneo of the Kisarazu Air Unit of the Imperial Japanese Navy](https://en.wikipedia.org/wiki/File:Photo_02_in_Nanjing_Massacre_(Itou_Kaneo's_Album).jpg)
	Photo in the album taken in Nanjing by Itou Kaneo of the Kisarazu Air Unit of the Imperial Japanese Navy
	Photo in the album taken in Nanjing by Itou Kaneo of the [Kisarazu Air Unit](https://en.wikipedia.org/wiki/Kisarazu_Air_Group "Kisarazu Air Group") of the Imperial Japanese Navy
- ![A picture of a dead child. Probably taken by Bernhard Sindberg](https://en.wikipedia.org/wiki/File:Child_killed_in_Nanking_massacre.jpg)
	A picture of a dead child. Probably taken by Bernhard Sindberg
	A picture of a dead child. Probably taken by [Bernhard Sindberg](https://en.wikipedia.org/wiki/Bernhard_Arp_Sindberg "Bernhard Arp Sindberg")
- ![Prisoners being buried alive](https://en.wikipedia.org/wiki/File:Chinese_civilians_to_be_buried_alive.jpg)
	Prisoners being buried alive
	Prisoners being buried alive [^134]
- ![Skeletons of the massacre's victims](https://en.wikipedia.org/wiki/File:Victims_in_Nanjing_massacre.jpg)
	Skeletons of the massacre's victims
	[Skeletons](https://en.wikipedia.org/wiki/Skeleton "Skeleton") of the massacre's victims
- ![A pond filled with dead victims](https://en.wikipedia.org/wiki/File:A_waterpond_filled_with_the_bodies_of_executed_Chinese_soldiers_who_got_safety_promise_by_Japanese_(b),_Nanjing_Massacre.jpg)
	A pond filled with dead victims
	A pond filled with dead victims
- ![Another photo from Itou Kaneo's album, displaying Chinese corpses](https://en.wikipedia.org/wiki/File:Photo_03_in_Nanjing_Massacre_(Itou_Kaneo's_Album).png)
	Another photo from Itou Kaneo's album, displaying Chinese corpses
	Another photo from Itou Kaneo's album, displaying Chinese corpses

### Literature

Eyewitness accounts include testimonies of expatriates engaged in humanitarian work (mostly physicians, professors, missionaries, and businessmen), journalists (both Western and Japanese), as well as the field diaries of military personnel. American missionary [John Magee](https://en.wikipedia.org/wiki/John_Magee_\(missionary\) "John Magee (missionary)") stayed behind to provide a 16 mm film [documentary](https://en.wikipedia.org/wiki/Documentary "Documentary") and first-hand photographs of the Nanjing Massacre. Rabe and American missionary [Lewis S. C. Smythe](https://en.wikipedia.org/wiki/Lewis_S._C._Smythe "Lewis S. C. Smythe"), secretary of the International Committee and a professor of [sociology](https://en.wikipedia.org/wiki/Sociology "Sociology") at the [University of Nanjing](https://en.wikipedia.org/wiki/University_of_Nanking "University of Nanking"), recorded the actions of the Japanese troops and filed complaints with the [Japanese embassy](https://en.wikipedia.org/wiki/Japanese_embassy "Japanese embassy").

## Causes

The Nanjing Massacre was influenced by several factors. The Japanese population was taught militaristic and [racist](https://en.wikipedia.org/wiki/Racist "Racist") ideologies. The Japanese government's [fascist](https://en.wikipedia.org/wiki/Fascist "Fascist") doctrine further propagated the belief in Japanese superiority over all other peoples. Other factors include the cruel treatment of Japanese soldiers by their commanders, the brutalization of the Japanese rank and file within the challenging combat conditions in China, and the presence of misogynistic attitudes in Japanese society.[^135] [^136]

### Racism and ultranationalism

![](https://en.wikipedia.org/wiki/File:BattleofShanghaiwarcrime.png)

A Japanese soldier slashes the throat of a prisoner in Shanghai, late October. Japanese atrocities had been in evidence months before the Nanjing Massacre.

The Nanjing Massacre occurred amidst Japan's invasion of China. The extreme cruelty witnessed in Nanjing, including extensive killing, torture, sexual violence, and looting, was not an isolated incident, but rather a reflection of Japan's behavior throughout the 1937 [Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai") – [Nanjing](https://en.wikipedia.org/wiki/Battle_of_Nanjing "Battle of Nanjing") Campaign in the Lower Yangtze Delta, and to that extent the entire war in China. This violence cannot be separated from the underlying contempt for other Asians that was deeply ingrained in Japanese society before the war.[^137]

To demonstrate the profound effects of ethnic prejudice, Japanese author Tsuda Michio gives an example:

> During the war in south China, a Japanese sergeant who had raped and killed numerous Chinese women became 'impotent' as soon as he found out to his shock that one of his victims was actually a Japanese woman who had married a Chinese man and emigrated to China.[^137]

[Shiro Azuma](https://en.wikipedia.org/wiki/Shiro_Azuma "Shiro Azuma"), a former Japanese soldier, testified in a 1998 interview:

> When I tried to cut off the first one, either the farmer moved or I mis-aimed. I ended up slicing off just part of his skull. Blood spurted upwards. I swung again... and this time I killed him... We were taught that we were a superior race since we lived only for the sake of a human god—our emperor. But the Chinese were not. So we held nothing but contempt for them... There were many rapes, and the women were always killed. When they were being raped, the women were human. But once the rape was finished, they became pig's flesh.[^138]

### Structural violence in the Japanese military

The brutality exhibited by Japanese soldiers in Nanjing partially stemmed from a Japanese military hierarchy where discipline was systematically reinforced by violent means. Japanese recruits were often subject to harsh abuse during their training, whilst Japanese soldiers were often disciplined violently by officers, ranging from slaps to beatings, while those officers were in turn disciplined by their superiors.[^136]

Historian Edward Drea writes that the brutalization and hierarchy of violence within the Imperial Japanese Army socialized many of its members to become accepting of a culture of cruelty against those perceived as weaker. Consequently, many amongst the Japanese rank and file routinely vented their rage and frustrations against helpless civilians, as demonstrated in Nanjing.[^139]

Thus, Japanese soldiers often killed innocent civilians out of excitement or "sheer sadistic pleasure".[^140] Similarly, Japanese soldiers were known to derive sadistic pleasure from setting houses aflame and watching them burn.[^141]

### A breakdown in discipline

Japanese behavior in Nanjing can also be partially attributed to a breakdown in discipline. Japanese soldiers, underpaid and suffering from low morale, were emboldened by a sense of freedom and a lack of consequences. Furthermore, Japanese officers either ignored or actively participated in the atrocities of their juniors.[^15] [^142]

Consequently, Japanese soldiers perpetrated and engaged in gratuitous atrocities, often "out of boredom" or in a "cheap search for thrills". In one such case, a group of Japanese soldiers doused a child in kerosene and then set him on fire for refusing to lead them to his "mama".[^143]

### Rage and revenge

Another cause that has been used to explain Japanese behavior in Nanjing was a buildup of rage and a widespread desire for revenge after months of fighting the Chinese. American officer Frank Dorn observed that Japanese cruelty against the Chinese populace came as a result of a frustration because the Chinese "did not want to be saved".[^144] Frank Dorn wrote:

> Brainwashed into a pseudoidealistic belief that his mission was essentially a crusade to liberate the Chinese people from oppression, the average Japanese soldier had been *shocked* at the rejection of his efforts at liberation.[^145]

Jennifer M. Dixon, Associate Professor in the Department of Political Science at [Villanova University](https://en.wikipedia.org/wiki/Villanova_University "Villanova University"), stated:

> In addition, the Battle of Shanghai which preceded the capture of Nanjing, was more difficult and prolonged than the Japanese side had anticipated, which contributed to a desire among Japanese officers and soldiers to exact revenge on the Chinese.[^135]

Prime Minister [Fumimaro Konoe](https://en.wikipedia.org/wiki/Fumimaro_Konoe "Fumimaro Konoe"), who presided over the Second Sino-Japanese War,[^146] justified the massacre as retaliation against persistent Kuomintang aggression,[^147] and advocated for the regime's destruction in January 1938.[^148] Prior to the fall of Nanjing, Konoe rejected Chiang Kai-Shek's offer of negotiation through a German ambassador.[^147] [Jonathan Spence](https://en.wikipedia.org/wiki/Jonathan_Spence "Jonathan Spence"), a British-American [sinologist](https://en.wikipedia.org/wiki/Sinologist "Sinologist") and historian, wrote:

> \[T\]here is no obvious explanation for this grim event, nor can one be found. The Japanese soldiers, who had expected easy victory, instead had been fighting hard for months and had taken infinitely higher casualties than anticipated. They were bored, angry, frustrated, tired. The Chinese women were undefended, their menfolk powerless or absent. The war, still undeclared, had no clear-cut goal or purpose. Perhaps all Chinese, regardless of sex or age, seemed marked out as victims.[^149]

### Misogyny

Historian [Richard B. Frank](https://en.wikipedia.org/wiki/Richard_B._Frank "Richard B. Frank") draws a parallel from the violence in Nanjing to the misogynistic attitudes present in Japanese society. Rampant physical violence against women in Japan translated into mass rape and sexual torture in wartime China.[^136]

## Matsui's reaction to the massacre

On December 18, 1937, as General [Iwane Matsui](https://en.wikipedia.org/wiki/Iwane_Matsui "Iwane Matsui") began to comprehend the full extent of the rape, torture, murder, and looting in the city, he grew increasingly dismayed. He reportedly told one of his civilian aides:

> I now realize that we have unknowingly wrought a most grievous effect on this city. When I think of the feelings and sentiments of many of my Chinese friends who have fled from Nanjing and of the future of the two countries, I cannot but feel depressed. I am very lonely and can never get in a mood to rejoice about this victory... I personally feel sorry for the tragedies to the people, but the Army must continue unless China repents. Now, in the winter, the season gives time to reflect. I offer my sympathy, with deep emotion, to a million innocent people.

On New Year's Day, over a toast he confided to a Japanese diplomat: "My men have done something very wrong and extremely regrettable." [^150]

Matsui blamed the atrocities on the moral decline of the Japanese Army, saying:

> The Nanjing Incident was a terrible disgrace... Immediately after the memorial services, I assembled the higher officers and wept tears of anger before them, as Commander-in-Chief... I told them that after all our efforts to enhance the Imperial prestige, everything had been lost in one moment through the brutalities of the soldiers. And can you imagine it, even after that, these officers laughed at me... I am really, therefore, quite happy that I, at least, should have ended this way, in the sense that it may serve to urge self-reflection on many more members of the military of that time.[^151]

## End of the massacre

In late January 1938, the Japanese army forced all refugees in the Safety Zone to return home, immediately claiming to have "restored order". After the establishment of the *weixin zhengfu* ([Chinese](https://en.wikipedia.org/wiki/Chinese_language "Chinese language"): 维新政府; [pinyin](https://en.wikipedia.org/wiki/Pinyin "Pinyin"): *Wéixīn zhèngfǔ*) [(the collaborating government) in 1938](https://en.wikipedia.org/wiki/Reformed_Government_of_the_Republic_of_China "Reformed Government of the Republic of China"), order was gradually restored in Nanjing and atrocities by Japanese troops lessened considerably.

On February 18, 1938, the [International Committee for the Nanking Safety Zone](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone") was forcibly renamed the Nanjing International Rescue Committee, and the Safety Zone effectively ceased to function. The last refugee camps were closed in May 1938.[^152]

## Recall of Matsui and Asaka

In February 1938, both Prince Asaka and General Matsui were recalled to Japan. Matsui returned to retirement, but Prince Asaka remained on the [Supreme War Council](https://en.wikipedia.org/wiki/Supreme_War_Council_\(Japan\) "Supreme War Council (Japan)") until the end of the war in August 1945. He was promoted to the rank of [general](https://en.wikipedia.org/wiki/General "General") in August 1939, though he held no further military commands.[^58]

## Evidence collection

The Japanese either destroyed or concealed important documents, severely reducing the amount of evidence available for confiscation. Between the declaration of a ceasefire on August 15, 1945, and the arrival of American troops in Japan on August 28, "the Japanese military and civil authorities systematically destroyed military, naval, and government archives, much of which was from the period 1942–1945".[^153] Overseas troops in the Pacific and East Asia were ordered to destroy incriminating evidence of war crimes.[^153] Approximately 70 percent of the Japanese army's wartime records were destroyed.[^153] In regards to the Nanjing Massacre, Japanese authorities deliberately concealed wartime records, eluding confiscation from American authorities.[^154] Some of the concealed information was only made public decades later. For example, a two-volume collection of military documents related to the Nanjing operations was published in 1989; and disturbing excerpts from [Kesago Nakajima](https://en.wikipedia.org/wiki/Kesago_Nakajima "Kesago Nakajima") 's diary, a commander at Nanjing, was published in the early 1980s.[^154]

According to American historian [Edward J. Drea](https://en.wikipedia.org/wiki/Edward_J._Drea "Edward J. Drea"):

> While the Germans, beginning in 1943, did engage in substantial efforts to obliterate evidence of such crimes as mass murder, and they destroyed a great deal of potentially incriminating records in 1945, a great deal survived, in part because not each one of the multiple copies had been burned. The situation was different in Japan. Between the announcement of a ceasefire on August 15, 1945, and the arrival of small advance parties of American troops in Japan on August 28, Japanese military and civil authorities systematically destroyed military, naval, and government archives, much of which was from the period 1942–1945. Imperial General Headquarters in Tokyo dispatched enciphered messages to field commands throughout the Pacific and East Asia ordering units to burn incriminating evidence of war crimes, especially offenses against prisoners of war.[^155]

According to Yang Daqing, professor of History and International Affairs at [George Washington University](https://en.wikipedia.org/wiki/George_Washington_University "George Washington University"):

> While it is standard practice for governments to destroy evidence in times of defeat, in the two weeks before the Allies arrived in Japan, various Japanese agencies—the military in particular—systematically destroyed sensitive documents to a degree perhaps unprecedented in history. Estimates of the impact of the destruction vary. Tanaka Hiromi, a professor at Japan's National Defense Academy who has conducted extensive research into remaining Imperial Japanese Army and Navy documents in Japan and overseas, claims that less than 0.1 percent of the material ordered for destruction survived.[^156]

In 2003, the director of Japan's Military History Archives of the National Institute for Defense Studies said that as much as 70 percent of Japan's wartime records were destroyed.[^155]

During his time in China, [Bernhard Arp Sindberg](https://en.wikipedia.org/wiki/Bernhard_Arp_Sindberg "Bernhard Arp Sindberg"), an amateur photographer and friend to several foreign journalists, always had his camera with him, taking graphic photos of the civilian massacres and extensive destruction.[^157] Sindberg smuggled the unprocessed film out of China with the help of his company and had entrusted the development of the film to his colleagues. After the war, he retrieved his photos, producing one of the few photographic records documenting the Nanjing massacre.[^157]

Ono Kenji, a chemical worker in Japan, procured a collection of wartime diaries from Japanese veterans who fought in the Battle of Nanjing in 1937.[^158] In 1994, nearly 20 diaries in his collection were published, which became an important source of evidence for the massacre. Official war journals and diaries were also published by [Kaikosha](https://en.wikipedia.org/wiki/Kaikosha "Kaikosha"), an organization of retired Japanese military veterans.[^158]

In 1984, in an attempt to refute accusations of Japanese war crimes in Nanjing, Kaikosha, the Japanese Army Veterans Association, interviewed former Japanese soldiers who had served in the Nanjing area from 1937 to 1938. Instead of refuting the massacre, the interviewed veterans confirmed that a massacre had taken place and openly described and admitted to taking part in the atrocities. In 1985, the interviews were published in the association's magazine, *Kaiko*, along with an admission and apology that read, "Whatever the severity of war or special circumstances of war psychology, we just lose words faced with this mass illegal killing. As those who are related to the prewar military, we simply apologize deeply to the people of China. It was truly a regrettable act of barbarity." [^159]

In early 1980s, after interviewing Chinese survivors and reviewing Japanese records, Japanese journalist [Honda Katsuichi](https://en.wikipedia.org/wiki/Honda_Katsuichi "Honda Katsuichi") concluded that the Nanjing Massacre was not an isolated case, and that Japanese atrocities against the Chinese were common throughout the Lower [Yangtze River](https://en.wikipedia.org/wiki/Yangtze_River "Yangtze River") since the [battle of Shanghai](https://en.wikipedia.org/wiki/Battle_of_Shanghai "Battle of Shanghai").[^33] The diaries of other Japanese combatants and medics who fought in China have corroborated his conclusions.[^33]

Responding in part to the influence of Japanese war crime denialists in Japan's public sphere, since the 1980s the government of China has sponsored academic research and other projects to collect evidence of the Nanjing Massacre and other Japanese atrocities during the war.**[^160]**<sup><span title="Page: 155">: 155</span></sup>

## Death toll estimates

![](https://en.wikipedia.org/wiki/File:%E5%8D%97%E4%BA%AC%E4%BA%BA%E6%96%87%E4%B9%8B%E6%97%85-%E8%82%83%E7%A9%86_-_panoramio_(1).jpg)

A monument at the Nanjing Massacre Memorial Hall that says there were 300,000 victims, in multiple languages

Numerous factors complicate the estimation of an accurate death toll.[^155] [^161] The most pressing include the systemic destruction of wartime records by Japanese military officials; the mass disposal of Chinese corpses by Japanese soldiers; the revisionist tendencies of both Chinese and Japanese individuals and groups, who are often driven by nationalistic and political motivations; and the subjectivity involved in the collection and interpretation of evidence.[^10] [^162] [^161] [^163] However, the most credible scholars in Japan, which include a large number of authoritative academics, support the validity of the [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East") and its findings, which estimate more than 200,000 casualties.[^7] [^162]

Japanese historian [Tokushi Kasahara](https://en.wikipedia.org/wiki/Tokushi_Kasahara "Tokushi Kasahara") estimates a death toll of "more than 100,000 and close to 200,000, or maybe more".[^164] With the emergence of more information and data, he said that there is a possibility that the death toll could be higher. Hiroshi Yoshida concludes "more than 200,000" in his book.[^165] [Tomio Hora](https://en.wikipedia.org/wiki/Tomio_Hora "Tomio Hora") supports the information found in the International Military Tribunal for the Far East, which estimates a death toll of at least 200,000.[^166] [^167] An estimated death toll of 300,000 has also been cited.[^112]

![](https://en.wikipedia.org/wiki/File:Bodies_piled_on_the_shore_of_Yangtze_River,_Nanking_Massacre.jpg)

Dead Chinese civilians near Xiaguan, their corpses deliberately burned by the Japanese

Canadian historian Bob Wakabayashi puts the total number of Chinese who died in December 1937 alone at 109,475, including massacre victims and soldiers killed in action. Of this number, an analysis of Japanese wartime records implicates Japanese forces in the illegal and "unjustifiable" mass murder of 46,215 men whom they considered Chinese military personnel, including men they had rounded up in civilian clothing.[^86]

In addition to male prisoners, Wakabayashi also adds tens of thousands of murdered Chinese civilians to the death toll, both within the walled city and in the six adjacent counties in the surrounding countryside. Factoring in Chinese victims murdered in February and March 1938, Wakabayashi concurs with Tokushi Kasahara's estimate of a death toll that "far exceed\[s\] 100,000 but fall\[s\] short of 200,000 in absence of new evidence".[^5]

[John Rabe](https://en.wikipedia.org/wiki/John_Rabe "John Rabe"), Chairman of the [International Committee for the Nanking Safety Zone](https://en.wikipedia.org/wiki/International_Committee_for_the_Nanking_Safety_Zone "International Committee for the Nanking Safety Zone"), estimated that between 50,000 and 60,000 civilians were killed in the city walls.[^168] However, Erwin Wickert, the editor of *The diaries of John Rabe*, points out that "It is likely that Rabe's estimate is too low, since he could not have had an overview of the entire municipal area during the period of the worst atrocities. Moreover, many troops of captured Chinese soldiers were led out of the city and down to the Yangtze, where they were summarily executed. But, as noted, no one actually counted the dead."

[Lewis S. C. Smythe](https://en.wikipedia.org/wiki/Lewis_S._C._Smythe "Lewis S. C. Smythe"), an American professor of sociology at Ginling College (now Nanking University), was present in Nanjing during the atrocity and conducted a survey of Nanjing's urban and rural areas between March and April 1938 to estimate the death toll. After a careful study of burial records, Smythe recorded that 12,000 civilians were murdered inside the city walls and another 26,780 were killed in the surrounding counties, mostly young men executed in the "mopping up campaigns". However, Tokushi Kasahara points out Smythe's survey substantially underestimated the death toll as Smythe only surveyed inhabited homes, and thus skipped over the homes of families who had been entirely destroyed or been unable to return. Kasahara thus concurs with Smythe's estimate of 30,000 civilians murdered in the countryside, but follows Rabe's original estimate of 50,000 to 60,000 civilian deaths within the city walls.[^169]

![](https://en.wikipedia.org/wiki/File:Skeletons_of_victims_in_Nanjing_Massacre.jpg)

A mass grave from the Nanjing Massacre

According to the [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East"), estimates made at a later date indicate that the total number of civilians and prisoners of war murdered in Nanjing and its vicinity during the first six weeks of the Japanese occupation were over 200,000. These estimates are borne out by the figures of burial societies and other organizations, which testify to over 155,000 buried bodies. These figures also do not take into account those persons whose bodies were destroyed by burning, drowning or other means, or whose bodies were interred in mass graves.[^113] The most credible scholars in Japan, which include a large number of authoritative academics, support the validity of the tribunal and its findings.[^162]

The 1947 verdict of the [Nanjing War Crimes Tribunal](https://en.wikipedia.org/wiki/Nanjing_War_Crimes_Tribunal "Nanjing War Crimes Tribunal") estimated that there were "more than 190,000 mass slaughtered civilians and Chinese soldiers killed by machine gun by the Japanese army, whose corpses have been burned to destroy proof. Besides, we count more than 150,000 victims of barbarian acts buried by the charity organizations. We thus have a total of more than 300,000 victims." [^170]

### The 300,000 death toll debate

Currently, the figure of 300,000 victims has been widely commemorated as the death toll of the Nanjing Massacre across China, a number that has been officially endorsed by the Chinese government.[^15] Documents in the UNESCO Memory of the World Register estimate at least 300,000 Chinese were killed.[^171] [^172]

![](https://en.wikipedia.org/wiki/File:Victims_300000,_Nanjing_massacre_memorial.jpg)

The figure of 300,000 victims etched into the Nanjing Massacre Memorial Hall

Modern historians contend that the figure of 300,000 civilian deaths in Nanjing appears to be an overestimate.[^15] [^173] [Ikuhiko Hata](https://en.wikipedia.org/wiki/Ikuhiko_Hata "Ikuhiko Hata") considers the number of 300,000 to be a "symbolic figure" representative of China's wartime suffering and not a figure to be taken literally.[^174]

Canadian historian Bob Wakabayashi contends that estimates over 200,000 victims are not credible, but concludes 300,000 represents a credible estimate for the total number of Chinese troops and civilians killed in the entire Yangtze delta area (Shanghai, Nanjing, and the 300 km stretch in between) from August to December 1937, including massacre victims and soldiers killed in action.[^5]

[Harold Timperley](https://en.wikipedia.org/wiki/Harold_Timperley "Harold Timperley"), a journalist in China during the Japanese invasion, reported that at least 300,000 Chinese civilians were killed in Nanjing and elsewhere, and tried to send a telegram but was censored by the Japanese military in Shanghai.[^175]

Other sources, including [Iris Chang](https://en.wikipedia.org/wiki/Iris_Chang "Iris Chang") 's *[The Rape of Nanjing](https://en.wikipedia.org/wiki/The_Rape_of_Nanking_\(book\) "The Rape of Nanking (book)")*, also conclude that the death toll reached 300,000. In December 2007, newly declassified [U.S. government](https://en.wikipedia.org/wiki/U.S._government "U.S. government") archive documents revealed that a telegraph by the U.S. ambassador to Germany in Berlin sent one day after the Japanese army occupied Nanjing, stated that he heard the Japanese ambassador in Germany boasting that the Japanese army had killed 500,000 Chinese soldiers and civilians as the Japanese army advanced from Shanghai to Nanjing. According to the archives research "The telegrams sent by the U.S. diplomats \[in Berlin\] pointed to the massacre of an estimated half a million people in Shanghai, Suzhou, Jiaxing, Hangzhou, Shaoxing, Wuxi and Changzhou".[^176] [^177]

To many Japanese scholars, post-war estimations were distorted by " [victor's justice](https://en.wikipedia.org/wiki/Victor's_justice "Victor's justice") ", when Japan was condemned as the sole aggressor. They believed the 300,000 toll typified a "Chinese-style exaggeration" with disregard for evidence. Yet, in China, this figure has come to symbolize the justice, legality, and authority of the post-war trials condemning Japan as the aggressor.[^178]

### Range and duration

The duration of the incident is naturally defined by its geography: the earlier the Japanese entered the area, the longer the duration. The [Battle of Nanjing](https://en.wikipedia.org/wiki/Battle_of_Nanjing "Battle of Nanjing") ended on December 13, when the divisions of the Japanese Army entered the walled city of Nanjing. The Tokyo War Crime Tribunal defined the period of the massacre to the ensuing six weeks. More conservative estimates say that the massacre started on December 14, when the troops entered the Safety Zone, and that it lasted for six weeks. Historians who define the Nanjing Massacre as having started from the time that the Japanese Army entered [Jiangsu](https://en.wikipedia.org/wiki/Jiangsu "Jiangsu") province push the beginning of the massacre to around mid-November to early December (Suzhou fell on November 19), and extended the end of the massacre to late March 1938.[^4]

A new scope of the Nanjing Massacre stretches beyond the walls of Nanking city to encompass the six adjacent counties in the surrounding countryside (Liuho, Chiangp'u, Kaochun, Chiangning, Lishui, and Kuyung). Within this zone, Japanese forces began committing atrocities on December 4, 1937, when their divisions first invaded the area. Although Japanese field operations ceased on February 14, 1938, massacres and other atrocities persisted until March 28, 1938, when the Japanese formed the collaborationist " [Reformed Government](https://en.wikipedia.org/wiki/Reformed_Government_of_the_Republic_of_China "Reformed Government of the Republic of China") " under [Liang Hongzhi](https://en.wikipedia.org/wiki/Liang_Hongzhi "Liang Hongzhi"); only then was public order restored to Nanking. Thus, per Kasahara and Wakabayashi's research, a more fitting range for the Nanjing Massacre encompasses both the Nanjing City and its surrounding countryside, while a more appropriate duration stretches from December 4, 1937, to March 28, 1938.[^4]

## War crimes tribunals

Shortly after the surrender of Japan, the primary officers in charge of the Japanese troops at Nanjing were put on trial. General Matsui was indicted before the [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East") for "deliberately and recklessly" ignoring his legal duty "to take adequate steps to secure the observance and prevent breaches" of the [Hague Convention](https://en.wikipedia.org/wiki/Hague_Conventions_of_1899_and_1907 "Hague Conventions of 1899 and 1907").

Other Japanese military leaders in charge at the time of the Nanjing Massacre were not tried. [Prince Kan'in Kotohito](https://en.wikipedia.org/wiki/Prince_Kan'in_Kotohito "Prince Kan'in Kotohito"), chief of staff of the Imperial Japanese Army during the massacre, had died before the end of the war in May 1945. Prince Asaka was granted immunity because of his status as a member of the imperial family.[^179] [^180] [Isamu Chō](https://en.wikipedia.org/wiki/Isamu_Ch%C5%8D "Isamu Chō"), the aide to Prince Asaka, and whom some historians believe issued the "kill all captives" memo, had committed *[seppuku](https://en.wikipedia.org/wiki/Seppuku "Seppuku")* (ritual suicide) during the [Battle of Okinawa](https://en.wikipedia.org/wiki/Battle_of_Okinawa "Battle of Okinawa").[^181]

- ![The International Military Tribunal for the Far East was convened at "Ichigaya Court," formally Imperial Japanese Army HQ building in Ichigaya, Tokyo.](https://en.wikipedia.org/wiki/File:International_Military_Tribunal_Ichigaya_Court.jpg)
	The International Military Tribunal for the Far East was convened at "Ichigaya Court," formally Imperial Japanese Army HQ building in Ichigaya, Tokyo.
	The [International Military Tribunal for the Far East](https://en.wikipedia.org/wiki/International_Military_Tribunal_for_the_Far_East "International Military Tribunal for the Far East") was convened at "Ichigaya Court," formally Imperial Japanese Army HQ building in [Ichigaya](https://en.wikipedia.org/wiki/Ichigaya "Ichigaya"), [Tokyo](https://en.wikipedia.org/wiki/Tokyo "Tokyo").
- ![General Iwane Matsui](https://en.wikipedia.org/wiki/File:Iwane_Matsui.jpg)
	General Iwane Matsui
	General [Iwane Matsui](https://en.wikipedia.org/wiki/Iwane_Matsui "Iwane Matsui") [^182]
- ![General Hisao Tani](https://en.wikipedia.org/wiki/File:Lieutenant-General_Hisao_Tani_(cropped).jpg)
	General Hisao Tani
	General [Hisao Tani](https://en.wikipedia.org/wiki/Hisao_Tani "Hisao Tani") [^183]

### Grant of immunity to Prince Asaka

On May 1, 1946, [SCAP](https://en.wikipedia.org/wiki/Supreme_Commander_of_the_Allied_Powers "Supreme Commander of the Allied Powers") officials interrogated [Prince Asaka](https://en.wikipedia.org/wiki/Prince_Asaka "Prince Asaka"), who was the ranking officer in the city at the height of the atrocities, about his involvement in the Nanjing Massacre and the deposition was submitted to the International Prosecution Section of the Tokyo tribunal. Asaka denied the existence of any massacre and claimed never to have received complaints about the conduct of his troops.[^184] For politico-strategic and geopolitical reasons, General Douglas MacArthur decided to support the Imperial family and to grant immunity to all its members.[^185]

### Evidence and testimony

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/3/3e/Nanking_telegram_Harold_John_Timperley.gif/250px-Nanking_telegram_Harold_John_Timperley.gif?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Harold John Timperley 's telegram of January 17, 1938, describing the atrocities

The prosecution began the Nanjing phase of its case in July 1946. Dr. [Robert O. Wilson](https://en.wikipedia.org/wiki/Robert_O._Wilson "Robert O. Wilson"), a surgeon and a member of the International Committee for the Nanking Safety Zone, testified.[^186] Other members of the International Committee for the Nanking Safety Zone who took the witness stand included [Miner Searle Bates](https://en.wikipedia.org/wiki/Miner_Searle_Bates "Miner Searle Bates") [^187] and [John Magee](https://en.wikipedia.org/wiki/John_Magee_\(missionary\) "John Magee (missionary)").[^188] [George A. Fitch](https://en.wikipedia.org/wiki/George_A._Fitch "George A. Fitch"),[^189] [Lewis S. C. Smythe](https://en.wikipedia.org/wiki/Lewis_S._C._Smythe "Lewis S. C. Smythe"),[^190] and James McCallum filed affidavits with their diaries and letters.[^191]

The entry for the same day in Matsui's diary read, "I could only feel sadness and responsibility today, which has been overwhelmingly piercing my heart. This is caused by the Army's misbehaviors after the fall of Nanjing and failure to proceed with the autonomous government and other political plans." [^192]

### Matsui's defense

Matsui asserted that he had never ordered the execution of Chinese [POWs](https://en.wikipedia.org/wiki/POWs "POWs"). He further argued that he had directed his army division commanders to discipline their troops for criminal acts, and was not responsible for their failure to carry out his directives. At trial, Matsui went out of his way to protect [Prince Asaka](https://en.wikipedia.org/wiki/Prince_Asaka "Prince Asaka") by shifting blame to lower-ranking division commanders.[^193]

### Verdict

[Kōki Hirota](https://en.wikipedia.org/wiki/K%C5%8Dki_Hirota "Kōki Hirota"), Prime Minister of Japan at an earlier stage of the war, and a diplomat during the atrocities at Nanjing, was convicted of participating in "the formulation or execution of a common plan or conspiracy" (count 1), waging "a war of aggression and a war in violation of international laws, treaties, agreements and assurances against the Republic of China" (count 27) and count 55. Matsui was convicted by a majority of the judges at the Tokyo tribunal who ruled that he bore ultimate responsibility for the "orgy of crime" at Nanjing because, "He did nothing, or nothing effective, to abate these horrors."

> Organized and wholesale murder of male civilians was conducted with the apparent sanction of the commanders on the pretext that Chinese soldiers had removed their uniforms and were mingling with the population. Groups of Chinese civilians were formed, bound with their hands behind their backs, and marched outside the walls of the city where they were killed in groups by machine gun fire and with bayonets. — From Judgment of the International Military Tribunal

### Sentences

On November 12, 1948, Matsui and Hirota, along with five other convicted Class-A war criminals, were sentenced to death by hanging. Eighteen others received lesser sentences. The death sentence imposed on Hirota, a six-to-five decision by the eleven judges, shocked the general public and prompted a petition on his behalf, which soon gathered over 300,000 signatures but did not succeed in commuting the Minister's sentence. All of them were hanged on December 23, 1948.[^194] [^195]

### Other trials

[Hisao Tani](https://en.wikipedia.org/wiki/Hisao_Tani "Hisao Tani"), a lieutenant general for the 6th Division of the Imperial Japanese Army, was tried by the [Nanjing War Crimes Tribunal](https://en.wikipedia.org/wiki/Nanjing_War_Crimes_Tribunal "Nanjing War Crimes Tribunal") in China.[^193] He was found guilty of war crimes, sentenced to death, and executed by shooting on April 26, 1947. However, according to historian Tokushi Kasahara, the evidence used to convict Hisao Tani was not convincing.[^196] Kasahara said that if there was a full investigation of the massacre, many other high ranking authorities, which include higher level commanders, army leaders and emperor [Hirohito](https://en.wikipedia.org/wiki/Hirohito "Hirohito"), could have been implicated.[^196]

In 1947, Toshiaki Mukai and Tsuyoshi Noda, the two officers responsible for the contest to kill 100 people, were both arrested and extradited to China. They were also tried by the Nanjing War Crimes Tribunal. On trial with them was Gunkichi Tanaka, a captain from the 6th Division who personally killed over 300 Chinese POWs and civilians with his sword during the massacre. All three men were found guilty of war crimes and sentenced to death. They were [executed by shooting](https://en.wikipedia.org/wiki/Executed_by_shooting "Executed by shooting") together on January 28, 1948.[^197] [^198]

[Moritake Tanabe](https://en.wikipedia.org/wiki/Moritake_Tanabe "Moritake Tanabe"), the Chief of Staff of the [Japanese 10th Army](https://en.wikipedia.org/wiki/Tenth_Army_\(Japan\) "Tenth Army (Japan)") at the time of the massacre, was tried for unrelated war crimes in the [Dutch East Indies](https://en.wikipedia.org/wiki/Dutch_East_Indies "Dutch East Indies"). He was sentenced to death and executed in 1949.[^199]

## Memorials

- In 1985, the [Memorial Hall for Nanjing Massacre victims](https://en.wikipedia.org/wiki/Memorial_Hall_of_the_Victims_in_Nanjing_Massacre_by_Japanese_Invaders "Memorial Hall of the Victims in Nanjing Massacre by Japanese Invaders") was built by the Nanjing Municipal Government in remembrance of the victims and to raise awareness of the Nanjing Massacre. It is located near a site where thousands of bodies were buried, called the "pit of ten thousand corpses" *wàn rén kēng* ([Chinese](https://en.wikipedia.org/wiki/Chinese_language "Chinese language"): 万人坑; [pinyin](https://en.wikipedia.org/wiki/Pinyin "Pinyin"): *Wàn rén kēng*). As of December 2016, there is a total of 10,615 Nanjing Massacre victim names inscribed on a memorial wall.[^200]
- In 1995, Daniel Kwan held a photo exhibit in Los Angeles titled, "The Forgotten Holocaust".
- In 2005, John Rabe's former residence in Nanjing was renovated and now accommodates the " [John Rabe and International Safety Zone Memorial Hall](https://en.wikipedia.org/wiki/John_Rabe_House "John Rabe House") ", which opened in 2006.
- On December 13, 2009, both the Chinese and Japanese monks held a religious assembly to mourn Chinese civilians killed by invading Japanese troops.[^201]
- On December 13, 2014, China held its first [Nanjing Massacre Memorial Day](https://en.wikipedia.org/wiki/Nanjing_Massacre_Memorial_Day "Nanjing Massacre Memorial Day").[^202]

On October 9, 2015, Documents of the Nanjing Massacre have been listed on the [UNESCO Memory of the World Register](https://en.wikipedia.org/wiki/UNESCO_Memory_of_the_World_Register?action=edit&redlink=1 "UNESCO Memory of the World Register (page does not exist)").[^172]

- ![Yanziji Nanjing Massacre Memorial in 2004](https://en.wikipedia.org/wiki/File:Sekihi02.jpg)
	Yanziji Nanjing Massacre Memorial in 2004
	Yanziji Nanjing Massacre Memorial in 2004
- ![A statue titled "Family Ruined" in front of the Nanjing Massacre Memorial Hall](https://en.wikipedia.org/wiki/File:%E5%8D%97%E4%BA%AC%E5%A4%A7%E5%B1%A0%E6%9D%80%E7%BA%AA%E5%BF%B5%E9%A6%86%E5%AE%B6%E7%A0%B4%E4%BA%BA%E4%BA%A1%E9%9B%95%E5%A1%91.jpg)
	A statue titled "Family Ruined" in front of the Nanjing Massacre Memorial Hall
	A statue titled "Family Ruined" in front of the Nanjing Massacre Memorial Hall
- ![John Rabe's former residence, now the "John Rabe and International Safety Zone Memorial Hall", in Nanjing, September 2010](https://en.wikipedia.org/wiki/File:Residence_of_John_Rabe,_Nanjing.jpg)
	John Rabe's former residence, now the "John Rabe and International Safety Zone Memorial Hall", in Nanjing, September 2010
	John Rabe's former residence, now the "John Rabe and International Safety Zone Memorial Hall", in Nanjing, September 2010

## Controversy

According to Japanese historian [Fujiwara Akira](https://en.wikipedia.org/wiki/Fujiwara_Akira "Fujiwara Akira"), "When Japan accepted the [Potsdam Declaration](https://en.wikipedia.org/wiki/Potsdam_Declaration "Potsdam Declaration") and surrendered in August 1945, the state officially acknowledged the war of aggression and the Nanjing massacre committed by the Japanese army." [^203]

### Debate in Japan

David Askew, formerly an associate professor at [Ritsumeikan Asia Pacific University](https://en.wikipedia.org/wiki/Ritsumeikan_Asia_Pacific_University "Ritsumeikan Asia Pacific University"), noted that in Japan views concerning the massacre were divided between two mutually exclusive groups. The "Great Massacre School" group accepts the findings of the Tokyo Trials, and concludes that there were at least 200,000 casualties and at least 20,000 rape cases; whereas "The Illusion School" group rejects the tribunal's findings as "victor's justice". According to Askew, the "Great Massacre School" is more sophisticated, and the credibility of its conclusions are supported by a large number of authoritative academics.[^204] Askew estimates that the city's population was 224,500 from December 24, 1937, to January 5, 1938.[^205]

[Tomio Hora](https://en.wikipedia.org/wiki/Tomio_Hora "Tomio Hora"), a Japanese history professor at [Waseda University](https://en.wikipedia.org/wiki/Waseda_University "Waseda University"), published a book in 1967 following his 1966 visit to China, devoting a third of the book to the massacre.[^206] During the 1970s, [Katsuichi Honda](https://en.wikipedia.org/wiki/Katsuichi_Honda "Katsuichi Honda") wrote a series of articles for the *[Asahi Shimbun](https://en.wikipedia.org/wiki/Asahi_Shimbun "Asahi Shimbun")* on war crimes committed by Japanese soldiers during World War II (such as the Nanjing Massacre).[^207] In response, Shichihei Yamamoto, using the [pen name](https://en.wikipedia.org/wiki/Pen_name "Pen name") "Isaiah Ben-Dasan", wrote an article that denied the massacre, and [Akira Suzuki](https://en.wikipedia.org/wiki/Akira_Suzuki_\(writer\) "Akira Suzuki (writer)") published a book that denied the massacre.[^208] However, the debate was short-lived because no denialist produced a study that was as comprehensive as the one conducted by Hora.[^208] The opposition was unable to present enough evidence to deny the massacre.[^208]

There are disputes about the official death toll of the massacre. This estimate includes an estimation that the Japanese Army murdered 57,418 Chinese POWs at Mufushan, though the latest research indicates that between 4,000 and 20,000 were massacred,[^16] [^209] and it also includes the 112,266 corpses apparently buried by the Chongshantang, a charitable association, though today some historians argue that the Chongshantang's records were at least greatly exaggerated if not entirely fabricated.[^210] [^211] [^212] According to Bob Wakabayashi, he estimates the death toll within [Nanjing City Wall](https://en.wikipedia.org/wiki/Nanjing_City_Wall "Nanjing City Wall") to be under 50,000, mostly massacred in the first five days; while the total victims after a three-month period in Nanjing and its surrounding six rural counties "far exceed 100,000 but fall short of 200,000".[^162] Wakabayashi concludes that estimates of over 200,000 are not credible.[^211]

### Denials of the massacre in Japan

For the past several decades, Japanese politicians who express no remorse for the Nanjing Massacre have exacerbated ongoing tensions in [Sino-Japanese relations](https://en.wikipedia.org/wiki/Sino-Japanese_relations "Sino-Japanese relations"), with numerous Japanese government officials and a few historians in Japan either denying or dismissing the atrocity.[^213] [^214] [^215] [^216]

Numerous scholars have stated that the [Japanese Wikipedia](https://en.wikipedia.org/wiki/Japanese_Wikipedia#Controversies "Japanese Wikipedia") version of the article ([南京事件](https://ja.wikipedia.org/wiki/%E5%8D%97%E4%BA%AC%E4%BA%8B%E4%BB%B6 "ja:南京事件")) contained revisionist and denialist narratives.[^217] [^218] [^219] [^220] They note that the article notably lacked pictures and expressed doubt about the massacre in the first paragraph of the article. In 2021, Yumiko Sato translated a sentence from the first paragraph: "The Chinese side calls it the Nanjing Massacre, but the truth of the incident is still unknown".[^219] [^220] This statement has since been removed from the Japanese Wikipedia version of the article.

## Legacy

### Effect on international relations

The memory of the Nanjing Massacre has been a point of contention in [Sino-Japanese relations](https://en.wikipedia.org/wiki/Sino-Japanese_relations "Sino-Japanese relations") since the early 1970s.[^221] Trade between the two nations is worth over $200 billion annually. Despite this, many Chinese people still have a strong sense of distrust due to the memory of the atrocity and failure of reconciliation measures. This sense of distrust is strengthened by Japan's unwillingness to admit to and apologize for the atrocities.[^222]

Takashi Yoshida described how changing political concerns and perceptions of the "national interest" in Japan, China, and the U.S. have shaped the collective memory of the Nanjing Massacre. Yoshida contended that over time the event has acquired different meanings to different people. People from mainland China saw themselves as the victims. For Japan, it was a question they needed to answer but were reluctant to do so because they too identified themselves as victims after the A-bombs. The U.S., which served as the melting pot of cultures and is home to descendants of members of both Chinese and Japanese cultures, took up the mantle of investigator for the victimized Chinese. Yoshida had argued that the Nanjing Massacre had figured in the attempts of all three nations as they work to preserve and redefine national and ethnic pride and identity, assuming different kinds of significance based on each country's changing internal and external enemies.[^223]

Many Japanese prime ministers have visited the [Yasukuni Shrine](https://en.wikipedia.org/wiki/Yasukuni_Shrine "Yasukuni Shrine"), a shrine for Japanese war deaths up until the end of the Second World War, which includes war criminals that were involved in the Nanjing Massacre. In the museum adjacent to the shrine, a panel informs visitors that there was no massacre in Nanjing, but that Chinese soldiers in plain clothes were "dealt with severely". In 2006 former Japanese prime minister [Junichiro Koizumi](https://en.wikipedia.org/wiki/Junichiro_Koizumi "Junichiro Koizumi") made a pilgrimage to the shrine despite warnings from China and South Korea. His decision to visit the shrine regardless sparked international outrage. Although Koizumi denied that he was trying to glorify war or historical [Japanese militarism](https://en.wikipedia.org/wiki/Japanese_militarism "Japanese militarism"), the Chinese Foreign Ministry accused Koizumi of "wrecking the political foundations of China-Japan relations". An official from South Korea said they would summon the Tokyo ambassador to protest.[^224] [^225]

The Massacre is contentiously compared to other disasters in China, which include the [Great Chinese famine](https://en.wikipedia.org/wiki/Great_Chinese_famine "Great Chinese famine") (1959–1961) [^226] [^227] [^228] and the [Cultural Revolution](https://en.wikipedia.org/wiki/Cultural_Revolution "Cultural Revolution").[^229] [^230] [^231]

### As a component of national identity

Yoshida asserts that "Nanjing has figured in the attempts of all three nations \[China, Japan and the United States\] to preserve and redefine national and ethnic pride and identity, assuming different kinds of significance based on each country's changing internal and external enemies." [^232]

### China

In her book *Rape of Nanjing,* [Iris Chang](https://en.wikipedia.org/wiki/Iris_Chang "Iris Chang") asserted that the politics of the [Cold War](https://en.wikipedia.org/wiki/Cold_War "Cold War") encouraged [Mao Zedong](https://en.wikipedia.org/wiki/Mao_Zedong "Mao Zedong") to stay relatively silent about Nanjing in order to keep a trade relationship with Japan.[^233] [Jung Chang](https://en.wikipedia.org/wiki/Jung_Chang "Jung Chang") and [Jon Halliday](https://en.wikipedia.org/wiki/Jon_Halliday "Jon Halliday") 's [biography of Mao](https://en.wikipedia.org/wiki/Mao:_The_Unknown_Story "Mao: The Unknown Story") claims Mao never made any comment either contemporaneously or later in his life about the massacre, but did frequently remark with enduring bitterness about a political struggle between himself and [Wang Ming](https://en.wikipedia.org/wiki/Wang_Ming "Wang Ming") which also occurred in December 1937.[^234]

Before the 1970s, China did relatively little to draw attention to the Nanjing Massacre. There was also virtually no public commemoration until after 1982.[^235] However, China was not oblivious to the Japanese debate over the massacre.[^236] In 1982, concerned with Japanese [denialism](https://en.wikipedia.org/wiki/Historical_negationism "Historical negationism"), accounts of the Nanjing Massacre, alongside other wartime atrocities committed by Japan in China, emerged in the Chinese media.[^236] Concerns regarding Japanese denialism about the massacre were not confined solely to the People's Republic of China; scholars in Taiwan also initiated a response, publishing many studies about Japanese atrocities in China.[^236]

According to American journalist [Howard W. French](https://en.wikipedia.org/wiki/Howard_W._French "Howard W. French"), mentioning of the massacre was suppressed in China because ideologically [the communists](https://en.wikipedia.org/wiki/Ideology_of_the_Chinese_Communist_Party "Ideology of the Chinese Communist Party") would rather promote the "martyrs of [class struggles](https://en.wikipedia.org/wiki/Class_struggles "Class struggles") " than wartime victims, especially when there were no communist heroes or any communists at all in Nanjing when the massacre happened.[^237]

According to Guo-Qiang Liu and Fengqi Qian of [Deakin University](https://en.wikipedia.org/wiki/Deakin_University "Deakin University"), only since the 1990s, through the revisionist [Patriotic Education Campaign](https://en.wikipedia.org/wiki/Patriotic_Education_Campaign "Patriotic Education Campaign"), the massacre had become a national memory as an episode of the " [Century of Humiliation](https://en.wikipedia.org/wiki/Century_of_Humiliation "Century of Humiliation") " prior to the communist founding of a "New China". This orthodox victimhood narrative has become entwined with the Chinese [national identity](https://en.wikipedia.org/wiki/National_identity "National identity") and is very sensitive to the revisionist sentiments from the far-right in Japan, which makes the memory of the massacre a recurring point of tension in [Sino-Japanese relations](https://en.wikipedia.org/wiki/Sino-Japanese_relations "Sino-Japanese relations") after 1982.[^238]

A fictionalized film about a Chinese photographer's documentation of the massacre, *[Dead to Rights](https://en.wikipedia.org/wiki/Dead_to_Rights_\(film\) "Dead to Rights (film)")*, was released in China in July 2025,[^239] [^240] with the Chinese newspaper *[China Daily](https://en.wikipedia.org/wiki/China_Daily "China Daily")* stating that the film is meant to "prevent amnesia" and not to spread animosity.[^241]

### Japan

Following the end of World War II, some circles of [civil society](https://en.wikipedia.org/wiki/Civil_society "Civil society") in Japan reflected on the extent of the massacre and the participation of ordinary soldiers. Notably, the novelist [Yoshie Hotta](https://en.wikipedia.org/wiki/Yoshie_Hotta "Yoshie Hotta") wrote a novel, *Time* (*Jikan*) in 1953, portraying the massacre from the point of view of a Chinese intellectual watching it happen. This novel has been translated into Chinese and Russian. Other eyewitnesses to the massacre also expressed their opinions in Japanese magazines in the 1950s and 1960s, but political shifts slowly eroded this tide of confessions.

In 21st century Japan, the Nanjing Massacre touches upon national identity and notions of "pride, honor and shame". Yoshida argues that "Nanjing crystallizes a much larger conflict over what should constitute the ideal perception of the nation: Japan, as a nation, acknowledges its past and apologizes for its wartime wrongdoings; or... stands firm against foreign pressures and teaches Japanese youth about the benevolent and courageous martyrs who fought a just war to save Asia from Western aggression." [^242] Recognizing the Nanjing Massacre as such can be viewed in some circles in Japan as "Japan-bashing" (in the case of foreigners) or "self-flagellation" (in the case of Japanese).[^243]

The government of Japan states that it cannot be denied that the killing of a large number of noncombatants, looting and other acts by the Japanese army occurred. However, it also states that the actual number of victims is hard to determine.[^244]

The most widely used Japanese textbooks for junior high schools do contain references to the Nanjing Massacre and other issues like [comfort women](https://en.wikipedia.org/wiki/Comfort_women "Comfort women").[^245] [^246] [^247] Fiercely critical of such references, the [Japanese Society for History Textbook Reform](https://en.wikipedia.org/wiki/Japanese_Society_for_History_Textbook_Reform "Japanese Society for History Textbook Reform") published the *New History Textbook* attempts to whitewash Japan's war record during the 1930s and early 1940s. It referred to the Nanjing Massacre as an "incident", and glossed over the issue of comfort women.[^248] There is also only one sentence that refers to the event: "they \[the Japanese troops\] occupied that city in December".[^249] This revisionist textbook though approved by the government was shunned by nearly all school districts and only used by 13 schools.[^250]

### Australia

Dockworkers in Australia were horrified by the massacre and refused to load [pig iron](https://en.wikipedia.org/wiki/Pig_iron "Pig iron") onto ships heading for Japan, leading to the [Dalfram Dispute of 1938](https://en.wikipedia.org/wiki/Dalfram_dispute_of_1938 "Dalfram dispute of 1938").[^251]

## Records

In December 2007, the PRC government published the names of 13,000 people who were killed by Japanese troops in the Nanjing Massacre. According to [Xinhua News Agency](https://en.wikipedia.org/wiki/Xinhua_News_Agency "Xinhua News Agency"), it is the most complete record to date. The report consists of eight volumes and was released to mark the 70th anniversary of the start of the massacre. It also lists the Japanese army units that were responsible for each of the deaths and states the way in which the victims were killed. Zhang Xianwen, editor-in-chief of the report, states that the information collected was based on "a combination of Chinese, Japanese and Western raw materials, which is objective and just and is able to stand the trial of history".[^252] This report formed part of a 55-volume series about the massacre, the *Collection of Historical Materials of Nanjing Massacre* ([南京大屠杀史料集](https://zh.wikipedia.org/wiki/%E5%8D%97%E4%BA%AC%E5%A4%A7%E5%B1%A0%E6%AE%BA%E5%8F%B2%E6%96%99%E9%9B%86 "zh:南京大屠殺史料集") [pinyin](https://en.wikipedia.org/wiki/Pinyin "Pinyin"): *Nánjīng dà túshā shǐliào jí*).[^253]

[^1]: "Six weeks long" is a convenient figure but far from precise. Killings were most intense in the first five days from December 13 and remained moderately intense until December 31, 1937, according to the Japanese military records. From February 7, 1938, killings were no longer in mass fashion as the senior Japanese officers came to restore discipline of their troops, according to the testimony of [Miner Searle Bates](https://en.wikipedia.org/wiki/Miner_Searle_Bates "Miner Searle Bates"), a humanitarian leader of the [Nanking Safety Zone](https://en.wikipedia.org/wiki/Nanking_Safety_Zone "Nanking Safety Zone"). None of the above dates is close to "six weeks", which should correspond to January 24, 1938. Bates testified before the [Tokyo Trial](https://en.wikipedia.org/wiki/Tokyo_Trial "Tokyo Trial") on July 29, 1946, pioneering the use of "six weeks long" and describing the respective duration of random murder, [looting](https://en.wikipedia.org/wiki/Looting "Looting") and [arson](https://en.wikipedia.org/wiki/Arson "Arson").[^19]

[^2]: [simplified Chinese](https://en.wikipedia.org/wiki/Simplified_Chinese_characters "Simplified Chinese characters"): 南京大屠杀; [traditional Chinese](https://en.wikipedia.org/wiki/Traditional_Chinese_characters "Traditional Chinese characters"): 南京大屠殺; [pinyin](https://en.wikipedia.org/wiki/Pinyin "Pinyin"): *Nánjīng Dàtúshā*; lit. 'Nanjing Great Massacre', [Japanese](https://en.wikipedia.org/wiki/Japanese_language "Japanese language"): 南京大虐殺, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Japanese "Romanization of Japanese"): *Nankin Daigyakusatsu*

[^3]: In the [Chinese postal romanization](https://en.wikipedia.org/wiki/Chinese_postal_romanization "Chinese postal romanization") used at the time, the city's name was [transliterated](https://en.wikipedia.org/wiki/Transliterate "Transliterate") as "Nanking", and so the event was called the **Nanking Massacre** or **Rape of Nanking**.

[^4]: Wakabayashi, Bob (2007). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghahn. p. 57.

[^5]: Wakabayashi, Bob (2000). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghahn Books. p. 384.

[^6]: [Frank, Richard B.](https://en.wikipedia.org/wiki/Richard_B._Frank "Richard B. Frank") (2020). [*Tower of Skulls: A History of the Asia-Pacific War*](https://en.wikipedia.org/wiki/Tower_of_Skulls "Tower of Skulls"). [W. W. Norton](https://en.wikipedia.org/wiki/W._W._Norton "W. W. Norton"). p. 55. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-324-00210-9](https://en.wikipedia.org/wiki/Special:BookSources/978-1-324-00210-9 "Special:BookSources/978-1-324-00210-9").

[^7]: ["Judgment of the International Military Tribunal for the Far East, Volume II, Part B, Chapter VIII"](https://tile.loc.gov/storage-services/service/ll/llmlp/Judgment-IMTFE-Vol-II-PartB-Chapter-VIII/Judgment-IMTFE-Vol-II-PartB-Chapter-VIII.pdf) (PDF). International Military Tribunal for the Far East. November 1948. p. 1015. Retrieved July 11, 2025. Estimates made at a later date indicate that the total number of civilians and prisoners of war murdered in Nanking and its vicinity during the first six weeks of the Japanese occupation was over 200,000.

[^8]: Drea, Edward (2009). *Japan's Imperial Army: Its Rise and Fall, 1853–1945*. University Press of Kansas. pp. 133–135.

[^9]: ["International Memory of the World Register Documents of Nanjing Massacre"](https://en.unesco.org/sites/default/files/china_nanjing_en.pdf) (PDF). *[UNESCO](https://en.wikipedia.org/wiki/UNESCO "UNESCO")*. [Archived](https://web.archive.org/web/20220417091308/https://en.unesco.org/sites/default/files/china_nanjing_en.pdf) (PDF) from the original on April 17, 2022. Retrieved March 23, 2022.

[^10]: Smalley, Martha L. (1997). [*American Missionary Eyewitnesses to the Nanking Massacre, 1937–1938*](https://elischolar.library.yale.edu/cgi/viewcontent.cgi?article=1017&context=ydl_pub). Connecticut: Yale Divinity Library Occasional Publications. [Archived](https://web.archive.org/web/20240124225928/https://elischolar.library.yale.edu/cgi/viewcontent.cgi?article=1017&context=ydl_pub) from the original on January 24, 2024. Retrieved April 3, 2024.

[^11]: [Chang, Iris](https://en.wikipedia.org/wiki/Chang,_Iris "Chang, Iris"). 1997. *[The Rape of Nanking](https://en.wikipedia.org/wiki/The_Rape_of_Nanking_\(book\) "The Rape of Nanking (book)")*. p. 6.

[^12]: Lee, Min (March 31, 2010). ["New film has Japan vets confessing to Nanjing rape"](http://www.salon.com/2010/03/31/as_film_japan_massacre_documentary). *Salon*. [Associated Press](https://en.wikipedia.org/wiki/Associated_Press "Associated Press"). [Archived](https://web.archive.org/web/20221031151950/https://www.salon.com/2010/03/31/as_film_japan_massacre_documentary/) from the original on October 31, 2022. Retrieved February 25, 2012.

[^13]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. p. 145. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-61200-284-2](https://en.wikipedia.org/wiki/Special:BookSources/978-1-61200-284-2 "Special:BookSources/978-1-61200-284-2").

[^14]: Beevor, Antony (2013). *The Second World War*. Vintage. p. 83.

[^15]: [van de Ven, Hans](https://en.wikipedia.org/wiki/Hans_van_de_Ven "Hans van de Ven") (February 12, 2018). [*China at War: Triumph and Tragedy in the Emergence of the New China*](https://en.wikipedia.org/wiki/China_at_War "China at War"). [Harvard University Press](https://en.wikipedia.org/wiki/Harvard_University_Press "Harvard University Press"). pp. 98–99. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/j.ctvhrd0kx](https://doi.org/10.2307%2Fj.ctvhrd0kx). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-674-91952-5](https://en.wikipedia.org/wiki/Special:BookSources/978-0-674-91952-5 "Special:BookSources/978-0-674-91952-5"). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [j.ctvhrd0kx](https://www.jstor.org/stable/j.ctvhrd0kx).

[^16]: Masahiro Yamamoto, Nanking: Anatomy of an Atrocity (Westport, Connecticut: Praeger, 2000), p. 193.

[^17]: Lu, Suping (2019). [*The 1937–1938 Nanjing Atrocities*](https://books.google.com/books?id=Dz_CDwAAQBAJ&pg=PA33). Springer. p. 33. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-9811396564](https://en.wikipedia.org/wiki/Special:BookSources/978-9811396564 "Special:BookSources/978-9811396564"). [Archived](https://web.archive.org/web/20230923141913/https://books.google.com/books?id=Dz_CDwAAQBAJ&pg=PA33) from the original on September 23, 2023. Retrieved February 23, 2020.

[^18]: [Fogel 2000](#CITEREFFogel2000), p. backcover.

[^19]: Library of Congress, ed. (1964–1974). ["29 July 1946. Prosecution's Witnesses. Bates, Miner Searle"](https://www.legal-tools.org/doc/a5a0b0/pdf). *Record of proceedings of the International Military Tribunal for the Far East*. pp. 2631, 2635, 2636, 2642–2645. [Archived](https://web.archive.org/web/20211214091011/https://www.legal-tools.org/doc/a5a0b0/pdf) from the original on December 14, 2021. Retrieved December 14, 2021.

[^20]: Jay Taylor, *The Generalissimo: Chiang Kai-shek and the Struggle for Modern China* (Cambridge, MA: Belknap, 2009), 145–147

[^21]: Hattori Satoshi and Edward J. Drea, "Japanese operations from July to December 1937," in *The Battle for China: Essays on the Military History of the Sino-Japanese War of 1937–1945*, eds. Mark Peattie et al. (Stanford University Press, 2011), 169, 171–172, 175–177.

[^22]: [1937 Japanese Field Commander's Map of the Battle of Shanghai, China](https://www.geographicus.com/P/AntiqueMap/ShanghaiGreater-japanese-1937) [Archived](https://web.archive.org/web/20200517173832/https://www.geographicus.com/P/AntiqueMap/ShanghaiGreater-japanese-1937) May 17, 2020, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") geographicus.com Retrieved April 22, 2020

[^23]: Tokushi Kasahara (1997). 南京事件 (in Japanese). Tokyo: Iwanami Shoten. pp. 50–52.

[^24]: Masahiro Yamamoto, *Nanking: Anatomy of an Atrocity* (Westport, CT: Praeger, 2000), 43, 49–50

[^25]: Toshio Morimatsu (1975). 戦史叢書: 支那事変陸軍作戦(1) (in Japanese). Tokyo: Asagumo Shinbunsha. p. 422.

[^26]: Askew, David (2003). "Defending Nanking: An Examination of the Capital Garrison Forces". *Sino-Japanese Studies*: 173.

[^27]: [Rabe & Wickert 1998](#CITEREFRabeWickert1998), pp. 56, 59–60.

[^28]: [Kingston 2008](#CITEREFKingston2008).

[^29]: Paine, Sarah (2014). *The Wars for Asia, 1911–1949*. Cambridge University Press. p. 137.

[^30]: Paine, Sarah (2012). *The Wars for Asia, 1911–1949*. Cambridge University Press. p. 137.

[^31]: Timberley, Harold (1969). *Japanese Terror in China*. Books for Libraries Press. p. 91.

[^32]: [Katsuichi, Honda](https://en.wikipedia.org/wiki/Honda_Katsuichi "Honda Katsuichi") (1998). *The Nanjing Massacre: A Japanese Journalist Confronts Japan's National Shame*. pp. 63–65.

[^33]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. x. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^34]: Harmsen, Peter (2013). *Shanghai 1937: Stalingrad on the Yangtze*. Casemate. p. 252.

[^35]: *Nishizawa*. p. 670.

[^36]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. p. 58.

[^37]: [Cummins, Joseph](https://en.wikipedia.org/wiki/Joseph_Cumming "Joseph Cumming"). 2009. *The World's Bloodiest History*. p. 149.

[^38]: [Honda, Katsuichi](https://en.wikipedia.org/wiki/Katsuichi_Honda "Katsuichi Honda"), and [Frank Gibney](https://en.wikipedia.org/wiki/Frank_Gibney "Frank Gibney"). "The Nanjing massacre: a Japanese journalist confronts Japan's national shame." pp. 39–41.

[^39]: Tokyo Nichi Nichi, December 13, 1937, article on the killing contest.

[^40]: Japan Advertiser, December 7, 1937 (an American-owned and edited English-language daily paper in Tokyo)

[^41]: [Kingston 2008](#CITEREFKingston2008), p. 9.

[^42]: [Wakabayashi 2000a](#CITEREFWakabayashi2000a), p. 319.

[^43]: Wakabayashi, Bob Tadashi (Summer 2000a). "The Nanking 100-Man Killing Contest Debate: War Guilt Amid Fabricated Illusions, 1971–75". *The Journal of Japanese Studies*. **26** (2): 307–340. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/133271](https://doi.org/10.2307%2F133271). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [133271](https://www.jstor.org/stable/133271).

[^44]: ["Jurist – Paper Chase: Japanese court rules newspaper didn't fabricate 1937 Chinese killing game"](https://web.archive.org/web/20110225011506/http://jurist.law.pitt.edu/paperchase/2005/08/japanese-court-rules-newspaper-didnt.php). Jurist.law.pitt.edu. August 23, 2005. Archived from [the original](http://jurist.law.pitt.edu/paperchase/2005/08/japanese-court-rules-newspaper-didnt.php) on February 25, 2011. Retrieved March 6, 2011.

[^45]: [楽天が運営するポータルサイト ： 【インフォシーク】Infoseek](https://web.archive.org/web/20060512091852/http://andesfolklore.hp.infoseek.co.jp/intisol/hyakunin/hanketu4.htm). *infoseek.co.jp* (in Japanese). Archived from [the original](http://andesfolklore.hp.infoseek.co.jp/intisol/hyakunin/hanketu4.htm) on May 12, 2006.

[^46]: ["The scars of Nanking: Memories of a Japanese outrage"](https://web.archive.org/web/20120128210201/http://www.independent.co.uk/news/world/asia/the-scars-of-nanking-memories-of-a-japanese-outrage-764827.html). *The Independent*. London. December 13, 2007. Archived from [the original](https://www.independent.co.uk/news/world/asia/the-scars-of-nanking-memories-of-a-japanese-outrage-764827.html) on January 28, 2012. Retrieved August 22, 2017.

[^47]: ["Five Western Journalists in the Doomed City"](https://web.archive.org/web/20050325115933/http://www.geocities.com/nankingatrocities/Fall/fall_01.htm). Archived from [the original](http://www.geocities.com/nankingatrocities/Fall/fall_01.htm) on March 25, 2005. Retrieved April 19, 2006.

[^48]: ["Chinese Fight Foe Outside Nanking; See Seeks's Stand"](http://www.ne.jp/asahi/unko/tamezou/nankin/1937-12-08-NewYorkTimesTillmanDurdin.html). [Archived](https://web.archive.org/web/20170703035524/http://www.ne.jp/asahi/unko/tamezou/nankin/1937-12-08-NewYorkTimesTillmanDurdin.html) from the original on July 3, 2017. Retrieved April 19, 2006.

[^49]: ["Japan Lays Gain to Massing of Foe"](http://www.ne.jp/asahi/unko/tamezou/nankin/1937-12-09-NewYorkTimesHallettAbend.html). [Archived](https://web.archive.org/web/20050913064732/http://www.ne.jp/asahi/unko/tamezou/nankin/1937-12-09-NewYorkTimesHallettAbend.html) from the original on September 13, 2005. Retrieved April 19, 2006.

[^50]: Askew, David (April 2002). ["The International Committee for the Nanking Safety Zone: An Introduction"](https://chinajapan.org/articles/14/14.03-23askew.pdf) (PDF). *Sino-Japanese Studies*. **14**: 3–23. [Archived](https://web.archive.org/web/20190819031634/http://www.chinajapan.org/articles/14/14.03-23askew.pdf) (PDF) from the original on August 19, 2019. Retrieved February 23, 2020.

[^51]: ["Genocide in the 20th Century: The Rape of Nanking 1937–1938 (300,000 Deaths)"](http://www.historyplace.com/worldhistory/genocide/nanking.htm). *History Place*. [Archived](https://web.archive.org/web/20170308232201/http://www.historyplace.com/worldhistory/genocide/nanking.htm) from the original on March 8, 2017. Retrieved March 27, 2017.

[^52]: ["Minnie Vautrin"](https://depts.washington.edu/triolive/quest/2007/TTQ07032/yuen/minnievautrin.html). [Archived](https://web.archive.org/web/20221005030657/https://depts.washington.edu/triolive/quest/2007/TTQ07032/yuen/minnievautrin.html) from the original on October 5, 2022. Retrieved October 5, 2022.

[^53]: Møller, Gregers (September 1, 2019). ["Dane saved thousands of Chinese at Nanjing massacre"](https://scandasia.com/dane-saved-thousands-of-chinese-at-nanjing-massacre/). *Scandasia*. [Archived](https://web.archive.org/web/20240529024640/https://scandasia.com/dane-saved-thousands-of-chinese-at-nanjing-massacre/) from the original on May 29, 2024. Retrieved May 29, 2024.

[^54]: ["Nanjing Massacre: Denmark honours hero who rescued Chinese"](https://www.bbc.com/news/world-europe-49524779). *BBC*. August 30, 2019. [Archived](https://web.archive.org/web/20191017171827/https://www.bbc.com/news/world-europe-49524779) from the original on October 17, 2019. Retrieved May 29, 2024.

[^55]: ["Statue honors Dane credited as Nanjing Massacre lifesaver"](https://apnews.com/article/5e768712a4dc4a559ab11cbf18eae3f2). *AP News*. August 31, 2019. [Archived](https://web.archive.org/web/20240529030442/https://apnews.com/article/5e768712a4dc4a559ab11cbf18eae3f2) from the original on May 29, 2024. Retrieved May 29, 2024.

[^56]: [Bergamini 1971](#CITEREFBergamini1971), p. 23.

[^57]: [Bergamini 1971](#CITEREFBergamini1971), p. 24.

[^58]: Chen, C. Peter. ["Yasuhiko"](https://ww2db.com/person_bio.php?person_id=380). *WW2DB*. Retrieved September 9, 2025.

[^59]: Iris Chang, *The Rape of Nanking*, 1997, p. 40

[^60]: Akira Fujiwara, "Nitchū Sensō ni Okeru Horyo Gyakusatsu2, *Kikan Sensō Sekinin Kenkyū* 9, 1995, p. 22

[^61]: Wakabayashi, Bob (2000b). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghan. pp. 84–85.

[^62]: Vautrin, Minnie (2008). [*Terror in Minnie Vautrin's Nanjing: Diaries and Correspondence, 1937–38*](https://books.google.com/books?id=XzfxnlfFPMMC&pg=PR11). [University of Illinois Press](https://en.wikipedia.org/wiki/University_of_Illinois_Press "University of Illinois Press"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-252-03332-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-252-03332-2 "Special:BookSources/978-0-252-03332-2"). [Archived](https://web.archive.org/web/20230923141914/https://books.google.com/books?id=XzfxnlfFPMMC&pg=PR11) from the original on September 23, 2023. Retrieved April 15, 2020.

[^63]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. p. 54.

[^64]: Wakabayashi, Bob (2007). *The Nanking Atrocity, 1937-1938: Complicating the Picture*. Bergham Books. p. 386.

[^65]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate.

[^66]: ["Special Report: How the Nanjing Massacre became a weapon | GRI"](https://globalriskinsights.com/2016/10/how-nanjing-became-a-political-tool/). *Global Risk Insights*. October 27, 2016. [Archived](https://web.archive.org/web/20210213115914/https://globalriskinsights.com/2016/10/how-nanjing-became-a-political-tool/) from the original on February 13, 2021. Retrieved March 19, 2021.

[^67]: ["Basic Facts on the Nanking Massacre and the Toyoko War Crimes Trial"](http://humanum.arts.cuhk.edu.hk/NanjingMassacre/NMNJ.html#nm). Retrieved January 26, 2017.

[^68]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. p. 238.

[^69]: Noboru Kojima (1984). *Ni~Tsu Chū sensō (3)* 日中戦争(3) \[*Sino-Japanese war (3)*\] (in Japanese). Tokyo: Bungei Shunju. pp. 191, 194–195, 197–200.

[^70]: Yamamoto, Masahiro (2000). *Nanking: Anatomy of an Atrocity*. Praeger. p. 100.

[^71]: Zhang, Kaiyuan. *Eyewitnesses to Massacre*. p. 94.

[^72]: Harmsen, Peter (2015). *Nanjing 1937, Battle for a Doomed City*. Casemate. pp. 242–243.

[^73]: Van de Ven, Hans (2018). *China at War: Triumph and Tragedy in the Emergence of the New China*. Harvard University Press. pp. 96–97.

[^74]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. p. 243.

[^75]: Harmsen, Peter (2015). *Nanjing 1937, Battle for a Doomed City*. Casemate. p. 241.

[^76]: [Frank 2020](#CITEREFFrank2020), p. 52.

[^77]: Van Ells, Mark D. (July 14, 2009). ["Nanjing, China"](https://www.historynet.com/nanjing-china.htm). [Archived](https://web.archive.org/web/20210130030155/https://www.historynet.com/nanjing-china.htm) from the original on January 30, 2021.

[^78]: Dorn, Frank (1974). *The Sino-Japanese War, 1937–1941*. MacMillan. p. 92.

[^79]: Wakabayashi, Bob (2000b). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghan. p. 64.

[^80]: Bristow, Michael (December 13, 2007). ["Nanjing remembers massacre victims"](http://news.bbc.co.uk/2/hi/asia-pacific/7140357.stm). *[BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News")*. [Archived](https://web.archive.org/web/20071214003451/http://news.bbc.co.uk/2/hi/asia-pacific/7140357.stm) from the original on December 14, 2007. Retrieved December 13, 2007.

[^81]: Durdin, F. Tillman. "Japanese Atrocities Marked Fall of Nanking After Chinese Command Fled." New York Times (New York), January 9, 1938; accessed March 12, 2016.

[^82]: Hua-ling Hu, *[American Goddess at the Rape of Nanking: The Courage of Minnie Vautrin](https://en.wikipedia.org/wiki/American_Goddess_at_the_Rape_of_Nanking:_The_Courage_of_Minnie_Vautrin "American Goddess at the Rape of Nanking: The Courage of Minnie Vautrin")*, 2000, p. 77.

[^83]: *CBI Roundup*, December 16, 1943, *Rape of Nanking described by Missionary*, [cbi-theater-1.home.comcast.net](http://cbi-theater-1.home.comcast.net/~cbi-theater-1/roundup/roundup121643.html) [Archived](https://web.archive.org/web/20110723045856/http://cbi-theater-1.home.comcast.net/~cbi-theater-1/roundup/roundup121643.html) July 23, 2011, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^84]: Mitter, Rana (2013). *Forgotten Ally: China's World War II, 1937–1945*. p. 138.

[^85]: Mitter, Rana. *Forgotten Ally: China's World War II, 1937–1945*. p. 139.

[^86]: Wakabayashi, Bob (2000). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghahn. pp. 370–372.

[^87]: ["HyperWar: International Military Tribunal for the Far East \[Chapter 8\]"](http://www.ibiblio.org/hyperwar/PTO/IMTFE/IMTFE-8.html). *www.ibiblio.org*. [Archived](https://web.archive.org/web/20180804062413/http://www.ibiblio.org/hyperwar/PTO/IMTFE/IMTFE-8.html) from the original on August 4, 2018. Retrieved December 13, 2007.

[^88]: Pan, Yihong (2025). *Not Just a Man's War: Chinese Women's Memories of the War of Resistance Against Japan, 1931–45*. [University of British Columbia Press](https://en.wikipedia.org/wiki/University_of_British_Columbia_Press "University of British Columbia Press"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [9780774870368](https://en.wikipedia.org/wiki/Special:BookSources/9780774870368 "Special:BookSources/9780774870368").

[^89]: ["Japanese Imperialism and the Massacre in Nanjing: Chapter X: Widespread Incidents of Rape"](http://museums.cnd.org/njmassacre/njm-tran/). Museums.cnd.org. [Archived](https://web.archive.org/web/20140807040825/http://museums.cnd.org/njmassacre/njm-tran/) from the original on August 7, 2014. Retrieved March 6, 2011.

[^90]: Winter, Jay (2009). [*America and the Armenian Genocide of 1915*](https://books.google.com/books?id=pnLSRXAXTfcC&dq=Takokoro+Kozo%2C+a+former+soldier+of+the+Japanese+army+in+Nanking+stated%3A+%E2%80%9Cwomen+suffered+most%2C+no+matter+how+young+or+old%2C+they+all+could+not+escape+the+fate+of+being+raped%E2%80%9D&pg=PA23). [Cambridge University Press](https://en.wikipedia.org/wiki/Cambridge_University_Press "Cambridge University Press"). p. 23. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-139-45018-8](https://en.wikipedia.org/wiki/Special:BookSources/978-1-139-45018-8 "Special:BookSources/978-1-139-45018-8").

[^91]: "A Debt of Blood: An Eyewitness Account of the Barbarous Acts of the Japanese Invaders in Nanjing." *Dagong Daily* (Wuhan ed.). February 7, 1938.; as quoted by Xingzu, Gao, Wu Shimin, Hu Yungong, and Cha Ruizhen. \[1962\] 1996. " [Widespread Incidents of Rape](http://museums.cnd.org/njmassacre/njm-tran/njm-ch10.htm) [Archived](https://web.archive.org/web/20120324084900/http://museums.cnd.org/njmassacre/njm-tran/njm-ch10.htm) 2012-03-24 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")." Ch. 10 in *Japanese Imperialism and the Massacre in Nanjing*, translated by R. Grey.

[^92]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. Casemate. pp. 245–246.

[^93]: John G. Gagee, Case 9, Film 4, Folder 7, Box 263, Record Group 8, Special Collection, Yale Divinity School Library, cited in [Suping Lu. *They were in Nanjing: the Nanjing Massacre witnessed by American and British nationals*. Hong Kong University Press, 2004](https://books.google.com/books?id=rRD_fXL3_swC&pg=PA118) [Archived](https://web.archive.org/web/20230804155610/https://books.google.com/books?id=rRD_fXL3_swC&pg=PA118) August 4, 2023, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^94]: [Rabe & Wickert 1998](#CITEREFRabeWickert1998), pp. 281–282.

[^95]: Hua-ling Hu, *[American Goddess at the Rape of Nanking: The Courage of Minnie Vautrin](https://en.wikipedia.org/wiki/American_Goddess_at_the_Rape_of_Nanking:_The_Courage_of_Minnie_Vautrin "American Goddess at the Rape of Nanking: The Courage of Minnie Vautrin")*, 2000, p. 97

[^96]: Documents on the Rape of Nanking, p. 254.

[^97]: [Zhang, Kaiyuan](https://en.wikipedia.org/wiki/Zhang_Kaiyuan "Zhang Kaiyuan") (2001). *Eyewitness to Massacre: American Missionaries Bear Witness to Japanese Atrocities in Nanjing*. [M. E. Sharpe](https://en.wikipedia.org/wiki/M._E._Sharpe "M. E. Sharpe").

[^98]: Woods, John E. (1998). *The Good Man of Nanking, the Diaries of John Rabe*. p. 77.

[^99]: Choy, Christine (director) (1997). *In the Name of the Emperor* (Documentary). New York: Filmmakers Library.

[^100]: Yang Daqing, "Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing", *[The American Historical Review](https://en.wikipedia.org/wiki/The_American_Historical_Review "The American Historical Review")* 104 (1999), p. 7.

[^101]: Chang, *The Rape of Nanking*, p. 95, citing:

[^102]: Shuhsi Hsu, *Documents of the Nanking Safety Zone*

[^103]: Chang, *The Rape of Nanking*, p. 89, citing:

[^104]: Catherine Rosair, *For One Veteran, Emperor Visit Should Be Atonement*

[^105]: George Fitch, *Nanking Outrages*

[^106]: Li En-han, *Questions of How Many Chinese Were Killed by the Japanese Army in the Great Nanking Massacre*

[^107]: [Frank 2020](#CITEREFFrank2020).

[^108]: [Chang, Iris](https://en.wikipedia.org/wiki/Chang,_Iris "Chang, Iris"). 1997. *[The Rape of Nanking](https://en.wikipedia.org/wiki/The_Rape_of_Nanking_\(book\) "The Rape of Nanking (book)")*. [Penguin Books](https://en.wikipedia.org/wiki/Penguin_Books "Penguin Books"). p. 95.

[^109]: ["Rape of Nanking: Iris Chang's death nine years ago silenced a voice against massacre"](https://www.mercurynews.com/2013/12/04/rape-of-nanking-iris-changs-death-nine-years-ago-silenced-a-voice-against-massacre/). December 4, 2013. [Archived](https://web.archive.org/web/20230621042249/https://www.mercurynews.com/2013/12/04/rape-of-nanking-iris-changs-death-nine-years-ago-silenced-a-voice-against-massacre/) from the original on June 21, 2023. Retrieved June 21, 2023.

[^110]: [Chang, Iris](https://en.wikipedia.org/wiki/Iris_Chang "Iris Chang") (2014). [*The Rape of Nanking: The Forgotten Holocaust of World War II*](https://books.google.com/books?id=8XnKuSxod8wC&q=comfort+women&pg=PT102). [Basic Books](https://en.wikipedia.org/wiki/Basic_Books "Basic Books"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-465-02825-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-465-02825-2 "Special:BookSources/978-0-465-02825-2"). [Archived](https://web.archive.org/web/20230923141914/https://books.google.com/books?id=8XnKuSxod8wC&q=comfort+women&pg=PT102) from the original on September 23, 2023. Retrieved May 24, 2022.

[^111]: Rabe, John (2000). [*The good German of Nanking: the diaries of John Rabe*](https://archive.org/details/goodgermanofnank0000rabe/page/192/mode/2up). Abacus. p. 193. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-349-11141-4](https://en.wikipedia.org/wiki/Special:BookSources/978-0-349-11141-4 "Special:BookSources/978-0-349-11141-4"). Retrieved May 25, 2024.

[^112]: Marquand, Robert (August 20, 2001) ["Why the Past Still Separates China and Japan"](https://www.csmonitor.com/2001/0820/p1s3-woap.html) [Archived](https://web.archive.org/web/20160303200741/http://www.csmonitor.com/2001/0820/p1s3-woap.html) March 3, 2016, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), *[Christian Science Monitor](https://en.wikipedia.org/wiki/Christian_Science_Monitor "Christian Science Monitor")* states an estimate of 300,000 dead.

[^113]: ["HyperWar: International Military Tribunal for the Far East (Chapter 8) (Paragraph 2, p. 1015, Judgment International Military Tribunal for the Far East)"](http://www.ibiblio.org/hyperwar/PTO/IMTFE/IMTFE-8.html). [Archived](https://web.archive.org/web/20180804062413/http://www.ibiblio.org/hyperwar/PTO/IMTFE/IMTFE-8.html) from the original on August 4, 2018. Retrieved December 13, 2007.

[^114]: Library of Congress, ed. (1964–1974). ["25 July 1946. Prosecution's Witnesses. Wilson, Dr. Robert O."](https://www.legal-tools.org/doc/9740a9/pdf/). *Record of proceedings of the International Military Tribunal for the Far East*. p. 2538. [Archived](https://web.archive.org/web/20211214101326/https://www.legal-tools.org/doc/9740a9/pdf/) from the original on December 14, 2021. Retrieved December 14, 2021.

[^115]: Campbell, Bradley (June 2009). "Genocide as social control". *[Sociological Theory](https://en.wikipedia.org/wiki/Sociological_Theory "Sociological Theory")*. **27** (2): 154. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1111/j.1467-9558.2009.01341.x](https://doi.org/10.1111%2Fj.1467-9558.2009.01341.x). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [40376129](https://www.jstor.org/stable/40376129). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [143902886](https://api.semanticscholar.org/CorpusID:143902886). Also, genocide may occur in the aftermath of warfare when mass killings continue after the outcome of a battle or a war has been decided. For instance, after the Japanese occupied Nanjing in December 1937, Japanese soldiers massacred over 250,000 residents of the city.

[^116]: [Jean-Louis, Margolin](https://en.wikipedia.org/wiki/Jean-Louis_Margolin "Jean-Louis Margolin") (2006). ["Japanese Crimes in Nanjing, 1937–38: A Reappraisal"](https://doi.org/10.4000%2Fchinaperspectives.571). *[China Perspectives](https://en.wikipedia.org/wiki/China_Perspectives "China Perspectives")*. **2006** (1): 5–6. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.4000/chinaperspectives.571](https://doi.org/10.4000%2Fchinaperspectives.571).

[^117]: [Tanaka, Yuki](https://en.wikipedia.org/wiki/Yuki_Tanaka_\(historian\) "Yuki Tanaka (historian)") (2023). "The Nanjing Massacre". In [Kiernan, Ben](https://en.wikipedia.org/wiki/Ben_Kiernan "Ben Kiernan"); [Lower, Wendy](https://en.wikipedia.org/wiki/Wendy_Lower "Wendy Lower"); [Naimark, Norman](https://en.wikipedia.org/wiki/Norman_Naimark "Norman Naimark"); [Straus, Scott](https://en.wikipedia.org/wiki/Scott_Straus "Scott Straus") (eds.). *The Cambridge World History of Genocide*. Vol. III: Genocide in the Contemporary Era, 1914–2020. [Cambridge University Press](https://en.wikipedia.org/wiki/Cambridge_University_Press "Cambridge University Press"). pp. 379–399 \[398\]. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1017/9781108767118](https://doi.org/10.1017%2F9781108767118). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-108-48707-8](https://en.wikipedia.org/wiki/Special:BookSources/978-1-108-48707-8 "Special:BookSources/978-1-108-48707-8").

[^118]: Woods, John E. (1998). *The Good Man of Nanking, the Diaries of John Rabe*. pp. 67, 187, 281.

[^119]: [Vautrin, Minnie](https://en.wikipedia.org/wiki/Minnie_Vautrin "Minnie Vautrin") (2008). [*Terror in Minnie Vautrin's Nanjing: Diaries and Correspondence, 1937–38*](https://books.google.com/books?id=XzfxnlfFPMMC&pg=PR11). [University of Illinois Press](https://en.wikipedia.org/wiki/University_of_Illinois_Press "University of Illinois Press"). pp. xi–xii. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-252-03332-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-252-03332-2 "Special:BookSources/978-0-252-03332-2"). [Archived](https://web.archive.org/web/20230923141914/https://books.google.com/books?id=XzfxnlfFPMMC&pg=PR11) from the original on September 23, 2023. Retrieved April 15, 2020.

[^120]: Yang, Celia (2006). ["The Memorial Hall for the Victims of the Nanjing Massacre: Rhetoric in the Face of Tragedy"](https://web.archive.org/web/20070612003745/http://bootheprize.stanford.edu/0506/PWR-Yang.pdf) (PDF). p. 310. Archived from [the original](http://bootheprize.stanford.edu/0506/PWR-Yang.pdf) (PDF) on June 12, 2007.

[^121]: [Japan's Last Vets of Nanking Massacre Open Up](https://news.yahoo.com/s/afp/20100516/wl_asia_afp/japanchinahistoryfilmnanking) [Archived](http://archive.wikiwix.com/cache/20170116085220/https://news.yahoo.com/s/afp/20100516/wl_asia_afp/japanchinahistoryfilmnanking) January 16, 2017, at Wikiwix, Yahoo! News

[^122]: Lei, Wan (February 2010). ["The Chinese Islamic "Goodwill Mission to the Middle East" During the Anti-Japanese War"](https://www.academia.edu/4427135). *Dîvân Di̇si̇pli̇nlerarasi Çalişmalar Dergi̇si̇*. cilt 15 (sayı 29): 139–141. [Archived](https://web.archive.org/web/20140318035752/http://www.academia.edu/4427135/The_Chinese_Islamic_Goodwill_Mission_to_the_Middle_East_-_Japonyaya_Karsi_Savasta_Cinli_Muslumanlarin_Orta_Dogu_iyi_Niyet_Heyeti_-_Wan_LEI) from the original on March 18, 2014. Retrieved June 19, 2014.

[^123]: Wan, Lei (2010). ["The Chinese Islamic "Goodwill Mission to the Middle East" During the Anti-Japanese War"](https://dergipark.org.tr/tr/download/article-file/254594). *Dîvân Di̇si̇pli̇nlerarasi Çalişmalar Dergi̇si̇*. **15** (29): 133–170. [Archived](https://web.archive.org/web/20240221043546/https://dergipark.org.tr/tr/download/article-file/254594) from the original on February 21, 2024. Retrieved October 6, 2024.

[^124]: Wan LEI. ["The Chinese Islamic "Goodwill Mission to the Middle East" During the Anti-Japanese War"](https://web.archive.org/web/20241007101325/https://isamveri.org/pdfdrg/D01525/2010_29/2010_29_LEIW.pdf) (PDF). Archived from [the original](https://isamveri.org/pdfdrg/D01525/2010_29/2010_29_LEIW.pdf) (PDF) on October 7, 2024.

[^125]: [https://web.archive.org/web/20241007100057/http://ktp.isam.org.tr/detayilhmklzt.php?navdil=eng](https://web.archive.org/web/20241007100057/http://ktp.isam.org.tr/detayilhmklzt.php?navdil=eng)

[^126]: ["Internet History Sourcebooks: Modern History"](https://sourcebooks.fordham.edu/mod/nanking.asp). *sourcebooks.fordham.edu*. [Archived](https://web.archive.org/web/20230508201620/https://sourcebooks.fordham.edu/mod/nanking.asp) from the original on May 8, 2023. Retrieved May 8, 2023.

[^127]: Chang, Iris. *The Rape of Nanking*, [Penguin Books](https://en.wikipedia.org/wiki/Penguin_Books "Penguin Books"), 1997, p. 162.

[^128]: Woods, John E. (1998). *The Good Man of Nanking, the Diaries of John Rabe*. p. 271.

[^129]: [Chang 1997](#CITEREFChang1997), pp. 105–139.

[^130]: [Rabe, John](https://en.wikipedia.org/wiki/John_Rabe "John Rabe") (1998). [*The Good Man of Nanking, the Diaries of John Rabe*](https://en.wikipedia.org/wiki/The_Good_Man_of_Nanking "The Good Man of Nanking"). Translated by Woods, John E. [Knopf Publishing Group](https://en.wikipedia.org/wiki/Knopf_Publishing_Group "Knopf Publishing Group"). p. 274. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-375-40211-X](https://en.wikipedia.org/wiki/Special:BookSources/0-375-40211-X "Special:BookSources/0-375-40211-X").

[^131]: Woods, John E. (1998). *The Good Man of Nanking, the Diaries of John Rabe*. pp. 275–278.

[^132]: [John Rabe](http://www.moreorless.au.com/heroes/rabe.html) [Archived](https://web.archive.org/web/20130722090333/http://www.moreorless.au.com/heroes/rabe.html) July 22, 2013, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), moreorless

[^133]: ["John Rabe's letter to Hitler, from Rabe's diary"](http://www.jiyuu-shikan.org/nanjing/tpopu.html) Population of Nanking, Jiyuu-shikan.org [Archived](https://web.archive.org/web/20101229013854/http://www.jiyuu-shikan.org/nanjing/tpopu.html) December 29, 2010, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^134]: Chapel, Joseph (2004). ["Denial of the Holocaust and the Rape of Nanking"](http://www.history.ucsb.edu/faculty/marcuse/classes/133p/133p04papers/JChapelNanjing046.htm). [Archived](https://web.archive.org/web/20160303175232/http://www.history.ucsb.edu/faculty/marcuse/classes/133p/133p04papers/JChapelNanjing046.htm) from the original on March 3, 2016. Retrieved May 26, 2006.

[^135]: Dixon, Jennifer (2018). [*Dark Pasts: Changing the State's Story in Turkey and Japan*](https://books.google.com/books?id=5tpwDwAAQBAJ&dq=japan+dehumanize+nanjing+massacre&pg=PA96). Ithaca: [Cornell University Press](https://en.wikipedia.org/wiki/Cornell_University_Press "Cornell University Press"). p. 96. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-5017-3025-2](https://en.wikipedia.org/wiki/Special:BookSources/978-1-5017-3025-2 "Special:BookSources/978-1-5017-3025-2").

[^136]: [Frank 2020](#CITEREFFrank2020), p. 57.

[^137]: [Fogel 2000](#CITEREFFogel2000), p. 154.

[^138]: Kamimura, Marina (September 16, 1998). ["A Japanese veteran attempts to make peace with haunting memories"](https://web.archive.org/web/20080522173307/http://www.cnn.com/WORLD/asiapcf/9808/16/japan.war.crimes/). *[CNN](https://en.wikipedia.org/wiki/CNN "CNN")*. Archived from [the original](http://www.cnn.com/WORLD/asiapcf/9808/16/japan.war.crimes/) on May 22, 2008. Retrieved May 13, 2008.

[^139]: Drea, Edward (2009). *Japan's Imperial Army: Its Rise and Fall, 1853–1945*. University Press of Kansas. pp. 133–135.

[^140]: Yamamoto, Masahiro (2000). *Nanking: Anatomy of an Atrocity*. Praeger. p. 59.

[^141]: Yamamoto, Masahiro (2000). *Nanking: Anatomy of an Atrocity*. Praeger. p. 69.

[^142]: Harmsen, Peter (2015). *Nanjing 1937*. Casemate. pp. 251–252.

[^143]: Harmsen, Peter (2015). *Nanjing 1937: Battle for a Doomed City*. [Casemate Publishers](https://en.wikipedia.org/wiki/Casemate_Publishers "Casemate Publishers"). p. 259.

[^144]: Harmsen, Peter (2015). *Nanjing 1937*. Casemate. p. 148.

[^145]: Dorn, Frank (1974). *The Sino-Japanese War 1937–1941*. Macmillan. p. 93.

[^146]: [Hotta 2013](#CITEREFHotta2013), pp. 31, 47.

[^147]: [Hotta 2013](#CITEREFHotta2013), p. 32.

[^148]: Wakabayashi, Bob Tadashi (1991). ["Emperor Hirohito on Localized Aggression in China"](https://web.archive.org/web/20110721021647/http://chinajapan.org/articles/04.1/04.1wakabayashi4-27.pdf) (PDF). *[Sino-Japanese Studies](https://en.wikipedia.org/wiki/Sino-Japanese_Studies?action=edit&redlink=1 "Sino-Japanese Studies (page does not exist)")*. **4** (1): 15. Archived from [the original](http://chinajapan.org/articles/04.1/04.1wakabayashi4-27.pdf) (PDF) on July 21, 2011.

[^149]: [Spence, Jonathan D.](https://en.wikipedia.org/wiki/Jonathan_Spence "Jonathan Spence") (1999). *[The Search for Modern China](https://en.wikipedia.org/wiki/The_Search_for_Modern_China "The Search for Modern China")*. [W. W. Norton and Company](https://en.wikipedia.org/wiki/W._W._Norton_and_Company "W. W. Norton and Company"). p. 424. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-393-97351-4](https://en.wikipedia.org/wiki/Special:BookSources/0-393-97351-4 "Special:BookSources/0-393-97351-4").

[^150]: [Chang 1997](#CITEREFChang1997), pp. 51–52.

[^151]: Shinsho Hanayama, *The Way of Deliverance: Three Years with the Condemned Japanese War Criminals* (New York: Scribner, 1950), 185–186. [OCLC](https://en.wikipedia.org/wiki/OCLC_\(identifier\) "OCLC (identifier)") [1527099](https://www.worldcat.org/oclc/1527099)

[^152]: Lu, Suping (November 30, 2004). [*They Were In Nanjing: The Nanjing Massacre Witnessed By American And British Nationals*](https://books.google.com/books?id=0a7UAQAAQBAJ&pg=PA57). Hong Kong University Press. p. 57. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-962-209-685-1](https://en.wikipedia.org/wiki/Special:BookSources/978-962-209-685-1 "Special:BookSources/978-962-209-685-1"). [OCLC](https://en.wikipedia.org/wiki/OCLC_\(identifier\) "OCLC (identifier)") [57580469](https://search.worldcat.org/oclc/57580469).

[^153]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 9. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^154]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 10. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^155]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 9. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^156]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 21. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^157]: ["Bernhard Arp Sindberg: An Inventory of His Papers and Photography Collection at the Harry Ransom Center"](https://norman.hrc.utexas.edu/fasearch/findingAid.cfm?eadid=01295#). *norman.hrc.utexas.edu*. Retrieved May 29, 2024.

[^158]: Drea, Edward (2006). [*Researching Japanese War Crimes*](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 28. [Archived](https://web.archive.org/web/20160303190336/http://www.archives.gov/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF) from the original on March 3, 2016. Retrieved July 22, 2022.

[^159]: Kingston, Jeff. March 1, 2014. " [Japan's reactionaries waging culture war](http://www.japantimes.co.jp/opinion/2014/03/01/commentary/japans-reactionaries-waging-culture-war/#.UxMH8o1WF9A) [Archived](https://web.archive.org/web/20210116034251/http://www.japantimes.co.jp/opinion/2014/03/01/commentary/japans-reactionaries-waging-culture-war/#.UxMH8o1WF9A) 2021-01-16 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")." *[Japan Times](https://en.wikipedia.org/wiki/Japan_Times "Japan Times")*.

[^160]: Pan, Yihong (2025). *Not Just a Man's War: Chinese Women's Memories of the War of Resistance Against Japan, 1931-45*. [University of British Columbia Press](https://en.wikipedia.org/wiki/University_of_British_Columbia_Press "University of British Columbia Press"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [9780774870368](https://en.wikipedia.org/wiki/Special:BookSources/9780774870368 "Special:BookSources/9780774870368").

[^161]: Yang Daqing, "Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing", *The American Historical Review* 104 (1999)

[^162]: Askew, David (April 4, 2002). ["The Nanjing Incident: Recent Research and Trends"](https://web.archive.org/web/20180405031715/http://www.japanesestudies.org.uk/articles/Askew.html). Archived from [the original](http://www.japanesestudies.org.uk/articles/Askew.html) on April 5, 2018.

[^163]: Drea, Edward (2006). *Researching Japanese War Crimes*. National Archives and Records Administration for the Nazi Warcrimes and Japanese Imperial Government Records Interagency Working Group. p. 17.

[^164]: Iwanami Shinsho, Fujiwara Akira (editor). *Nankin jiken O Dou Miruka*, 1998, Aoki shoten, [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [4250980162](https://en.wikipedia.org/wiki/Special:BookSources/4250980162 "Special:BookSources/4250980162"), p. 18.

[^165]: Yoshida, Hiroshi. *Nankin jiken o dou miruka* p. 123, *Tennou no guntai to Nankin jiken* 1998, Aoki shoten, p. 160; [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [4250980197](https://en.wikipedia.org/wiki/Special:BookSources/4250980197 "Special:BookSources/4250980197").

[^166]: Takashi Yoshida, *The Making of the "Rape of Nanking"* (New York: Oxford University Press, 2006), 60.

[^167]: Yang, Daqing (2001). "Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing". *Perennial*. **104** (3): 842–865. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2650991](https://doi.org/10.2307%2F2650991). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-06-093130-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-06-093130-8 "Special:BookSources/978-0-06-093130-8"). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2650991](https://www.jstor.org/stable/2650991).

[^168]: Wudunn, Sheryl (December 13, 1998). ["The Good Nazi"](https://www.nytimes.com/1998/12/13/books/the-good-nazi.html). *The New York Times*. [Archived](https://web.archive.org/web/20240918195803/https://www.nytimes.com/1998/12/13/books/the-good-nazi.html) from the original on September 18, 2024. Retrieved March 6, 2024.

[^169]: Wakabayashi, Bob (2000). *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghahn. pp. 66–68.

[^170]: [Tokushi Kasahara](https://en.wikipedia.org/wiki/Tokushi_Kasahara "Tokushi Kasahara"). ["Le massacre de Nankin et les mécanismes de sa négation par la classe politique dirigeante"](http://www.ihtp.cnrs.fr/IMG/pdf_interventionsnankin-francais.pdf) \[The Nanjing Massacre and the mechanisms of its negation by the political ruling class\] (PDF). *ihtp.cnrs.fr* (in French).

[^171]: ["Documents of Nanjing Massacre (Nomination Form, International Memory of the World Register)"](https://web.archive.org/web/20220417091308/https://en.unesco.org/sites/default/files/china_nanjing_en.pdf) (PDF). Archived from [the original](https://en.unesco.org/sites/default/files/china_nanjing_en.pdf) (PDF) on April 17, 2022. Retrieved February 18, 2023.

[^172]: ["Documents of Nanjing Massacre"](https://web.archive.org/web/20221213235111/https://en.unesco.org/memoryoftheworld/registry/311). Archived from [the original](https://en.unesco.org/memoryoftheworld/registry/311) on December 13, 2022. Retrieved December 13, 2022.

[^173]: Wakabayashi, Bob. *The Nanking Atrocity, 1937–1938: Complicating the Picture*. Berghahn. p. 19.

[^174]: Yamamoto, Masahiro (2000). *Nanking: Anatomy of an Atrocity*. Praeger. p. 252.

[^175]: Ringle, Ken (January 8, 2024). ["THE FORGOTTEN HOLOCAUST"](https://www.washingtonpost.com/archive/lifestyle/1997/12/11/the-forgotten-holocaust/f824128d-7770-49d4-a93e-5126c7970520/). *[The Washington Post](https://en.wikipedia.org/wiki/The_Washington_Post "The Washington Post")*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0190-8286](https://search.worldcat.org/issn/0190-8286). Retrieved May 29, 2024.

[^176]: [U.S. Archives Reveal War Massacre of 500,000 Chinese by Japanese Army](http://news.xinhuanet.com/english/2007-12/12/content_7236237.htm) [Archived](https://web.archive.org/web/20071213073944/http://news.xinhuanet.com/english/2007-12/12/content_7236237.htm) December 13, 2007, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine").

[^177]: United States Department of State, ed. (1954). [*Foreign relations of the United States diplomatic papers, 1937. The Far East*](http://digicoll.library.wisc.edu/cgi-bin/FRUS/FRUS-idx?type=turn&id=FRUS.FRUS1937v03&entity=FRUS.FRUS1937v03.p0813). Vol. 3. U.S. Government Printing Office. p. 806. [Archived](https://web.archive.org/web/20160304042245/http://digicoll.library.wisc.edu/cgi-bin/FRUS/FRUS-idx?type=turn&id=FRUS.FRUS1937v03&entity=FRUS.FRUS1937v03.p0813) from the original on March 4, 2016. Retrieved November 13, 2014.

[^178]: Yang Daqing, "Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing", *The American Historical Review* 104 (1999), p. 4.

[^179]: [Herbert Bix](https://en.wikipedia.org/wiki/Herbert_Bix "Herbert Bix"), *[Hirohito and the Making of Modern Japan](https://en.wikipedia.org/wiki/Hirohito_and_the_Making_of_Modern_Japan "Hirohito and the Making of Modern Japan")*, 2000, p. 583

[^180]: [John W. Dower](https://en.wikipedia.org/wiki/John_W._Dower "John W. Dower"), *[Embracing Defeat: Japan in the Wake of World War II](https://en.wikipedia.org/wiki/Embracing_Defeat:_Japan_in_the_Wake_of_World_War_II "Embracing Defeat: Japan in the Wake of World War II")*, 1999, p. 326.

[^181]: Thomas M. Huber, *Japan's Battle of Okinawa, April–June 1945*, Leavenworth Papers Number 18, Combat Studies Institute, 1990, p. 47

[^182]: ["「松井石根研究会」の必要性について"](https://web.archive.org/web/20110721122627/http://www.history.gr.jp/~koa_kan_non/16-4.html). *history.gr.jp*. Archived from [the original](http://www.history.gr.jp/~koa_kan_non/16-4.html) on July 21, 2011.

[^183]: ["Hisao Tani"](https://web.archive.org/web/20100218182317/http://www.people.com.cn/media/200112/12/NewsMedia_147412.jpg). Archived from [the original](http://www.people.com.cn/media/200112/12/NewsMedia_147412.jpg) on February 18, 2010. Retrieved March 26, 2009.

[^184]: Awaya Kentarô, Yoshida Yutaka, *Kokusai kensatsukyoku jinmonchôsho*, dai 8 kan, Nihon Tosho Centâ, 1993., Case 44, pp. 358–366.

[^185]: ["Famous Visitors: Prince Yasuhiko Asaka and Princess Nobuko Asaka of Japan"](https://peacepalacelibrary.nl/blog/2013/famous-visitors-prince-yasuhiko-asaka-and-princess-nobuko-asaka-japan). *Peace Palace Library*. Retrieved October 20, 2026.

[^186]: ["Robert O. Wilson"](https://imtfe.law.virginia.edu/contributors/robert-o-wilson). [Archived](https://web.archive.org/web/20240227140608/http://imtfe.law.virginia.edu/contributors/robert-o-wilson) from the original on February 27, 2024. Retrieved March 6, 2024.

[^187]: ["Miner Searle Bates | Yale University Library"](https://web.library.yale.edu/divinity/nanking/bates). [Archived](https://web.archive.org/web/20240525082128/https://web.library.yale.edu/divinity/nanking/bates) from the original on May 25, 2024. Retrieved March 6, 2024.

[^188]: Zhang, Kaiyuan (2015). [*Eyewitnesses to Massacre*](https://api.pageplace.de/preview/DT0400.9781317470724_A24854418/preview-9781317470724_A24854418.pdf) (PDF). New York: Routledge. p. x. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-7656-0685-3](https://en.wikipedia.org/wiki/Special:BookSources/978-0-7656-0685-3 "Special:BookSources/978-0-7656-0685-3"). [Archived](https://web.archive.org/web/20240416192700/https://api.pageplace.de/preview/DT0400.9781317470724_A24854418/preview-9781317470724_A24854418.pdf) (PDF) from the original on April 16, 2024. Retrieved March 6, 2024.

[^189]: Cook, Joan (January 23, 1979). ["George A. Witch Dies; Worked for Y.M.C.A. In China for Decades"](https://www.nytimes.com/1979/01/23/archives/george-a-fitch-dies-worked-for-ymca-in-china-for-decades.html). *The New York Times*. [Archived](https://web.archive.org/web/20240912151901/https://www.nytimes.com/1979/01/23/archives/george-a-fitch-dies-worked-for-ymca-in-china-for-decades.html) from the original on September 12, 2024. Retrieved March 6, 2024.

[^190]: ["Atrocities"](https://imtfe.law.virginia.edu/subject-45?page=11). [Archived](https://web.archive.org/web/20240723042303/https://imtfe.law.virginia.edu/subject-45?page=11) from the original on July 23, 2024. Retrieved March 6, 2024.

[^191]: ["James Henry McCallum | Yale University Library"](https://web.library.yale.edu/divinity/nanking/mccallum). [Archived](https://web.archive.org/web/20231114024835/https://web.library.yale.edu/divinity/nanking/mccallum) from the original on November 14, 2023. Retrieved March 6, 2024.

[^192]: Lu, Suping (2013). "The Nanjing Massacre: Primary Source Records and Secondary Interpretations—A Textual Critique of Bob Tadashi Wakabayashi's Review". *China Review International*. **20** (3/4): 259–282. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [1069-5834](https://search.worldcat.org/issn/1069-5834). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [43818315](https://www.jstor.org/stable/43818315).

[^193]: Bix, Herbert (2001). ["Hirohito and the Making of Modern Japan"](https://archive.org/details/hirohitomakingmo00bixh). *Perennial*: [734](https://archive.org/details/hirohitomakingmo00bixh/page/n754). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-06-093130-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-06-093130-8 "Special:BookSources/978-0-06-093130-8").

[^194]: [Dower, John](https://en.wikipedia.org/wiki/John_W._Dower "John W. Dower") (2000). *Embracing defeat: Japan in the wake of World War II* (Paperback ed.). New York: Norton. p. 459. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-393-32027-5](https://en.wikipedia.org/wiki/Special:BookSources/978-0-393-32027-5 "Special:BookSources/978-0-393-32027-5").

[^195]: Brackman, Arnold C. (1988). *The other Nuremberg: the untold story of the Tokyo war trials*. New York: Quill. p. 395. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-688-07957-1](https://en.wikipedia.org/wiki/Special:BookSources/0-688-07957-1 "Special:BookSources/0-688-07957-1").

[^196]: Yang, Daqing (June 1999). ["Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing"](https://www.jstor.org/stable/2650991). *The Journal of Japanese Studies*. **104** (3): 857. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2650991](https://doi.org/10.2307%2F2650991). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2650991](https://www.jstor.org/stable/2650991). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [19291890](https://pubmed.ncbi.nlm.nih.gov/19291890).

[^197]: 国防部审判战犯军事法庭对战犯向井敏明等人的判决书. 民国史档案资料丛书—侵华日军南京大屠杀档案. 1947年12月18日: pp. 616–621.

[^198]: Sheng, Zhang (November 8, 2021). [*The Rape of Nanking: A Historical Study*](https://books.google.com/books?id=HrJIEAAAQBAJ&dq=Gunkichi+Tanaka+300&pg=PT442). Walter de Gruyter GmbH & Co KG. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-3-11-065289-5](https://en.wikipedia.org/wiki/Special:BookSources/978-3-11-065289-5 "Special:BookSources/978-3-11-065289-5"). [Archived](https://web.archive.org/web/20230923141942/https://books.google.com/books?id=HrJIEAAAQBAJ&dq=Gunkichi+Tanaka+300&pg=PT442) from the original on September 23, 2023. Retrieved September 24, 2022.

[^199]: ["Biography of Lieutenant-General Moritake Tanabe – (田辺盛武) – (たなべ もりたけ) (1889–1949), Japan"](https://www.generals.dk/general/Tanabe/Moritake/Japan.html). *www.generals.dk*. [Archived](https://web.archive.org/web/20230923142417/https://www.generals.dk/general/Tanabe/Moritake/Japan.html) from the original on September 23, 2023. Retrieved September 19, 2022.

[^200]: ["More names on Nanjing Massacre memorial wall"](http://www.china.org.cn/china/2016-12/11/content_39891069.htm). *www.china.org.cn*. [Archived](https://web.archive.org/web/20161211042757/http://china.org.cn/china/2016-12/11/content_39891069.htm) from the original on December 11, 2016. Retrieved March 31, 2017.

[^201]: ["Religious Assembly Held to Mourn Nanjing Massacre Victims"](http://en.chinagate.cn/photos/2009-12/14/content_19061762.htm). [Archived](https://web.archive.org/web/20170313041956/http://en.chinagate.cn/photos/2009-12/14/content_19061762.htm) from the original on March 13, 2017. Retrieved March 12, 2017.

[^202]: ["China holds first Nanjing Massacre memorial day"](https://www.telegraph.co.uk/news/worldnews/asia/china/11291820/China-holds-first-Nanjing-Massacre-memorial-day.html). *Telegraph.co.uk*. AFP. December 13, 2014. [Archived](https://ghostarchive.org/archive/20220110/https://www.telegraph.co.uk/news/worldnews/asia/china/11291820/China-holds-first-Nanjing-Massacre-memorial-day.html) from the original on January 10, 2022.

[^203]: Bary, Wm Theodore De; Gluck, Carol; Tiedemann, Arthur (October 3, 2006). [*Sources of Japanese Tradition, Abridged: 1600 to 2000; Part 2: 1868 to 2000*](https://books.google.com/books?id=DsALRa-r5QoC&dq=When+Japan+accepted+the+Potsdam+Declaration+and+surrendered+in+August+1945%2C+the+state+officially+acknowledged+the+war+of+aggression+and+the+Nanjing+massacre+committed+by+the+Japanese+army.&pg=PA564). Columbia University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-231-51815-4](https://en.wikipedia.org/wiki/Special:BookSources/978-0-231-51815-4 "Special:BookSources/978-0-231-51815-4"). [Archived](https://web.archive.org/web/20230627002412/https://books.google.com/books?id=DsALRa-r5QoC&dq=When%20Japan%20accepted%20the%20Potsdam%20Declaration%20and%20surrendered%20in%20August%201945%2C%20the%20state%20officially%20acknowledged%20the%20war%20of%20aggression%20and%20the%20Nanjing%20massacre%20committed%20by%20the%20Japanese%20army.&pg=PA564) from the original on June 27, 2023. Retrieved May 28, 2023 – via Google Books.

[^204]: ["The Nanjing Incident: Recent Research and Trends"](http://www.japanesestudies.org.uk/articles/Askew.html). April 4, 2002. [Archived](https://web.archive.org/web/20180405031715/http://www.japanesestudies.org.uk/articles/Askew.html) from the original on April 5, 2018. Retrieved October 20, 2004.

[^205]: Askew, David (March 2001). ["The Nanjing Incident: An Examination of the Civilian Population"](https://chinajapan.org/articles/13.2/13.2askew2-20.pdf) (PDF). *Sino-Japanese Studies*. **13** (2): 2. [Archived](https://web.archive.org/web/20240531162056/https://chinajapan.org/articles/13.2/13.2askew2-20.pdf) (PDF) from the original on May 31, 2024. Retrieved May 31, 2024.

[^206]: Yang, Daqing. ["A SINO-JAPANESE CONTROVERSY: THE NANJING ATROCITY AS HISTORY"](https://chinajapan.org/articles/03.1/03.1.14-35yang.pdf) (PDF). *Sino-Japanese Studies*: 18.

[^207]: Honda, Katsuich. "Chūgoku no Tabi" (中国の旅), "Travels in China"". *[Asahi Shimbun](https://en.wikipedia.org/wiki/Asahi_Shimbun "Asahi Shimbun")*.

[^208]: Yang, Daqing. ["A SINO-JAPANESE CONTROVERSY: THE NANJING ATROCITY AS HISTORY"](https://chinajapan.org/articles/03.1/03.1.14-35yang.pdf) (PDF). *Sino-Japanese Studies*: 20. [Archived](https://web.archive.org/web/20230309191845/https://chinajapan.org/articles/03.1/03.1.14-35yang.pdf) (PDF) from the original on March 9, 2023. Retrieved June 7, 2024.

[^209]: Ono Kenji, "Massacre Near Mufushan," in The Nanking Atrocity, 1937–38: Complicating the Picture, ed. Bob Tadashi Wakabayashi (New York: Berghahn Books, 2008), p. 85.

[^210]: Masahiro Yamamoto, Nanking: Anatomy of an Atrocity (Westport, Connecticut: Praeger, 2000), 112.

[^211]: Bob Tadashi Wakabayashi, "Leftover Problems," in The Nanking Atrocity, 1937–38: Complicating the Picture, ed. Bob Tadashi Wakabayashi (New York: Berghahn Books, 2008), 382–384.

[^212]: David Askew, "The Scale of Japanese Atrocities in Nanjing: An Examination of the Burial Records," Ritsumeikan Journal of Asia Pacific Studies, June 2004, 7–10.

[^213]: Gallicchio, Marc S. 2007. *The Unpredictability of the Past*. p. 158.

[^214]: Yoshida, Takashi. 2006. *The Making of the 'Rape of Nanking'.* pp. 157–158.

[^215]: Jun Hongo (February 23, 2012). ["Nagoya mayor won't budge on Nanjing remark"](https://web.archive.org/web/20120713031230/http://www.japantimes.co.jp/text/nn20120223a5.html). *Japan Times*. Archived from [the original](http://www.japantimes.co.jp/text/nn20120223a5.html) on July 13, 2012. Retrieved February 22, 2012.

[^216]: ["Japan ruling MPs call Nanjing massacre fabrication"](https://web.archive.org/web/20090522051839/http://www.alertnet.org/thenews/newsdesk/T214128.htm). June 19, 2007. Archived from [the original](http://www.alertnet.org/thenews/newsdesk/T214128.htm) on May 22, 2009. Retrieved March 19, 2009.

[^217]: Schneider, Florian (August 16, 2018). [*China's Digital Nationalism*](https://books.google.com/books?id=DXBoDwAAQBAJ). Oxford University Press. pp. 123–124. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-087681-4](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-087681-4 "Special:BookSources/978-0-19-087681-4"). [Archived](https://web.archive.org/web/20230829111146/https://books.google.com/books?id=DXBoDwAAQBAJ) from the original on August 29, 2023. Retrieved July 31, 2023.

[^218]: Gustafsson, Karl (July 18, 2019). ["International reconciliation on the Internet? Ontological security, attribution and the construction of war memory narratives in Wikipedia"](https://doi.org/10.1177%2F0047117819864410). *International Relations*. **34** (1): 3–24. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/0047117819864410](https://doi.org/10.1177%2F0047117819864410). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0047-1178](https://search.worldcat.org/issn/0047-1178). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [200020669](https://api.semanticscholar.org/CorpusID:200020669).

[^219]: Sato, Yumiko (March 19, 2021). ["Non-English Editions of Wikipedia Have a Misinformation Problem"](https://slate.com/technology/2021/03/japanese-wikipedia-misinformation-non-english-editions.html). *[Slate](https://en.wikipedia.org/wiki/Slate_\(magazine\) "Slate (magazine)")*. The Slate Group. [Archived](https://web.archive.org/web/20220314115723/https://slate.com/technology/2021/03/japanese-wikipedia-misinformation-non-english-editions.html) from the original on March 14, 2022. Retrieved August 23, 2021.

[^220]: Sato, Yumiko (January 9, 2021). ["日本語版ウィキペディアで「歴史修正主義」が広がる理由と解決策"](https://yumikosato.com/2021/01/09/japanese-wikipedia/) \[Reasons Why "Historical Revisionism" is Widespread on Japanese Wikipedia and Solutions for It\]. *Yumiko Sato's Music Therapy Journal* (in Japanese). [Archived](https://web.archive.org/web/20210806005724/https://yumikosato.com/2021/01/09/japanese-wikipedia/) from the original on August 6, 2021. Retrieved August 23, 2021.

[^221]: Yuan 2004

[^222]: Pu, Xiaoyu (September 30, 2005). ["The Nanking Massacre, Justice and Reconciliation: A Chinese Perspective"](https://web.archive.org/web/20090325100403/http://www.oycf.org/oycfold/httpdocs/Perspectives2/30_09302005/2c_Pu_NankingMassacre.pdf) (PDF). *Perspectives*. **6** (3). Archived from the original on March 25, 2009. Retrieved March 21, 2009.

[^223]: Yoshida, Takashi. The Making of the *Rape of Nanking*: History and Memory in Japan, China, and the United States (New York: Oxford University Press, 2006), p. 5.

[^224]: ["Fury as Koizumi honours war dead"](http://www.theage.com.au/news/world/fury-as-koizumi-honours-war-dead/2006/08/15/1155407790276.html). *The Age*. Melbourne. August 15, 2006. [Archived](https://web.archive.org/web/20170816100010/http://www.theage.com.au/news/world/fury-as-koizumi-honours-war-dead/2006/08/15/1155407790276.html) from the original on August 16, 2017. Retrieved September 17, 2009.

[^225]: ["In Japan, denial over Nanjing still holds sway after 70 years"](https://www.csmonitor.com/2007/1214/p04s01-woap.html). *The Christian Science Monitor*. [Archived](https://web.archive.org/web/20180630214229/https://www.csmonitor.com/2007/1214/p04s01-woap.html) from the original on June 30, 2018. Retrieved March 6, 2011.

[^226]: Mao, Yushi (2014). ["Lessons from China's Great Famine"](https://www.cato.org/sites/cato.org/files/serials/files/cato-journal/2014/9/cj34n3-2.pdf) (PDF). *Cato Journal*. **34** (3): 486. [Archived](https://web.archive.org/web/20211127182608/https://www.cato.org/sites/cato.org/files/serials/files/cato-journal/2014/9/cj34n3-2.pdf) (PDF) from the original on November 27, 2021. Retrieved December 14, 2021.

[^227]: Monk, Paul (1997). "Book review. 'Hungry Ghosts: Mao's Secret Famine' by Jasper Becker". *The China Journal*. **38**: 201–202. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2950355](https://doi.org/10.2307%2F2950355). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2950355](https://www.jstor.org/stable/2950355).

[^228]: Brown, Clayton D. (2014). ["Book review. 'Tombstone: The Great Chinese Famine, 1958–1962' by Yang Jisheng"](https://www.asianstudies.org/publications/eaa/archives/tombstone-the-great-chinese-famine-1958-1962/). *Education About Asia*. **19** (2): 92. [Archived](https://web.archive.org/web/20211215100007/https://www.asianstudies.org/publications/eaa/archives/tombstone-the-great-chinese-famine-1958-1962/) from the original on December 15, 2021. Retrieved December 16, 2021.

[^229]: Martina, Michael (July 3, 2014). ["China cites Japan wartime 'confessions' in propaganda push"](https://www.reuters.com/article/us-china-japan-idUSKBN0F80M320140703). *Reuters*. [Archived](https://web.archive.org/web/20230923142417/https://www.reuters.com/article/us-china-japan-idUSKBN0F80M320140703) from the original on September 23, 2023. Retrieved December 16, 2021.

[^230]: Mirsky, Jonathan (December 2, 1998). ["The Chinese, Too, Have Much to Apologize For"](https://www.nytimes.com/1998/12/02/opinion/IHT-the-chinese-too-have-much-to-apologize-for.html). *[The New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times")*. [Archived](https://web.archive.org/web/20211215100007/https://www.nytimes.com/1998/12/02/opinion/IHT-the-chinese-too-have-much-to-apologize-for.html) from the original on December 15, 2021. Retrieved December 16, 2021.

[^231]: Hillenbrand, Margaret (2020). *Negative exposures: knowing what not to know in contemporary China*. [Duke University Press](https://en.wikipedia.org/wiki/Duke_University_Press "Duke University Press"). p. xix.

[^232]: Yoshida, Takashi (2006). [*The Making of the "Rape of Nanking"*](https://archive.org/details/makingrapenankin00yosh). [Oxford University Press](https://en.wikipedia.org/wiki/Oxford_University_Press "Oxford University Press"), USA. p. [5](https://archive.org/details/makingrapenankin00yosh/page/n15). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-518096-1](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-518096-1 "Special:BookSources/978-0-19-518096-1").

[^233]: ["Special Report: How the Nanjing Massacre became a weapon"](https://globalriskinsights.com/2016/10/how-nanjing-became-a-political-tool/). *Global Risk Insights*. October 27, 2016. [Archived](https://web.archive.org/web/20210213115914/https://globalriskinsights.com/2016/10/how-nanjing-became-a-political-tool/) from the original on February 13, 2021. Retrieved January 25, 2021.

[^234]: Chang, Jung; Halliday, Jon (2005). *Mao: The Unknown Story* (1st American ed.). New York: Knopf. p. 207. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-679-42271-4](https://en.wikipedia.org/wiki/Special:BookSources/0-679-42271-4 "Special:BookSources/0-679-42271-4"). [OCLC](https://en.wikipedia.org/wiki/OCLC_\(identifier\) "OCLC (identifier)") [57357425](https://search.worldcat.org/oclc/57357425).

[^235]: Yang, Daqing (1999). "Convergence or Divergence? Recent Historical Writings on the Rape of Nanjing". *The American Historical Review*. **104** (3): 842–865. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2650991](https://doi.org/10.2307%2F2650991). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0002-8762](https://search.worldcat.org/issn/0002-8762). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2650991](https://www.jstor.org/stable/2650991). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [19291890](https://pubmed.ncbi.nlm.nih.gov/19291890).

[^236]: Yang, Daqing. ["A SINO-JAPANESE CONTROVERSY: THE NANJING ATROCITY AS HISTORY"](https://chinajapan.org/articles/03.1/03.1.14-35yang.pdf) (PDF). *Sino-Japanese Studies*: 24–28. [Archived](https://web.archive.org/web/20230309191845/https://chinajapan.org/articles/03.1/03.1.14-35yang.pdf) (PDF) from the original on March 9, 2023. Retrieved June 7, 2024.

[^237]: French, Howard W. (2017). *Everything under the Heavens: How the past helps shape China's push for global power*. Knopf. pp. 201–203.

[^238]: Qian, Fengqi; Liu, Guoqiang (2019). "Remembrance of the Nanjing Massacre in the Globalised Era: The Memory of Victimisation, Emotions and the Rise of China". *China Report*. **55** (2): 86–88. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/0009445519834365](https://doi.org/10.1177%2F0009445519834365). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [159087909](https://api.semanticscholar.org/CorpusID:159087909).

[^239]: Zhang Rui (June 22, 2025). ["'Dead to Rights' highlights Japanese wartime atrocities in Nanjing Massacre"](http://www.china.org.cn/2025-06/22/content_117940733.shtml). *[China.org.cn](https://en.wikipedia.org/wiki/China_Internet_Information_Center "China Internet Information Center")*. [China International Communications Group](https://en.wikipedia.org/wiki/China_International_Communications_Group "China International Communications Group"). Retrieved July 30, 2025.

[^240]: Xu Fan (July 25, 2025). ["Nanjing Massacre film showing in theaters"](https://global.chinadaily.com.cn/a/202507/25/WS68833560a310ad07b5d9207a.html). *[China Daily](https://en.wikipedia.org/wiki/China_Daily "China Daily")*. China Daily Information Co. Retrieved July 30, 2025.

[^241]: Zhang Xi (July 30, 2025). ["Nanjing film aims to counter amnesia, not fuel animosity"](https://global.chinadaily.com.cn/a/202507/30/WS688958dea310c26fd717c61a.html). *[China Daily](https://en.wikipedia.org/wiki/China_Daily "China Daily")*. China Daily Information Co. Retrieved July 30, 2025.

[^242]: Yoshida, Takashi (2006). *The Making of the 'Rape of Nanking'*.

[^243]: He, Yinan, ed. (2009), ["Volatility and Downward Spiral: Sino-Japanese Relations from the 1990s to the Present"](https://www.cambridge.org/core/books/abs/search-for-reconciliation/volatility-and-downward-spiral-sinojapanese-relations-from-the-1990s-to-the-present/2AF2859A3218664DD97FD131BC79787F), *The Search for Reconciliation: Sino-Japanese and German-Polish Relations since World War II*, Cambridge: Cambridge University Press, pp. 234–288, [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1017/CBO9780511770463.008](https://doi.org/10.1017%2FCBO9780511770463.008), [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-521-51440-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-521-51440-8 "Special:BookSources/978-0-521-51440-8"), retrieved November 9, 2024

[^244]: ["Ministry of Foreign Affairs of Japan"](http://www.mofa.go.jp/policy/q_a/faq16.html#q8). [Archived](https://web.archive.org/web/20141213205234/http://www.mofa.go.jp/policy/q_a/faq16.html#q8) from the original on December 13, 2014. Retrieved June 15, 2015.

[^245]: ["Examining the Japanese History Textbook Controversies"](http://spice.fsi.stanford.edu/docs/examining_the_japanese_history_textbook_controversies). *spice.fsi.stanford.edu*. [Stanford University](https://en.wikipedia.org/wiki/Stanford_University "Stanford University"). [Archived](https://web.archive.org/web/20230405140507/https://spice.fsi.stanford.edu/docs/examining_the_japanese_history_textbook_controversies) from the original on April 5, 2023. Retrieved October 12, 2023.

[^246]: ["Japanese Textbook Controversies, Nationalism, and Historical Memory: Intra- and Inter-national Conflicts"](https://apjjf.org/-Mark-Selden/3173/article.html). *The Asia-Pacific Journal: Japan Focus*. June 15, 2009. [Archived](https://web.archive.org/web/20200806174824/https://apjjf.org/-Mark-Selden/3173/article.html) from the original on August 6, 2020. Retrieved October 12, 2023.

[^247]: "Nankin dai gyakusatsu" 南京大虐殺 \[Nanjing massacre\]. [*Encyclopedia Nipponica*](https://kotobank.jp/word/%E5%8D%97%E4%BA%AC%E5%A4%A7%E8%99%90%E6%AE%BA-108774) (in Japanese). [Shogakukan](https://en.wikipedia.org/wiki/Shogakukan "Shogakukan"). March 24, 2021. [Archived](https://web.archive.org/web/20231017074405/https://kotobank.jp/word/%E5%8D%97%E4%BA%AC%E5%A4%A7%E8%99%90%E6%AE%BA-108774) from the original on October 17, 2023. Retrieved October 12, 2023.

[^248]: Oi, Mariko (March 14, 2013). ["What Japanese history lessons leave out"](https://www.bbc.com/news/magazine-21226068). *[BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News")*. [Archived](https://web.archive.org/web/20180616083041/https://www.bbc.com/news/magazine-21226068) from the original on June 16, 2018. Retrieved June 20, 2018.

[^249]: Wang, Zheng (April 23, 2014). ["History Education: The Source of Conflict Between China and Japan"](https://thediplomat.com/2014/04/history-education-the-source-of-conflict-between-china-and-japan/). *The Diplomat*. [Archived](https://web.archive.org/web/20171111205550/https://thediplomat.com/2014/04/history-education-the-source-of-conflict-between-china-and-japan/) from the original on November 11, 2017. Retrieved November 12, 2017.

[^250]: ["0.03% of junior high students to use disputed textbook Japan Policy & Politics"](https://web.archive.org/web/20070707191736/http://findarticles.com/p/articles/mi_m0XPQ/is_2001_August_20/ai_78375128). *Japan Policy & Politics*. July 7, 2007. Archived from the original on July 7, 2007. Retrieved October 12, 2023.

[^251]: Jones, Paul. "2001 ASSLH conference – Chinese seamen and Australian labour: The mass desertion from the *SS Silksworth* at Newcastle, October 1937". Retrieved September 26, 2013.

[^252]: ["Nanjing massacre victims named"](http://news.bbc.co.uk/2/hi/asia-pacific/7126455.stm). *[BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News")*. December 4, 2007. [Archived](https://web.archive.org/web/20071206012016/http://news.bbc.co.uk/2/hi/asia-pacific/7126455.stm) from the original on December 6, 2007. Retrieved December 4, 2007.

[^253]: ["以史為鑒面向未來——《南京大屠殺史料集》評介--黨史頻道-人民網"](http://dangshi.people.com.cn/BIG5/n/2014/0915/c85037-25663543.html). *dangshi.people.com.cn*. [Archived](https://web.archive.org/web/20241109040606/http://dangshi.people.com.cn/BIG5/n/2014/0915/c85037-25663543.html) from the original on November 9, 2024. Retrieved November 9, 2024.