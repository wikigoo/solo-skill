---
title: Automatism - sane and insane
source: https://www.judcom.nsw.gov.au/publications/benchbks/criminal/automatism.html
tags:
  - criminal
---
### \[6-050\] Preliminary notes

1.

Criminal responsibility does not attach to an act done in a state of automatism, that is, where the act is not done in consciousness of the nature of the act and in exercise of a choice to do an act of that nature: *Ryan v The Queen* (1967) 121 CLR 205 at 213; *R v Falconer* (1990) 171 CLR 30 at 39.

2.

The general presumption that an accused has the mental capacity to act in such a way as to incur criminal responsibility includes a presumption that the relevant act was willed or voluntary, that is, if the accused was apparently conscious at the time: *R v Falconer* at 40.

3.

Where an issue of voluntariness due to automatism arises (as to which, the accused bears an evidential burden of showing a reasonable possibility that the act was not willed: *R v Youssef* (1990) 50 A Crim R 1 at 3), consideration has to be given as to the aetiology of the automatism, since the manner in which the issue is left to the jury depends on the distinction drawn between sane and insane automatism.

4.

Where there is some evidence of automatism which points to an aetiology other than a mental health or cognitive impairment, the Crown must prove beyond reasonable doubt, that the relevant act was a willed and voluntary one, that is, was not the result of a condition of automatism, otherwise the accused is entitled to an outright acquittal.

5.

The relationship between voluntariness, intent and mental disease was considered by the High Court in *Hawkins v The Queen* (1994) 179 CLR 500.

6.

As to the distinction between an underlying mental infirmity which is prone to recur, which deprives the accused of the capacity to control his or her act and which prevents him or her from appreciating its nature and quality (insane automatism); and a transient, non-recurrent mental malfunction caused by external factors (whether physical or psychological) which the mind of an ordinary person would be likely not to have withstood and which produces an incapacity to control his or her acts (sane automatism), see: *R v Falconer* at 30, 53.

7.

Illustrations of sane automatism include —

(a)

the act of a sleepwalker: *R v Tolson* (1889) 23 QBD 168 at 187; *R v DB* \[2022\] NSWCCA 87 at \[43\];

(b)

post-traumatic loss of control due to head injury: *Bratty v Attorney-General (Northern Ireland)* (1963) AC 386 at 401 and 415; *Cooper v McKenna* (1960) Qd R 406;

(c)

an act done in a state of temporary or transient dissociation following severe emotional shock or psychological trauma, which was not prone to recur and which the mind of an ordinary person (of the accused’s age and circumstances and of normal temperament and control) would be likely not to have withstood: *R v Falconer* at 56–57;

(d)

an act done under the influence of an anaesthetic: *R v Sullivan* (1984) AC 156.

(e)

some forms of epilepsy, depending on their aetiology: *R v Youssef*.

8.

It will be a matter for the trial judge to determine whether there is evidence sufficient for the issue of automatism to be left to the jury and the basis on which it should be left: *R v Mcleod* (1991) 56 A Crim R 320. Commonly, it will be clear that the condition is referable exclusively to a mental health or cognitive impairment in which case only those defences should be left, as to which see **\[[6-200](https://www.judcom.nsw.gov.au/publications/benchbks/criminal/mental_illness.html#p6-200)\]**. It would be inappropriate in such a case to direct the jury as to sane automatism. In other cases, the reverse may be the position.

9.

If the evidence is capable of demonstrating either form of automatism, then it must be left to the jury for them to decide whether the automatism was sane or insane in nature, and to consider it accordingly in relation to the issue to which it thereby becomes relevant: *R v Youssef* at 5–6. In such cases, a full direction will need to be given as to the distinction between the two strands of automatism and as to the evidential burden and standard of proof. Additionally, the special directions required under s 28 of the *Mental Health and Cognitive Impairment Forensic Provisions Act 2020* would need to be given, see **\[[6-280](https://www.judcom.nsw.gov.au/publications/benchbks/criminal/mental_illness.html#p6-280)\]**.

### \[6-060\] Suggested direction

In order for an accused to be convicted of a crime, his or her act (giving rise to the unlawful conduct) must be voluntary.

Where an act (otherwise criminal) is done in a state of automatism, that is, without control or direction of the will of the accused over what is being done, then no crime is committed and the accused must be found “not guilty”. Here automatism raises itself for your consideration because of the evidence … \[*outline the evidence*\].

Although the defence has raised this issue for you to consider, this does not mean that it is the accused who bears the onus of proving that \[*his/her*\] act was done in a state of automatism. It is for the Crown to prove beyond reasonable doubt that all of the ingredients of \[*the offence*\] were present, and one of these is the requirement that the act be voluntary.

It is therefore for the Crown to prove beyond reasonable doubt that the act of the accused was voluntary, that is, it is for the Crown to remove any reasonable doubt from your minds as to whether the accused was acting as an automaton, divested of the control and direction of \[*his/her*\] will over what \[*he/she*\] was doing.

\[*Where the case involves sane automatism*\] Automatism in this case does not involve any question of mental health impairment or cognitive impairment. It is concerned with involuntariness, which does not derive from any of those conditions.

To summarise, unless the Crown proves beyond reasonable doubt that the act of the accused was subject to the control and direction of \[*his/her*\] will, then \[*he/she*\] must be acquitted because no offence has been committed.

\[*Where the case involves insane automatism*\] If you conclude the Crown has proved beyond reasonable doubt that the act of the accused was voluntary, you must then consider whether the accused had a mental health or cognitive impairment so as not to be responsible according to law. \[*Follow with suggested direction under s 28 of the Mental Health and Cognitive Impairment Forensic Provisions Act 2020 at \[[6-280](https://www.judcom.nsw.gov.au/publications/benchbks/criminal/mental_illness.html#p6-280)\]*\].