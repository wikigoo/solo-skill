---
title: "Study Reveals People Are Talking Less: 15-Year Decline"
source: https://everydayresearchmethods.com/2026/05/were-talking-less/
description: Discover why recent studies show people are speaking less daily than 15 years ago and how it affects communication and well-being.
tags:
  - Anthropology
  - Technology
---
In the textbook’s Chapter 6 you read about an Electronically Activated Recorder, or EAR device, which is able to record people’s conversations throughout the day. Researchers have used it to estimate how many words people speak per day. You might remember how the original study found no gender difference in words spoken per day. They also use the EAR to see if people who speak more words are also more likely to have certain traits such as extroversion or happiness.

![](https://i0.wp.com/everydayresearchmethods.com/wp-content/uploads/2026/05/week-354_shutterstock_1343268506.jpg?resize=2048%2C1365&ssl=1)

The study found that the decline in the amount of words spoken was more dramatic for younger compared to older adults. Photo: Monkey Business Images/Shutterstock

A new paper from the EAR research lab has just been published, and **[it was featured in an interview on the CBC Radio Canada.](https://www.cbc.ca/player/play/audio/9.7168559)** The study found something surprising: People are talking less now than they did 15 years ago.

In an interview, one of the study’s authors, Valeria Pfeifer, explains that she discovered the effect almost by accident: “we were originally looking at gender differences in the amount of words that people speak in a given day. But when we were doing the statistics for this study, I noticed that the estimate that we got for the more recent studies from 2019 was a lot lower than that from the studies that we did earlier in 2005.” Specifically, Dr. Pfiefer noticed that “the year that a study was being reported actually predicted a lower amount of daily spoken words.”

Pfiefer and Mehl’s published study “found that in 2019, people spoke an average of about 12,700 words per day compared to 15,900 back in 2005. The decline was significantly worse in younger individuals than older, leading the scientists to suggest the rise in smartphone use and social media may be playing a role.”

a) In the original empirical article, published in *[**Perspectives in Psychological Science**](https://doi.org/10.1177/17456916261425131)*, you can see a scatterplot showing year on the x-axis and “daily number of words” on the y-axis. Before you look at the scatterplot, sketch it out yourself. According to what you’ve learned so far, how *should* the scatterplot’s cloud of points slope–upwards, downwards, or flat?

b) When the interviewing journalist asked Dr. Pfiefer about how large this decline was, she used a bookshelf analogy: “if you imagine that how many words we speak in a day is a little bookshelf, then each year we lose about one book from that bookshelf. There were probably about 40 books there in 2005 and now were a lot lower, say closer to 30 books.”  
  
Do you think this analogy describes a small, medium, or large effect size?

c) The study found that the decline has been steeper for people under 25 compared to people over 25. This is a moderator! Write about it in a sentence like this: “\_\_\_\_\_\_ moderates the relationship between \_\_\_\_\_ and \_\_\_\_\_\_\_.”

d) In the opening scenario, the journalist observed that in a coffee shop, many people now order their drinks from an app, meaning they don’t have to talk to any cashiers or baristas. Perhaps this is one of the reasons why our amount of talking has gone down. They also mention social media use. Can you think of other factors? How might you test these factors?

e) We might wonder what impact, if any, the COVID pandemic has had on this downward trend. What do you think?

f) At the end of the interview, Pfiefer says, “there is data showing that speaking more generally is associated with higher psychological well-being. That’s true for both introverts and extroverts. So if we have fewer spoken conversations it’s likely that this will also impact our well-being.” What do you think? Could less talking be a contributor to our culture’s current struggles with loneliness and well-being?