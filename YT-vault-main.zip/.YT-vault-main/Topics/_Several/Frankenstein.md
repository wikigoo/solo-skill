---
title: "Frankenstein"
source: "https://en.wikipedia.org/wiki/Frankenstein"
---
***Frankenstein; or, The Modern Prometheus*** is an 1818 [Gothic novel](https://en.wikipedia.org/wiki/Gothic_fiction "Gothic fiction") [^1] written by English author [Mary Shelley](https://en.wikipedia.org/wiki/Mary_Shelley "Mary Shelley"). It tells the story of [Victor Frankenstein](https://en.wikipedia.org/wiki/Victor_Frankenstein "Victor Frankenstein"), a young scientist who creates a [sapient](https://en.wikipedia.org/wiki/Sapience "Sapience") creature from different body parts in an unorthodox scientific experiment. Shelley started writing the story when she was 18 and staying in [Bath](https://en.wikipedia.org/wiki/Bath,_Somerset "Bath, Somerset"),[^4] and the first edition was published anonymously in London on 1 January 1818, when she was 20. Her name first appeared in a French translation published in Paris in 1821.

Shelley travelled through Europe in 1815, moving along the river [Rhine](https://en.wikipedia.org/wiki/Rhine "Rhine") in Germany, and stopping in [Gernsheim](https://en.wikipedia.org/wiki/Gernsheim "Gernsheim"), 17 kilometres (11 mi) away from [Frankenstein Castle](https://en.wikipedia.org/wiki/Frankenstein_Castle "Frankenstein Castle"), where, about a century earlier, [Johann Konrad Dippel](https://en.wikipedia.org/wiki/Johann_Konrad_Dippel "Johann Konrad Dippel"), an [alchemist](https://en.wikipedia.org/wiki/Alchemist "Alchemist"), had engaged in experiments.[^5] [^6] [^7] She then journeyed to the region of [Geneva](https://en.wikipedia.org/wiki/Geneva "Geneva"), [Switzerland](https://en.wikipedia.org/wiki/Restoration_and_Regeneration_in_Switzerland "Restoration and Regeneration in Switzerland"), where much of the story takes place. [Galvanism](https://en.wikipedia.org/wiki/Galvanism "Galvanism") and [occult](https://en.wikipedia.org/wiki/Occult "Occult") ideas were topics of conversation for her companions, particularly for her lover and future husband, [Percy Bysshe Shelley](https://en.wikipedia.org/wiki/Percy_Bysshe_Shelley "Percy Bysshe Shelley").

In 1816—at the suggestion of [Lord Byron](https://en.wikipedia.org/wiki/Lord_Byron "Lord Byron") —Mary, Percy, [John Polidori](https://en.wikipedia.org/wiki/John_Polidori "John Polidori") and Byron himself, each agreed to try writing a ghost story.[^8] After thinking for days, Shelley was inspired to write *Frankenstein* after imagining a scientist who created life and was horrified by what he had made.[^9] The novel was first published anonymously in 1818, and in 1831, a revised edition was published under Mary Shelley's name. This version included significant stylistic revisions, a new preface describing the story's conception, and a more explicitly moral tone.[^10]

*Frankenstein* is one of the best-known works of [English literature](https://en.wikipedia.org/wiki/English_literature "English literature"). Infused with elements of the [Gothic novel](https://en.wikipedia.org/wiki/Gothic_novel "Gothic novel") and the [Romantic](https://en.wikipedia.org/wiki/Romanticism "Romanticism") movement, it has had a considerable influence on literature and on popular culture, spawning a complete genre of horror stories, films, and plays. Since the publication of the novel, the name Frankenstein has often been used, erroneously, to [refer to the monster](https://en.wikipedia.org/wiki/Frankenstein's_monster "Frankenstein's monster") rather than the man who created it.[^11] [^12] [^13]

## Plot summary

[Victor Frankenstein](https://en.wikipedia.org/wiki/Victor_Frankenstein "Victor Frankenstein"), born in late 18th-century [Naples](https://en.wikipedia.org/wiki/Kingdom_of_Naples "Kingdom of Naples") to an upper-class [Genevese](https://en.wikipedia.org/wiki/Republic_of_Geneva "Republic of Geneva") family, spends his youth obsessed with [alchemy](https://en.wikipedia.org/wiki/Alchemy "Alchemy"). As he grows older, he develops an interest in modern sciences such as chemistry and electricity. After his mother Caroline dies of [scarlet fever](https://en.wikipedia.org/wiki/Scarlet_fever "Scarlet fever"), Victor leaves home to attend the [University of Ingolstadt](https://en.wikipedia.org/wiki/University_of_Ingolstadt "University of Ingolstadt"). Through his studies, Victor discovers a new way to create life, assembling human body parts stolen from [charnel houses](https://en.wikipedia.org/wiki/Charnel_house "Charnel house") and fresh graves, which he uses to create a large and grotesque humanoid creature. When [the creature](https://en.wikipedia.org/wiki/Frankenstein's_monster "Frankenstein's monster") awakens, Victor is repelled by it and flees in terror, returning the next day to find the creature gone.

The newly conscious creature runs away, discovers fire, and learns to avoid humans, who find him frightening. He finds a hovel attached to a small house, which lets him observe a family while remaining unseen. As the family teaches their language to a foreigner, the creature also learns to speak and write. He also finds a collection of books, including *[Paradise Lost](https://en.wikipedia.org/wiki/Paradise_Lost "Paradise Lost")*, and learns to read. He reads some papers that had been in the clothes he had taken from [Ingolstadt](https://en.wikipedia.org/wiki/Ingolstadt "Ingolstadt"), through which he learns the truth of his origin and the identity of his creator. He finally reveals himself to the family's blind father while he is alone, who treats him with kindness. When the rest of the family returns, however, they are horrified by his appearance and chase him away. The creature then saves a young girl from drowning, only to be shot by her father, who had misunderstood, and thought the creature had attacked her.

Embittered by humanity, the creature travels to Geneva to confront his creator; upon arrival, he encounters Victor's younger brother, William. Realizing that William belongs to the same family, the creature kills him, then frames the family's servant Justine for his death. Victor suspects his creature was responsible, but does not intervene while Justine is tried and executed. Later, while hiking on [Mer de Glace](https://en.wikipedia.org/wiki/Mer_de_Glace "Mer de Glace"), Victor once more encounters the creature. The creature relays his story and asks Victor to create a female companion, which he believes will be his only chance at happiness. Victor consents to this.

> "Oh, Frankenstein, be not equitable to every other, and trample upon me alone, to whom thy justice, and even thy clemency and affection, is most due. Remember, that I am thy creature; I ought to be thy [Adam](https://en.wikipedia.org/wiki/Adam "Adam"); but I am rather the [fallen angel](https://en.wikipedia.org/wiki/Fallen_angel "Fallen angel"), whom thou drivest from joy for no misdeed. Everywhere I see bliss, from which I alone am irrevocably excluded. I was benevolent and good; misery made me a fiend. Make me happy, and I shall again be virtuous."
> 
> — The Creature asks Victor Frankenstein to create a female companion.

Victor and his friend Henry Clerval leave the European mainland for [Britain](https://en.wikipedia.org/wiki/Great_Britain "Great Britain"), where Victor establishes a laboratory in [Orkney](https://en.wikipedia.org/wiki/Orkney "Orkney"). While working on [the female creature](https://en.wikipedia.org/wiki/Bride_of_Frankenstein_\(character\) "Bride of Frankenstein (character)"), Victor imagines his creations giving birth, and fearfully decides to destroy the incomplete female. The original creature issues a warning that he will meet Victor on his wedding night, and murders Henry in an act of revenge.

Victor suffers a [mental breakdown](https://en.wikipedia.org/wiki/Mental_breakdown "Mental breakdown"), then returns home. Back in Geneva, Victor marries [Elizabeth Lavenza](https://en.wikipedia.org/wiki/Elizabeth_Lavenza "Elizabeth Lavenza"), a childhood friend born in Italy. Fulfilling his threat, the creature murders her on the wedding night. Days later, Victor's father Alphonse dies of grief. With no remaining family (besides his other brother Ernest), Victor vows revenge and pursues the creature, eventually following him to the Arctic.

Chasing the creature across Arctic ice, Victor nearly dies from exhaustion and [hypothermia](https://en.wikipedia.org/wiki/Hypothermia "Hypothermia"), but is rescued by Captain Robert Walton, who is leading an expedition to the [North Pole](https://en.wikipedia.org/wiki/North_Pole "North Pole"). Victor recounts his story to Walton and encourages the crew to continue their expedition; instead, they decide to abandon their journey and turn back. Victor vows that he will go on chasing the creature, but in his weakened state, he dies aboard the ship. As the ship leaves the Arctic, the creature comes on board. He mourns Victor's death, tells Walton he plans to burn himself on a pyre, and departs.

## Author's background

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b4/Mary_Wollstonecraft_Shelley_Rothwell.tif/lossy-page1-250px-Mary_Wollstonecraft_Shelley_Rothwell.tif.jpg?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Mary Shelley by Richard Rothwell (1840–41)

Mary Shelley's mother, [Mary Wollstonecraft](https://en.wikipedia.org/wiki/Mary_Wollstonecraft "Mary Wollstonecraft"), died from infection eleven days after giving birth to her. Shelley grew close to her father, [William Godwin](https://en.wikipedia.org/wiki/William_Godwin "William Godwin"). Godwin hired a nurse, who briefly cared for her and her half-sister, before marrying his second wife, [Mary Jane Clairmont](https://en.wikipedia.org/wiki/Mary_Jane_Clairmont "Mary Jane Clairmont"), who did not like the close bond between Shelley and her father. The resulting friction caused Godwin to favour his other children.

Shelley's father was a famous author of the time, and her education was of great importance to him, although it was not formal. Shelley grew up surrounded by her father's friends, writers, and persons of political importance, who often gathered at the family home. This inspired her authorship at an early age. Mary, at the age of sixteen, met Percy Bysshe Shelley (who later became her husband) while he was visiting her father. Godwin disapproved of the relationship between his daughter and an older, married man, so they fled to France along with her stepsister, [Claire Clairmont](https://en.wikipedia.org/wiki/Claire_Clairmont "Claire Clairmont"). On 22 February 1815, Shelley gave birth prematurely to her first child, Clara, who died two weeks later.[^14]

In the [summer of 1816](https://en.wikipedia.org/wiki/Year_Without_a_Summer "Year Without a Summer"), Mary, Percy, and Claire took a trip to visit Claire's lover, [Lord Byron](https://en.wikipedia.org/wiki/Lord_Byron "Lord Byron"), in [Geneva](https://en.wikipedia.org/wiki/Geneva "Geneva"). Poor weather conditions, more akin to winter, forced Byron and the visitors to stay indoors. Byron suggested that he, Mary, Percy, and Byron's physician, [John Polidori](https://en.wikipedia.org/wiki/John_Polidori "John Polidori"), each try writing a ghost story.[^15] Mary was 20 years old when her novel *Frankenstein* was published.[^16] [^17]

## Literary influences

Shelley's work was heavily influenced by that of her parents. Her father was famous for his 1793 book *[Enquiry Concerning Political Justice](https://en.wikipedia.org/wiki/Enquiry_Concerning_Political_Justice "Enquiry Concerning Political Justice")* and her mother was famous for the 1792 essay *[A Vindication of the Rights of Woman](https://en.wikipedia.org/wiki/A_Vindication_of_the_Rights_of_Woman "A Vindication of the Rights of Woman")*. Her father's novels also influenced her writing of *Frankenstein*. These novels included *[Things as They Are; or, The Adventures of Caleb Williams](https://en.wikipedia.org/wiki/Things_as_They_Are;_or,_The_Adventures_of_Caleb_Williams "Things as They Are; or, The Adventures of Caleb Williams")* (1794), *St. Leon*, and *Fleetwood*. All of these books were set in Switzerland, similar to the setting in *Frankenstein*. Some major themes of social affections and the renewal of life that appear in Shelley's novel stem from these works she had in her possession. Other literary influences that appear in *Frankenstein* are *[Pygmalion](https://en.wikipedia.org/wiki/Pygmalion_\(mythology\) "Pygmalion (mythology)") et Galatée* by [Madame de Genlis](https://en.wikipedia.org/wiki/Madame_de_Genlis "Madame de Genlis"), and [Ovid](https://en.wikipedia.org/wiki/Ovid "Ovid"), with the use of individuals identifying the problems with society.[^18] Ovid also inspires the use of [Prometheus](https://en.wikipedia.org/wiki/Prometheus "Prometheus") in the book's subtitle.[^19]

The influence of [John Milton](https://en.wikipedia.org/wiki/John_Milton "John Milton") 's *[Paradise Lost](https://en.wikipedia.org/wiki/Paradise_Lost "Paradise Lost")* and [Samuel Taylor Coleridge](https://en.wikipedia.org/wiki/Samuel_Taylor_Coleridge "Samuel Taylor Coleridge") 's *[The Rime of the Ancient Mariner](https://en.wikipedia.org/wiki/The_Rime_of_the_Ancient_Mariner "The Rime of the Ancient Mariner")* are evident in the novel. In *The Frankenstein of the French Revolution*, author Julia Douthwaite posits that Shelley probably acquired some ideas for Frankenstein's character from [Humphry Davy](https://en.wikipedia.org/wiki/Humphry_Davy "Humphry Davy") 's book *Elements of Chemical Philosophy*, in which he had written that,

> science has... bestowed upon man powers which may be called creative; which have enabled him to change and modify the beings around him...

References to the [French Revolution](https://en.wikipedia.org/wiki/French_Revolution "French Revolution") run through the novel; a possible source is François-Félix Nogaret's *[Le Miroir des événemens actuels, ou la Belle au plus offrant](https://en.wikipedia.org/wiki/Le_Miroir_des_%C3%A9v%C3%A9nemens_actuels,_ou_la_Belle_au_plus_offrant "Le Miroir des événemens actuels, ou la Belle au plus offrant")* (1790), a political parable about scientific progress featuring an inventor named "Wak-wik-vauk-an-son-frankésteïn",[^20] then abridged as Frankésteïn, who creates a life-sized automaton.[^21] However there is no evidence Shelley had read it.[^22]

Both Frankenstein and the monster quote passages from [Percy Shelley](https://en.wikipedia.org/wiki/Percy_Bysshe_Shelley "Percy Bysshe Shelley") 's 1816 poem, " [Mutability](https://en.wikipedia.org/wiki/Mutability_\(poem\) "Mutability (poem)") ", and its theme of the role of the subconscious is discussed in prose. Percy Shelley's name never appears as the author of the poem, although the novel credits other quoted poets by name. Coleridge's poem *The Rime of the Ancient Mariner* (1798) is associated with the theme of guilt and [William Wordsworth](https://en.wikipedia.org/wiki/William_Wordsworth "William Wordsworth") 's " [Tintern Abbey](https://en.wikipedia.org/wiki/Lines_Written_a_Few_Miles_above_Tintern_Abbey "Lines Written a Few Miles above Tintern Abbey") " (1798) with that of innocence.

Many writers and historians have attempted to associate several then-popular natural philosophers (now called physical scientists) with Shelley's work because of several notable similarities. Two of the most noted natural philosophers among Shelley's contemporaries were Italian [Giovanni Aldini](https://en.wikipedia.org/wiki/Giovanni_Aldini "Giovanni Aldini"), who made many public attempts at human reanimation through bio-electric [Galvanism](https://en.wikipedia.org/wiki/Galvanism "Galvanism") in London,[^23] and [Johann Konrad Dippel](https://en.wikipedia.org/wiki/Johann_Konrad_Dippel "Johann Konrad Dippel"), who was supposed to have developed chemical means to extend the life span of humans. While Shelley was aware of both of these men and their activities, she makes no mention of or reference to them or their experiments in any of her published or released notes.

Ideas about life and death discussed by Percy and [Byron](https://en.wikipedia.org/wiki/Lord_Byron "Lord Byron") were of great interest to scientists of the time. They drew on the theories of [Erasmus Darwin](https://en.wikipedia.org/wiki/Erasmus_Darwin "Erasmus Darwin") and the experiments of [Luigi Galvani](https://en.wikipedia.org/wiki/Luigi_Galvani "Luigi Galvani"), as well as the work of [James Lind](https://en.wikipedia.org/wiki/James_Lind_\(naturalist\) "James Lind (naturalist)").[^24] Mary joined these conversations, and the ideas of Darwin, Galvani, and perhaps Lind are reflected in her novel.

Shelley's personal experiences also influenced the themes within *Frankenstein*. The themes of loss, guilt, and the consequences of defying nature present in the novel all developed from Mary Shelley's own life. The loss of her mother, the relationship with her father, and the death of her first child are thought to have inspired the monster and his separation from parental guidance. In a 1965 issue of *The Journal of Religion and Health* a psychologist proposed that the theme of guilt stemmed from her not feeling good enough for Percy because of the loss of their child.[^17]

Mary Shelley read *[The Empire of the Nairs](https://en.wikipedia.org/wiki/The_Empire_of_the_Nairs "The Empire of the Nairs")* (1811), [James Henry Lawrence](https://en.wikipedia.org/wiki/James_Henry_Lawrence "James Henry Lawrence") 's utopian romance abolishing marriage and paternity, in late September 1814.[^25] David S. Neff has read *Frankenstein* as a reply to that utopia, its bachelor scientist a "Lawrentian motherson" whose flight from fatherhood destroys those around him, and has connected the novel's De Lacey family to Lawrence's character Lacy; the historian Anne Verjus, while confirming the 1814 reading, considers the influence unproven.[^26] [^27]

## Composition

![](https://en.wikipedia.org/wiki/File:FrankensteinDraft.jpg)

Draft of Frankenstein ("It was on a dreary night of November that I beheld my man completed...")

During the rainy summer of 1816, the " [Year Without a Summer](https://en.wikipedia.org/wiki/Year_Without_a_Summer "Year Without a Summer") ", the world was locked in a long, cold [volcanic winter](https://en.wikipedia.org/wiki/Volcanic_winter "Volcanic winter") caused by the eruption of [Mount Tambora](https://en.wikipedia.org/wiki/Mount_Tambora "Mount Tambora") in 1815.[^28] [^29] Mary Shelley, aged 18, and her lover (and future husband), [Percy Bysshe Shelley](https://en.wikipedia.org/wiki/Percy_Bysshe_Shelley "Percy Bysshe Shelley"), visited [Lord Byron](https://en.wikipedia.org/wiki/Lord_Byron "Lord Byron") at the [Villa Diodati](https://en.wikipedia.org/wiki/Villa_Diodati "Villa Diodati") by [Lake Geneva](https://en.wikipedia.org/wiki/Lake_Geneva "Lake Geneva"), in the [Swiss Alps](https://en.wikipedia.org/wiki/Swiss_Alps "Swiss Alps"). The weather was too cold and dreary that summer to enjoy the outdoor holiday activities they had planned, so the group retired indoors until dawn.

Sitting around a log fire at Byron's villa, the company amused themselves by reading German ghost stories translated into French from the book *[Fantasmagoriana](https://en.wikipedia.org/wiki/Fantasmagoriana "Fantasmagoriana")*.[^30] Byron proposed that they "each write a ghost story." [^31] Unable to think of a story, Mary Shelley became anxious. She recalled being asked "Have you thought of a story?" each morning, and every time being "forced to reply with a mortifying negative." [^32] During one evening in the middle of summer, the discussions turned to the nature of the principle of life. "Perhaps a corpse would be re-animated," Mary noted, " [galvanism](https://en.wikipedia.org/wiki/Galvanism "Galvanism") had given token of such things".[^33] It was after midnight before they retired and, unable to sleep, she became possessed by her imagination as she beheld the "grim terrors" of her "waking dream".[^9]

> I saw the pale student of unhallowed arts kneeling beside the thing he had put together. I saw the hideous phantasm of a man stretched out, and then, on the working of some powerful engine, show signs of life, and stir with an uneasy, half vital motion. Frightful must it be; for supremely frightful would be the effect of any human endeavour to mock the stupendous mechanism of the Creator of the world.[^34]

In 2011, astronomer Donald Olson, after a visit to the Lake Geneva villa in the previous year and inspecting data about the motion of the moon and stars, concluded that her "waking dream" took place between 2 a.m. and 3 a.m. on 16 June 1816, several days after the initial idea by Lord Byron that they each write a ghost story.[^35]

![](https://en.wikipedia.org/wiki/File:Bath_(2023-06-18)_080.jpg)

Mary Shelley's House of Frankenstein, a museum dedicated to the life of Shelley and her novel, at 37 Gay Street, Bath, the city where she wrote the book.

Mary Shelley began writing what she assumed would be a short story, but with Percy Shelley's encouragement, she expanded the tale into a fully-fledged novel.[^36] She later described that summer in Switzerland as the moment "when I first stepped out from childhood into life." [^37] Shelley wrote the first four chapters in the weeks following the suicide of her half-sister Fanny.[^38] This was one of many personal tragedies that impacted Shelley's work. Shelley's first child died in infancy, and when she began composing *Frankenstein* in 1816, she was probably nursing her second child, who was also dead by the time of *Frankenstein* 's publication.[^39]

Shelley wrote much of the book while residing in a lodging house in the centre of [Bath](https://en.wikipedia.org/wiki/Bath,_Somerset "Bath, Somerset"), England in 1816.[^40] According to Lorna Parkes in *[The Guardian](https://en.wikipedia.org/wiki/The_Guardian "The Guardian")*:

> By all accounts, Shelley came to Bath to hide. Yet she found deep wells of inspiration while living in the shadow of the [city's gothic abbey](https://en.wikipedia.org/wiki/Bath_Abbey "Bath Abbey"), particularly among Bath's medical community. Significantly, she was a contemporary of Dr Charles Wilkinson, a pioneer of medical electricity, and attended lectures at his laboratory around the corner from her lodgings when she was writing about Victor Frankenstein breaking taboos by using galvanism to shock life into a creature stitched together from dead body parts.[^41]

Byron managed to write just a fragment based on the [vampire](https://en.wikipedia.org/wiki/Vampire "Vampire") legends he heard while travelling the [Balkans](https://en.wikipedia.org/wiki/Balkans "Balkans"), and from this [John Polidori](https://en.wikipedia.org/wiki/John_Polidori "John Polidori") created *[The Vampyre](https://en.wikipedia.org/wiki/The_Vampyre "The Vampyre")* (1819), the progenitor of the romantic [vampire literary genre](https://en.wikipedia.org/wiki/Vampire_literature "Vampire literature"), thus two seminal horror tales originated from the conclave.[^42] [^43] [^44] The group talked about [Enlightenment](https://en.wikipedia.org/wiki/The_Enlightenment "The Enlightenment") and [Counter-Enlightenment](https://en.wikipedia.org/wiki/Counter-Enlightenment "Counter-Enlightenment") ideas as well. Mary Shelley believed the Enlightenment idea that society could progress and grow if political leaders used their powers responsibly; however, she also believed the Romantic idea that misused power could destroy society.[^45]

Shelley's manuscripts for the first [three-volume](https://en.wikipedia.org/wiki/Three-volume_novel "Three-volume novel") edition in 1818 (written 1816–1817), as well as the [fair copy](https://en.wikipedia.org/wiki/Fair_copy "Fair copy") for her publisher, are now housed in the [Bodleian Library](https://en.wikipedia.org/wiki/Bodleian_Library "Bodleian Library") in [Oxford](https://en.wikipedia.org/wiki/Oxford "Oxford"). The Bodleian acquired the papers in 2004, and they belong now to the [Abinger](https://en.wikipedia.org/wiki/Baron_Abinger "Baron Abinger") Collection.[^46] [^47] In 2008, the Bodleian published a new edition of *Frankenstein*, edited by Charles E. Robinson, that contains comparisons of Mary Shelley's original text with Percy Shelley's additions and interventions alongside.[^48]

## Frankenstein and the Monster

### The Creature

![](https://en.wikipedia.org/wiki/File:Punch_Anti-Irish_propaganda_(1882)_Irish_Frankenstein_(cropped).jpg)

An English editorial cartoonist conceives the Irish Fenian movement as akin to Frankenstein's creature, in the wake of the Phoenix Park murders in an 1882 issue of Punch. 49

Although the Creature was described in later works as a composite of whole body parts grafted together from cadavers and [reanimated](https://en.wikipedia.org/wiki/Reanimation_\(science_fiction\) "Reanimation (science fiction)") by the use of electricity, this description is not consistent with Shelley's work; both the use of electricity and the cobbled-together image of Frankenstein's monster were more the result of [James Whale](https://en.wikipedia.org/wiki/James_Whale "James Whale") 's popular 1931 [film adaptation of the story](https://en.wikipedia.org/wiki/Frankenstein_\(1931_film\) "Frankenstein (1931 film)") and other early motion-picture works based on the creature. The impact of James Whale's adaptation is noteworthy enough that in a 2025 publication of *Frankenstein*, the introduction by [Jeanette Winterson](https://en.wikipedia.org/wiki/Jeanette_Winterson "Jeanette Winterson") erroneously references the use of a massive jolt of electricity to imbue life in the creature.[^50] In Shelley's original work, Victor Frankenstein discovers a previously unknown but elemental principle of life, and that insight allows him to develop a method to imbue vitality into inanimate matter, though the exact nature of the process is left ambiguous. After a great deal of hesitation in exercising this power, Frankenstein spends two years painstakingly constructing the Creature's body (one anatomical feature at a time, from raw materials supplied by "the dissecting room and the slaughter-house"), which he then brings to life using his unspecified process.

![](https://en.wikipedia.org/wiki/File:Frankenstein_and_Monster_-_Birmingham_Post-Herald,_1910.jpg) ![](https://en.wikipedia.org/wiki/File:Frankenstein_and_Monster_-_The_Cincinnati_Enquirer,_1910.jpg)

Newspaper illustrations from abridged versions of *Frankenstein*, 1910

Frankenstein does not give him a name. Instead, Frankenstein's creation is referred to by words such as "wretch", "monster", "creature", "demon", "devil", "fiend", and "it". When Frankenstein converses with the creature, he addresses him as "vile insect", "abhorred monster", "fiend", "wretched devil", and "abhorred devil".

In the novel, the creature is compared to [Adam](https://en.wikipedia.org/wiki/Adam "Adam"),[^51] the [first man](https://en.wikipedia.org/wiki/List_of_first_men_or_women_in_mythology_and_religion "List of first men or women in mythology and religion") in the [Garden of Eden](https://en.wikipedia.org/wiki/Garden_of_Eden "Garden of Eden"). The monster also compares himself with the [fallen angel](https://en.wikipedia.org/wiki/Fallen_angel "Fallen angel"). Speaking to Frankenstein, the monster says "I ought to be thy Adam, but I am rather the fallen angel". That angel would be [Lucifer](https://en.wikipedia.org/wiki/Lucifer "Lucifer") (meaning "light-bringer") in [Milton](https://en.wikipedia.org/wiki/John_Milton "John Milton") 's *[Paradise Lost](https://en.wikipedia.org/wiki/Paradise_Lost "Paradise Lost")*, which the monster has read. Adam is also referred to in the epigraph of the 1818 edition:[^52]

> Did I request thee, Maker, from my clay
> 
> To mould Me man? Did I solicit thee
> 
> From darkness to promote me?[^53]

Some have posited the creature as a composite of [Percy Shelley](https://en.wikipedia.org/wiki/Percy_Bysshe_Shelley "Percy Bysshe Shelley") and [Thomas Paine](https://en.wikipedia.org/wiki/Thomas_Paine "Thomas Paine"). If the creature's hatred for Victor and his desire to raise a child mirror Percy's filial rebelliousness and his longing to adopt children, his desire to do good and his persecution can be said to echo Paine's utopian visions and fate in England.[^54]

The Creature has often been mistakenly called Frankenstein. In 1908, one author said "It is strange to note how well-nigh universally the term 'Frankenstein' is misused, even by intelligent people, as describing some hideous monster." [^55] [Edith Wharton](https://en.wikipedia.org/wiki/Edith_Wharton "Edith Wharton") 's *[The Reef](https://en.wikipedia.org/wiki/The_Reef_\(novel\) "The Reef (novel)")* (1916) describes an unruly child as an "infant Frankenstein".[^56] [David Lindsay](https://en.wikipedia.org/wiki/David_Lindsay_\(novelist\) "David Lindsay (novelist)") 's "The Bridal Ornament", published in *The Rover*, 12 June 1844, mentioned "the maker of poor Frankenstein." After the release of Whale's cinematic *Frankenstein*, the public at large began speaking of the Creature itself as "Frankenstein". This misnomer continued with the successful sequel *[Bride of Frankenstein](https://en.wikipedia.org/wiki/Bride_of_Frankenstein "Bride of Frankenstein")* (1935), as well as in film titles such as *[Abbott and Costello Meet Frankenstein](https://en.wikipedia.org/wiki/Abbott_and_Costello_Meet_Frankenstein "Abbott and Costello Meet Frankenstein")*.

![](https://en.wikipedia.org/wiki/File:Frontispiece_to_Frankenstein_1831.jpg)

Illustration by Theodor von Holst from the frontispiece of the 1831 edition 57

### Origin of Victor Frankenstein's name

Mary Shelley maintained that she derived the name *Frankenstein* from a dream-vision. This claim has since been disputed and debated by scholars that have suggested alternative sources for Shelley's inspiration.[^58] The German name *Frankenstein* means "stone of the [Franks](https://en.wikipedia.org/wiki/Franks "Franks") ", and is associated with various places in Germany, including [Frankenstein Castle](https://en.wikipedia.org/wiki/Frankenstein_Castle "Frankenstein Castle") (Burg Frankenstein) in Darmstadt, Hesse, and [Frankenstein Castle](https://en.wikipedia.org/wiki/Frankenstein_Castle,_Palatinate "Frankenstein Castle, Palatinate") in Frankenstein, a village in the Palatinate.[^59] There is also a castle called Frankenstein in [Bad Salzungen](https://en.wikipedia.org/wiki/Bad_Salzungen "Bad Salzungen"), Thuringia, and a municipality called [Frankenstein](https://en.wikipedia.org/wiki/Frankenstein,_Saxony "Frankenstein, Saxony") in Saxony. The town of [Frankenstein](https://en.wikipedia.org/wiki/Z%C4%85bkowice_%C5%9Al%C4%85skie "Ząbkowice Śląskie") in [Silesia](https://en.wikipedia.org/wiki/Silesia "Silesia") (now Ząbkowice, Poland) was the site of a [scandal involving gravediggers](https://en.wikipedia.org/wiki/Frankenstein_gravediggers_scandal "Frankenstein gravediggers scandal") in 1606, and this has been suggested as an inspiration to the author.[^60] Finally, the name is borne by the aristocratic [House of Franckenstein](https://en.wikipedia.org/wiki/House_of_Franckenstein "House of Franckenstein") from Franconia.

[Radu Florescu](https://en.wikipedia.org/wiki/Radu_Florescu "Radu Florescu") argued that Mary and Percy Shelley visited Frankenstein Castle near Darmstadt in 1814, where alchemist [Johann Konrad Dippel](https://en.wikipedia.org/wiki/Johann_Konrad_Dippel "Johann Konrad Dippel") had experimented with human bodies, and reasoned that Mary suppressed mention of her visit to maintain her public claim of originality.[^61] A literary essay by A.J. Day supports Florescu's position that Mary Shelley knew of and visited Frankenstein Castle before writing her debut novel.[^62] Day includes details of an alleged description of the Frankenstein castle in Mary Shelley's "lost journals". However, according to Jörg Heléne, Day's and Florescu's claims cannot be verified.[^63]

A possible interpretation of the name "Victor" is derived from *[Paradise Lost](https://en.wikipedia.org/wiki/Paradise_Lost "Paradise Lost")* by [John Milton](https://en.wikipedia.org/wiki/John_Milton "John Milton"), a great influence on Shelley (a quotation from *Paradise Lost* is on the opening page of *Frankenstein* and Shelley writes that the monster reads it in the novel).[^64] [^65] Milton frequently refers to God as "the victor" in *Paradise Lost*, and Victor's creation of life in the novel is compared to God's creation of life in *Paradise Lost*. In addition, Shelley's portrayal of the monster owes much to the character of [Satan](https://en.wikipedia.org/wiki/Satan "Satan") in *Paradise Lost*, and the monster says in the story, after reading the epic poem, that he empathizes with Satan's role.

Parallels between Victor Frankenstein and Mary's husband, Percy Shelley, have also been drawn. Percy Shelley was the first-born son of [Member of Parliament](https://en.wikipedia.org/wiki/Member_of_Parliament_\(United_Kingdom\) "Member of Parliament (United Kingdom)") [Timothy Shelley](https://en.wikipedia.org/wiki/Timothy_Shelley "Timothy Shelley"), a [country squire](https://en.wikipedia.org/wiki/Country_squire "Country squire") with strong political connections, and grandson of Sir [Bysshe Shelley](https://en.wikipedia.org/wiki/Bysshe_Shelley "Bysshe Shelley"), 1st Baronet of [Castle Goring](https://en.wikipedia.org/wiki/Castle_Goring "Castle Goring").[^66] Similarly, Victor's family is one of the most distinguished of that republic and his ancestors were counsellors and [syndics](https://en.wikipedia.org/wiki/Syndic "Syndic"). Percy's sister and Victor's adopted sister were both named Elizabeth. There are many other similarities, from Percy's usage of "Victor" as a pen name for *[Original Poetry by Victor and Cazire](https://en.wikipedia.org/wiki/Original_Poetry_by_Victor_and_Cazire "Original Poetry by Victor and Cazire")*, a collection of poetry he wrote with Elizabeth,[^67] to Percy's days at Eton, where he had "experimented with electricity and magnetism as well as with gunpowder and numerous chemical reactions," and the way in which Percy's rooms at [Oxford](https://en.wikipedia.org/wiki/University_of_Oxford "University of Oxford") were filled with scientific equipment.[^68] [^69]

### Modern Prometheus

*The Modern Prometheus* is the novel's subtitle (though modern editions now drop it, only mentioning it in introduction).[^70] [Prometheus](https://en.wikipedia.org/wiki/Prometheus "Prometheus"), in versions of Greek mythology, was the [Titan](https://en.wikipedia.org/wiki/Titan_\(mythology\) "Titan (mythology)") who created humans in the image of the gods so that they could have a spirit breathed into them at the behest of [Zeus](https://en.wikipedia.org/wiki/Zeus "Zeus").[^2] Prometheus then taught humans to hunt, but after he tricked Zeus into accepting "poor-quality offerings" from humans, Zeus kept fire from humankind. Prometheus took back the fire from Zeus to give to humanity. When Zeus discovered this, he sentenced Prometheus to be eternally punished by fixing him to a rock of [Caucasus](https://en.wikipedia.org/wiki/Caucasus "Caucasus"), where each day an eagle pecked out his liver, only for the liver to regrow the next day because of his immortality as a god.

As a [Pythagorean](https://en.wikipedia.org/wiki/Pythagoreanism "Pythagoreanism"), or believer in *[An Essay on Abstinence from Animal Food, as a Moral Duty](https://en.wikipedia.org/wiki/An_Essay_on_Abstinence_from_Animal_Food,_as_a_Moral_Duty "An Essay on Abstinence from Animal Food, as a Moral Duty")* by [Joseph Ritson](https://en.wikipedia.org/wiki/Joseph_Ritson "Joseph Ritson"),[^71] Mary Shelley saw Prometheus not as a hero but rather as something of a devil, and blamed him for bringing fire to humanity and thereby seducing the human race to the vice of eating meat.[^72] Percy wrote several essays on what became known as vegetarianism including *[A Vindication of Natural Diet](https://en.wikipedia.org/wiki/A_Vindication_of_Natural_Diet "A Vindication of Natural Diet")*.[^71]

Byron was particularly attached to the play *[Prometheus Bound](https://en.wikipedia.org/wiki/Prometheus_Bound "Prometheus Bound")* by [Aeschylus](https://en.wikipedia.org/wiki/Aeschylus "Aeschylus"), and Percy Shelley soon wrote his own *[Prometheus Unbound](https://en.wikipedia.org/wiki/Prometheus_Unbound_\(Shelley\) "Prometheus Unbound (Shelley)")* (1820). The term "Modern Prometheus" was derived from [Immanuel Kant](https://en.wikipedia.org/wiki/Immanuel_Kant "Immanuel Kant"), who described [Benjamin Franklin](https://en.wikipedia.org/wiki/Benjamin_Franklin "Benjamin Franklin") as the "Prometheus of modern times" in reference to his experiments with electricity.[^73]

## Publication

Shelley completed her writing in April/May 1817, and *Frankenstein; or, The Modern Prometheus* was published on 1 January 1818 [^74] by the small London publishing house Lackington, Hughes, Harding, Mavor, & Jones.[^75] [^76] It was issued anonymously, with a preface written for Mary by Percy Bysshe Shelley and with a dedication to philosopher [William Godwin](https://en.wikipedia.org/wiki/William_Godwin "William Godwin"), her father. It was published in an edition of just 500 copies in three volumes, the standard " [triple-decker](https://en.wikipedia.org/wiki/Three-volume_novel "Three-volume novel") " format for 19th-century first editions.

![](https://en.wikipedia.org/wiki/File:Editions_of_Frankenstein.jpg)

A variety of different editions

A French translation (*Frankenstein: ou le Prométhée Moderne*, translated by Jules Saladin) appeared as early as 1821. The second English edition of *Frankenstein* was published on 11 August 1823 in two volumes (by G. and W. B. Whittaker) following the success of the stage play *[Presumption; or, the Fate of Frankenstein](https://en.wikipedia.org/wiki/Presumption;_or,_the_Fate_of_Frankenstein "Presumption; or, the Fate of Frankenstein")* by [Richard Brinsley Peake](https://en.wikipedia.org/wiki/Richard_Brinsley_Peake "Richard Brinsley Peake").[^77] This edition credited Mary Shelley as the book's author on its title page.[^78]

On 31 October 1831, the first "popular" edition in one volume appeared, published by [Henry Colburn](https://en.wikipedia.org/wiki/Henry_Colburn "Henry Colburn") & [Richard Bentley](https://en.wikipedia.org/wiki/Richard_Bentley_\(publisher\) "Richard Bentley (publisher)").[^79] This edition was heavily revised by Mary Shelley, partially to make the story less radical. It included a lengthy new introduction by the author, presenting a somewhat embellished version of the genesis of the story. This edition is the one most widely published and read now, although a few editions follow the 1818 text.[^80] Some scholars such as [Anne K. Mellor](https://en.wikipedia.org/wiki/Anne_K._Mellor "Anne K. Mellor") prefer the original version, arguing that it preserves the spirit of Mary Shelley's vision.[^81]

## Reception

Contemporary critical reviews were varied. [Walter Scott](https://en.wikipedia.org/wiki/Walter_Scott "Walter Scott"), writing in *[Blackwood's Edinburgh Magazine](https://en.wikipedia.org/wiki/Blackwood's_Magazine "Blackwood's Magazine")*, praised the novel as an "extraordinary tale, in which the author seems to us to disclose uncommon powers of poetic imagination," although he was less convinced about the way in which the monster gains knowledge about the world and language.[^82] *[La Belle Assemblée](https://en.wikipedia.org/wiki/La_Belle_Assembl%C3%A9e "La Belle Assemblée")* described the novel as "very bold fiction" [^83] and the *[Edinburgh Magazine and Literary Miscellany](https://en.wikipedia.org/wiki/The_Scots_Magazine "The Scots Magazine")* hoped to see "more productions... from this author".[^84] On the other hand, [John Wilson Croker](https://en.wikipedia.org/wiki/John_Wilson_Croker "John Wilson Croker"), writing anonymously in the *[Quarterly Review](https://en.wikipedia.org/wiki/Quarterly_Review "Quarterly Review")*, although conceding that "the author has powers, both of conception and language," described the book as "a tissue of horrible and disgusting absurdity." [^85]

The *[British Critic](https://en.wikipedia.org/wiki/British_Critic "British Critic")*, a conservative and high-church journal, attacked the novel's flaws as the fault of the author:

> The writer of it is, we understand, a female; this is an aggravation of that which is the prevailing fault of the novel; but if our authoress can forget the gentleness of her sex, it is no reason why we should; and we shall therefore dismiss the novel without further comment.[^86]

*The Literary Panorama and National Register* attacked the novel as a "feeble imitation of [Mr. Godwin](https://en.wikipedia.org/wiki/William_Godwin "William Godwin") 's novels" produced by the "daughter of a celebrated living novelist." [^87]

![](https://en.wikipedia.org/wiki/File:Peake-1823-play.jpg)

Cover of the 1823 West End stage play, Presumption; or, the Fate of Frankenstein, the first adaptation of the novel

Despite these reviews, *Frankenstein* achieved an almost immediate popular success. It became widely known, especially through melodramatic theatrical adaptations. The first adaptation, *[Presumption; or, the Fate of Frankenstein](https://en.wikipedia.org/wiki/Presumption;_or,_the_Fate_of_Frankenstein "Presumption; or, the Fate of Frankenstein")*, a play by [Richard Brinsley Peake](https://en.wikipedia.org/wiki/Richard_Brinsley_Peake "Richard Brinsley Peake"), was performed thirty-seven times at the [English Opera House](https://en.wikipedia.org/wiki/Lyceum_Theatre,_London "Lyceum Theatre, London") in the [West End](https://en.wikipedia.org/wiki/West_End_theatre "West End theatre") during the 1823 season. The acclaim it received caused a second printing of Shelley's novel and other theatrical adaptations.[^88] [^89] Shelley attended a performance on 29 August 1823 and following the success of the play she wrote, "lo & behold! I found myself famous!".[^78]

Critical reception of *Frankenstein* has been largely positive since the mid-20th century.[^90] Major critics such as M. A. Goldberg and [Harold Bloom](https://en.wikipedia.org/wiki/Harold_Bloom "Harold Bloom") have praised the "aesthetic and moral" relevance of the novel,[^91] although there have also been critics, such as [Germaine Greer](https://en.wikipedia.org/wiki/Germaine_Greer "Germaine Greer"), who criticized the novel for technical and narrative defects: for example, she claimed that its three narrators all speak in the same way.[^92] In more recent years the novel has become a popular subject for psychoanalytic and feminist criticism: Lawrence Lipking states: "\[E\]ven the [Lacanian](https://en.wikipedia.org/wiki/Jacques_Lacan "Jacques Lacan") subgroup of psychoanalytic criticism, for instance, has produced at least half a dozen discrete readings of the novel".[^93] *Frankenstein* has frequently been recommended on *Five Books*, with literary scholars, psychologists, novelists, and historians citing it as an influential text.[^94] Today, the novel is generally considered to be a landmark work as one of the greatest Romantic and Gothic novels, as well as one of the first science fiction novels.[^95]

[Brian Aldiss](https://en.wikipedia.org/wiki/Brian_Aldiss "Brian Aldiss") has argued for regarding it as the [first true science-fiction](https://en.wikipedia.org/wiki/History_of_science_fiction "History of science fiction") story. In contrast to previous stories with fantastical elements resembling those of later science fiction, Aldiss states, the central character "makes a deliberate decision" and "turns to modern experiments in the laboratory" to achieve fantastic results.[^96]

In 2018, film director [Guillermo del Toro](https://en.wikipedia.org/wiki/Guillermo_del_Toro "Guillermo del Toro") – who would later direct [his own adaptation](https://en.wikipedia.org/wiki/Frankenstein_\(2025_film\) "Frankenstein (2025 film)") of the novel – described *Frankenstein* as "the quintessential teenage book", noting that the feelings that "You don't belong. You were brought to this world by people that don't care for you and you are thrown into a world of pain and suffering, and tears and hunger" are an important part of the story. He adds that "it's an amazing book written by a teenage girl. It's mind-blowing." [^97] Professor of philosophy [Patricia MacCormack](https://en.wikipedia.org/wiki/Patricia_MacCormack "Patricia MacCormack") says that the Creature addresses the most fundamental human questions: "It's the idea of asking your maker what your purpose is. Why are we here, what can we do?" [^97]

On 5 November 2019, [BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News") included *Frankenstein* in its list of the [100 most influential novels](https://en.wikipedia.org/wiki/BBC_list_of_100_'most_inspiring'_novels "BBC list of 100 'most inspiring' novels").[^98] In 2018, [Jersey Post](https://en.wikipedia.org/wiki/Jersey_Post "Jersey Post") released series of 8 stamps celebrating the 200th anniversary of *Frankenstein*.[^99] In 2021 it was one of six classic science fiction novels by British authors selected by [Royal Mail](https://en.wikipedia.org/wiki/Royal_Mail "Royal Mail") to be featured on a [series of UK postage stamps](https://en.wikipedia.org/wiki/Great_Britain_commemorative_stamps_2020%E2%80%932029#2021 "Great Britain commemorative stamps 2020–2029").[^100]

## Films, plays, television and comic books

12:10

In 1910, [Edison Studios](https://en.wikipedia.org/wiki/Edison_Studios "Edison Studios") released the [first motion-picture adaptation](https://en.wikipedia.org/wiki/Frankenstein_\(1910_film\) "Frankenstein (1910 film)") of Shelley's story.

The [1931 film](https://en.wikipedia.org/wiki/Frankenstein_\(1931_film\) "Frankenstein (1931 film)"), with [Boris Karloff](https://en.wikipedia.org/wiki/Boris_Karloff "Boris Karloff") playing the monster, is considered the most well-known portrayal of Frankenstein.[^101] The [Hammer Horror films](https://en.wikipedia.org/wiki/Hammer_Film_Productions "Hammer Film Productions") focused on the character of Dr Frankenstein (played by [Peter Cushing](https://en.wikipedia.org/wiki/Peter_Cushing "Peter Cushing") in [six films](https://en.wikipedia.org/wiki/Frankenstein_\(Hammer_film_series\) "Frankenstein (Hammer film series)") beginning with the [1957 film](https://en.wikipedia.org/wiki/The_Curse_of_Frankenstein "The Curse of Frankenstein")) rather than his monster.[^102]

In December 1945, the [Gilberton Company](https://en.wikipedia.org/wiki/Gilberton_\(publisher\) "Gilberton (publisher)") issued a comic book version of *Frankenstein* as No. 26 in its long-running *[Classics Illustrated](https://en.wikipedia.org/wiki/Classics_Illustrated "Classics Illustrated")* series, with illustrations by Robert Hayward Webb and [Ann Brewster](https://en.wikipedia.org/wiki/Ann_Brewster "Ann Brewster"). The title went through nineteen printings between 1945 and 1971,[^103] and has been praised by comics historian Mike Benton as "probably the most faithful adaptation of the original novel -- movies included." [^104]

[Manga](https://en.wikipedia.org/wiki/Manga "Manga") artist and writer [Junji Ito](https://en.wikipedia.org/wiki/Junji_Ito "Junji Ito"), best known for his horror work, published a comics adaptation of *Frankenstein*, which won an Eisner Award in 2019 for "Best Adaptation from Another Medium." [^105]

[^1]: This is the primary genre. The work is also known for its elements of science fiction and horror, which were often amplified in adaptations.

[^2]: In the best-known versions of the Prometheus story, by Hesiod and Aeschylus, Prometheus merely brings fire to humankind, but in other versions, such as several of Aesop's fables (See in particular Fable 516), Sappho (Fragment 207), and Ovid's Metamorphoses, Prometheus is the actual creator of humanity.

[^3]: Stableford, Brian (1995). ["Frankenstein and the Origins of Science Fiction"](https://archive.org/details/anticipationsess00unse/page/47). In Seed, David (ed.). *Anticipations: Essays on Early Science Fiction and its Precursors*. Syracuse University Press. pp. [47–49](https://archive.org/details/anticipationsess00unse/page/47). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0815626404](https://en.wikipedia.org/wiki/Special:BookSources/978-0815626404 "Special:BookSources/978-0815626404"). Retrieved 19 July 2018.

[^4]: Hindle, Maurice (1990). ["Vital matters: Mary Shelley's Frankenstein and Romantic science"](https://www.jstor.org/stable/41555493). *Critical Survey*. **2** (1): 29–35. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0011-1570](https://search.worldcat.org/issn/0011-1570). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [41555493](https://www.jstor.org/stable/41555493).

[^5]: Hobbler, Dorthy and Thomas. *The Monsters: Mary Shelley and the Curse of Frankenstein*. Back Bay Books; 20 August 2007.

[^6]: Garrett, Martin. *Mary Shelley*. Oxford University Press, 2002

[^7]: Seymour, Miranda. *Mary Shelley*. Atlanta, GA: Grove Press, 2002. pp. 110–11

[^8]: McGasko, Joe. ["Her 'Midnight Pillow': Mary Shelley and the Creation of Frankenstein"](https://www.biography.com/news/mary-shelley-frankenstein-i-frankenstein-movie). *Biography*. [Archived](https://web.archive.org/web/20190219072925/https://www.biography.com/news/mary-shelley-frankenstein-i-frankenstein-movie) from the original on 19 February 2019. Retrieved 18 February 2019.

[^9]: Shelley, Mary W. ["Frankenstein: or, The Modern Prometheus"](https://www.gutenberg.org/files/42324/42324-h/42324-h.htm). Paragraphs 11-13. Retrieved 29 December 2022 – via Project Gutenberg.

[^10]: ["Mary Wollstonecraft Shelley, Frankenstein; or, The Modern Prometheus"](https://exhibits.library.duke.edu/exhibits/show/baskin/item/4115). Duke University Libraries. Retrieved 26 October 2025.

[^11]: Bergen Evans, *Comfortable Words*, New York: Random House, 1957

[^12]: Bryan Garner, *A Dictionary of Modern American Usage*, New York, Oxford: Oxford University Press, 1998.

[^13]: *Merriam-Webster's Dictionary of American English*, Merriam-Webster: 2002.

[^14]: Lepore, Jill (5 February 2018). ["The Strange and Twisted Life of "Frankenstein""](https://www.newyorker.com/magazine/2018/02/12/the-strange-and-twisted-life-of-frankenstein). *The New Yorker*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0028-792X](https://search.worldcat.org/issn/0028-792X). [Archived](https://web.archive.org/web/20180222230948/https://www.newyorker.com/magazine/2018/02/12/the-strange-and-twisted-life-of-frankenstein) from the original on 22 February 2018. Retrieved 4 March 2019.

[^15]: ["Mary Shelley's "Frankenstein" is published"](https://www.history.com/this-day-in-history/frankenstein-published). *History.com*. 13 November 2009. Retrieved 11 February 2021.

[^16]: ["Frankenstein: Penetrating the Secrets of Nature: The Birth of Frankenstein"](https://www.nlm.nih.gov/exhibition/frankenstein/exhibition1.html). *nlm.nih.gov*. [Archived](https://web.archive.org/web/20181129054357/https://www.nlm.nih.gov/exhibition/frankenstein/exhibition1.html) from the original on 29 November 2018. Retrieved 20 November 2018.

[^17]: Badalamenti, Anthony (Fall 2006). "Why did Mary Shelley Write Frankenstein". *Journal of Religion and Health*. **45** (3): 419–39. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1007/s10943-006-9030-0](https://doi.org/10.1007%2Fs10943-006-9030-0). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0022-4197](https://search.worldcat.org/issn/0022-4197). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [27512949](https://www.jstor.org/stable/27512949). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [37615140](https://api.semanticscholar.org/CorpusID:37615140).

[^18]: ["Pollin, "Philosophical and Literary Sources""](http://knarf.english.upenn.edu/Articles/pollin.html). *knarf.english.upenn.edu*. [Archived](https://web.archive.org/web/20190405185454/http://knarf.english.upenn.edu/Articles/pollin.html) from the original on 5 April 2019. Retrieved 26 May 2019.

[^19]: Pollin, Burton (Spring 1965). "Philosophical and Literary Sources of Frankenstein". *Comparative Literature*. **17** (2): 97–108. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/1769997](https://doi.org/10.2307%2F1769997). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [1769997](https://www.jstor.org/stable/1769997).

[^20]: [Original text](http://gallica.bnf.fr/ark:/12148/bpt6k854529k/f58.item.r=Le%20Miroir%20des%20%C3%A9v%C3%A9nemens%20actuels.zoom) [Archived](https://web.archive.org/web/20180105180801/http://gallica.bnf.fr/ark:/12148/bpt6k854529k/f58.item.r=Le%20Miroir%20des%20%C3%A9v%C3%A9nemens%20actuels.zoom) 2018-01-05 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") on [Gallica](https://en.wikipedia.org/wiki/Gallica "Gallica").

[^21]: Douthwaite, Julia V. "The Frankenstein of the French Revolution". [*The Frankenstein of 1790 and Other Lost Chapters from Revolutionary France*](https://press.uchicago.edu/ucp/books/book/chicago/F/bo13265096.html). University of Chicago Press. [Archived](https://web.archive.org/web/20121116230136/http://press.uchicago.edu/ucp/books/book/chicago/F/bo13265096.html) from the original on 16 November 2012.

[^22]: Douthwaite, Julia V.; Richter, Daniel (2009). ["The Frankenstein of the French Revolution: Nogaret's automaton tale of 1790"](https://www.academia.edu/9512220). *European Romantic Review*. **20** (3): 381–411. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/10509580902986369](https://doi.org/10.1080%2F10509580902986369). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [143492105](https://api.semanticscholar.org/CorpusID:143492105).

[^23]: Ruston, Sharon (25 November 2015). ["The Science of Life and Death in Mary Shelley's *Frankenstein* "](http://publicdomainreview.org/2015/11/25/the-science-of-life-and-death-in-mary-shelleys-frankenstein/). *[The Public Domain Review](https://en.wikipedia.org/wiki/The_Public_Domain_Review "The Public Domain Review")*. [Archived](https://web.archive.org/web/20151126072751/http://publicdomainreview.org/2015/11/25/the-science-of-life-and-death-in-mary-shelleys-frankenstein/) from the original on 26 November 2015. Retrieved 25 November 2015.

[^24]: ["Lind, James (1736–1812) on JSTOR"](https://plants.jstor.org/stable/10.5555/al.ap.person.bm000033179). *plants.jstor.org*. Retrieved 8 May 2021.

[^25]: Feldman, Paula R., ed. (1995). *The Journals of Mary Shelley, 1814–1844*. Vol. I. Baltimore: Johns Hopkins University Press. p. 29.

[^26]: Neff, David S. (1996). "The "Paradise of the Mothersons": Frankenstein and The Empire of the Nairs". *The Journal of English and Germanic Philology*. **95** (2): 204–222.

[^27]: Verjus, Anne (2025). *Abolir le patriarcat. L'utopie féministe de James Henry Lawrence (1773–1840)* (in French). Saint-Étienne: Presses universitaires de Saint-Étienne. pp. 346–350. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-2-86272-793-6](https://en.wikipedia.org/wiki/Special:BookSources/978-2-86272-793-6 "Special:BookSources/978-2-86272-793-6").

[^28]: Marshall, Alan (January 2020). ["Did a Volcanic Eruption in Indonesia Really Lead to the Creation of Frankenstein?"](https://theconversation.com/did-a-volcanic-eruption-in-indonesia-really-lead-to-the-creation-of-frankenstein-130212). *The Conversation*.

[^29]: [Sunstein 1989](#CITEREFSunstein1989), p. 118.

[^30]: Dr. [John Polidori](https://en.wikipedia.org/wiki/John_William_Polidori "John William Polidori"), "The Vampyre" 1819, The New Monthly Magazine and Universal Register; London: H. Colburn, 1814–1820. Vol. 1, No. 63.

[^31]: paragraph 7, Introduction, Frankenstein 1831 edition

[^32]: paragraph 8, Introduction, Frankenstein 1831 edition

[^33]: paragraph 10, Introduction, Frankenstein 1831 edition

[^34]: Quoted in Spark, 157, from Mary Shelley's introduction to the 1831 edition of *Frankenstein*.

[^35]: Radford, Tim (25 September 2011). ["Frankenstein's hour of creation identified by astronomers"](https://www.theguardian.com/books/2011/sep/26/frankenstein-hour-creation-identified-astronomers). *The Guardian*. London. [Archived](https://web.archive.org/web/20170302174254/https://www.theguardian.com/books/2011/sep/26/frankenstein-hour-creation-identified-astronomers) from the original on 2 March 2017. Retrieved 29 December 2022.

[^36]: [Bennett 1998](#CITEREFBennett1998), pp. 30–31; [Sunstein 1989](#CITEREFSunstein1989), p. 124.

[^37]: [Sunstein 1989](#CITEREFSunstein1989), p. 117.

[^38]: Hay, 103.

[^39]: Lepore, Jill (5 February 2018). ["The Strange and Twisted Life of 'Frankenstein'"](https://www.newyorker.com/magazine/2018/02/12/the-strange-and-twisted-life-of-frankenstein). *The New Yorker*. [Archived](https://web.archive.org/web/20180222230948/https://www.newyorker.com/magazine/2018/02/12/the-strange-and-twisted-life-of-frankenstein) from the original on 22 February 2018. Retrieved 22 February 2018.

[^40]: Kennedy, Maev (26 February 2018). ["'A 200-year-old secret': plaque to mark Bath's hidden role in Frankenstein"](https://www.theguardian.com/books/2018/feb/26/a-200-year-old-secret-plaque-to-mark-baths-hidden-role-in-frankenstein). *The Guardian*. London. [Archived](https://web.archive.org/web/20181114060614/https://www.theguardian.com/books/2018/feb/26/a-200-year-old-secret-plaque-to-mark-baths-hidden-role-in-frankenstein) from the original on 14 November 2018. Retrieved 13 November 2018.

[^41]: Parkes, Lorna (23 July 2021). ["House of horror: Bath opens the world's first museum dedicated to Mary Shelley"](https://www.theguardian.com/travel/2021/jul/23/house-of-horror-bath-opens-the-worlds-first-museum-dedicated-to-mary-shelley). *The Guardian*. Retrieved 15 November 2025.

[^42]: ["Frankenstein and the Vampyre: A Dark and Stormy Night"](https://www.bbc.co.uk/programmes/b04nvq7q). *[BBC Two](https://en.wikipedia.org/wiki/BBC_Two "BBC Two")*. [BBC](https://en.wikipedia.org/wiki/BBC "BBC"). Retrieved 28 December 2024.

[^43]: ["Frankenstein and the Vampyre: A Dark and Stormy Night - BBC Literary Archive"](https://era.org.uk/lit-resource/frankenstein-and-the-vampyre-a-dark-and-stormy-night/). *Educational Recording Agency Limited*. Retrieved 28 December 2024.

[^44]: ["Frankenstein and the Vampyre: A Dark and Stormy Night"](https://www.films.com/id/96431). *Films Media Group*. Retrieved 29 December 2024.

[^45]: [Bennett 1998](#CITEREFBennett1998), pp. 36–42.

[^46]: ["OX.ac.uk"](http://www.bodley.ox.ac.uk/dept/scwmss/wmss/online/1500-1900/abinger/abinger.html). Bodley.ox.ac.uk. 15 December 2009. [Archived](https://web.archive.org/web/20171205102149/http://www.bodley.ox.ac.uk/dept/scwmss/wmss/online/1500-1900/abinger/abinger.html) from the original on 5 December 2017. Retrieved 28 August 2010.

[^47]: ["Shelley's Ghost – Reshaping the image of a literary family"](http://shelleysghost.bodleian.ox.ac.uk/Frankenstein-notebook-reader#page/1/mode/2up). *shelleysghost.bodleian.ox.ac.uk*. [Archived](https://web.archive.org/web/20190810021645/http://shelleysghost.bodleian.ox.ac.uk/Frankenstein-notebook-reader#page/1/mode/2up) from the original on 10 August 2019. Retrieved 19 September 2019.

[^48]: Mary Shelley, with Percy Shelley (2008). Charles E. Robinson (ed.). [*The Original Frankenstein*](https://web.archive.org/web/20150925134955/http://www.bodleianshop.co.uk/the-original-frankenstein.html). Oxford: Bodleian Library. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-851-24396-9](https://en.wikipedia.org/wiki/Special:BookSources/978-1-851-24396-9 "Special:BookSources/978-1-851-24396-9"). Archived from [the original](http://www.bodleianshop.co.uk/the-original-frankenstein.html) on 25 September 2015.

[^49]: ["Frankenstein:Celluloid Monster"](https://www.nlm.nih.gov/exhibition/frankenstein/escaping.html). *National Library of Medicine of the National Institute of Health*. [Archived](https://web.archive.org/web/20160515180541/https://www.nlm.nih.gov/hmd/frankenstein/escaping.html) from the original on 15 May 2016.

[^50]: Winterson, Jeanette. "Introduction to the Vintage Classics Edition (2025)." *Frankenstein; or, the Modern Prometheus* by Mary Shelley, Vintage Classics, 2025, pp. viii-xi.

[^51]: ["Frankenstein: Penetrating the Secrets of Nature / Exhibit Text"](https://web.archive.org/web/20061204162542/http://www.ala.org/ala/ppo/currentprograms/frankenstein/exhibittext.pdf) (PDF). [National Library of Medicine](https://en.wikipedia.org/wiki/National_Library_of_Medicine "National Library of Medicine") and ALA Public Programs Office. Archived from [the original](http://www.ala.org/ala/ppo/currentprograms/frankenstein/exhibittext.pdf) (PDF) on 4 December 2006. Retrieved 31 December 2007. from the travelling exhibition [Frankenstein: Penetrating the Secrets of Nature](http://www.ala.org/ala/ppo/currentprograms/frankenstein/frankensteinpenetrating.cfm) [Archived](https://web.archive.org/web/20071109215920/http://www.ala.org/ala/ppo/currentprograms/frankenstein/frankensteinpenetrating.cfm) 9 November 2007 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^52]: Shelley, Mary (1818). [*Frankenstein*](http://www.gutenberg.org/files/41445/41445-h/41445-h.htm) (1 ed.).

[^53]: [John Milton](https://en.wikipedia.org/wiki/John_Milton "John Milton"), *[Paradise Lost](https://en.wikipedia.org/wiki/Paradise_Lost "Paradise Lost")* (X. 743–45)

[^54]: Chiu, Frances A. "Reform, Revolution, and the relevance of Frankenstein in 2020" in *Frankenstein Reanimated: Conversations with Artists in Dystopian Times*, ed. by Marc Garrett and Yiannis Colakides. London: Torque, 2022, 33–44.

[^55]: Johnson, Rossiter (1908). [*Author's digest: the world's great stories in brief. Vol. 16, Robert Louis Stevenson to Albion Winegar Tourgée*](http://archive.org/details/authorsdigestwo10johngoog). unknown library. \[New York\]: Issued under the auspices of the Author's Press.

[^56]: *[The Reef](https://en.wikipedia.org/wiki/The_Reef_\(novel\) "The Reef (novel)")*, p. 96.

[^57]: This illustration is reprinted in the frontispiece to the [2008 edition of *Frankenstein*](https://www.amazon.com/dp/098092104X) [Archived](https://web.archive.org/web/20151107023530/http://www.amazon.com/dp/098092104X) 7 November 2015 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^58]: Gray, Paul (23 July 1979). ["Books: The Man-Made Monster"](https://content.time.com/time/subscriber/article/0,33009,947086-3,00.html). *Time*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0040-781X](https://search.worldcat.org/issn/0040-781X). Retrieved 21 September 2020.

[^59]: ["The Real-Life Places That Inspired Frankenstein"](https://www.smithsonianmag.com/arts-culture/geography-of-frankenstein-180956964/). *Smithsonian*. Retrieved 13 November 2025.

[^60]: zapomniana, Historia (24 January 2016). ["Afera grabarzy z Frankenstein"](https://historiamniejznanaizapomniana.wordpress.com/2016/01/24/afera-grabarzy-z-frankenstein/). [Archived](https://web.archive.org/web/20180203135121/https://historiamniejznanaizapomniana.wordpress.com/2016/01/24/afera-grabarzy-z-frankenstein/) from the original on 3 February 2018. Retrieved 15 February 2017.

[^61]: [Florescu 1996](#CITEREFFlorescu1996), pp. 48–92.

[^62]: Day, A.J. (2005). [*Fantasmagoriana (Tales of the Dead)*](https://books.google.com/books?id=szyuBymktB4C&pg=PA150). Fantasmagoriana Press. pp. 149–51. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-4116-5291-0](https://en.wikipedia.org/wiki/Special:BookSources/978-1-4116-5291-0 "Special:BookSources/978-1-4116-5291-0").

[^63]: Heléne, Jörg (12 September 2016). ["Mary Shelley's Frankenstein, Castle Frankenstein and the alchemist Johann Conrad Dippel"](https://darmundestat.wordpress.com/sonstiges/mary-shelleys-frankenstein-castle-frankenstein-and-the-alchemist-johann-conrad-dippel). *Darmstadt*. [Archived](https://web.archive.org/web/20161007001226/https://darmundestat.wordpress.com/sonstiges/mary-shelleys-frankenstein-castle-frankenstein-and-the-alchemist-johann-conrad-dippel/) from the original on 7 October 2016. Retrieved 23 June 2017.

[^64]: ["Wade, Phillip. "Shelley and the Miltonic Element in Mary Shelley's *Frankenstein*." *Milton and the Romantics*, 2 (December, 1976), 23–25"](http://www.english.upenn.edu/Projects/knarf/Articles/wade.html). [Archived](https://web.archive.org/web/20110414014829/http://www.english.upenn.edu/Projects/knarf/Articles/wade.html) from the original on 14 April 2011. Retrieved 5 August 2011.

[^65]: [Jones 1952](#CITEREFJones1952), pp. 496–97.

[^66]: Shelley, Percy (1885). *The Complete Poetical Works of Percy Bysshe Shelley. The Text Carefully Revised by William Michael Rossetti · Volume 1*. Harvard University. p. 3.

[^67]: Sandy, Mark (20 September 2002). ["Original Poetry by Victor and Cazire"](http://www.litencyc.com/php/sworks.php?rec=true&UID=3010). *[The Literary Encyclopedia](https://en.wikipedia.org/wiki/The_Literary_Encyclopedia "The Literary Encyclopedia")*. The Literary Dictionary Company. [Archived](https://web.archive.org/web/20061108135507/http://www.litencyc.com/php/sworks.php?rec=true&UID=3010) from the original on 8 November 2006. Retrieved 2 January 2007.

[^68]: ["Percy Bysshe Shelley (1792–1822)"](http://www.dickinson.edu/~nicholsa/Romnat/pbshelley.htm). *Romantic Natural History*. Department of English, [Dickinson College](https://en.wikipedia.org/wiki/Dickinson_College "Dickinson College"). [Archived](https://web.archive.org/web/20060816015001/http://www.dickinson.edu/~nicholsa/Romnat/pbshelley.htm) from the original on 16 August 2006. Retrieved 2 January 2007.

[^69]: Goulding, Christopher (2002). ["The real Doctor Frankenstein?"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1279684). *Journal of the Royal Society of Medicine*. **95** (5): 257–259. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/014107680209500514](https://doi.org/10.1177%2F014107680209500514). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0141-0768](https://search.worldcat.org/issn/0141-0768). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [1279684](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1279684). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [11983772](https://pubmed.ncbi.nlm.nih.gov/11983772).

[^70]: For example, the Longman study edition published in India in 2007 by Pearson Education

[^71]: Morton, Timothy (21 September 2006). [*The Cambridge Companion to Shelley*](https://books.google.com/books?id=NXEytZwWziEC&q=mary+shelley+vegetarian&pg=PA196). Cambridge University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [9781139827072](https://en.wikipedia.org/wiki/Special:BookSources/9781139827072 "Special:BookSources/9781139827072").

[^72]: [Wolf, Leonard](https://en.wikipedia.org/wiki/Leonard_Wolf "Leonard Wolf") (1993). *The Essential Frankenstein: The Definitive, Annotated Edition of Mary Shelley's Classic Novel*. New York: Plume. p. 20.

[^73]: ["Benjamin Franklin in London"](https://web.archive.org/web/20130512063335/http://royalsociety.org/exhibitions/2006/benjamin-franklin/). *The Royal Society*. Archived from [the original](http://royalsociety.org/exhibitions/2006/benjamin-franklin/) on 12 May 2013. Retrieved 8 August 2007.

[^74]: Robinson, Charles (1996). [*The Frankenstein Notebooks: A Facsimile Edition*](https://books.google.com/books?id=9q6tjgEACAAJ). Vol. 1. Garland Publishing, Inc. p. xxv. [Archived](https://web.archive.org/web/20170316132025/https://books.google.com/books/about/The_Frankenstein_Notebooks.html?id=9q6tjgEACAAJ) from the original on 16 March 2017. Retrieved 15 March 2017. She began that novel as Mary Godwin in June 1816 when she was eighteen years old, she finished it as Mary Shelley in April/May 1817 when she was nineteen... and she published it anonymously on 1 January 1818 when she was twenty.

[^75]: [Bennett 1998](#CITEREFBennett1998).

[^76]: D. L. Macdonald and Kathleen Scherf, "A Note on the Text", Frankenstein, 2nd ed., Peterborough: Broadview Press, 1999.

[^77]: [Wollstonecraft Shelley, Mary](https://en.wikipedia.org/wiki/Mary_Shelley "Mary Shelley") (2000). [*Frankenstein*](https://books.google.com/books?id=qykBJvG0iJQC&pg=PA3). Bedford Publishing. p. 3. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0312227623](https://en.wikipedia.org/wiki/Special:BookSources/978-0312227623 "Special:BookSources/978-0312227623").

[^78]: Smith, Andrew (2016). *The Cambridge Companion to Frankenstein*. Cambridge University Press. p. 20.

[^79]: See forward to *Barnes and Noble* classic edition.

[^80]: The edition published by *Forgotten Books* is the original text, as is the "Ignatius Critical Edition". *Vintage Books* has an edition presenting both versions.

[^81]: Mellor, Anne K. (1990). "Choosing a Text of *Frankenstein* to Teach". In Behrendt, Stephen C. (ed.). *Approaches to Teaching Shelley's* Frankenstein. New York: Modern Language Association of America. pp. 31–37. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-87352-539-6](https://en.wikipedia.org/wiki/Special:BookSources/0-87352-539-6 "Special:BookSources/0-87352-539-6"). \[Reprinted in the [Norton Critical Edition](https://en.wikipedia.org/wiki/Norton_Critical_Edition "Norton Critical Edition").\]

[^82]: Scott, Walter (March 1818). ["Remarks on Frankenstein, or the Modern Prometheus; A Novel"](https://en.wikisource.org/wiki/Blackwood%27s_Magazine/Volume_2/Issue_12/Remarks_on_Frankenstein). *Blackwood's Edinburgh Magazine*: 613–620. Retrieved 9 May 2025.

[^83]: ["Frankenstein; or, The Modern Prometheus. 3 vols. 12mo. Lackington and Co"](http://romantic-circles.org/reference/chronologies/mschronology/reviews/barev.html). *La Belle Assemblée*. New Series. 1 February 1818. pp. 139–142. [Archived](https://web.archive.org/web/20200114224740/http://romantic-circles.org/reference/chronologies/mschronology/reviews/barev.html) from the original on 14 January 2020. Retrieved 14 January 2020.

[^84]: ["Review – Frankenstein"](https://babel.hathitrust.org/cgi/pt?id=hvd.32044092547710&view=1up&seq=259). *The Edinburgh Magazine and Literary Miscellany*. New Series. March 1818. pp. 249–253.

[^85]: ["Review of *Frankenstein, or the Modern Prometheus* "](https://babel.hathitrust.org/cgi/pt?id=hvd.32044092624956;view=1up;seq=389). *The Quarterly Review*. **18**: 379–85. January 1818. [Archived](https://web.archive.org/web/20181106171936/https://babel.hathitrust.org/cgi/pt?id=hvd.32044092624956;view=1up;seq=389) from the original on 6 November 2018. Retrieved 18 March 2017.

[^86]: ["Art. XII. Frankenstein: or the Modern Prometheus. 3 vols. 12mo. 16s. 6d. Lackington and Co. 1818"](https://romantic-circles.org/reference/chronologies/mschronology/reviews/bcrev.html). *The British Critic*. New Series. **9**: 432–438. April 1818. [Archived](https://web.archive.org/web/20200114224651/https://romantic-circles.org/reference/chronologies/mschronology/reviews/bcrev.html) from the original on 14 January 2020. Retrieved 14 January 2020.

[^87]: ["Frankenstein; or, the modern Prometheus. 3 vols. Lackington and Co. 1818"](https://romantic-circles.org/reference/chronologies/mschronology/reviews/lprev.html). *The Literary Panorama and National Register*. New Series. **8**: 411–414. June 1818. [Archived](https://web.archive.org/web/20200114225926/https://romantic-circles.org/reference/chronologies/mschronology/reviews/lprev.html) from the original on 14 January 2020. Retrieved 14 January 2020.

[^88]: Hoeveler, Diane Long (2016). *The Cambridge Companion to Frankenstein*. Cambridge University Press. pp. 175–189.

[^89]: Plath, James; Sinclair, Gail; Curnutt, Kirk (2019). *The 100 Greatest Literary Characters*. Rowman & Littlefield. p. 94.

[^90]: ["Enotes.com"](http://www.enotes.com/nineteenth-century-criticism/frankenstein-modern-prometheus-mary-wollstonecraft). Enotes.com. [Archived](https://web.archive.org/web/20100924042953/http://www.enotes.com/nineteenth-century-criticism/frankenstein-modern-prometheus-mary-wollstonecraft) from the original on 24 September 2010. Retrieved 28 August 2010.

[^91]: ["KCTCS.edu"](https://web.archive.org/web/20041115203418/http://www.octc.kctcs.edu/crunyon/CE/Frankenstein/Bloom/4-7_BloomIntro.htm). Octc.kctcs.edu. Archived from [the original](http://www.octc.kctcs.edu/crunyon/CE/Frankenstein/Bloom/4-7_BloomIntro.htm) on 15 November 2004. Retrieved 28 August 2010.

[^92]: Germaine Greer (9 April 2007). ["Yes, Frankenstein really was written by Mary Shelley. It's obvious – because the book is so bad"](https://www.theguardian.com/world/2007/apr/09/gender.books). *The Guardian*. London. [Archived](https://web.archive.org/web/20161006091847/https://www.theguardian.com/world/2007/apr/09/gender.books) from the original on 6 October 2016. Retrieved 4 October 2016.

[^93]: L. Lipking. Frankenstein the True Story; or [Rousseau](https://en.wikipedia.org/wiki/Rousseau "Rousseau") Judges Jean-Jacques. (Published in the [Norton](https://en.wikipedia.org/wiki/W._W._Norton_&_Company "W. W. Norton & Company") critical edition. 1996)

[^94]: Five Books. ["Frankenstein by Mary Shelley | Five Books Expert Reviews"](https://fivebooks.com/book/frankenstein-by-mary-shelley/). *Five Books*. [Archived](https://web.archive.org/web/20190324222556/https://fivebooks.com/book/frankenstein-by-mary-shelley/) from the original on 24 March 2019. Retrieved 13 September 2019.

[^95]: Alexander, Lynn. ["Mary Shelley, *Frankenstein* "](https://web.archive.org/web/20101203105236/http://www.utm.edu/staff/lalexand/frankqst.htm). Department of English, University of Tennessee at Martin. Archived from [the original](http://www.utm.edu/staff/lalexand/frankqst.htm) on 3 December 2010. Retrieved 27 August 2009.

[^96]: Aldiss, Brian Wilson (1995). [*The detached retina: aspects of SF and fantasy*](http://archive.org/details/detachedretinaas00aldi). Internet Archive. Syracuse, N.Y.: Syracuse University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-8156-2681-7](https://en.wikipedia.org/wiki/Special:BookSources/978-0-8156-2681-7 "Special:BookSources/978-0-8156-2681-7").

[^97]: ["Frankenstein: Behind the monster smash"](https://www.bbc.co.uk/news/entertainment-arts-42411484). BBC. 1 January 2018. [Archived](https://web.archive.org/web/20180727232736/https://www.bbc.co.uk/news/entertainment-arts-42411484) from the original on 27 July 2018. Retrieved 21 July 2018.

[^98]: ["100 'most inspiring' novels revealed by BBC Arts"](https://www.bbc.com/news/entertainment-arts-50302788). [BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News"). 5 November 2019. [Archived](https://web.archive.org/web/20191108030557/https://www.bbc.com/news/entertainment-arts-50302788) from the original on 8 November 2019. Retrieved 10 November 2019. The reveal kickstarts the BBC's year-long celebration of literature.

[^99]: ["Celebrating the 200th anniversary of Frankenstein! Eight spooky stamps introduced by Jersey Post"](https://findyourstampsvalue.com/news/celebrating-the-200th-anniversary-of-frankenstein-eight-spooky-stamps-introduced-by-jersey-post). *findyourstampsvalue.com*. 8 May 2018. Retrieved 28 November 2024.

[^100]: ["Stamps to feature original artworks celebrating classic science fiction novels"](https://www.yorkpress.co.uk/news/national/19220163.stamps-feature-original-artworks-celebrating-classic-science-fiction-novels/). *Yorkpress.co.uk*. 9 April 2021. Retrieved 20 September 2022.

[^101]: Anderson, John (25 January 2022). ["'Boris Karloff: The Man Behind the Monster' Review: A Very Different Creature"](https://www.wsj.com/articles/boris-karloff-the-man-behind-the-monster-shudder-frankenstein-the-mummy-how-the-grinch-stole-christmas-11643149446). *[The Wall Street Journal](https://en.wikipedia.org/wiki/The_Wall_Street_Journal "The Wall Street Journal")*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0099-9660](https://search.worldcat.org/issn/0099-9660). Retrieved 26 January 2022.

[^102]: ["Peter Cushing: 10 essential films"](https://www.bfi.org.uk/lists/peter-cushing-10-essential-films). *BFI*. Retrieved 7 November 2025.

[^103]: Jones Jr., William B (2002). *Classics Illustrated: A Cultural History, with Illustrations*. North Carolina: McFarland & Company. pp. 40–41. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-7864-1077-9](https://en.wikipedia.org/wiki/Special:BookSources/0-7864-1077-9 "Special:BookSources/0-7864-1077-9").

[^104]: Benton, Mike (1991). *Horror Comics: The Illustrated History*. Dallas: Taylor Publishing Company. p. 10.

[^105]: ["Junji Ito's contemporary visual adaptation of Mary Shelley's Frankenstein. A comparative study"](https://www.ceeol.com/search/article-detail?id=1020434). *Lingua. Language and Culture*. **XX** (2): 247–259. 2021. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [2068-5351](https://search.worldcat.org/issn/2068-5351).