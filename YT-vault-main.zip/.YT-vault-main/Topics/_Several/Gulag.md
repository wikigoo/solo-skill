---
title: "Gulag"
source: "https://en.wikipedia.org/wiki/Gulag"
---
![](https://en.wikipedia.org/wiki/File:Vorkuta.jpg)

A punishment cell block in one of the subcamps of Vorkutlag, 1945

The **Gulag** [^3] [^4] was a system of [labor camps](https://en.wikipedia.org/wiki/Labor_camp "Labor camp") in the [Soviet Union](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union").[^14] [^15] [^13] In the Russian language, the word *Gulag* refers only to the division of the [Soviet secret police](https://en.wikipedia.org/wiki/Chronology_of_Soviet_secret_police_agencies "Chronology of Soviet secret police agencies") that was in charge of running the forced labor camps from the 1930s to the early 1950s during [Joseph Stalin](https://en.wikipedia.org/wiki/Joseph_Stalin "Joseph Stalin") 's rule, but in English literature the term is popularly used for the system of forced labor throughout the [Soviet era](https://en.wikipedia.org/wiki/History_of_the_Soviet_Union "History of the Soviet Union"). The Russian term that matches the English usage is Система Гулага, *Sistema Gylaga*, '"Gulag system"'. The abbreviation GULAG (ГУЛАГ) stands for " **G** lávnoye **u** pravléniye ispravítel'no-trudovýkh **lag** eréy" (**Г** ла́вное **у** правле́ние исправи́тельно-трудовы́х **лаг** ере́й or "Main Directorate of [Correctional Labour Camps](https://en.wikipedia.org/wiki/Correctional_Labour_Camp "Correctional Labour Camp") "), but the full official name of the agency changed several times.

The Gulag was a major instrument of [political repression in the Soviet Union](https://en.wikipedia.org/wiki/Political_repression_in_the_Soviet_Union "Political repression in the Soviet Union"). The camps housed both ordinary criminals and [political prisoners](https://en.wikipedia.org/wiki/Political_prisoner "Political prisoner"), a large number of whom were convicted in accordance with simplified procedures, such as [NKVD troikas](https://en.wikipedia.org/wiki/NKVD_troika "NKVD troika") or other instruments of [extrajudicial punishment](https://en.wikipedia.org/wiki/Extrajudicial_punishment "Extrajudicial punishment"). The agency was established in 1930 and initially was administered by the [OGPU](https://en.wikipedia.org/wiki/Joint_State_Political_Directorate "Joint State Political Directorate") (1923–1934), later known as the [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD") (1934–1946) and the [Ministry of Internal Affairs](https://en.wikipedia.org/wiki/Ministry_of_Internal_Affairs_\(Soviet_Union\) "Ministry of Internal Affairs (Soviet Union)") (MVD) in the final years.

The [internment](https://en.wikipedia.org/wiki/Internment "Internment") system grew rapidly, reaching a population of 100,000 in the 1920s. By the end of 1940, the population of the Gulag camps amounted to 1.5 million.[^16] The emergent consensus among scholars is that of the 14 million prisoners who passed through the Gulag camps and the 4 million prisoners who passed through the Gulag colonies from 1930 to 1953, roughly 1.5 to 1.7 million prisoners perished there or died soon after they were released.[^7] [^8] [^9] Some journalists and writers who question the reliability of such data heavily rely on memoir sources that come to higher estimations.[^7] [^17] Archival researchers have found "no plan of destruction" of the Gulag population and no statement of official intent to kill them, and prisoner releases vastly exceeded the number of deaths in the Gulag.[^7] This policy can partially be attributed to the common practice of releasing prisoners who were suffering from incurable diseases as well as prisoners who were near death.[^16] [^18]

Almost immediately after the [death of Stalin](https://en.wikipedia.org/wiki/Death_and_state_funeral_of_Joseph_Stalin "Death and state funeral of Joseph Stalin"), a [mass general amnesty](https://en.wikipedia.org/wiki/Amnesty_of_1953 "Amnesty of 1953") was granted to non-political prisoners and political prisoners who had been sentenced to a maximum of five years in prison. Shortly thereafter, [Nikita Khrushchev](https://en.wikipedia.org/wiki/Nikita_Khrushchev "Nikita Khrushchev") was elected [First Secretary](https://en.wikipedia.org/wiki/General_Secretary_of_the_Communist_Party_of_the_Soviet_Union "General Secretary of the Communist Party of the Soviet Union"), initiating the processes of [de-Stalinization](https://en.wikipedia.org/wiki/De-Stalinization "De-Stalinization") and the [Khrushchev Thaw](https://en.wikipedia.org/wiki/Khrushchev_Thaw "Khrushchev Thaw"), triggering a mass release and [rehabilitation](https://en.wikipedia.org/wiki/Rehabilitation_\(Soviet\) "Rehabilitation (Soviet)") of political prisoners. Six years later, on 25 January 1960, the Gulag system was officially abolished when the remains of its administration were dissolved by Khrushchev. The legal practice of sentencing convicts to [penal labor](https://en.wikipedia.org/wiki/Penal_labor "Penal labor") continues to exist in the [Russian Federation](https://en.wikipedia.org/wiki/Russian_Federation "Russian Federation"), but its capacity is greatly reduced.[^19] [^20]

[Aleksandr Solzhenitsyn](https://en.wikipedia.org/wiki/Aleksandr_Solzhenitsyn "Aleksandr Solzhenitsyn"), winner of the [Nobel Prize in Literature](https://en.wikipedia.org/wiki/Nobel_Prize_in_Literature "Nobel Prize in Literature"), who survived eight years of Gulag incarceration, gave the term its international repute with the publication of *[The Gulag Archipelago](https://en.wikipedia.org/wiki/The_Gulag_Archipelago "The Gulag Archipelago")* in 1973. The author likened the scattered camps to " [a chain of islands](https://en.wikipedia.org/wiki/Archipelago "Archipelago") ", and as an eyewitness, he described the Gulag as a system where people were worked to death.[^21] In March 1940, there were 53 Gulag camp directorates (simply referred to as "camps") and 423 labor colonies in the Soviet Union.[^10] Many mining and industrial towns and cities in northern Russia, eastern Russia and [Kazakhstan](https://en.wikipedia.org/wiki/Kazakhstan "Kazakhstan") —such as [Karaganda](https://en.wikipedia.org/wiki/Karaganda "Karaganda"), [Norilsk](https://en.wikipedia.org/wiki/Norilsk "Norilsk"), [Vorkuta](https://en.wikipedia.org/wiki/Vorkuta "Vorkuta") and [Magadan](https://en.wikipedia.org/wiki/Magadan "Magadan") —originated as blocks of camps built by prisoners and subsequently run by ex-prisoners.[^22]

## Etymology

GULAG ([ГУЛАГ](https://en.wiktionary.org/wiki/%D0%93%D0%A3%D0%9B%D0%90%D0%93 "wikt:ГУЛАГ")) stands for "Гла́вное управле́ние исправи́тельно-трудовы́х лагере́й" (Main Directorate of [Correctional Labour Camps](https://en.wikipedia.org/wiki/Correctional_labour_camp "Correctional labour camp")). It was renamed several times, e.g., the Main Directorate of [Correctional Labor Colonies](https://en.wikipedia.org/wiki/Corrective_labor_colony "Corrective labor colony") (Главное управление исправительно-трудовых колоний (ГУИТК)), which names can be seen in the documents describing the subordination of various camps.[^23] The term was not used in Russian very often, either officially or colloquially; the predominant terms were *the camps* (лагеря, *lagerya*) and *the zone* (зона, *zona*), usually singular, for the labor camp system and for the individual camps. The official term "correctional labour camp" was suggested for official use by the [Politburo](https://en.wikipedia.org/wiki/Politburo_of_the_Communist_Party_of_the_Soviet_Union "Politburo of the Communist Party of the Soviet Union") of the [Communist Party of the Soviet Union](https://en.wikipedia.org/wiki/Communist_Party_of_the_Soviet_Union "Communist Party of the Soviet Union") in the session of July 27, 1929.

Although the term was originally used in reference to a government agency, in English and many other languages, the acronym acquired the qualities of a common noun, denoting *the Soviet system of [prison](https://en.wikipedia.org/wiki/Prison "Prison") -based, [unfree labor](https://en.wikipedia.org/wiki/Unfree_labor "Unfree labor")*.[^24]

> Even more broadly, "Gulag" has come to mean the Soviet repressive system itself, the set of procedures that prisoners once called the "meat-grinder": the arrests, the interrogations, the transport in unheated cattle cars, the forced labor, the destruction of families, the years spent in exile, the early and unnecessary deaths.

Western authors use the term *Gulag* to denote all of the prisons and internment camps which existed in the Soviet Union. In contemporary times, the term is not solely used in reference to the prisons and internment camps which existed in the USSR, such as in the expression " [North Korea's Gulag](https://en.wikipedia.org/wiki/Prisons_in_North_Korea "Prisons in North Korea") " [^25] for camps operational today.[^26]

## Overview

![](https://en.wikipedia.org/wiki/File:Yagoda_kanal_Moskva_Volga.jpg)

Genrikh Yagoda (middle) inspecting the construction of the Moscow-Volga canal, 1935. Behind his right shoulder is Nikita Khrushchev.

Some historians estimate that 14 million people were imprisoned in the Gulag labor camps from 1929 to 1953 (the estimates for the period from 1918 to 1929 are more difficult to calculate).[^27] Other calculations, by historian [Orlando Figes](https://en.wikipedia.org/wiki/Orlando_Figes "Orlando Figes"), refer to 25 million prisoners of the Gulag in 1928–1953.[^28] A further 6–7 million were [deported and exiled](https://en.wikipedia.org/wiki/Population_transfer_in_the_Soviet_Union#Timeline "Population transfer in the Soviet Union") to remote areas of the [USSR](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union"), and 4–5 million passed through [labor colonies](https://en.wikipedia.org/wiki/Corrective_labor_colony "Corrective labor colony"), plus 3.5 million who were already in, or had been sent to, [labor settlements](https://en.wikipedia.org/wiki/Special_settlements_in_the_Soviet_Union "Special settlements in the Soviet Union").[^27]

According to some estimates, the total population of the camps varied from 510,307 in 1934 to 1,727,970 in 1953.[^10] According to other estimates, at the beginning of 1953 the total number of prisoners in prison camps was more than 2.4 million, of which more than 465,000 were political prisoners.[^29] [^30] Between 1934 and 1953, 20% to 40% of the Gulag population in each given year were released.[^31] [^32] Most Gulag inmates were not political prisoners, although significant numbers of political prisoners could be found in the camps at any one time.[^29]

Petty crimes and jokes about the Soviet government and officials were punishable by imprisonment.[^33] [^34] About half of political prisoners in the Gulag camps were imprisoned "by administrative means", i.e., without trial at courts; official data suggest that there were over 2.6 million sentences to imprisonment on cases investigated by the secret police throughout 1921–53.[^35] Maximum sentences varied depending on the type of crime and changed over time. From 1953, the maximum sentence for petty theft was six months,[^36] having previously been one year and seven years. Theft of state property carried a sentence of 7 to 25 years.[^37] In 1958, the maximum sentence for any crime was reduced from 25 to 15 years.[^38]

In 1960, the MVD ceased to function as the Soviet-wide administration of the camps in favour of individual republic MVD branches. The centralised detention administrations temporarily ceased functioning.[^39] [^40]

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e1/The_fence_at_the_old_GULag_in_Perm-36.JPG/250px-The_fence_at_the_old_GULag_in_Perm-36.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

The fence at the old Gulag camp in Perm-36, founded in 1943, turned into a museum.

## History

### Background

![](https://en.wikipedia.org/wiki/File:V.M._Doroshevich-Sakhalin._Part_I._Prisoners_on_Steamship_of_Voluntary_Fleet.png)

Prisoners on a ship on their way to Sakhalin, remote prison island, c. 1903

The [tsar](https://en.wikipedia.org/wiki/Tsardom_of_Russia "Tsardom of Russia") and the [Russian Empire](https://en.wikipedia.org/wiki/Russian_Empire "Russian Empire") both used forced [exile](https://en.wikipedia.org/wiki/Exile "Exile") and [forced labour](https://en.wikipedia.org/wiki/Forced_labour "Forced labour") as forms of judicial punishment. [Katorga](https://en.wikipedia.org/wiki/Katorga "Katorga"), a category of punishment which was reserved for those who were convicted of the most serious crimes, had many of the features which were associated with labor-camp imprisonment: confinement, simplified facilities (as opposed to the facilities which existed in prisons), and forced labor, usually involving hard, unskilled or semi-skilled work. According to historian [Anne Applebaum](https://en.wikipedia.org/wiki/Anne_Applebaum "Anne Applebaum"), katorga was not a common sentence; approximately 6,000 katorga convicts were serving sentences in 1906, with up to 28,600 by 1916.[^41] Under the Imperial Russian penal system, those who were convicted of less serious crimes were sent to corrective prisons and they were also made to work.[^42]

Forced exile to [Siberia](https://en.wikipedia.org/wiki/Siberia "Siberia") had been in use for a wide range of offenses since the 17th century, and it was a common punishment for political dissidents and revolutionaries. In the 19th century, the members of the failed [Decembrist revolt](https://en.wikipedia.org/wiki/Decembrist_revolt "Decembrist revolt") and [Polish nobles who resisted Russian rule](https://en.wikipedia.org/wiki/Sybirak "Sybirak") were sent into exile. [Fyodor Dostoevsky](https://en.wikipedia.org/wiki/Fyodor_Dostoevsky "Fyodor Dostoevsky") was sentenced to die for reading banned literature in 1849, but the sentence was commuted to banishment to Siberia. Members of various socialist revolutionary groups, including [Bolsheviks](https://en.wikipedia.org/wiki/Bolsheviks "Bolsheviks") such as [Sergo Ordzhonikidze](https://en.wikipedia.org/wiki/Sergo_Ordzhonikidze "Sergo Ordzhonikidze"), [Vladimir Lenin](https://en.wikipedia.org/wiki/Vladimir_Lenin "Vladimir Lenin"), [Leon Trotsky](https://en.wikipedia.org/wiki/Leon_Trotsky "Leon Trotsky"), and [Joseph Stalin](https://en.wikipedia.org/wiki/Joseph_Stalin "Joseph Stalin") were also sent into exile.[^43] Convicts who were serving labor sentences and exiles were sent to the underpopulated areas of Siberia and the [Russian Far East](https://en.wikipedia.org/wiki/Russian_Far_East "Russian Far East") —regions that lacked towns or food sources, as well as organized transportation systems. Despite the isolated conditions, some prisoners successfully escaped to populated areas. Stalin escaped three of the four times after he was sent into exile.[^44]

Since those times, Siberia gained its fearful connotation as a place of punishment, a reputation which was further enhanced by the Soviet Gulag system. The Bolsheviks' own experiences with exile and forced labor provided them with a model which they could base their own system on, including the importance of strict enforcement. From 1920 to 1950, the leaders of the Communist Party and the Soviet state considered repression a tool that they should use to secure the normal functioning of the Soviet state system and preserve and strengthen their positions within their social base, the working class (when the Bolsheviks took power, peasants represented 80% of the population).[^45]

In the midst of the [Russian Civil War](https://en.wikipedia.org/wiki/Russian_Civil_War "Russian Civil War"), Lenin and the Bolsheviks established a "special" prison camp system, separate from its traditional prison system and under the control of the [Cheka](https://en.wikipedia.org/wiki/Cheka "Cheka").[^46] These camps, as Lenin envisioned them, had a distinctly political purpose.[^47] These early camps of the Gulag system were introduced in order to isolate and eliminate those considered class-aliens, socially dangerous, disruptive, suspicious, and other disloyal elements, whose deeds and thoughts were not seen as contributing to the strengthening of the [dictatorship of the proletariat](https://en.wikipedia.org/wiki/Dictatorship_of_the_proletariat "Dictatorship of the proletariat").[^45]

Forced labor as a "method of reeducation" was applied in the [Solovki prison camp](https://en.wikipedia.org/wiki/Solovki_prison_camp "Solovki prison camp") as early as the 1920s,[^48] based on Trotsky's experiments with forced labor camps for Czech war prisoners from 1918 and his proposals to introduce "compulsory labor service" voiced in *[Terrorism and Communism](https://en.wikipedia.org/wiki/Terrorism_and_Communism "Terrorism and Communism")*.[^48] [^49] These concentration camps were not identical to the Stalinist or [Nazi concentration camps](https://en.wikipedia.org/wiki/Nazi_concentration_camps "Nazi concentration camps") but were introduced to isolate war prisoners given the extreme historical situation following [World War I](https://en.wikipedia.org/wiki/World_War_I "World War I").[^50]

Various categories of prisoners were defined: petty criminals, POWs of the Russian Civil War, officials accused of corruption, sabotage and embezzlement, political enemies, dissidents and other people deemed dangerous for the state. In the first decade of Soviet rule, the judicial and penal systems were neither unified nor coordinated, and there was a distinction between criminal prisoners and political or "special" prisoners.

The "traditional" judicial and prison system, which dealt with criminal prisoners, were first overseen by The People's Commissariat of Justice until 1922, after which they were overseen by the People's Commissariat of Internal Affairs, also known as the [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD").[^51] The Cheka and its successor organizations, the GPU or [State Political Directorate](https://en.wikipedia.org/wiki/State_Political_Directorate "State Political Directorate") and the [OGPU](https://en.wikipedia.org/wiki/Joint_State_Political_Directorate "Joint State Political Directorate"), oversaw political prisoners and the "special" camps to which they were sent.[^52] In April 1929, the judicial distinctions between criminal and political prisoners were eliminated, and control of the entire Soviet penal system turned over to the OGPU.[^53] In 1928, there were 30,000 individuals interned; the authorities were opposed to compelled labor. In 1927, the official in charge of prison administration wrote:

> The exploitation of prison labour, the system of squeezing "golden sweat" from them, the organisation of production in places of confinement, which while profitable from a commercial point of view is fundamentally lacking in corrective significance – these are entirely inadmissible in Soviet places of confinement.[^54]

The legal base and the guidance for the creation of the system of "corrective labor camps" (исправи́тельно-трудовые лагеря, *Ispravitel'no-trudovye lagerya*), the backbone of what is commonly referred to as the "Gulag", was a secret decree from the [Sovnarkom](https://en.wikipedia.org/wiki/Sovnarkom "Sovnarkom") of July 11, 1929, about the use of [penal labor](https://en.wikipedia.org/wiki/Penal_labor "Penal labor") that duplicated the corresponding appendix to the minutes of the Politburo meeting of June 27, 1929.[^55]

One of the Gulag system founders was [Naftaly Frenkel](https://en.wikipedia.org/wiki/Naftaly_Frenkel "Naftaly Frenkel"). In 1923, he was arrested for illegally crossing borders and smuggling. He was sentenced to 10 years' hard labor at Solovki, which later came to be known as the "first camp of the Gulag". While serving his sentence he wrote a letter to the camp administration detailing a number of "productivity improvement" proposals including the infamous system of labor exploitation whereby the inmates' food rations were to be linked to their rate of production, a proposal known as nourishment scale (шкала питания). This notorious you-eat-as-you-work system would often kill weaker prisoners in weeks and caused countless casualties. The letter caught the attention of a number of high communist officials including [Genrikh Yagoda](https://en.wikipedia.org/wiki/Genrikh_Yagoda "Genrikh Yagoda"), and Frenkel soon went from being an inmate to becoming a camp commander and an important Gulag official. His proposals saw widespread adoption in the Gulag system.[^56]

After having appeared as an instrument and place for isolating counter-revolutionary and criminal elements, the Gulag, because of its principle of "correction by forced labor", quickly became, in fact, an independent branch of the national economy secured on the cheap labor force presented by prisoners. Hence it is followed by one more important reason for the constancy of the repressive policy, namely the state's interest in unremitting rates of receiving a cheap labor force that was forcibly used, mainly in the extreme conditions of the east and north.[^45] The Gulag possessed both punitive and economic functions.[^57]

### Formation and expansion during Stalin's rule

The Gulag was an administrative body that watched over the camps; eventually, its name would retrospectively be used as a name for these camps. After [Lenin's death in 1924](https://en.wikipedia.org/wiki/Death_and_state_funeral_of_Vladimir_Lenin "Death and state funeral of Vladimir Lenin"), Stalin was able to take control of the government, and he began to form the Gulag system. On June 27, 1929, the Politburo created a system of self-supporting camps that would eventually replace the existing prisons around the country.[^58] Prisoners who received a prison sentence which exceeded three years were required to remain in these prisons. Prisoners who received a prison sentence which was shorter than three years were required to remain in the prison system that was still under the purview of the NKVD.

The purpose of these new camps was to colonise the remote and inhospitable environments throughout the Soviet Union. These changes took place around the time when Stalin started to institute [collectivization](https://en.wikipedia.org/wiki/Collectivization_in_the_Soviet_Union "Collectivization in the Soviet Union") and rapid industrial development. Collectivisation resulted in a large-scale purge of peasants and so-called [kulaks](https://en.wikipedia.org/wiki/Kulak "Kulak"). In contrast to other Soviet peasants, the kulaks were supposedly wealthy, and as a result, the state classified them as [capitalists](https://en.wikipedia.org/wiki/Capitalism "Capitalism"), and by extension it also classified them as [enemies of socialism](https://en.wikipedia.org/wiki/Enemy_of_the_people#Soviet_Union "Enemy of the people"). The term would also become associated with anyone who opposed or even seemed dissatisfied with the [Soviet government](https://en.wikipedia.org/wiki/Government_of_the_Soviet_Union "Government of the Soviet Union"). By late 1929, Stalin launched a program which was known as *[dekulakization](https://en.wikipedia.org/wiki/Dekulakization "Dekulakization")*. Stalin demanded the complete elimination of the kulak class, resulting in the imprisonment and execution of Soviet peasants. In just four months, 60,000 people were sent to the camps and 154,000 other people were exiled. However, this was only the beginning of the *dekulakisation* process. In 1931 alone, 1,803,392 people were exiled.[^59]

Although these massive relocation processes were successful in transferring a large potential free forced labor work force to places where it was needed, that is about all it was successful in doing. All of the " [special settlers](https://en.wikipedia.org/wiki/Forced_settlements_in_the_Soviet_Union "Forced settlements in the Soviet Union") ", as the Soviet government referred to them, lived on starvation level rations, and as a result, many people starved to death in the camps, and anyone who was healthy enough to escape tried to do just that. This situation forced the government to give rations to a group of people which it was hardly getting any use out of, and as a result, it was just costing the Soviet government money. The OGPU quickly discovered the problem, and in response, it began to reform the *dekulakisation* process.[^60] In an attempt to prevent mass escapes from the colony, the OGPU started to recruit prisoners who lived inside it, and it also set up ambushes around popular escape routes. The OGPU also attempted to raise the living conditions in these camps in order to discourage people from actively trying to escape from them, and kulaks were told that they would regain their rights in five years. Even these revisions ultimately failed to resolve the problem, and as a result, the *dekulakisation* process was a failure because it did not lead to the creation of a steady forced labor force for the government.[^60]

The Gulag was officially established on 25 April 1930, as the GULAG by the OGPU order 130/63 in accordance with the [Sovnarkom](https://en.wikipedia.org/wiki/Council_of_People's_Commissars "Council of People's Commissars") order 22 p. 248 dated April 7, 1930. It was renamed as the GULAG in November of that year.[^61] The hypothesis that economic considerations were responsible for mass arrests during the period of Stalinism has been refuted on the grounds of former Soviet archives that have become accessible since the 1990s, although some archival sources also tend to support an economic hypothesis.[^62] [^63] The 1931–32 archives indicate the Gulag had approximately 200,000 prisoners in the camps; while in 1935, approximately 800,000 were in camps and 300,000 in colonies.[^64] The Gulag population reached a peak value (1.5 million) in 1941, gradually decreased during the war and then started to grow again, achieving a maximum by 1953.[^10] Besides Gulag camps, a significant amount of prisoners, which confined prisoners serving short sentence terms.[^10]

![](https://en.wikipedia.org/wiki/File:USSR_custodial_population_in_1934-53.png)

The population of Gulag camps (blue) and Gulag colonies (red) in 1934–53 10

In the early 1930s, a tightening of the Soviet penal policy caused a significant growth of the prison camp population.[^65] During the [Great Purge](https://en.wikipedia.org/wiki/Great_Purge "Great Purge") of 1937–1938, mass arrests caused another increase in inmate numbers. Hundreds of thousands were arrested and sentenced to long prison terms on the grounds of one of the multiple passages of the notorious [Article 58](https://en.wikipedia.org/wiki/Article_58 "Article 58") of the Criminal Codes of the Union republics, which defined punishment for various forms of "counterrevolutionary activities". Under [NKVD Order No. 00447](https://en.wikipedia.org/wiki/NKVD_Order_No._00447 "NKVD Order No. 00447"), tens of thousands of Gulag inmates were executed in 1937–38 for "continuing counterrevolutionary activities".

Between 1934 and 1941, the number of prisoners with higher education increased more than eight times, and the number of prisoners with high education increased five times.[^45] It resulted in their increased share in the overall composition of the camp prisoners.[^45] Among the camp prisoners, the number and share of the intelligentsia was growing at the quickest pace.[^45] Distrust, hostility, and even hatred for the [intelligentsia](https://en.wikipedia.org/wiki/Intelligentsia "Intelligentsia") was a common characteristic of the Soviet leaders.[^45] Information regarding the imprisonment trends and consequences for the intelligentsia derive from the extrapolations of [Viktor Zemskov](https://en.wikipedia.org/wiki/Viktor_Zemskov "Viktor Zemskov") from a collection of prison camp population movements data.[^45] [^66]

### During World War II

#### Political role

Soviet archives indicate that on the eve of [World War II](https://en.wikipedia.org/wiki/Soviet_Union_in_World_War_II "Soviet Union in World War II"), the combined population of the camps and colonies was upwards of 1.6 million in 1939, according to V. P. Kozlov.[^64] Applebaum and [Steven Rosefielde](https://en.wikipedia.org/wiki/Steven_Rosefielde "Steven Rosefielde") estimate that 1.2 to 1.5 million people were incarcerated in the Gulag system's prison camps and colonies when the war started.[^67] [^68] After the [German invasion of Poland](https://en.wikipedia.org/wiki/Invasion_of_Poland "Invasion of Poland") that marked the start of World War II in Europe, the [Soviet Union invaded and annexed eastern parts](https://en.wikipedia.org/wiki/Soviet_invasion_of_Poland "Soviet invasion of Poland") of the [Second Polish Republic](https://en.wikipedia.org/wiki/Second_Polish_Republic "Second Polish Republic"). In 1940, the Soviet Union occupied [Estonia](https://en.wikipedia.org/wiki/Estonia "Estonia"), [Latvia](https://en.wikipedia.org/wiki/Latvia "Latvia"), [Lithuania](https://en.wikipedia.org/wiki/Lithuania "Lithuania"), [Bessarabia](https://en.wikipedia.org/wiki/Bessarabia "Bessarabia") (now the Republic of Moldova) and [Bukovina](https://en.wikipedia.org/wiki/Bukovina "Bukovina"). According to some estimates, hundreds of thousands of Polish citizens [^69] [^70] and inhabitants of the other annexed lands, regardless of their ethnic origin, were arrested and sent to the Gulag camps. However, according to the official data, the total number of sentences for political and anti-state (espionage, terrorism) crimes in the USSR in 1939–41 was 211,106.[^35]

Approximately 300,000 [Polish prisoners of war](https://en.wikipedia.org/wiki/Polish_prisoners_of_war_in_the_Soviet_Union_after_1939 "Polish prisoners of war in the Soviet Union after 1939") were captured by the USSR during and after the "Polish Defensive War".[^71] Almost all of the captured officers and a large number of ordinary soldiers were then murdered (see [Katyn massacre](https://en.wikipedia.org/wiki/Katyn_massacre "Katyn massacre")) or sent to the Gulag.[^72] Of the 10,000–12,000 Poles sent to [Kolyma](https://en.wikipedia.org/wiki/Kolyma "Kolyma") in 1940–41, most prisoners of war, only 583 men survived, released in 1942 to join the [Polish Armed Forces in the East](https://en.wikipedia.org/wiki/Polish_Armed_Forces_in_the_East "Polish Armed Forces in the East").[^73] Out of Polish General [Władysław Anders](https://en.wikipedia.org/wiki/W%C5%82adys%C5%82aw_Anders "Władysław Anders") ' 80,000 evacuees from the Soviet Union gathered in Great Britain, only 310 volunteered to return to Soviet-controlled Poland in 1947.[^74]

During the [Great Patriotic War](https://en.wikipedia.org/wiki/Eastern_Front_\(World_War_II\) "Eastern Front (World War II)"), Gulag populations declined sharply because of a steep rise in mortality in 1942–43. In the winter of 1941, a quarter of the Gulag's population died of starvation.[^75] 516,841 prisoners died in prison camps in 1941–43,[^76] [^77] from a combination of their harsh working conditions and the famine caused by the German invasion. This period accounts for about half of all Gulag deaths, according to Russian statistics. In 1943, the term *katorga works* (каторжные работы) was reintroduced. They were initially intended for [Nazi collaborators](https://en.wikipedia.org/wiki/Collaboration_with_Nazi_Germany_and_Fascist_Italy "Collaboration with Nazi Germany and Fascist Italy"), but then other categories of political prisoners (for example, members of [deported peoples](https://en.wikipedia.org/wiki/Population_transfer_in_the_Soviet_Union "Population transfer in the Soviet Union") who fled from exile) were also sentenced to "katorga works". Prisoners sentenced to "katorga works" were sent to Gulag prison camps with the most harsh regime, and many of them perished.[^77]

#### Economic role

![](https://en.wikipedia.org/wiki/File:Central_shop_in_Norilsk_in_1957.jpg)

Central shop in Norilsk built by prisoners of the Norillag

![](https://en.wikipedia.org/wiki/File:Logging_at_Small_Ungut_(no_border).jpeg)

Lithuanian deportees preparing logs for rafting on the Mana River

Until World War II, the Gulag system expanded dramatically to create a Soviet "camp economy". Right before the war, forced labor provided 46.5% of the nation's nickel, 76% of its tin, 40% of its cobalt, 40.5% of its chrome-iron ore, 60% of its gold, and 25.3% of its timber.[^78] And in preparation for war, the NKVD put up many more factories and built highways and railroads.

The Gulag quickly switched to the production of arms and supplies for the army after fighting began. At first, transportation remained a priority. In 1940, the NKVD focused most of its energy on railroad construction.[^79] This would prove extremely important when the German advance into the Soviet Union started in 1941. In addition, factories were converted to produce ammunition, uniforms, and other supplies. Moreover, the NKVD gathered skilled workers and specialists from throughout the Gulag into 380 special colonies which produced tanks, aircraft, armaments, and ammunition.[^78]

Despite its low capital costs, the camp economy suffered from serious flaws. Actual productivity almost never matched estimates: the estimates proved far too optimistic. Scarcity of machinery and tools plagued the camps, and the tools that the camps did have quickly broke. The Eastern Siberian Trust of the Chief Administration of Camps for Highway Construction destroyed 94 trucks in just three years.[^78] But the greatest problem was that forced labor was less efficient than free labor. In fact, prisoners in the Gulag were, on average, half as productive as free laborers in the USSR at the time,[^78] which may be partially explained by malnutrition. To make up for this disparity, the NKVD worked prisoners harder than ever. To meet rising demand, prisoners worked longer and longer hours, and on lower food-rations than ever before. A camp administrator said in a meeting: "There are cases when a prisoner is given only four or five hours out of twenty-four for rest, which significantly lowers his productivity." In the words of a former Gulag prisoner: "By the spring of 1942, the camp ceased to function. It was difficult to find people who were even able to gather firewood or bury the dead." [^78]

The scarcity of food stemmed in part from the general strain on the entire Soviet Union but also the lack of central aid to the Gulag during the war. The central government focused all its attention on the military and left the camps to their own devices. In 1942, the Gulag set up the Supply Administration to find their own food and industrial goods. During this time, not only did food become scarce, but the NKVD limited rations in an attempt to motivate the prisoners to work harder for more food, a policy that lasted until 1948.[^80]

In addition to food shortages, the Gulag suffered from labor scarcity at the beginning of the war. The [Great Terror](https://en.wikipedia.org/wiki/Great_Purge "Great Purge") of 1936–1938 had provided a large supply of free labor, but by the start of World War II the purges had slowed down. In order to complete all of their projects, camp administrators moved prisoners from project to project.[^79] To improve the situation, laws were implemented in mid-1940 that allowed giving short camp sentences (4 months to one year) to those convicted of petty theft, hooliganism, or labor-discipline infractions. By January 1941, the Gulag workforce had increased by approximately 300,000 prisoners.[^79] But in 1942, serious food shortages began, and camp populations dropped again. The camps lost still more prisoners to the war effort as the Soviet Union went into a total war footing in June 1941. Many laborers received early releases so that they could be drafted and sent to the front.[^80]

Even as the pool of workers shrank, demand for output continued to grow rapidly. As a result, the Soviet government pushed the Gulag to "do more with less". With fewer able-bodied workers and few supplies from outside the camp system, camp administrators had to find a way to maintain production. The solution they found was to push the remaining prisoners still harder. The NKVD employed a system of setting unrealistically high production goals, straining resources in an attempt to encourage higher productivity. As the Axis armies pushed into Soviet territory from June 1941 on, labor resources became further strained, and many of the camps had to evacuate out of western Russia.[^80]

From the beginning of the war to halfway through 1944, 40 camps were set up, and 69 were disbanded. During evacuations, machinery received priority, leaving prisoners to reach safety on foot. The speed of [Operation Barbarossa](https://en.wikipedia.org/wiki/Operation_Barbarossa "Operation Barbarossa") 's advance prevented the evacuation of all prisoners in good time, and the NKVD [massacred many to prevent them from falling into German hands](https://en.wikipedia.org/wiki/NKVD_prisoner_massacres "NKVD prisoner massacres"). While this practice denied the Germans a source of free labor, it also further restricted the Gulag's capacity to keep up with the Red Army's demands. When the tide of the war turned, however, and the Soviets started pushing the Axis invaders back, fresh batches of laborers replenished the camps. As the Red Army recaptured territories from the Germans, an influx of Soviet ex-POWs greatly increased the Gulag population.[^80]

### World War II aftermath

The [Allies of World War II](https://en.wikipedia.org/wiki/Allies_of_World_War_II "Allies of World War II") agreed to mandatory repatriation of Soviet citizens at the [Yalta Conference](https://en.wikipedia.org/wiki/Yalta_Conference "Yalta Conference") in February 1945. The bulk of handovers occurred from May to October 1945. Amounting to 4.2 million people, these included *[Ostarbeiters](https://en.wikipedia.org/wiki/Ostarbeiter "Ostarbeiter")*, [collaborationists](https://en.wikipedia.org/wiki/Collaborationist "Collaborationist"), [prisoners of war](https://en.wikipedia.org/wiki/Prisoner_of_war "Prisoner of war"), and [refugees](https://en.wikipedia.org/wiki/Refugee "Refugee").[^81] The state cleared and sent home 58 percent of the population. Another 33.5 percent faced mobilization into the military or [construction battalions](https://en.wikipedia.org/wiki/Construction_battalion_\(Soviet_Union\) "Construction battalion (Soviet Union)").[^82]

The vast majority of repatriates underwent verification and filtration outside of the Gulag system: in front-line and army camps, assembly-evacuation points of the [People's Commissariat of Defense](https://en.wikipedia.org/wiki/People's_Commissariat_of_Defense "People's Commissariat of Defense"), and verification-filtration points of the [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD"). Rank-and-file prisoners of war were checked in reserve military units. Those needing further investigation, designated as the "NKVD special contingent" (*spetskontingent*), were transferred to [NKVD special camps](https://en.wikipedia.org/wiki/NKVD_filtration_camps "NKVD filtration camps"), part of the Gulag network.[^81] Personnel of collaborationist units were sent to the NKVD camps or directly to Gulag corrective labor camps to undergo filtration.[^81] Officers among the prisoners of war were also sent to the NKVD special camps for further checking.[^83]

Declassified archives disprove claims of universal, immediate persecution for the returnees. The regime detained 6.5 percent of the 4.2 million returnees during filtration. This included 14 percent of prisoners of war and 2 percent of civilians. Most arrests targeted members of German-commanded formations, resulting in six-year administrative exile terms to distant [special settlements](https://en.wikipedia.org/wiki/Special_settlements_in_the_Soviet_Union "Special settlements in the Soviet Union"). Non-criminal repression included the transfer of 14.5 percent of returnees to construction battalions, effectively [forced labor](https://en.wikipedia.org/wiki/Forced_labor "Forced labor") without an opportunity to change one's place of employment.[^82]

By law, military collaborators were expected to face the heaviest punishment. In practice, however, the rank-and-file (privates and sergeants) among the [Hiwis](https://en.wikipedia.org/wiki/Hiwi_\(volunteer\) "Hiwi (volunteer)"), [Cossack collaborators](https://en.wikipedia.org/wiki/Cossack_collaborators "Cossack collaborators"), and [Russian Liberation Army](https://en.wikipedia.org/wiki/Russian_Liberation_Army "Russian Liberation Army") (ROA) usually received six-year terms in special settlements and avoided criminal prosecution. On the other hand, NKVD arrested and prosecuted commanders and officers of ROA, *[Ostlegionen](https://en.wikipedia.org/wiki/Ostlegionen "Ostlegionen")* (eastern legions), [XV SS Cossack Cavalry Corps](https://en.wikipedia.org/wiki/XV_SS_Cossack_Cavalry_Corps "XV SS Cossack Cavalry Corps"), [Kazachi Stan](https://en.wikipedia.org/wiki/Kazachi_Stan "Kazachi Stan"), *[Schutzmannschaft](https://en.wikipedia.org/wiki/Schutzmannschaft "Schutzmannschaft")* (auxiliary police), *[Gestapo](https://en.wikipedia.org/wiki/Gestapo "Gestapo")*, and similar units; mayors; village heads who collaborated with special zeal; Red Army servicemen who voluntarily defected; and those who participated in [punitive operations](https://en.wikipedia.org/wiki/Bandenbekampfung "Bandenbekampfung") or were accused of war crimes. They were typically sentenced to the Gulag and received harsh sentences.[^81]

The vast majority of the repatriations were carried out by March 1946, with the following results:

| Category | Total | % | Civilian | % | POWs | % |
| --- | --- | --- | --- | --- | --- | --- |
| Released and sent home [^5] | 2,427,906 | 58 | 2,146,126 | 81 | 281,780 | 18 |
| Conscripted | 801,152 | 19 | 141,962 | 5 | 659,190 | 43 |
| Drafted into [construction battalions](https://en.wikipedia.org/wiki/Construction_battalion_\(Soviet_Union\) "Construction battalion (Soviet Union)") of the Ministry of Defence | 608,095 | 14.5 | 263,647 | 10 | 344,448 | 22 |
| Sent to NKVD as *spetskontingent* [^6] | 272,867 | 6.5 | 46,740 | 2 | 226,127 | 15 |
| Were waiting for transportation and worked for Soviet military units abroad | 89,468 | 2 | 61,538 | 2 | 27,930 | 2 |
| **Total** | **4,199,488** | **100** | **2,660,013** | **100** | **1,539,475** | **100** |

After [Nazi Germany](https://en.wikipedia.org/wiki/Nazi_Germany "Nazi Germany") 's defeat, NKVD set up ten [NKVD special camps in the Soviet occupation zone in Germany](https://en.wikipedia.org/wiki/NKVD_special_camps_in_Germany_1945%E2%80%931950 "NKVD special camps in Germany 1945–1950") subordinate to the Gulag. These camps were former [Stalags](https://en.wikipedia.org/wiki/Stalag "Stalag"), prisons, or [Nazi concentration camps](https://en.wikipedia.org/wiki/Nazi_concentration_camps "Nazi concentration camps") such as [Sachsenhausen](https://en.wikipedia.org/wiki/Sachsenhausen_concentration_camp "Sachsenhausen concentration camp") ([special camp number 7](https://en.wikipedia.org/wiki/NKVD_special_camp_Nr._7 "NKVD special camp Nr. 7")) and [Buchenwald](https://en.wikipedia.org/wiki/Buchenwald_concentration_camp "Buchenwald concentration camp") ([special camp number 2](https://en.wikipedia.org/wiki/NKVD_special_camp_Nr._2 "NKVD special camp Nr. 2")). According to German government estimates "65,000 people died in those Soviet-run camps or in transportation to them." [^85] According to German researchers, Sachsenhausen, where 12,500 Soviet era victims have been uncovered, should be seen as an integral part of the Gulag system.[^86]

![](https://en.wikipedia.org/wiki/File:Magadan_seen_from_mountain.jpg)

During the Stalin era, Magadan was a major transit center for prisoners sent to the Kolyma camps.

### Later history

![](https://en.wikipedia.org/wiki/File:Transpolar_Railway_between_Salekhard_and_Nadym.jpg)

The Transpolar Railway was a project of the Gulag system that took place from 1947 to 1953.

By the early 1950s, the number of inmates in prison camps and colonies sharply rose again, reaching approximately 2.5 million people by the early 1950s (about 1.7 million of whom were in camps). Yet the major reason for the post-war increase in the number of prisoners was the tightening of legislation on property offences in summer 1947 (at this time there was a famine in some parts of the Soviet Union, claiming about 1 million lives), which resulted in hundreds of thousands of convictions to lengthy prison terms, sometimes on the basis of cases of petty theft or embezzlement. At the beginning of 1953, the total number of prisoners in prison camps was more than 2.4 million of which more than 465,000 were political prisoners.[^77]

![](https://en.wikipedia.org/wiki/File:Political_prisoners_at_Intalag,_USSR.jpg)

Political prisoners eating lunch in the Minlag "special camp" coal mine. In "special camps" prisoners had to wear prison garb with personal numbers.

In 1948, the [system of "special camps"](https://en.wikipedia.org/wiki/MVD_special_camp "MVD special camp") was established exclusively for a "special contingent" of political prisoners, convicted according to the more severe sub-articles of [Article 58](https://en.wikipedia.org/wiki/Article_58_of_the_RSFSR_Penal_Code "Article 58 of the RSFSR Penal Code") (Enemies of people): treason, espionage, terrorism, etc., for various real political opponents, such as [Trotskyites](https://en.wikipedia.org/wiki/Trotskyism "Trotskyism"), "nationalists" ([Ukrainian nationalism](https://en.wikipedia.org/wiki/Ukrainian_nationalism "Ukrainian nationalism")), [white émigré](https://en.wikipedia.org/wiki/White_%C3%A9migr%C3%A9 "White émigré"), as well as for fabricated ones. The state continued to maintain the extensive camp system for a while after Stalin's death in March 1953, although the period saw the grip of the camp authorities weaken, and a number of conflicts and uprisings occur (*see* [Bitch Wars](https://en.wikipedia.org/wiki/Bitch_Wars "Bitch Wars"); [Kengir uprising](https://en.wikipedia.org/wiki/Kengir_uprising "Kengir uprising"); [Vorkuta uprising](https://en.wikipedia.org/wiki/Vorkuta_uprising "Vorkuta uprising")).

The [amnesty of 1953](https://en.wikipedia.org/wiki/Amnesty_of_1953 "Amnesty of 1953") was limited to non-political prisoners and for political prisoners sentenced to not more than 5 years, therefore mostly those convicted for common crimes were then freed. The release of political prisoners started in 1954 and became widespread, and also coupled with mass [rehabilitations](https://en.wikipedia.org/wiki/Rehabilitation_\(Soviet\) "Rehabilitation (Soviet)"), after [Nikita Khrushchev](https://en.wikipedia.org/wiki/Nikita_Khrushchev "Nikita Khrushchev") 's denunciation of [Stalinism](https://en.wikipedia.org/wiki/Stalinism "Stalinism") in his [Secret Speech](https://en.wikipedia.org/wiki/On_the_Cult_of_Personality_and_Its_Consequences "On the Cult of Personality and Its Consequences") at the 20th Congress of the [CPSU](https://en.wikipedia.org/wiki/Communist_Party_of_the_Soviet_Union "Communist Party of the Soviet Union") in February 1956.

The *Gulag* institution was closed in compliance with the MVD order Number 20 on 25 January 1960,[^61] but forced labor colonies for political and criminal prisoners continued to exist. Political prisoners continued to be kept in one of the most famous camps [Perm-36](https://en.wikipedia.org/wiki/Perm-36 "Perm-36") [^87] until 1987 when it was closed.[^88] Despite its reforms and despite a reduction in the size of the prison population, the Russian penal system informally or formally continues many of the practices which were endemic to the *Gulag* system, including the subjection of inmates to forced labor, the policing of inmates, and the intimidation of prisoners.[^20] In the late 2000s, some human rights activists accused the Russian authorities of gradually removing Gulag remembrance from places such as Perm-36 and the Solovki prison camp.[^89]

According to [Encyclopædia Britannica](https://en.wikipedia.org/wiki/Encyclop%C3%A6dia_Britannica "Encyclopædia Britannica"),

> At its height the Gulag consisted of many hundreds of camps, with the average camp holding 2,000–10,000 prisoners. Most of these camps were "corrective labour colonies" in which prisoners felled timber, laboured on general construction projects (such as the building of canals and railroads), or worked in mines. Most prisoners laboured under the threat of starvation or execution if they refused. It is estimated that the combination of very long working hours, harsh climatic and other working conditions, inadequate food, and summary executions killed tens of thousands of prisoners each year. Western scholarly estimates of the total number of deaths in the Gulag in the period from 1918 to 1956 ranged from 1.2 to 1.7 million.[^90]

## Death toll

A 1993 study of archival Soviet data estimates 1,053,829 people died in the Gulag from 1934 to 1953.[^10]<sup><span title="Page / location: 1024">: 1024</span> </sup> Mortality in Gulag camps in 1934–1940 was 4–6 times higher than average in the Soviet Union.[^91] [^92]

It was common practice to release prisoners who were either suffering from incurable diseases or near death,[^16] [^18] so a combined statistics on mortality *in the camps* and mortality *caused by the camps* was higher. The tentative historical consensus is that, of the 18 million people who passed through the Gulag from 1930 to 1953, between 1.6 million [^8] [^9] and 1.76 million [^93] perished as a result of their detention,[^7] and about half of all deaths occurred between 1941 and 1943 following the German invasion.[^93] [^94] [Timothy Snyder](https://en.wikipedia.org/wiki/Timothy_Snyder "Timothy Snyder") writes that "with the exception of the war years, a very large majority of people who entered the Gulag left alive".[^95] If prisoner deaths from labor colonies and special settlements are included, the death toll rises to 2,749,163, according to J. Otto Pohl's incomplete data.[^18] [^11]

In her 2018 study, Golfo Alexopoulos attempts to challenge this consensus figure by encompassing those whose life was shortened by the extreme conditions.[^7] Alexopoulos concludes that a systematic practice of the Gulag was to release sick prisoners on the verge of death; and that all prisoners who received the health classification "invalid", "light physical labor", "light individualised labor", or "physically defective" encompassed at least one third of all inmates who passed through the Gulag died or had their lives shortened due to detention in the Gulag in captivity or shortly after release.[^96] The mortality estimated in this way yields the figure of 6 million deaths.[^12] Historian Orlando Figes and Russian writer Vadim Erlikman have posited similar estimates.[^17] [^97] The estimate of Alexopoulos, however, has obvious methodological difficulties [^7] and is supported by misinterpreted evidence, such as presuming that hundreds of thousands of prisoners "directed to other places of detention" in 1948 was a euphemism for releasing prisoners on the verge of death into labor colonies, when it was really referring to internal transport in the Gulag rather than release.[^98]

In a University of Oxford doctoral dissertation, in 2020, the problem of medical release (*aktirovka*) and of mortality among "certified invalids" (*aktirovannye*) was considered in detail by Mikhail Nakonechnyi. He concludes that the number of terminally ill people discharged early on medical grounds from the Gulag was about 1 million. Mikhail adds 800,000–850,000 excess deaths to the death toll directly caused by the results of Gulag incarceration, which brings the death toll to 2.5 million people.[^99]

### Mortality rate

In 2009, [Steven Rosefielde](https://en.wikipedia.org/wiki/Steven_Rosefielde "Steven Rosefielde") stated more complete archival data increases camp deaths by 19.4 percent to 1,258,537, "the best archivally-based estimate of Gulag excess deaths at present is 1.6 million from 1929 to 1953." [^9] [Dan Healey](https://en.wikipedia.org/wiki/Dan_Healey "Dan Healey") in 2018 also stated the same thing "New studies using declassified Gulag archives have provisionally established a consensus on mortality and "inhumanity." The tentative consensus says that once secret records of the Gulag administration in Moscow show a lower death toll than expected from memoir sources, generally between 1.5 and 1.7 million (out of 18 million who passed through) between 1930 and 1953." [^100]

Certificates of death in the Gulag system for the period from 1930 to 1956 [^101]

| Year | Deaths | Mortality rate % |
| --- | --- | --- |
| 1930 | 7,980 | 4.20 |
| 1931 | 7,283 | 2.90 |
| 1932 | 13,197 | 4.80 |
| 1933 | 67,297 | 15.30 |
| 1934 | 25,187 | 4.28 |
| 1935 | 31,636 | 2.75 |
| 1936 | 24,993 | 2.11 |
| 1937 | 31,056 | 2.42 |
| 1938 | 108,654 | 5.35 |
| 1939 | 44,750 | 3.10 |
| 1940 | 41,275 | 2.72 |
| 1941 | 115,484 | 6.10 |
| 1942 | 352,560 | 24.90 |
| 1943 | 267,826 | 22.40 |
| 1944 | 114,481 | 9.20 |
| 1945 | 81,917 | 5.95 |
| 1946 | 30,715 | 2.20 |
| 1947 | 66,830 | 3.59 |
| 1948 | 50,659 | 2.28 |
| 1949 | 29,350 | 1.21 |
| 1950 | 24,511 | 0.95 |
| 1951 | 22,466 | 0.92 |
| 1952 | 20,643 | 0.84 |
| 1953 | 9,628 | 0.67 |
| 1954 | 8,358 | 0.69 |
| 1955 | 4,842 | 0.53 |
| 1956 | 3,164 | 0.40 |
| Total | 1,606,748 | 8.88 |

## Administrators

| Name | Years [^102] [^103] [^104] |
| --- | --- |
| [Feodor (Teodors) Ivanovich Eihmans](https://en.wikipedia.org/wiki/Teodors_Eihmans "Teodors Eihmans") | April 25, 1930 – June 16, 1930 |
| [Lazar Iosifovich Kogan](https://en.wikipedia.org/wiki/Lazar_Kogan "Lazar Kogan") | June 16, 1930 – June 9, 1932 |
| [Matvei Davidovich Berman](https://en.wikipedia.org/wiki/Matvei_Berman "Matvei Berman") | June 9, 1932 – August 16, 1937 |
| [Israel Israelevich Pliner](https://en.wikipedia.org/wiki/Israel_Pliner "Israel Pliner") | August 16, 1937 – November 16, 1938 |
| [Gleb Vasilievich Filaretov](https://en.wikipedia.org/wiki/Gleb_Filaretov?action=edit&redlink=1 "Gleb Filaretov (page does not exist)") | November 16, 1938 – February 18, 1939 |
| [Vasili Vasilievich Chernyshev](https://en.wikipedia.org/wiki/Vasili_Chernyshev?action=edit&redlink=1 "Vasili Chernyshev (page does not exist)") | February 18, 1939 – February 26, 1941 |
| [Victor Grigorievich Nasedkin](https://en.wikipedia.org/wiki/Victor_Nasedkin?action=edit&redlink=1 "Victor Nasedkin (page does not exist)") | February 26, 1941 – September 2, 1947 |
| [Georgy Prokopievich Dobrynin](https://en.wikipedia.org/wiki/Georgy_Dobrynin?action=edit&redlink=1 "Georgy Dobrynin (page does not exist)") | September 2, 1947 – January 31, 1951 |
| [Ivan Ilyich Dolgikh](https://en.wikipedia.org/wiki/Ivan_Ilyich_Dolgikh "Ivan Ilyich Dolgikh") | January 31, 1951 – October 5, 1954 |
| [Sergei Yegorovich Yegorov](https://en.wikipedia.org/wiki/Sergei_Yegorovich_Yegorov?action=edit&redlink=1 "Sergei Yegorovich Yegorov (page does not exist)") | October 5, 1954 – April 4, 1956 |

## Conditions

Living and working conditions in the camps varied significantly across time and place, depending, among other things, on the impact of broader events (World War II, countrywide [famines](https://en.wikipedia.org/wiki/Droughts_and_famines_in_Russia_and_the_USSR "Droughts and famines in Russia and the USSR") and shortages, waves of terror, sudden influx or release of large numbers of prisoners) and the type of crime committed. Instead of being used for economic gain, [political prisoners](https://en.wikipedia.org/wiki/Political_prisoner "Political prisoner") were typically given the worst work or were dumped into the less productive parts of the Gulag. For example, [Victor Herman](https://en.wikipedia.org/wiki/Victor_Herman "Victor Herman"), in his memoirs, compares the [Burepolom](https://en.wikipedia.org/wiki/Burepolom?action=edit&redlink=1 "Burepolom (page does not exist)") and the [Nuksha](https://en.wikipedia.org/wiki/Nuksha?action=edit&redlink=1 "Nuksha (page does not exist)") 2 camps, which were both near [Vyatka](https://en.wikipedia.org/wiki/Kirov,_Kirov_Oblast "Kirov, Kirov Oblast").[^105] [^106]

In Burepolom there were roughly 3,000 prisoners, all non-political, in the central compound. They could walk around at will, were lightly guarded, had unlocked barracks with mattresses and pillows, and watched western movies. However, Nuksha 2, which housed serious criminals and political prisoners, featured guard towers with machine guns and locked barracks.[^106] In some camps prisoners were only permitted to send one letter a year and were not allowed to have photos of loved ones.[^107]

Some prisoners were released early if they displayed good performance.[^106] There were several productive activities for prisoners in the camps. For example, in early 1935, a course in livestock raising was held for prisoners at a [state farm](https://en.wikipedia.org/wiki/Sovkhoz "Sovkhoz"); those who took it had their workday reduced to four hours.[^106] During that year, the professional theater group in the camp complex gave 230 performances of plays and concerts to over 115,000 spectators.[^106] Camp newspapers also existed.[^106]

[Andrei Vyshinsky](https://en.wikipedia.org/wiki/Andrei_Vyshinsky "Andrei Vyshinsky"), chief procurator of the Soviet Union, wrote a memorandum to [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD") chief [Nikolai Yezhov](https://en.wikipedia.org/wiki/Nikolai_Yezhov "Nikolai Yezhov") in 1938, during the [Great Purge](https://en.wikipedia.org/wiki/Great_Purge "Great Purge"), which stated:[^108]

> Among the prisoners there are some so ragged and lice-ridden that they pose a sanitary danger to the rest. These prisoners have deteriorated to the point of losing any resemblance to human beings. Lacking food...they collect orts \[refuse\] and, according to some prisoners, eat rats and dogs.

According to prisoner [Yevgenia Ginzburg](https://en.wikipedia.org/wiki/Yevgenia_Ginzburg "Yevgenia Ginzburg"), Gulag inmates could tell when Yezhov was no longer in charge as one day the conditions relaxed. A few days later, Beria's name appeared in official prison notices.[^109]

In general, the central administrative bodies showed a discernible interest in maintaining the labor force of prisoners in a condition allowing the fulfilment of construction and production plans handed down from above. Besides a wide array of punishments for prisoners refusing to work (which, in practice, were sometimes applied to prisoners that were too enfeebled to meet [production quota](https://en.wikipedia.org/wiki/Production_quota "Production quota")), they instituted a number of positive incentives intended to boost productivity. These included monetary bonuses (since the early 1930s) and wage payments (from 1950 onward), cuts of individual sentences, general early-release schemes for norm fulfilment and overfulfilment (until 1939, again in selected camps from 1946 onward), preferential treatment, sentence reduction and privileges for the most productive workers ([shock workers](https://en.wikipedia.org/wiki/Udarnik "Udarnik") or [Stakhanovites](https://en.wikipedia.org/wiki/Stakhanovite_movement "Stakhanovite movement") in Soviet parlance).[^110] [^106]

Inmates were used as camp guards and could purchase camp newspapers as well as [bonds](https://en.wikipedia.org/wiki/Bond_\(finance\) "Bond (finance)"). [Robert W. Thurston](https://en.wikipedia.org/wiki/Robert_W._Thurston "Robert W. Thurston") writes that this was "at least an indication that they were still regarded as participants in society to some degree." [^106] Sports teams, particularly [football](https://en.wikipedia.org/wiki/Soccer "Soccer") teams, were set up by the prison authorities.[^111]

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/8/88/Shack_from_Gulag_-_Museum_of_the_Occupation_of_Latvia.JPG/250px-Shack_from_Gulag_-_Museum_of_the_Occupation_of_Latvia.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

A shack in a prison camp – a reconstruction in the Museum of the Occupation of Latvia. The number of prisoners confined to each shack is not stated.

Boris Sulim, a former prisoner who had worked in the Omsuchkan camp, close to [Magadan](https://en.wikipedia.org/wiki/Magadan "Magadan"), when he was a teenager stated:[^112]

> I was 18 years old and Magadan seemed a very romantic place to me. I got 880 rubles a month and a 3,000 ruble installation grant, which was a hell of a lot of money for a kid like me. I was able to give my mother some of it. They even gave me membership in the Komsomol. There was a mining and ore-processing plant which sent out parties to dig for tin. I worked at the radio station which kept contact with the parties. \[...\] If the inmates were good and disciplined they had almost the same rights as the free workers. They were trusted and they even went to the movies. As for the reason they were in the camps, well, I never poked my nose into details. We all thought the people were there because they were guilty.

Immediately after the [German attack on the Soviet Union](https://en.wikipedia.org/wiki/Operation_Barbarossa "Operation Barbarossa") in June 1941, the conditions in camps worsened drastically: quotas were increased, rations cut, and medical supplies came close to none, all of which led to a sharp increase in mortality. The situation slowly improved in the final period and after the end of the war.

Considering the overall conditions and their influence on inmates, it is important to distinguish three major strata of Gulag inmates:

- *[Kulaks](https://en.wikipedia.org/wiki/Kulak "Kulak")*, *[osadniks](https://en.wikipedia.org/wiki/Osadnik "Osadnik")*, *[ukazniks](https://en.wikipedia.org/wiki/Ukaznik "Ukaznik")* (people sentenced for violation of various [ukases](https://en.wikipedia.org/wiki/Ukase "Ukase"), e.g. [Law of Spikelets](https://en.wikipedia.org/wiki/Law_of_Spikelets "Law of Spikelets"), decree about work discipline, etc.), occasional violators of [criminal law](https://en.wikipedia.org/wiki/Criminal_law "Criminal law")
- Dedicated criminals: " [thieves in law](https://en.wikipedia.org/wiki/Thieves_in_law "Thieves in law") "
- People sentenced for various [political](https://en.wikipedia.org/wiki/Political_prisoner "Political prisoner") and religious reasons.

### 1932–33 famine

The [Soviet famine of 1932–1933](https://en.wikipedia.org/wiki/Soviet_famine_of_1932%E2%80%931933 "Soviet famine of 1932–1933") swept across many different regions of the Soviet Union. During this time, it is estimated that around six to seven million people starved to death.[^113] On August 7, 1932, a new decree drafted by Stalin ([Law of Spikelets](https://en.wikipedia.org/wiki/Law_of_Spikelets "Law of Spikelets")) specified a minimum sentence of ten years or execution for theft from collective farms or of cooperative property. Over the next few months, prosecutions rose fourfold. A large share of cases prosecuted under the law were for the theft of small quantities of grain worth less than fifty rubles. The law was later relaxed on May 8, 1933.[^114] Overall, during the first half of 1933, prisons saw more new incoming inmates than the three previous years combined.

Prisoners in the camps faced harsh working conditions. One Soviet report stated that, in early 1933, up to 15% of the prison population in [Soviet Uzbekistan](https://en.wikipedia.org/wiki/Soviet_Uzbekistan "Soviet Uzbekistan") died monthly. During this time, prisoners were getting around 300 calories (1,300 kJ) worth of food a day. Many inmates attempted to flee, causing an upsurge in coercive and violent measures. Camps were directed "not to spare bullets".[^115]

### Social conditions

The convicts in such camps were actively involved in all kinds of labor with one of them being [logging](https://en.wikipedia.org/wiki/Logging "Logging"). The working territory of logging presented by itself a square and was surrounded by forest clearing. Thus, all attempts to exit or escape from it were well observed from the four towers set at each of its corners.

Locals who captured a [runaway](https://en.wikipedia.org/wiki/Fugitive "Fugitive") were given rewards.[^116] It is also said that camps in colder areas were less concerned with finding escaped prisoners as they would die anyhow from the severely cold winters. In such cases prisoners who did escape without getting shot were often found dead kilometres away from the camp.

## Geography

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/2/22/Talkessel_von_Werchojansk.JPG/250px-Talkessel_von_Werchojansk.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Siberian taiga in the river valley near Verkhoyansk. The lowest temperature recorded there was −68°C (−90°F).

![](https://en.wikipedia.org/wiki/File:Ru200008020027.jpg)

Part of 'Project 503' to build a railroad from Salekhard to Igarka near Turukhansk on the Yenisey

In the early days of the Gulag, the locations for the camps were chosen primarily for the isolated conditions involved. Remote monasteries, in particular, were frequently reused as sites for new camps. The site on the [Solovetsky Islands](https://en.wikipedia.org/wiki/Solovetsky_Islands "Solovetsky Islands") in the [White Sea](https://en.wikipedia.org/wiki/White_Sea "White Sea") is one of the earliest and also most noteworthy, taking root soon after the Revolution in 1918.[^21] The [colloquial](https://en.wikipedia.org/wiki/Colloquial "Colloquial") name for the islands, " [Solovki](https://en.wikipedia.org/wiki/Solovki_prison_camp "Solovki prison camp") ", entered the [vernacular](https://en.wikipedia.org/wiki/Vernacular "Vernacular") as a [synonym](https://en.wikipedia.org/wiki/Synonym "Synonym") for the labor camp in general. It was presented to the world as an example of the new Soviet method for "re-education of [class enemies](https://en.wikipedia.org/wiki/Class_enemy "Class enemy") " and reintegrating them through labor into Soviet society. Initially the inmates, largely Russian [intelligentsia](https://en.wikipedia.org/wiki/Intelligentsia "Intelligentsia"), enjoyed relative freedom within the natural confinement of the islands.[^117]

Local newspapers and magazines were published. Even some scientific research was carried out, e.g., a local botanical garden was maintained but unfortunately later lost completely. Eventually, Solovki turned into an ordinary Gulag camp. Some historians maintain that it was a pilot camp of this type. In 1929, [Maxim Gorky](https://en.wikipedia.org/wiki/Maxim_Gorky "Maxim Gorky") visited the camp and published an apology for it. The report of Gorky's trip to Solovki was included in the cycle of impressions titled "Po Soiuzu Sovetov", Part V, subtitled "Solovki." In the report, Gorky wrote that "camps such as 'Solovki' were absolutely necessary." [^117]

With the new emphasis on Gulag as the means of concentrating cheap labor, new camps were then constructed throughout the Soviet sphere of influence, wherever the economic task at hand dictated their existence, or was designed specifically to avail itself of them, such as the [White Sea–Baltic Canal](https://en.wikipedia.org/wiki/White_Sea%E2%80%93Baltic_Canal "White Sea–Baltic Canal") or the [Baikal–Amur Mainline](https://en.wikipedia.org/wiki/Baikal%E2%80%93Amur_Mainline "Baikal–Amur Mainline"), including facilities in big cities — parts of the famous [Moscow Metro](https://en.wikipedia.org/wiki/Moscow_Metro "Moscow Metro") and the [Moscow State University](https://en.wikipedia.org/wiki/Moscow_State_University "Moscow State University") new campus were built by forced labor. Many more projects during the rapid industrialisation of the 1930s, [war-time](https://en.wikipedia.org/wiki/World_War_II "World War II") and post-war periods were fulfilled on the backs of convicts. The activity of Gulag camps spanned a wide cross-section of Soviet industry. Gorky organized in 1933 a trip of 120 writers and artists to the White Sea–Baltic Canal, 36 of them wrote a propaganda book about the construction published in 1934 and destroyed in 1937.

The majority of Gulag camps were positioned in extremely remote areas of northeastern Siberia (the best known clusters are *[Sevvostlag](https://en.wikipedia.org/wiki/Sevvostlag "Sevvostlag")* (*The North-East Camps*) along [Kolyma](https://en.wikipedia.org/wiki/Kolyma "Kolyma") river and *[Norillag](https://en.wikipedia.org/wiki/Norillag "Norillag")* near [Norilsk](https://en.wikipedia.org/wiki/Norilsk "Norilsk")) and in the southeastern parts of the Soviet Union, mainly in the [steppes](https://en.wikipedia.org/wiki/Steppe "Steppe") of [Kazakhstan](https://en.wikipedia.org/wiki/Kazakhstan "Kazakhstan") (*[Luglag](https://en.wikipedia.org/wiki/Luglag?action=edit&redlink=1 "Luglag (page does not exist)")*, *[Steplag](https://en.wikipedia.org/wiki/Steplag "Steplag")*, *[Peschanlag](https://en.wikipedia.org/wiki/Peschanlag?action=edit&redlink=1 "Peschanlag (page does not exist)")*). A detailed map was made by the Memorial Foundation.[^118]

These were vast and sparsely inhabited regions with no roads or sources of food, but rich in minerals and other natural resources, such as timber. The construction of the roads was assigned to the inmates of specialised railway camps. Camps were generally spread throughout the entire Soviet Union, including the European parts of Russia, [Belarus](https://en.wikipedia.org/wiki/Belarus "Belarus"), and [Ukraine](https://en.wikipedia.org/wiki/Ukraine "Ukraine").

There were several camps outside the Soviet Union, in [Czechoslovakia](https://en.wikipedia.org/wiki/Czechoslovak_Socialist_Republic "Czechoslovak Socialist Republic"), [Hungary](https://en.wikipedia.org/wiki/Hungarian_People's_Republic "Hungarian People's Republic"), [Poland](https://en.wikipedia.org/wiki/Polish_People's_Republic "Polish People's Republic"), and [Mongolia](https://en.wikipedia.org/wiki/Mongolian_People's_Republic "Mongolian People's Republic"), which were under the direct control of the Gulag.

Throughout the [history of the Soviet Union](https://en.wikipedia.org/wiki/History_of_the_Soviet_Union "History of the Soviet Union"), there were at least 476 separate camp administrations.[^119] [^120] The Russian researcher Galina Ivanova stated that,[^120]

> to date, Russian historians have discovered and described 476 camps that existed at different times on the territory of the USSR. It is well known that practically every one of them had several branches, many of which were quite large. In addition to the large numbers of camps, there were no less than 2,000 colonies. It would be virtually impossible to reflect the entire mass of Gulag facilities on a map that would also account for the various times of their existence.

Since many of these existed only for short periods, the number of camp administrations at any given point was lower. It peaked in the early 1950s when there were more than 100 camp administrations across the Soviet Union. Most camp administrations oversaw several single camp units, some as many as dozens or even hundreds.[^121] The infamous complexes were those at [Kolyma](https://en.wikipedia.org/wiki/Kolyma "Kolyma"), [Norilsk](https://en.wikipedia.org/wiki/Norilsk "Norilsk"), and [Vorkuta](https://en.wikipedia.org/wiki/Vorkuta "Vorkuta"), all in arctic or subarctic regions. However, prisoner mortality in Norilsk in most periods was actually lower than across the camp system as a whole.[^122]

## Personnel

<table><tbody><tr><th></th><th colspan="2">Higher Operational Personnel</th><th colspan="3">Senior Operational Personnel</th><th colspan="3">Middle Operational Personnel</th><th colspan="2">Junior Operational Personnel</th><th colspan="1">Enlisted Personnel</th></tr><tr><th>Rank insignia 1936–1943</th><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D0%B2%D1%812.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D0%B2%D1%811.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%80%D1%813.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%80%D1%812.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%80%D1%811.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%813.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%812.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D1%81%D1%811.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D0%BC%D1%813.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D0%BC%D1%812.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td><td><figure><img src="https://en.wikipedia.org/wiki/File:%D0%93%D0%A3%D0%9B%D0%90%D0%931936%D0%BC%D1%81.png" height="162" width="50"><figcaption>петлица ГУЛАГ</figcaption></figure></td></tr><tr><td><b>Command category</b></td><td><b>3</b></td><td><b>4</b></td><td><b>5</b></td><td><b>6</b></td><td><b>7</b></td><td><b>8</b></td><td><b>9</b></td><td><b>10</b></td><td><b>11</b></td><td><b>12</b></td><td><i><b>None</b></i></td></tr><tr><th><i><a href="https://en.wikipedia.org/wiki/Military_ranks_of_the_Soviet_Union_(1935%E2%80%931940)">Rank equivalent</a></i></th><td><a href="https://en.wikipedia.org/wiki/Komdiv">Komdiv</a></td><td><a href="https://en.wikipedia.org/wiki/Kombrig">Kombrig</a></td><td>Colonel</td><td>Major</td><td>Captain</td><td>Senior Lieutenant</td><td>Lieutenant</td><td><a href="https://en.wikipedia.org/wiki/Starshina">Starshina</a></td><td>Junior Platoon Commander</td><td>Section Commander</td><td>Red Army Man</td></tr><tr><td><i><b>Source:</b></i> <sup><a href="#fn:123">123</a></sup></td></tr></tbody></table>

![](https://en.wikipedia.org/wiki/File:%D0%A4%D0%BE%D1%80%D0%BC%D0%B0_%D0%93%D0%A3%D0%9B%D0%90%D0%93_1936-1943.png)

Gulag personnel uniforms 1936–1943

Command Category 1 (head of the Gulag) was a Commissar of State Security of the 2nd class; Command Category 2 (deputy head of the Gulag) was a Commissar of State Security of the 3rd class. They wore the uniform and insignia of the [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD"). When the Gulag was transferred to the [NKGB](https://en.wikipedia.org/wiki/NKGB "NKGB") in 1943, the Gulag personnel began to use NKGB ranks and distinctions.

- 7 – Military personnel of the guard units wore a silver triangle on the collar.
- 9 – Technical-administrative and political personnel of the guard units wore a red triangle on the collar.
- 10 – Technical personnel wore crossed hammers and wrenches on the collar.

## Special institutions

- There were separate camps or zones within camps for juveniles (малолетки, *maloletki*), the disabled (in [Spassk](https://en.wikipedia.org/wiki/Spassk "Spassk")), and mothers (мамки, *mamki*) with babies.
- [Family members of "Traitors of the Motherland"](https://en.wikipedia.org/wiki/Traitor_of_Motherland_Family_Member "Traitor of Motherland Family Member") (ЧСИР, член семьи изменника Родины, *ChSIR, Chlyen sem'i izmennika Rodini*) were placed under a special category of repression.
- Secret research laboratories known as *[Sharashka](https://en.wikipedia.org/wiki/Sharashka "Sharashka")* (шарашка) held arrested and convicted scientists, some of them prominent, where they anonymously developed new technologies and also conducted basic research.

## Prisoner-of-war and internee affairs

During World War II, Soviet authorities established a parallel camp system managed by the [Main Administration for Affairs of Prisoners of War and Internees](https://en.wikipedia.org/wiki/Main_Administration_for_Affairs_of_Prisoners_of_War_and_Internees "Main Administration for Affairs of Prisoners of War and Internees") (Главное управление по делам военнопленных и интернированных, *Glavnoye upravleniye po delam voyennoplennyh i internirovannyh*, also known by the acronym GUPVI). A department of [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD") (later [MVD](https://en.wikipedia.org/wiki/Ministry_of_Internal_Affairs_\(Russia\) "Ministry of Internal Affairs (Russia)")), GUPVI was in charge of handling of foreign [civilian internees](https://en.wikipedia.org/wiki/Civilian_internee "Civilian internee") and [prisoners of war](https://en.wikipedia.org/wiki/Prisoner_of_war "Prisoner of war") from 1939 to 1953.[^124] According to Soviet estimates, in total, during the whole period of the existence of the GUPVI, there were over 500 POW camps (within the Soviet Union and abroad), which imprisoned over 4,000,000 POWs.[^125]

GUPVI's major function was the organization of [foreign forced labor in the Soviet Union](https://en.wikipedia.org/wiki/Foreign_forced_labor_in_the_Soviet_Union "Foreign forced labor in the Soviet Union"). The NKVD used a decade of GULAG experience to design the GUPVI system. Officials copied existing housing, feeding, and labor protocols; the top management of GUPVI came from the GULAG system. Still, differences separated the two networks. The NKVD ordered better treatment for German captives than for Soviet prisoners, keeping GUPVI camps out of remote, inhospitable regions. The Hague and Geneva Conventions shaped working conditions and food rations. Soviet officials followed these metrics to prevent foreign retaliation and protect global diplomacy, knowing that POWs would be eventually repatriated. Camp re-education focused on anti-fascist training, aiming to build a pro-Soviet Germany. However, postwar economic devastation meant reality rarely matched the central directives. The internees faced hard labor, poor nutrition and living conditions, and high mortality rate.[^126]

## Historiography

### Origins and functions of the Gulag

According to historian Stephen Barnes, the origins and functions of the Gulag can be looked at in four major ways:[^127]

- The first approach was championed by [Alexander Solzhenitsyn](https://en.wikipedia.org/wiki/Aleksandr_Solzhenitsyn "Aleksandr Solzhenitsyn"), and is what Barnes terms the **[moral explanation](https://en.wikipedia.org/wiki/Moral_explanation "Moral explanation")**. According to this view, Soviet ideology eliminated the moral checks on the darker side of human nature – providing convenient justifications for violence and evil-doing on all levels: from political decision-making to personal relations.
- Another approach is the **political explanation**, according to which the Gulag (along with executions) was primarily a means for eliminating the regime's perceived political enemies (this understanding is favoured by historian [Robert Conquest](https://en.wikipedia.org/wiki/Robert_Conquest "Robert Conquest"), amongst others).
- The **economic explanation**, in turn as set out by journalist Anne Applebaum, argues that the Soviet regime instrumentalised the Gulag for its economic development projects. Although never economically profitable, it was perceived as such right up to Stalin's death in 1953.
- Finally, Barnes advances his own, fourth explanation, which situates the Gulag in the context of modern projects of ' **cleansing** ' the social body of hostile elements, through spatial isolation and physical elimination of individuals defined as harmful.

[Hannah Arendt](https://en.wikipedia.org/wiki/Hannah_Arendt "Hannah Arendt") argues that as part of a [totalitarian](https://en.wikipedia.org/wiki/Totalitarian "Totalitarian") system of government, the camps of the Gulag system were experiments in "total domination." In her view, the goal of a totalitarian system was not merely to establish limits on liberty, but rather to abolish liberty entirely in service of its ideology. She argues that the Gulag system was not merely political repression because the system survived and grew long after Stalin had wiped out all serious political resistance. Although the various camps were initially filled with criminals and political prisoners, eventually they were filled with prisoners who were arrested irrespective of anything relating to them as individuals, but rather only on the basis of their membership in some ever shifting category of imagined threats to the state.[^128]<sup><span title="Page / location: 437–59">: 437–59</span></sup>

She also argues that the function of the Gulag system was not truly economic. Although the Soviet government deemed them all "forced labor" camps, this in fact highlighted that the work in the camps was deliberately pointless, since all Russian workers could be subject to forced labor.[^128]<sup><span title="Page / location: 444–5">: 444–5</span> </sup> The only real economic purpose they typically served was financing the cost of their own supervision. Otherwise the work performed was generally useless, either by design or made that way through extremely poor planning and execution; some workers even preferred more difficult work if it was actually productive. She differentiated between "authentic" forced-labor camps, concentration camps, and "annihilation camps".[^128]<sup><span title="Page / location: 444–5">: 444–5</span></sup>

In authentic labor camps, inmates worked in "relative freedom and are sentenced for limited periods." Concentration camps had extremely high mortality rates but were still "essentially organized for labor purposes." Annihilation camps were those where the inmates were "systematically wiped out through starvation and neglect." She criticizes other commentators' conclusion that the purpose of the camps was a supply of cheap labor. According to her, the Soviets were able to liquidate the camp system without serious economic consequences, showing that the camps were not an important source of labor and were overall economically irrelevant.[^128]<sup><span title="Page / location: 444–5">: 444–5</span></sup>

Arendt argues that together with the systematized, arbitrary cruelty inside the camps, this served the purpose of total domination by eliminating the idea that the arrestees had any political or legal rights. Morality was destroyed by maximizing cruelty and organizing the camps internally to make the inmates and guards complicit. The terror which resulted from the operation of the Gulag system caused people outside the camps to cut all ties with anyone who was arrested or purged and it also caused them to avoid forming ties with others for fear of being associated with anyone who was targeted. As a result, the camps were essential as the nucleus of a system that destroyed individuality and dissolved all social bonds. Thereby, the system attempted to eliminate any capacity for resistance or self-directed action in the greater population.[^128]<sup><span title="Page / location: 437–59">: 437–59</span></sup>

### Archival documents

Statistical reports compiled by the [OGPU](https://en.wikipedia.org/wiki/OGPU "OGPU") – [NKVD](https://en.wikipedia.org/wiki/NKVD "NKVD") – [MGB](https://en.wikipedia.org/wiki/Ministry_for_State_Security_\(USSR\) "Ministry for State Security (USSR)") – [MVD](https://en.wikipedia.org/wiki/Ministry_of_Internal_Affairs_\(Soviet_Union\) "Ministry of Internal Affairs (Soviet Union)") between the 1930s and the 1950s are kept in the [State Archive of the Russian Federation](https://en.wikipedia.org/wiki/State_Archive_of_the_Russian_Federation "State Archive of the Russian Federation") formerly called the Central State Archive of the October Revolution (CSAOR). These documents were highly classified and inaccessible. Amid [glasnost](https://en.wikipedia.org/wiki/Glasnost "Glasnost") and [democratization](https://en.wikipedia.org/wiki/Democratization "Democratization") in the late 1980s, [Viktor Zemskov](https://en.wikipedia.org/wiki/Viktor_Zemskov "Viktor Zemskov") and other Russian researchers managed to gain access to the documents and published the highly classified statistical data collected by the OGPU-NKVD-MGB-MVD and related to the number of the Gulag prisoners, special settlers, etc. In 1995, Zemskov wrote that foreign scientists have begun to be admitted to the restricted-access collection of these documents in the State Archive of the Russian Federation since 1992.[^129] However, only one historian, namely Zemskov, was admitted to these archives, and later the archives were again "closed", according to Leonid Lopatnikov.[^130] Pressure from the [Putin administration](https://en.wikipedia.org/wiki/Putin_administration "Putin administration") has exacerbated the difficulties of Gulag researchers.[^131]

While considering the issue of the reliability of the primary data which was provided by corrective labor institutions, it is necessary to take the following two circumstances into account. On the one hand, their administration was not interested in understating the number of prisoners in its reports, because it would have automatically led to a decrease in the food supply plan for camps, prisons, and corrective labor colonies. The decrement in food would have been accompanied by an increase in mortality that would have led to wrecking of the vast production program of the Gulag. On the other hand, overstatement of data of the number of prisoners also did not comply with departmental interests, because it was fraught with the same (i.e., impossible) increase in production tasks set by planning bodies. In those days, people were highly responsible for non-fulfilment of plan. It seems that a resultant of these objective departmental interests was a sufficient degree of reliability of the reports.[^132]

Between 1990 and 1992, the first collection of precise statistical data on the Gulag based on the Gulag archives was published by [Viktor Zemskov](https://en.wikipedia.org/wiki/Viktor_Zemskov "Viktor Zemskov").[^133] These had been generally accepted by leading Western scholars,[^27] [^16] despite the fact that a number of inconsistencies were found in this statistics.[^134] Not all the conclusions drawn by Zemskov based on his data have been generally accepted. Thus, Sergei Maksudov alleged that although literary sources, for example the books of [Lev Razgon](https://en.wikipedia.org/wiki/Lev_Razgon "Lev Razgon") or [Aleksandr Solzhenitsyn](https://en.wikipedia.org/wiki/Aleksandr_Solzhenitsyn "Aleksandr Solzhenitsyn"), did not envisage the total number of the camps very well and markedly exaggerated their size. On the other hand, Viktor Zemskov, who published many documents by the NKVD and [KGB](https://en.wikipedia.org/wiki/KGB "KGB"), was far from understanding of the Gulag essence and the nature of socio-political processes in the country. He added that without distinguishing the degree of accuracy and reliability of certain figures, without making a critical analysis of sources, without comparing new data with already known information, Zemskov absolutizes the published materials by presenting them as the ultimate truth. As a result, Maksudov charges that Zemskov's attempts to make generalized statements with reference to a particular document, as a rule, do not hold water.[^135]

![](https://en.wikipedia.org/wiki/File:Frenkel2.jpg)

OGPU chiefs responsible for construction of the White Sea–Baltic Canal, 1932: right: Frenkel; center: Berman; left: Afanasyev (Head of the southern part of Belbaltlag )

In response, Zemskov wrote that the charge that he allegedly did not compare new data with already known information could not be called fair. In his words, the trouble with most western writers is that they do not benefit from such comparisons. Zemskov added that when he tried not to overuse the juxtaposition of new information with "old" one, it was only because of a sense of delicacy, not to once again psychologically traumatize the researchers whose works used incorrect figures, as it turned out after the publication of the statistics by the OGPU-NKVD-MGB-MVD.[^129]

According to French historian [Nicolas Werth](https://en.wikipedia.org/wiki/Nicolas_Werth "Nicolas Werth"), the mountains of the materials of the Gulag archives, which are stored in funds of the [State Archive of the Russian Federation](https://en.wikipedia.org/wiki/State_Archive_of_the_Russian_Federation "State Archive of the Russian Federation") and were being constantly exposed during the last fifteen years, represent only a very small part of bureaucratic prose of immense size left over after the decades of "creativity" by the "dull and reptile" organization managing the Gulag. In many cases, local camp archives, which had been stored in sheds, barracks, or other rapidly disintegrating buildings, simply disappeared in the same way as most of the camp buildings did.[^136]

In 2004 and 2005, some archival documents were published in the edition *Istoriya Stalinskogo Gulaga. Konets 1920-kh — Pervaya Polovina 1950-kh Godov. Sobranie Dokumentov v 7 Tomakh* (*The History of Stalin's Gulag. From the Late 1920s to the First Half of the 1950s. Collection of Documents in Seven Volumes*), wherein each of its seven volumes covered a particular issue indicated in the title of the volume:

1. *Mass Repression in the USSR* (*Massovye Repressii v SSSR*);[^137]
2. *Punitive System. Structure and Cadres* (*Karatelnaya Sistema. Struktura i Kadry*);[^138]
3. *Economy of the Gulag* (*Ekonomika Gulaga*);[^139]
4. *The Population of the Gulag. The Number and Conditions of Confinement* (*Naselenie Gulaga. Chislennost i Usloviya Soderzhaniya*);[^140]
5. *Specsettlers in the USSR* (*Specpereselentsy v SSSR*);[^141]
6. *Uprisings, Riots, and Strikes of Prisoners* (*Vosstaniya, Bunty i Zabastovki Zaklyuchyonnykh*);[^142] and
7. *Soviet Repressive and Punitive Policy. Annotated Index of Cases of the SA RF* (*Sovetskaya Pepressivno-karatelnaya Politika i Penitentsiarnaya Sistema. Annotirovanniy Ukazatel Del GA RF*).[^143]

The edition contains the brief introductions by the two "patriarchs of the Gulag science", [Robert Conquest](https://en.wikipedia.org/wiki/Robert_Conquest "Robert Conquest") and [Aleksandr Solzhenitsyn](https://en.wikipedia.org/wiki/Aleksandr_Solzhenitsyn "Aleksandr Solzhenitsyn"), and 1,431 documents, the overwhelming majority of which were obtained from funds of the State Archive of the Russian Federation.[^144]

### Population estimates

During the decades before the [dissolution of the USSR](https://en.wikipedia.org/wiki/Dissolution_of_the_Soviet_Union "Dissolution of the Soviet Union"), the debates about the size of the population of the Gulag failed to arrive at generally accepted figures; wide-ranging estimates have been offered,[^145] and the bias toward higher or lower side was sometimes ascribed to political views of the particular author.[^145] Some of those earlier estimates (both high and low) are shown in the table below.

<table><caption>Historical estimates of the Gulag population size (in chronological order)</caption><tbody><tr><td><b>Gulag population</b></td><td><b>Year the estimate was made for</b></td><td><b>Source</b></td><td><b>Methodology</b></td></tr><tr><td>2.3 million</td><td>December 1937</td><td>Timasheff (1948) <sup><a href="#fn:146">146</a></sup></td><td>Calculation of disenfranchised population</td></tr><tr><td>5.5–9.5 million</td><td>late 1938</td><td>Conquest (1991) <sup><a href="#fn:147">147</a></sup></td><td>1937 Census figures, arrest and deaths<br>estimates, variety of personal and literary sources.<sup><a href="#endnote_ros_note">a</a></sup></td></tr><tr><td>4–5 million</td><td>1939</td><td>Wheatcroft (1981) <sup><a href="#fn:148">148</a></sup></td><td>Analysis of demographic data.<sup><a href="#endnote_ros_note">a</a></sup></td></tr><tr><td>15 million</td><td>1940–42</td><td>Mora & Zwiernag (1945) <sup><a href="#fn:149">149</a></sup></td><td>–</td></tr><tr><td>Up to 3.5 million</td><td>1941</td><td>Jasny (1951) <sup><a href="#fn:150">150</a></sup></td><td>Analysis of the output of the Soviet enterprises run by NKVD</td></tr><tr><td>10.6 million</td><td>1941</td><td>Rosefielde (1981) <sup><a href="#fn:151">151</a></sup></td><td>Based on data of Mora & Zwiernak and annual mortality.<sup><a href="#endnote_ros_note">a</a></sup></td></tr><tr><td>17.6 million</td><td>1942</td><td><a href="https://en.wikipedia.org/wiki/Anton_Antonov-Ovseenko">Anton Antonov-Ovseenko</a> (1999) <sup><a href="#fn:152">152</a></sup></td><td><a href="https://en.wikipedia.org/wiki/NKVD">NKVD</a> documents <sup><a href="#fn:153">153</a></sup></td></tr><tr><td>50 million</td><td>total number of persons who<br>passed through Gulag</td><td>Solzhenitsyn (1975) <sup><a href="#fn:154">154</a></sup></td><td>Analysis of various indirect data,<br>including own experience and testimonies of numerous witnesses</td></tr><tr><td>4–5 million</td><td>every single year</td><td>Volkogonov (1990s) <sup><a href="#fn:155">155</a></sup></td><td></td></tr><tr><td colspan="6">a.<b><a href="#ref_ros_note">^</a></b> <i>Note: Later numbers from Rosefielde, Wheatcroft and Conquest were revised down by the authors themselves.</i><sup><a href="#fn:27">27</a></sup> <sup><a href="#fn:67">67</a></sup></td></tr></tbody></table>

The [glasnost](https://en.wikipedia.org/wiki/Glasnost "Glasnost") political reforms in the late 1980s and the subsequent dissolution of the USSR, led to the release of a large amount of formerly classified archival documents [^156] including new demographic and NKVD data.[^16] Analysis of the official Gulag statistics by Western scholars immediately demonstrated that, despite their inconsistency, they do not support previously published higher estimates.[^145] Importantly, the released documents made possible to clarify terminology used to describe different categories of forced labor population, because the use of the terms "forced labor", "GULAG", "camps" interchangeably by early researchers led to significant confusion and resulted in significant inconsistencies in the earlier estimates.[^145]

Archival studies revealed several components of the NKVD penal system in the Stalinist USSR: prisons, labor camps, labor colonies, as well as various "settlements" (exile) and of non-custodial forced labor.[^10] Although most of them fit the definition of forced labor, only labor camps, and labor colonies were associated with punitive forced labor in detention.[^10] Forced labor camps ("Gulag camps") were hard regime camps, whose inmates were serving more than three-year terms. As a rule, they were situated in remote parts of the USSR, and labor conditions were extremely hard there. They formed a core of the Gulag system. The inmates of "corrective labor colonies" served shorter terms; these colonies were located in less remote parts of the USSR, and they were run by local NKVD administration.[^10]

Preliminary analysis of the Gulag camps and colonies statistics (see the chart on the right) demonstrated that the population reached the maximum before World War II, then dropped sharply, partially due to massive releases, partially due to wartime high mortality, and then was gradually increasing until the end of the Stalin era, reaching the global maximum in 1953, when the combined population of Gulag camps and labor colonies amounted to 2,625,000.[^157]

The results of these archival studies convinced many scholars, including [Robert Conquest](https://en.wikipedia.org/wiki/Robert_Conquest "Robert Conquest") [^27] or [Stephen Wheatcroft](https://en.wikipedia.org/wiki/Stephen_Wheatcroft "Stephen Wheatcroft") to reconsider their earlier estimates of the size of the Gulag population, although the 'high numbers' of arrested and deaths are not radically different from earlier estimates.[^27] Although such scholars as Rosefielde or Vishnevsky point at several inconsistencies in archival data with Rosefielde pointing out the archival figure of 1,196,369 for the population of the Gulag and labor colonies combined on December 31, 1936, is less than half the 2.75 million labor camp population given to the Census Board by the NKVD for the 1937 census,[^158] [^134] it is generally believed that these data provide more reliable and detailed information that the indirect data and literary sources available for the scholars during the Cold War era.[^16] Although Conquest cited Beria's report to the Politburo of the labor camp numbers at the end of 1938 stating there were almost 7 million prisoners in the labor camps, more than three times the archival figure for 1938 and an official report to Stalin by the Soviet minister of State Security in 1952 stating there were 12 million prisoners in the labor camps.[^159]

These data allowed scholars to conclude that during the period of 1928–53, about 14 million prisoners passed through the system of Gulag *labor camps* and 4–5 million passed through the *labor colonies*.[^27] Thus, these figures reflect the number of convicted persons, and do not take into account the fact that a significant part of Gulag inmates had been convicted more than one time, so the actual number of convicted is somewhat overstated by these statistics.[^16] On the other hand, during some periods of Gulag history the official figures of Gulag population reflected the camps' capacity, not the actual number of inmates, so the figures were inflated by 15%, e.g. 1946.[^27]

The USSR implemented a number of labor disciplinary measures, due to the lack of productivity of its labour force in the early 1930s. 1.8 million workers were sentenced to 6 months in forced labor with a quarter of their original pay, 3.3 million faced sanctions, and 60k were imprisoned for absentees in 1940 alone. The conditions of Soviet workers worsened in WW2 as 1.3 million were punished in 1942, and 1 million each were punished in subsequent 1943 and 1944 with the reduction of 25% of food rations. Further more, 460 thousand were imprisoned throughout these years.[^160]

## Impact

### Colonization

![](https://en.wikipedia.org/wiki/File:Vorkuta_r.jpg)

The city of Vorkuta

Soviet [state documents](https://en.wikisource.org/wiki/%D0%9E%D0%B1%20%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B8%20%D1%82%D1%80%D1%83%D0%B4%D0%B0%20%D1%83%D0%B3%D0%BE%D0%BB%D0%BE%D0%B2%D0%BD%D0%BE-%D0%B7%D0%B0%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%BD%D1%8B%D1%85 "wikisource:Об использовании труда уголовно-заключенных") show that the goals of the Gulag included colonization of sparsely populated remote areas and exploiting its resources using forced labor. In 1929, OGPU was given the task to colonize these areas.[^161] To this end, the notion of " [free settlement](https://en.wikipedia.org/wiki/Free_settlement "Free settlement") " was introduced. On 12 April 1930, [Genrikh Yagoda](https://en.wikipedia.org/wiki/Genrikh_Yagoda "Genrikh Yagoda") wrote to the OGPU Commission:

> The camps must be transformed into colonizing settlements, without waiting for the end of periods of confinement... Here is my plan: to turn all the prisoners into a settler population until they have served their sentences.[^161]

When well-behaved persons had served the majority of their terms, they could be released for "free settlement" (вольное поселение, *volnoye poseleniye*) outside the confinement of the camp. They were known as "free settlers" (вольнопоселенцы, *volnoposelentsy*; not to be confused with the term ссыльнопоселенцы, *ssyl'noposelentsy*, " [exile settlers](https://en.wikipedia.org/wiki/Involuntary_settlements_in_the_Soviet_Union "Involuntary settlements in the Soviet Union") "). In addition, for persons who served full term, but who were denied the free choice of place of residence, it was recommended to assign them for "free settlement" and give them land in the general vicinity of the place of confinement. The Gulag inherited this approach from the katorga system. It is estimated that of the 40,000 people collecting state pensions in [Vorkuta](https://en.wikipedia.org/wiki/Vorkuta_Gulag "Vorkuta Gulag"), 32,000 are trapped former Gulag inmates, or their descendants.[^162]

### Economics

According to a 2024 study, areas near Gulag camps that held a larger share of educated elites among its prisoner population have subsequently been characterized by greater economic growth.[^163] According to the authors, it demonstrates long-run persistence of human capital across generations.[^163]

### Life after a term was served

Former camp and prison inmates often encountered discrimination in employment and remained subject to surveillance after their release.[^164] [^165] Political prisoners in particular attracted heightened attention from security organs and workplace security departments, which monitored former inmates and other individuals deemed politically suspect.[^164] [^166]

Many released Gulag prisoners, particularly those convicted on political charges, were prohibited from returning to major cities and instead subjected to administrative exile in remote regions.[^167] [^168]

## Memorials

![](https://en.wikipedia.org/wiki/File:Gulag_ALZHIR_in_Astana,_Kazakhstan,_Monument_to_the_victims_03.jpg)

Memorial in Astana, Kazakhstan, dedicated to the Akmola Female Labor Camp prisoners

![](https://en.wikipedia.org/wiki/File:State_Museum_of_Gulag_History_(2017-12-12)_-_59.jpg)

Map of Gulag camps in Gulag Museum in Moscow

![](https://en.wikipedia.org/wiki/File:GulagMemorial.jpg)

Memorial in St. Petersburg

Both Moscow and St. Petersburg have memorials to the victims of the Gulag made of boulders from the Solovki camp. Moscow's memorial is on [Lubyanka Square](https://en.wikipedia.org/wiki/Lubyanka_Square "Lubyanka Square"), the site of the headquarters of the NKVD. People gather at these memorials every year on the [Day of Victims of the Repression (October 30)](https://en.wikipedia.org/wiki/Day_of_Remembrance_of_the_Victims_of_Political_Repressions "Day of Remembrance of the Victims of Political Repressions").

![](https://en.wikipedia.org/wiki/File:GULag_2_Museum_Moscow_Russia.jpg)

Gulag Museum in Moscow, founded in 2001 by historian Anton Antonov-Ovseyenko

Gulag survivor [Anton Antonov-Ovseyenko](https://en.wikipedia.org/wiki/Anton_Antonov-Ovseyenko "Anton Antonov-Ovseyenko") was the first director of the State Gulag Museum in Moscow.[^169] [^170] [^171] [^172]

In 2015, the [Gulag History Museum](https://en.wikipedia.org/wiki/Gulag_History_Museum?action=edit&redlink=1 "Gulag History Museum (page does not exist)") was opened in Moscow.[^173] In November 2024, the museum was ordered to close for an indefinite period due to alleged "fire safety violations" after its director reportedly refused to censor its exhibits.[^174] On December 13, 2025 Romanov was dismissed and his position was assigned to Anna Trapkova, director of the [Museum of Moscow](https://en.wikipedia.org/wiki/Museum_of_Moscow "Museum of Moscow").[^175] At the same time, the section about Stalinist repressions was removed from the Museum of Moscow.. In February 2026, it was announced that it will be replaced with the Museum of Remembrance of the Victims of [Genocide of the Soviet People](https://en.wikipedia.org/wiki/Genocide_of_the_Soviet_People "Genocide of the Soviet People").[^176]

[^1]: Based on data from [Memorial](https://en.wikipedia.org/wiki/Memorial_\(society\) "Memorial (society)"), a [human-rights group](https://en.wikipedia.org/wiki/Human_rights_group "Human rights group").

[^2]: Some disputed [^7] estimates range from over 2.7 [^11] to 6 [^12] million.[^7]

[^3]: [/ ˈ ɡ uː l ɑː ɡ /](https://en.wikipedia.org/wiki/Help:IPA/English "Help:IPA/English"), [UK](https://en.wikipedia.org/wiki/British_English "British English") also [/- l æ ɡ /](https://en.wikipedia.org/wiki/Help:IPA/English "Help:IPA/English"); Russian: [\[ɡʊˈlak\]](https://en.wikipedia.org/wiki/Help:IPA/Russian "Help:IPA/Russian") .[^13] Also spelled **GULAG**, or **GULag**.

[^4]: ГУЛАГ, ГУЛаг, an [acronym](https://en.wikipedia.org/wiki/Acronym "Acronym") for Глaвное управлeние лагерeй Russian pronunciation: [\[ɡɫavnəjə ʊprɐˈvlʲenʲɪje ɫəɡʲɪˈrʲej\]](https://en.wikipedia.org/wiki/Help:IPA/Russian "Help:IPA/Russian"), *Glavnoye upravleniye lagerey*, "chief administration of the camps". The original name given to the system of camps controlled by the [GPU](https://en.wikipedia.org/wiki/State_Political_Directorate "State Political Directorate") was the **Main Administration of [Correctional Labor Camps](https://en.wikipedia.org/wiki/Correctional_labour_camp "Correctional labour camp")** (Главное управление исправительно-трудовых лагерей, Russian pronunciation: [\[ˈɡɫavnəjə ʊprɐˈvlʲenʲɪje ɪsprɐˈvʲitʲɪlʲnə trʊdɐˈvɨx ɫəɡʲɪˈrʲej\]](https://en.wikipedia.org/wiki/Help:IPA/Russian "Help:IPA/Russian") *Glavnoje upravlenije ispraviteljno-trudovyh lagerej*).

[^5]: Including those who died in custody.

[^6]: *Special contingent*

[^7]: [Healey, Dan](https://en.wikipedia.org/wiki/Dan_Healey "Dan Healey") (June 1, 2018). ["GOLFO ALEXOPOULOS. Illness and Inhumanity in Stalin's Gulag"](https://www.deepdyve.com/lp/ou_press/golfo-alexopoulos-illness-and-inhumanity-in-stalin-s-gulag-i363rKPYOp). *[The American Historical Review](https://en.wikipedia.org/wiki/The_American_Historical_Review "The American Historical Review")*. **123** (3): 1049–1051. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1093/ahr/123.3.1049](https://doi.org/10.1093%2Fahr%2F123.3.1049). New studies using declassified Gulag archives have provisionally established a consensus on mortality and "inhumanity." The tentative consensus says that once secret records of the Gulag administration in Moscow show a lower death toll than expected from memoir sources, generally between 1.5 and 1.7 million (out of 18 million who passed through) for the years from 1930 to 1953.

[^8]: Wheatcroft, Stephen G. (1999). ["Victims of Stalinism and the Soviet Secret Police: The Comparability and Reliability of the Archival Data. Not the Last Word"](https://web.archive.org/web/20191206042326/http://sovietinfo.tripod.com/WCR-Secret_Police.pdf) (PDF). *[Europe-Asia Studies](https://en.wikipedia.org/wiki/Europe-Asia_Studies "Europe-Asia Studies")*. **51** (2): 320. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/09668139999056](https://doi.org/10.1080%2F09668139999056). Archived from [the original](http://sovietinfo.tripod.com/WCR-Secret_Police.pdf) (PDF) on December 6, 2019. Retrieved February 14, 2018.

[^9]: [Rosefielde, Steven](https://en.wikipedia.org/wiki/Steven_Rosefielde "Steven Rosefielde"). 2009. *[Red Holocaust](https://en.wikipedia.org/wiki/Red_Holocaust_\(2009_book\) "Red Holocaust (2009 book)").* [Routledge](https://en.wikipedia.org/wiki/Routledge "Routledge"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-415-77757-7](https://en.wikipedia.org/wiki/Special:BookSources/0-415-77757-7 "Special:BookSources/0-415-77757-7"). p. 67 "...more complete archival data increases camp deaths by 19.4 percent to 1,258,537"; pg 77: "The best archivally-based estimate of Gulag excess deaths at present is 1.6 million from 1929 to 1953."

[^10]: Getty, Arch; Rittersporn, Gábor; Zemskov, Viktor (October 1993). ["Victims of the Soviet penal system in the pre-war years: a first approach on the basis of archival evidence"](https://web.archive.org/web/20191206042327/http://sovietinfo.tripod.com/GTY-Penal_System.pdf) (PDF). *[American Historical Review](https://en.wikipedia.org/wiki/American_Historical_Review "American Historical Review")*. **98** (4): 1017–1049. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2166597](https://doi.org/10.2307%2F2166597). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2166597](https://www.jstor.org/stable/2166597). Archived from [the original](http://sovietinfo.tripod.com/GTY-Penal_System.pdf) (PDF) on December 6, 2019. Retrieved April 10, 2016.

[^11]: Pohl, *The Stalinist Penal System*, p. 131.

[^12]: Alexopoulos, Golfo (2017). *Illness and Inhumanity in Stalin's Gulag*. Yale University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-300-17941-5](https://en.wikipedia.org/wiki/Special:BookSources/978-0-300-17941-5 "Special:BookSources/978-0-300-17941-5").

[^13]: Applebaum, Anne. *Gulag: A History*. Doubleday, 2003, pp. 50.

[^14]: " [Introduction: Stalin's Gulag](http://gulaghistory.org/nps/onlineexhibit/stalin/)." *GULAG: Soviet Labor Camps and the Struggle for Freedom*. US: [Center for History and New Media](https://en.wikipedia.org/wiki/Roy_Rosenzweig_Center_for_History_and_New_Media "Roy Rosenzweig Center for History and New Media"), [George Mason University](https://en.wikipedia.org/wiki/George_Mason_University "George Mason University"). Retrieved June 23, 2020.

[^15]: " [Gulag](https://www.history.com/topics/russia/gulag)." *[History.com](https://en.wikipedia.org/wiki/History.com "History.com")*. [A&E Networks](https://en.wikipedia.org/wiki/A&E_Networks "A&E Networks"). 2018. Retrieved June 23, 2020.

[^16]: Michael Ellman. [Soviet Repression Statistics: Some Comments.](http://sovietinfo.tripod.com/ELM-Repression_Statistics.pdf) [Archived](https://web.archive.org/web/20190525134942/http://sovietinfo.tripod.com/ELM-Repression_Statistics.pdf) May 25, 2019, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") *Europe-Asia Studies*, Vol. 54, No. 7 (Nov. 2002), pp. 1151–1172

[^17]: Figes, Orlando (2009). ["Ученый: при Сталине погибло больше, чем в холокост"](https://www.bbc.com/russian/international/2009/10/091023_figes_int). *BBC News*. Хотя даже по самым консервативным оценкам, от 20 до 25 млн человек стали жертвами репрессий, из которых, возможно, от пяти до шести миллионов погибли в результате пребывания в ГУЛАГе. Translation: 'The most conservative calculations speak of 20–25 million victims of repression, 5 to 6 million of whom died in the Gulag.'

[^18]: [Applebaum, Anne](https://en.wikipedia.org/wiki/Anne_Applebaum "Anne Applebaum") (2003) *[Gulag: A History](https://en.wikipedia.org/wiki/Gulag:_A_History "Gulag: A History").* [Doubleday](https://en.wikipedia.org/wiki/Doubleday_\(publisher\) "Doubleday (publisher)"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-7679-0056-1](https://en.wikipedia.org/wiki/Special:BookSources/0-7679-0056-1 "Special:BookSources/0-7679-0056-1") pg 583: "both archives and memoirs indicate that it was a common practice in many camps to release prisoners who were on the point of dying, thereby lowering camp death statistics."

[^19]: Смирнов, М.Б. (1998). *Система Исправительно-трудовьх лагерей в СССР*. Moscow: Звенья. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-7870-0022-6](https://en.wikipedia.org/wiki/Special:BookSources/5-7870-0022-6 "Special:BookSources/5-7870-0022-6").

[^20]: ["Slave labour and criminal cultures"](https://www.economist.com/news/europe/21588130-russias-prison-colonies-resemble-old-soviet-camps-slave-labour-and-criminal-cultures). *The Economist*. October 19, 2013.

[^21]: [Applebaum, Anne](https://en.wikipedia.org/wiki/Anne_Applebaum "Anne Applebaum") (2003) *[Gulag: A History](https://en.wikipedia.org/wiki/Gulag:_A_History "Gulag: A History")*. [Doubleday](https://en.wikipedia.org/wiki/Doubleday_\(publisher\) "Doubleday (publisher)"). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-7679-0056-1](https://en.wikipedia.org/wiki/Special:BookSources/0-7679-0056-1 "Special:BookSources/0-7679-0056-1")

[^22]: ["Gulag: a History of the Soviet Camps"](http://www.arlindo-correia.org/041003.html). Arlindo-correia.org. Retrieved January 6, 2009.

[^23]: [ГЛАВНОЕ УПРАВЛЕНИЕ ЛАГЕРЕЙ ОГПУ–НКВД–МВД](http://old.memo.ru/history/nkvd/gulag/r1/r1-4.htm) [Archived](https://web.archive.org/web/20220920094012/http://old.memo.ru/history/nkvd/gulag/r1/r1-4.htm) September 20, 2022, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), a section from "Система исправительно-трудовых лагерей в СССР", Moscow, 1998, [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-7870-0022-6](https://en.wikipedia.org/wiki/Special:BookSources/5-7870-0022-6 "Special:BookSources/5-7870-0022-6")

[^24]: Applebaum, Anne. ["GULAG: a history"](https://web.archive.org/web/20071013124127/http://anneapplebaum.com/gulag/intro.html). Archived from [the original](http://www.anneapplebaum.com/gulag/intro.html) on October 13, 2007. Retrieved December 21, 2007.

[^25]: ["The Hidden Gulag – Exposing North Korea's Prison Camps"](https://www.hrnk.org/uploads/pdfs/HRNK_HiddenGulag2_Web_5-18.pdf) (PDF). *The Committee for Human Rights in North Korea*. [Archived](https://web.archive.org/web/20121021061756/http://www.hrnk.org/uploads/pdfs/HRNK_HiddenGulag2_Web_5-18.pdf) (PDF) from the original on October 21, 2012. Retrieved September 20, 2012.

[^26]: Barnett, Antony (February 1, 2004). ["Revealed: the gas chamber horror of North Korea's Gulag"](https://www.theguardian.com/korea/article/0,2763,1136483,00.html#article_continue). *Guardian Unlimited*. London. Retrieved December 21, 2007.

[^27]: [Conquest, Robert](https://en.wikipedia.org/wiki/Robert_Conquest "Robert Conquest"). 1997. " [Victims of Stalinism: A Comment](http://sovietinfo.tripod.com/CNQ-Victims_Stalinism.pdf) [Archived](https://web.archive.org/web/20110927152248/http://sovietinfo.tripod.com/CNQ-Victims_Stalinism.pdf) September 27, 2011, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")." *[Europe-Asia Studies](https://en.wikipedia.org/wiki/Europe-Asia_Studies "Europe-Asia Studies")* 49(7):1317–19, [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [154087](https://www.jstor.org/stable/154087).

*Quote:* "We are all inclined to accept the Zemskov totals (even if not as complete) with their 14 million intake to Gulag 'camps' alone, to which must be added 4–5 million going to Gulag 'colonies', to say nothing of the 3.5 million already in, or sent to, 'labor settlements'. However taken, these are surely 'high' figures." There are reservations to be made. For example, we now learn that the Gulag reported totals were of capacity rather than actual counts, leading to an underestimate in 1946 of around 15%. Then as to the numbers 'freed': there is no reason to accept the category simply because the MVD so listed them, and, in fact, we are told of 1947 (when the anecdotal evidence is of almost no one released) that this category concealed deaths: 100000 in the first quarter of the year'"

[^28]: J. Gheith, K. Jolluck (2011). [*Gulag Voices: Oral Histories of Soviet Incarceration and Exile*](https://archive.org/details/gulagvoicesoralh00ghei_465). Palgrave Macmillan US. pp. [3](https://archive.org/details/gulagvoicesoralh00ghei_465/page/n23). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-230-61062-0](https://en.wikipedia.org/wiki/Special:BookSources/978-0-230-61062-0 "Special:BookSources/978-0-230-61062-0"). Orlando Figes Estimates that 25 million people circulated through the Gulag system between 1928 and 1953

[^29]: ["Repressions"](https://web.archive.org/web/20080327005552/http://publicist.n1.by/articles/repressions/repressions_gulag2.html). Publicist.n1.by. Archived from [the original](http://publicist.n1.by/articles/repressions/repressions_gulag2.html) on March 27, 2008. Retrieved January 6, 2009.

[^30]: Земсков, Виктор (1991), ["ГУЛАГ (историко-социологический аспект)"](https://scepsis.net/library/id_937.html), *Социологические исследования*, vol. 6, no. 7, retrieved June 22, 2024

[^31]: Barnes, Steven A. (2011). *Death and Redemption: The Gulag and the Shaping of Soviet Society*. Princeton University Press. pp. 71–72.

[^32]: Alexopoulos, Golfo (Summer 2005). "Amnesty 1945: The Revolving Door of Stalin's Gulag". *[Slavic Review](https://en.wikipedia.org/wiki/Slavic_Review "Slavic Review")*. **64** (2): 274–306. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/3649985](https://doi.org/10.2307%2F3649985). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [3649985](https://www.jstor.org/stable/3649985). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [73613155](https://api.semanticscholar.org/CorpusID:73613155).

[^33]: ["What Were Their Crimes?"](https://web.archive.org/web/20071105114641/http://gulaghistory.org/exhibits/nps/onlineexhibit/stalin/crimes.php). Gulaghistory.org. Archived from [the original](http://gulaghistory.org/nps/onlineexhibit/stalin/crimes.php) on November 5, 2007. Retrieved January 6, 2009.

[^34]: Uschan, M. *Political Leaders*. Lucent Books. 2002.

[^35]: ["Repressions"](https://web.archive.org/web/20080311080150/http://publicist.n1.by/articles/repressions/repressions_organy1.html). Publicist.n1.by. Archived from [the original](http://publicist.n1.by/articles/repressions/repressions_organy1.html) on March 11, 2008. Retrieved January 6, 2009.

[^36]: Daly, Jonathan (2018). *Crime and Punishment in Russia A Comparative History from Peter the Great to Vladimir Putin*. Bloomsbury Publishing.

[^37]: Filtzer, Donald (2002). *Soviet Workers and Late Stalinism Labour and the Restoration of the Stalinist System After World War II*. Cambridge University Press. pp. 28–9.

[^38]: Hardy, Jeffrey S. (2016). *The Gulag After Stalin Redefining Punishment in Khrushchev's Soviet Union, 1953–1964*. Cornell University Press. p. 124.

[^39]: ["Whore Marchtrenk"](https://penpolit.ru/author-item+M5cd00dd4488.html). *penpolit.ru*.

[^40]: ["News Release: Forced labor camp artifacts from Soviet era on display at NWTC"](https://web.archive.org/web/20080828051139/http://www.nwtc.edu/Archives/LaborCamps05-30.htm). *www.nwtc.edu*. Archived from [the original](http://www.nwtc.edu/Archives/LaborCamps05-30.htm) on August 28, 2008.

[^41]: Applebaum, Anne. *Gulag: A History.* Anchor, 2004, pp. xxxi

[^42]: Jakobson, Michael. *Origins of the Gulag*. E-book, The University Press of Kentucky, 2015, pp. 11

[^43]: Applebaum, Anne. *Gulag: A History.* Anchor, 2004, pp. xxix–xxx

[^44]: Applebaum, Anne. *Gulag: A History.* Anchor, 2004, pp. xxxiii

[^45]: Земсков, Виктор (1991). ["ГУЛАГ (историко-социологический аспект)"](http://scepsis.ru/library/id_937.html). *Социологические Исследования* (6–7). Retrieved August 14, 2011.

[^46]: Applebaum, Anne. "Gulag: A History." Anchor, 2003, pp. 12

[^47]: Applebaum, Anne. "Gulag: A History." Anchor, 2003, pp. 5

[^48]: Applebaum, "Gulag: A History", Chapter 3

[^49]: "The only way to attract the labor power necessary for our economic problems is to introduce compulsory labor service", in: Trotsky, Leon. ["Leon Trotsky: Terrorism and Communism (Chapter 8)"](https://www.marxists.org/archive/trotsky/1920/terrcomm/ch08.htm). *www.marxists.org*. Retrieved August 6, 2015.

[^50]: Krausz, Tamás (February 27, 2015). [*Reconstructing Lenin: An Intellectual Biography*](https://books.google.com/books?id=z23IBgAAQBAJ&dq=lenin+concentration+camps+stalinist+obviously&pg=PA512). NYU Press. p. 512. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-58367-449-9](https://en.wikipedia.org/wiki/Special:BookSources/978-1-58367-449-9 "Special:BookSources/978-1-58367-449-9").

[^51]: Jakobson, Michael. *Origins of the Gulag.* E-book, The University Press of Kentucky, pp. 52

[^52]: Applebaum, Anne. *Gulag: A History.* Anchor, 2004, pp. 12.

[^53]: Applebaum, Anne. *Gulag: A History.* Anchor, 2003, pp. 50.

[^54]: [David Dallin](https://en.wikipedia.org/wiki/David_Dallin "David Dallin") and [Boris Nicolaevsky](https://en.wikipedia.org/wiki/Boris_Nicolaevsky "Boris Nicolaevsky"), *Forced Labor in Soviet Russia*, New Haven: Yale University Press, 1947, p. 153.

[^55]: *Transcripts from the Soviet Archives Volume III*. Erdogan A (published February 9, 2021). 2021. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-329-63144-1](https://en.wikipedia.org/wiki/Special:BookSources/978-1-329-63144-1 "Special:BookSources/978-1-329-63144-1").

[^56]: Applebaum, Anne (2004). Gulag: a History of the Soviet Camps. London: Penguin Books., p. 52-53

[^57]: Ellman, Michael (2002). ["Soviet Repression Statistics: Some Comments"](https://web.archive.org/web/20190525134942/http://sovietinfo.tripod.com/ELM-Repression_Statistics.pdf) (PDF). *Europe-Asia Studies*. **54** (2): 1151–1172. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/0966813022000017177](https://doi.org/10.1080%2F0966813022000017177). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [43510161](https://api.semanticscholar.org/CorpusID:43510161). Archived from [the original](http://sovietinfo.tripod.com/ELM-Repression_Statistics.pdf) (PDF) on May 25, 2019. Retrieved August 14, 2011.

[^58]: Khlevniuk, Oleg (2004). *The History of the Gulag*. New Haven: Yale University Press. p. 9.

[^59]: khlevniuk, Oleg (2004). *The History of the Gulag*. New Haven: Yale University Press. p. 11.

[^60]: Khlevniuk, Oleg (2004). *The History of the Gulag*. New Haven: Yale University Press. p. 17.

[^61]: [Memorial](https://en.wikipedia.org/wiki/Memorial_\(society\) "Memorial (society)") [http://www.memo.ru/history/NKVD/GULAG/r1/r1-4.htm](http://www.memo.ru/history/NKVD/GULAG/r1/r1-4.htm) [Archived](https://web.archive.org/web/20170318014949/http://www.memo.ru/history/NKVD/GULAG/r1/r1-4.htm) March 18, 2017, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^62]: See, e.g. Jakobson, Michael. 1993. *Origins of the GULag: The Soviet Prison Camp System 1917–34*. Lexington, Kentucky: [University Press of Kentucky](https://en.wikipedia.org/wiki/University_Press_of_Kentucky "University Press of Kentucky"). p. 88.

[^63]: See, e.g. Ivanova, Galina M. 2000. *Labor Camp Socialism: The Gulag in the Totalitarian System*. Armonk, New York: [M. E. Sharpe](https://en.wikipedia.org/wiki/M._E._Sharpe "M. E. Sharpe"). ch. 2.

[^64]: See, for example, Gulaga, Naselenie. 2004. " sobranie dokumentov v 7 tomakh." *Istorija stalinskogo Gulaga: konec 1920-kh – pervaia polovina 1950-kh godov*, vol. 4, edited by V. P. Kozlov et al. Moskva: [ROSSPEN](https://en.wikipedia.org/wiki/ROSSPEN "ROSSPEN").

[^65]: Applebaum, Anne (August 2, 2012). ["The Camps Expand"](https://books.google.com/books?id=HYSGZs6mW5wC). *Gulag: A History of the Soviet Camps*. Penguin Books Limited. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-14-197526-9](https://en.wikipedia.org/wiki/Special:BookSources/978-0-14-197526-9 "Special:BookSources/978-0-14-197526-9").

[^66]: ["Таблица №3 к статье Виктора Земскова «ГУЛАГ (историко-социологический аспект)»"](https://scepsis.net/library/misc/id-937_table3.html). *scepsis.net*.

[^67]: Rosefielde, Steven (February 12, 2007). [*The Russian economy: from Lenin to Putin*](https://books.google.com/books?id=L4s1H9v2yOwC&pg=PA95). Wiley. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-4051-1337-3](https://en.wikipedia.org/wiki/Special:BookSources/978-1-4051-1337-3 "Special:BookSources/978-1-4051-1337-3").

[^68]: Applebaum, Anne (2003). [*Gulag: a history*](https://books.google.com/books?id=8fIfmxAs_T0C&pg=PA446). Doubleday. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-7679-0056-0](https://en.wikipedia.org/wiki/Special:BookSources/978-0-7679-0056-0 "Special:BookSources/978-0-7679-0056-0").

[^69]: Franciszek Proch, Poland's Way of the Cross, New York 1987 P.146

[^70]: ["Project In Posterum"](https://web.archive.org/web/20171114152931/http://www.projectinposterum.org/docs/poland_WWII_casualties.htm). Project In Posterum. Archived from [the original](http://www.projectinposterum.org/docs/poland_WWII_casualties.htm) on November 14, 2017. Retrieved December 19, 2011.

[^71]: [Encyklopedia PWN](https://en.wikipedia.org/wiki/Internetowa_encyklopedia_PWN "Internetowa encyklopedia PWN") ['KAMPANIA WRZEŚNIOWA 1939'](http://encyklopedia.pwn.pl/33490_1.html) [Archived](https://web.archive.org/web/20050927194547/http://encyklopedia.pwn.pl/33490_1.html) September 27, 2005, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), last retrieved on December 10, 2005, Polish language

[^72]: [Marek Jan Chodakiewicz](https://en.wikipedia.org/wiki/Marek_Jan_Chodakiewicz "Marek Jan Chodakiewicz") (2004). *Between Nazis and Soviets: Occupation Politics in Poland, 1939–1947*. Lexington Books. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-7391-0484-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-7391-0484-2 "Special:BookSources/978-0-7391-0484-2").

[^73]: beanbean (May 2, 2008). ["A Polish life. 5: Starobielsk and the trans-Siberian railway"](https://web.archive.org/web/20140531104804/http://my.telegraph.co.uk/beanbean/beanbean/4054641/A_Polish_life_5_Starobielsk_and_the_transSiberian_railway/). *[My Telegraph](https://en.wikipedia.org/wiki/My_Telegraph "My Telegraph")*. London. Archived from [the original](http://my.telegraph.co.uk/beanbean/beanbean/4054641/A_Polish_life_5_Starobielsk_and_the_transSiberian_railway/) on May 31, 2014. Retrieved May 8, 2012.

[^74]: Hope, Michael. ["Polish deportees in the Soviet Union"](https://web.archive.org/web/20090408081337/http://www.wajszczuk.v.pl/english/drzewo/czytelnia/michael_hope.htm). Wajszczuk.v.pl. Archived from [the original](http://www.wajszczuk.v.pl/english/drzewo/czytelnia/michael_hope.htm) on April 8, 2009. Retrieved January 6, 2009.

[^75]: [GULAG: a History](http://www.anneapplebaum.com/gulag-a-history/), Anne Applebaum

[^76]: Zemskov, *Gulag*, Sociologičeskije issledovanija, 1991, No. 6, pp. 14–15.

[^77]: ["Repressions"](https://web.archive.org/web/20090419222914/http://soviet-history.com/doc/prison/gulag_info1.php). Publicist.n1.by. Archived from [the original](http://publicist.n1.by/articles/repressions/repressions_gulag1.html) on April 19, 2009. Retrieved January 6, 2009.

[^78]: Ivanova, Galina Mikhailovna (2000). *Labor Camp Socialism: The Gulag in the Soviet Totalitarian System*. Armonk, New York: Sharpe. pp. 69–126.

[^79]: Khevniuk, Oleg V. (2004). *The History of the Gulag: From Collectivization to the Great Terror*. Yale University Press. pp. 236–286.

[^80]: Bacon, Edwin (1994). *The Gulag at War: Stalin's Forced Labor System in the Light of the Archives*. New York: New York University Press. pp. 42–63, 82–100, 123–144.

[^81]: [Zemskov 2011](#CITEREFZemskov2011).

[^82]: [Bernstein 2019](#CITEREFBernstein2019).

[^83]: [Polian 2002](#CITEREFPolian2002), p. 359.

[^84]: Земсков В.Н. К вопросу о репатриации советских граждан. 1944–1951 годы // История СССР. 1990. No. 4 Zemskov V.N. On repatriation of Soviet citizens. Istoriya SSSR., 1990, No.4

[^85]: [Germans Find Mass Graves at an Ex-Soviet Camp](https://query.nytimes.com/gst/fullpage.html?res=9E0CE6D61131F937A1575AC0A964958260&sec=&spon=&scp=13&sq=Sachsenhausen&st=cse) New York Times, September 24, 1992

[^86]: [Ex-Death Camp Tells Story Of Nazi and Soviet Horrors](https://query.nytimes.com/gst/fullpage.html?res=9A0CEFDA163EF934A25751C1A9679C8B63&sec=&spon=&pagewanted=1) New York Times, December 17, 2001

[^87]: ["The museum of history of political repressions "Perm-36""](https://web.archive.org/web/20130902030729/http://www.russianmuseums.info/M3029). Archived from [the original](http://www.russianmuseums.info/M3029) on September 2, 2013. Retrieved October 29, 2013.

[^88]: ["Perm-36"](https://www.wmf.org/project/perm-36). *World Monuments Fund*. Retrieved November 11, 2020.

[^89]: ["Сюжеты о "Перми-36" на НТВ сочли "квазижурналистским пасквилем""](http://59.ru/text/newsline/892938.html). February 13, 2015. Retrieved August 31, 2015.

[^90]: ["Gulag | Definition, History, & Facts"](https://www.britannica.com/place/Gulag). *Encyclopædia Britannica*. Retrieved February 18, 2021.

[^91]: Getty, J. A.; Rittersporn, G. T.; Zemskov, V. N. (1993). ["Victims of the Soviet Penal System in the Pre-war Years"](https://web.archive.org/web/20080611064213/http://www.etext.org/Politics/Staljin/Staljin/articles/AHR/AHR.html). *American Historical Review*. **98** (4): 1017–1049. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2166597](https://doi.org/10.2307%2F2166597). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2166597](https://www.jstor.org/stable/2166597). Archived from [the original](http://www.etext.org/Politics/Staljin/Staljin/articles/AHR/AHR.html) on June 11, 2008. The long-awaited archival evidence on repression in the period of the Great Purges shows that levels of arrests, political prisoners, executions, and general camp populations tend to confirm the orders of magnitude indicated by those labeled as "revisionists" and mocked by those proposing high estimates.

[^92]: Wheatcroft, Stephen G. (1999). ["Victims of Stalinism and the Soviet Secret Police: The Comparability and Reliability of the Archival Data. Not the Last Word"](https://web.archive.org/web/20191206042326/http://sovietinfo.tripod.com/WCR-Secret_Police.pdf) (PDF). *[Europe-Asia Studies](https://en.wikipedia.org/wiki/Europe-Asia_Studies "Europe-Asia Studies")*. **51** (2): 340–342. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/09668139999056](https://doi.org/10.1080%2F09668139999056). Archived from [the original](http://sovietinfo.tripod.com/WCR-Secret_Police.pdf) (PDF) on December 6, 2019. Retrieved February 14, 2018.

*Quote:* "For decades, many historians counted Stalin' s victims in 'tens of millions', which was a figure supported by Solzhenitsyn. Since the collapse of the USSR, the lower estimates of the scale of the camps have been vindicated. The arguments about excess mortality are far more complex than normally believed. R. Conquest, *The Great Terror: A Re-assessment* (London, 1992) does not really get to grips with the new data and continues to present an exaggerated picture of the repression. The view of the 'revisionists' has been largely substantiated (J. Arch Getty & R. T. Manning (eds), *Stalinist Terror: New Perspectives* (Cambridge, 1993)). The popular press, even TLS and The Independent, have contained erroneous journalistic articles that should not be cited in respectable academic articles."

[^93]: ["Demographic Losses Due to Repressions"](http://demoscope.ru/weekly/2007/0313/tema06.php), by [Anatoly Vishnevsky](https://en.wikipedia.org/wiki/Anatoly_Vishnevsky "Anatoly Vishnevsky"), Director of the Centre for Human Demography and Ecology, [Russian Academy of Sciences](https://en.wikipedia.org/wiki/Russian_Academy_of_Sciences "Russian Academy of Sciences"), (in Russian)

[^94]: ["The History of the GULAG"](http://yalepress.yale.edu/yupbooks/book.asp?isbn=9780300092844) [Archived](https://web.archive.org/web/20100622052449/http://yalepress.yale.edu/yupbooks/book.asp?isbn=9780300092844) June 22, 2010, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), by [Oleg V. Khlevniuk](https://en.wikipedia.org/wiki/Oleg_V._Khlevniuk "Oleg V. Khlevniuk")

[^95]: Snyder, Timothy (January 27, 2011). ["Hitler vs. Stalin: Who Was Worse?"](https://www.nybooks.com/online/2011/01/27/hitler-vs-stalin-who-was-worse/#:~:text=Mass%20murder%20in%20the%20Soviet,disconcertingly%20close%20to%20Nazi%20motivations.&text=It%20turns%20out%20that%2C%20with,entered%20the%20Gulag%20left%20alive.). *[New York Review of Books](https://en.wikipedia.org/wiki/New_York_Review_of_Books "New York Review of Books")*.

[^96]: Golfo Alexopoulos (April 12, 2019). ["Medicine and Mortality in the Gulag"](https://www.youtube.com/watch?v=TwUgqHthjTs?t=50m25s). NYUJordanCenter.

[^97]: Erlikman, Vadim (2004). *Poteri narodonaseleniia v XX veke: spravochnik*. Moscow 2004: Russkaia panorama. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-93165-107-1](https://en.wikipedia.org/wiki/Special:BookSources/5-93165-107-1 "Special:BookSources/5-93165-107-1").

[^98]: Hardy, Jeffery (April 2018). ["Slavic Review, Volume 77, Issue 1 Spring 2018 pp.269–270"](https://web.archive.org/web/20190429033750/https://www.cambridge.org/core/journals/slavic-review/article/illness-and-inhumanity-in-stalins-gulag-by-golfo-alexopoulos-new-haven-yale-university-press-2007-xi-308-pp-notes-index-maps-6500-hard-bound/130C12D73C6AE10333805FF0AD847790/core-reader). *Slavic Review*. **77** (1). © Association for Slavic, East European, and Eurasian Studies 2018: 269–270. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1017/slr.2018.57](https://doi.org/10.1017%2Fslr.2018.57). Archived from [the original](https://www.cambridge.org/core/journals/slavic-review/article/illness-and-inhumanity-in-stalins-gulag-by-golfo-alexopoulos-new-haven-yale-university-press-2007-xi-308-pp-notes-index-maps-6500-hard-bound/130C12D73C6AE10333805FF0AD847790/core-reader) on April 29, 2019. Retrieved July 29, 2019.

[^99]: Nakonechnyi, Mikhail (2020). [*'Factory of invalids': Mortality, disability and early release on medical grounds in GULAG, 1930–1955*](https://ora.ox.ac.uk/objects/uuid:f81e082c-a3b1-46a8-993c-4a134c199d89) (Thesis). University of Oxford.

[^100]: Healey, Dan (June 1, 2018). ["Golfo Alexopoulos. Illness and Inhumanity in Stalin's Gulag"](https://academic.oup.com/ahr/article/123/3/1049/5025385). *The American Historical Review*. **123** (3): 1049–1051. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1093/ahr/123.3.1049](https://doi.org/10.1093%2Fahr%2F123.3.1049). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0002-8762](https://search.worldcat.org/issn/0002-8762).

[^101]: [*Документ № 103. Справка о смертности заключённых в системе ГУЛага за период 1930—1956 гг*](https://web.archive.org/web/20201112030502/http://www.alexanderyakovlev.org/fond/issues-doc/1009320). Mezhdunarodnyi Fond "Demokratiia". 2000. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-85646-046-4](https://en.wikipedia.org/wiki/Special:BookSources/5-85646-046-4 "Special:BookSources/5-85646-046-4"). Archived from [the original](http://www.alexanderyakovlev.org/fond/issues-doc/1009320) on November 12, 2020. Retrieved May 25, 2020.

[^102]: [History of Gulag in 7 Volumes. Volume 2: Structure and Personnel](http://www.statearchive.ru/470) documents, ed. [Petrov N. V.](https://en.wikipedia.org/wiki/Nikita_Petrov "Nikita Petrov") [State Archive of the Russian Federation](https://en.wikipedia.org/wiki/State_Archive_of_the_Russian_Federation "State Archive of the Russian Federation"), 2004 (in Russian)

[^103]: [The Heads of the Central Committee of NKVD](http://www.memo.ru/history/nkvd/kto/centr.htm) [Archived](https://web.archive.org/web/20111021040407/http://www.memo.ru/history/NKVD/kto/centr.htm) October 21, 2011, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") [Petrov N. V.](https://en.wikipedia.org/wiki/Nikita_Petrov "Nikita Petrov"), Sorokyn K. V. *Who Headed NKVD 1934—1941* Moscow: [Memorial](https://en.wikipedia.org/wiki/Memorial_\(society\) "Memorial (society)"), 1999, 504 pages. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-7870-0032-3](https://en.wikipedia.org/wiki/Special:BookSources/5-7870-0032-3 "Special:BookSources/5-7870-0032-3")

[^104]: [Lubyanka. VCheka — KGB. Documents 1917–1960](http://istmat.info/node/38978) [Archived](https://web.archive.org/web/20201213222752/http://istmat.info/node/38978) December 13, 2020, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") Moscow: International Democracy Fund, 1997. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-89511-004-5](https://en.wikipedia.org/wiki/Special:BookSources/5-89511-004-5 "Special:BookSources/5-89511-004-5")

[^105]: [The Gulag Collection: Paintings of Nikolai Getman](http://www.jamestown.org/getman_paintings.php?painting_id=29) [Archived](https://web.archive.org/web/20071127121250/http://www.jamestown.org/getman_paintings.php?painting_id=29) November 27, 2007, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^106]: Thurston, Robert W. *Life and Terror in Stalin's Russia, 1934–1941*. Yale University Press. pp. 102–104.

[^107]: ["Stalin's legacy lives on in city that slaves built – archive, 1994"](https://www.theguardian.com/world/2017/dec/29/stalin-russia-soviet-union-gulag-norilsk). *the Guardian*. December 29, 2017. Retrieved April 12, 2021.

[^108]: [Brent, Jonathan](https://en.wikipedia.org/wiki/Jonathan_Brent "Jonathan Brent"). 2008. " [Introduction](https://web.archive.org/web/20090224230330/http://atlasandco.com/images/uploads/samples/pdf/InsideStalinArchives-web.pdf)." Pp. 1–18 in *Inside the Stalin Archives: Discovering the New Russia.* Atlas & Co. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-9777433-3-0](https://en.wikipedia.org/wiki/Special:BookSources/0-9777433-3-0 "Special:BookSources/0-9777433-3-0"). Archived from the [original](http://atlasandco.com/images/uploads/samples/pdf/InsideStalinArchives-web.pdf) on February 24, 2009. p. 12.

[^109]: Getty, J. Arch (1985). *Origins of the Great Purges*. Cambridge University Press. p. 189.

[^110]: [Borodkin, Leonid](https://en.wikipedia.org/wiki/Leonid_Borodin "Leonid Borodin"), and Simon Ertz. 2005. "Forced Labor and the Need for Motivation: Wages and Bonuses in the Stalinist Camp System." *Comparative Economic Studies* 47(2):418–36.

[^111]: Maddox, S. (2018). Gulag Football: Competitive and Recreational Sport in Stalin's System of Forced Labor. Kritika: Explorations in Russian and Eurasian History, 19(3), 509–536.

[^112]: Remnick, David (April 2, 2014). [*Lenin's Tomb: The Last Days of the Soviet Empire*](https://books.google.com/books?id=dEvoAgAAQBAJ). Knopf Doubleday Publishing Group. p. 425. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-8041-7358-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-8041-7358-2 "Special:BookSources/978-0-8041-7358-2").

[^113]: Khlevniuk, Oleg (2004). *The History of the Gulag*. New Haven: Yale University Press. p. 55.

[^114]: Gorlizki, Yoram (June 28, 2001). ["Theft Under Stalin: A Property Rights Analysis"](https://www2.warwick.ac.uk/fac/soc/economics/staff/mharrison/archive/persa/010fulltext.pdf) (PDF). [Archived](https://web.archive.org/web/20170307204130/https://www2.warwick.ac.uk/fac/soc/economics/staff/mharrison/archive/persa/010fulltext.pdf) (PDF) from the original on March 7, 2017. Retrieved March 7, 2017.

[^115]: Khlevniuk, Oleg (2004). *The History of the Gulag*. New Haven: Yale University Press. p. 61.

[^116]: " [Nikolai Getman: The Gulag Collection](http://www.jamestown.org/aboutus/getmanpaintings/getmancatalog/) [Archived](https://web.archive.org/web/20120513172402/http://www.jamestown.org/aboutus/getmanpaintings/getmancatalog/) May 13, 2012, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") "

[^117]: Yedlin, Tova (1999). [*Maxim Gorky: A Political Biography*](https://books.google.com/books?id=Zxt5_vI_ozcC&pg=PA188). Greenwood Publishing Group. p. 188. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-275-96605-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-275-96605-8 "Special:BookSources/978-0-275-96605-8").

[^118]: Map of Gulag, made by the Memorial Foundation on: . [Archived](https://web.archive.org/web/20210308021523/https://www.google.com/imgres?imgurl=http://www.g-to-g.com/picts/user/repressed/mapgulag_1.jpg&imgrefurl=http://www.g-to-g.com/showpict.php%3Fpict%3D/repressed/mapgulag_1.jpg%26at%3DCorrective%20Labor%20Camps%20\(GULAG\)%20map%20\(1:%2025%20000%20000\)%20-%20by%20Magazine%20Map%20and%20Ryazan%20Memorial%20Society%26caption%3DCorrective%20Labor%20Camps%20\(GULAG\)%20map%20\(1:%2025%20000%20000\)%3CBR%3Eby%20Magazine%20Map%20and%20Ryazan%20Memorial%20Society&usg=__HktMeLxUyIicCykfQtiNhzBMdvI=&h=1020&w=1516&sz=150&start=0&zoom=1&tbnid=22GAI-e-k3ouhM:&tbnh=147&tbnw=227&ei=M0XqTa3EFISV8QPN7-WPAQ&prev=/search%3Fq%3DGulag%2Bmap%26hl%3Dfr%26safe%3Doff%26client%3Dfirefox-a%26rls%3Dorg.mozilla:fr:official%26biw%3D1108%26bih%3D615%26gbv%3D2%26tbm%3Disch&itbs=1&iact=hc&vpx=795&vpy=97&dur=4204&hovh=184&hovw=274&tx=153&ty=97&page=1&ndsp=13&ved=1t:429,r:3,s:0&biw=1108&bih=615) March 8, 2021, at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^119]: ["Система исправительно-трудовых лагерей в СССР"](https://web.archive.org/web/20160304031657/http://www.memo.ru/history/nkvd/gulag/gulag3.htm). Memo.ru. Archived from [the original](http://www.memo.ru/history/nkvd/gulag/gulag3.htm) on March 4, 2016. Retrieved January 6, 2009.

[^120]: Ivanova, Galina; Flath, Carol; Raleigh, Donald (2000). [*Labor Camp Socialism: The Gulag in the Soviet Totalitarian System*](https://books.google.com/books?id=q3y8D69IyG4C&pg=PA188). London: M.E. Sharpe. p. 188. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-7656-0426-2](https://en.wikipedia.org/wiki/Special:BookSources/978-0-7656-0426-2 "Special:BookSources/978-0-7656-0426-2").

[^121]: ["Anne Applebaum — Inside the Gulag"](https://web.archive.org/web/20081015012139/http://www.anneapplebaum.com/communism/2000/06_15_nyrb_gulag.html). Archived from [the original](http://www.anneapplebaum.com/communism/2000/06_15_nyrb_gulag.html) on October 15, 2008.

[^122]: ["Coercion versus Motivation: Forced Labor in Norilsk"](https://web.archive.org/web/20081203230839/http://media.hoover.org/documents/0817939423_75.pdf) (PDF). Archived from [the original](http://media.hoover.org/documents/0817939423_75.pdf) (PDF) on December 3, 2008. Retrieved January 6, 2009.

[^123]: [*Знаки различия ГУЛАГа*](http://www.opoccuu.com/gulag.htm) Retrieved December 26, 2024.

[^124]: ["H-Net Reviews"](https://web.archive.org/web/20070627065714/http://h-net.org/reviews/showrev.cgi?path=9539851382536). April 1996. Archived from [the original](http://www.h-net.org/reviews/showrev.cgi?path=9539851382536) on June 27, 2007. Retrieved December 27, 2014.

[^125]: MVD of Russia: An Encyclopedia (МВД России: энциклопедия), 2002, [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-224-03722-0](https://en.wikipedia.org/wiki/Special:BookSources/5-224-03722-0 "Special:BookSources/5-224-03722-0"), p.541

[^126]: Grunewald, Susan C. I. (September 11, 2024). ["From Incarceration to Repatriation"](https://www.peripheralhistories.co.uk/post/from-incarceration-to-repatriation). *Peripheral Histories*. Retrieved August 11, 2026.

[^127]: Barnes, Stephen A. (2011). *Death and Redemption: The Gulag and the Shaping of Soviet Society*. Princeton: Princeton University Press. pp. 7–16. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-691-15112-0](https://en.wikipedia.org/wiki/Special:BookSources/978-0-691-15112-0 "Special:BookSources/978-0-691-15112-0").

[^128]: [Arendt, Hannah](https://en.wikipedia.org/wiki/Hannah_Arendt "Hannah Arendt"). 1985. *[The Origins of Totalitarianism](https://en.wikipedia.org/wiki/The_Origins_of_Totalitarianism "The Origins of Totalitarianism")*. [Harcourt](https://en.wikipedia.org/wiki/Harcourt_\(publisher\) "Harcourt (publisher)").

[^129]: Земсков, Виктор (1995). ["К вопросу о масштабах репрессий в СССР"](http://scepsis.ru/library/id_957.html). *Социологические Исследования* (9): 118–127. Retrieved August 20, 2011.

[^130]: Лопатников, Леонид (2009). ["К дискуссиям о статистике "Большого террора""](http://magazines.russ.ru/vestnik/2009/26/ll28.html). *Вестник Европы* (26–27). Retrieved August 20, 2011.

[^131]: Nechepurenko, Ivan (March 13, 2021). ["Born in Soviet Exile, They Might Die in a Russian One"](https://www.nytimes.com/2021/03/13/world/europe/russia-stalin-exile.html). *[The New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times")*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0362-4331](https://search.worldcat.org/issn/0362-4331). To ensure that the preferred version of history prevailed, the Kremlin has squeezed historians, researchers and rights groups that focus on Gulag research and memory.

[^132]: Земсков, Виктор (1994). ["Политические репрессии в СССР (1917–1990 гг.)"](https://web.archive.org/web/20120330205748/http://kob.rv.ua/doki-dai/dotu/other/zemskov/zemskov_politrepressii\(1917-1990\).pdf) (PDF). *Россия XXI* (1–2): 107–124. Archived from [the original](http://kob.rv.ua/doki-dai/dotu/other/zemskov/zemskov_politrepressii\(1917-1990\).pdf) (PDF) on March 30, 2012. Retrieved August 17, 2011.

[^133]: [Rousso, Henry](https://en.wikipedia.org/wiki/Henry_Rousso "Henry Rousso"); Golsan, Richard (2004). [*Stalinism and nazism: history and memory compared*](https://books.google.com/books?id=CIt7fMp30sAC&pg=PA92). U of Nebraska Press. p. 92. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-8032-9000-6](https://en.wikipedia.org/wiki/Special:BookSources/978-0-8032-9000-6 "Special:BookSources/978-0-8032-9000-6").

[^134]: Vishnevsky, Alantoly. Демографические потери от репрессий (The Demographic Loss of Repression), Demoscope Weekly, December 31, 2007, [retrieved](http://demoscope.ru/weekly/2007/0313/tema06.php) April 13, 2011

[^135]: Максудов, Сергей (1995). ["О публикациях в журнале "Социс""](http://scepsis.ru/library/id_956.html). *Социологические Исследования* (9): 114–118. Retrieved August 17, 2011.

[^136]: Werth, Nicolas (June 2007). ["Der Gulag im Prisma der Archive. Zugänge, Erkenntnisse, Ergebnisse"](https://web.archive.org/web/20140109222749/http://dl.oe.dgo-online.org/issues/dl/0706de.pdf) (PDF). *Osteuropa*. **57** (6): 9–30. Archived from [the original](http://dl.oe.dgo-online.org/issues/dl/0706de.pdf) (PDF) on January 9, 2014.

[^137]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 1. Массовые репрессии в СССР*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0605-7](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0605-7 "Special:BookSources/978-5-8243-0605-7").

[^138]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 2. Карательная система. Структура и кадры*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0606-4](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0606-4 "Special:BookSources/978-5-8243-0606-4").

[^139]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 3. Экономика Гулага*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0607-1](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0607-1 "Special:BookSources/978-5-8243-0607-1").

[^140]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 4. Население Гулага. Численность и условия содержания*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0608-8](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0608-8 "Special:BookSources/978-5-8243-0608-8").

[^141]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 5. Спецпереселенцы в СССР*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0608-8](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0608-8 "Special:BookSources/978-5-8243-0608-8").

[^142]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 6. Восстания, бунты и забастовки заключенных*. Москва: Российская политическая энциклопедия. 2004. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0610-1](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0610-1 "Special:BookSources/978-5-8243-0610-1").

[^143]: *История сталинского Гулага. Конец 1920–х — первая половина 1950–х годов. Собрание документов в 7 томах. Том 7. Советская репрессивно-карательная политика и пенитенциарная система. Аннотированный указатель дел ГА РФ*. Москва: Российская политическая энциклопедия. 2005. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-5-8243-0611-8](https://en.wikipedia.org/wiki/Special:BookSources/978-5-8243-0611-8 "Special:BookSources/978-5-8243-0611-8").

[^144]: Полян, Павел (2006). ["Новые карты архипелага ГУЛАГ"](http://magazines.russ.ru/nz/2006/2/po32.html). *Неприкосновенный Запас*. **2** (46): 277–286. Retrieved August 20, 2011.

[^145]: Edwin Bacon. Glasnost' and the Gulag: New Information on Soviet Forced Labor around World War II. *Soviet Studies*, Vol. 44, No. 6 (1992), pp. 1069–1086

[^146]: N. S. Timasheff. The Postwar Population of the Soviet Union. *[American Journal of Sociology](https://en.wikipedia.org/wiki/American_Journal_of_Sociology "American Journal of Sociology")*, Vol. 54, No. 2 (Sep. 1948), pp. 148–155

[^147]: Robert Conquest. Excess Deaths and Camp Numbers: Some Comments. *Soviet Studies*, Vol. 43, No. 5 (1991), pp. 949–952

[^148]: S. G. Wheatcroft. On Assessing the Size of Forced Concentration Camp Labour in the Soviet Union, 1929–56. *Soviet Studies*, Vol. 33, No. 2 (Apr. 1981), pp. 265–295

[^149]: Cited in [David Dallin](https://en.wikipedia.org/wiki/David_Dallin "David Dallin") and [Boris Nicolaevsky](https://en.wikipedia.org/wiki/Boris_Nicolaevsky "Boris Nicolaevsky"), *Forced Labor in Soviet Russia*, New Haven: Yale University Press, 1947, p. 59-62.

[^150]: Naum Jasny. Labor and Output in Soviet Concentration Camps. *Journal of Political Economy*, Vol. 59, No. 5 (Oct. 1951), pp. 405–419

[^151]: Steven Rosefielde. An Assessment of the Sources and Uses of Gulag Forced Labour 1929–56. *Soviet Studies*, Vol. 33, No. 1 (Jan. 1981), pp. 51–87

[^152]: (in Russian) *Beria* Moscow, ACT, 1999, [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [5-237-03178-1](https://en.wikipedia.org/wiki/Special:BookSources/5-237-03178-1 "Special:BookSources/5-237-03178-1"), page 203.

[^153]: According to [Anton Antonov-Ovseenko](https://en.wikipedia.org/wiki/Anton_Antonov-Ovseenko "Anton Antonov-Ovseenko"), "average number of prisoners \[in Gulag\] was 17.6 million in 1942, which many times exceeds the "declassified" official (forged) data frequently published in press"; the number was taken from an NKVD document dated January 18, 1945. The number of prisoners in 1943 was estimated as 13 million.

[^154]: Solzhenitsyn, A. *The Gulag Archipelago Two*, Harper and Row, 1975. Estimate was through 1953.

[^155]: Rappaport, H. Joseph Stalin: A Biographical Companion. ABC-CLIO Greenwood. 1999.

[^156]: Andrea Graziosi. The New Soviet Archival Sources. Hypotheses for a Critical Assessment. *Cahiers du Monde russe*, Vol. 40, No. 1/2, Archives et nouvelles sources de l'histoiresoviétique, une réévaluation / Assessing the New Soviet Archival Sources (Jan. – Jun. 1999), pp. 13–63

[^157]: ["The Total Number of Repressed"](http://demoscope.ru/weekly/2007/0313/tema05.php), by [Anatoly Vishnevsky](https://en.wikipedia.org/wiki/Anatoly_Vishnevsky "Anatoly Vishnevsky"), Director of the Center for Human Demography and Ecology, [Russian Academy of Sciences](https://en.wikipedia.org/wiki/Russian_Academy_of_Sciences "Russian Academy of Sciences"), (in Russian)

[^158]: Steven Rosefielde (1997). ["Documented Homicides and Excess Deaths: New Insights into the Scale of Killing in the USSR During the 1930s"](https://web.archive.org/web/20111113035745/http://www.paulbogdanor.com/left/soviet/rosefielde.pdf) (PDF). *Communist and Post-Communist Studies*. **30** (3): l-33. Archived from [the original](http://www.paulbogdanor.com/left/soviet/rosefielde.pdf) (PDF) on November 13, 2011.

[^159]: Robert Conquest. ["Knowing the Soviet Union: The Historical Dimension"](https://web.archive.org/web/20121018091358/http://www.bu.edu/iscip/pubseries/PubSeries1conquest.pdf) (PDF). Archived from [the original](https://www.bu.edu/iscip/pubseries/PubSeries1conquest.pdf) (PDF) on October 18, 2012. Retrieved January 31, 2017.

[^160]: Andrei Sokolov (January 2003). ["Forced Labor in Soviet Industry: The End of the 1930s to the Mid-1950s An Overview"](https://www.hoover.org/sites/default/files/uploads/documents/0817939423_23.pdf) (PDF). Hoover Press.

[^161]: [Petrov, Nikita](https://en.wikipedia.org/wiki/Nikita_Petrov "Nikita Petrov") (2003). ["The GULag as Instrument of the USSR's Punitive System 1917–39"](https://books.google.com/books?id=X2FGqiDKFysC&pg=PA10). In Dundovich, Elena; Gori, Francesca; Guercetti, Emanuela (eds.). *Reflections on the Gulag: With a Documentary Index on the Italian Victims of Repression in the USSR*. Feltrinelli Editore. pp. 8–10. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-88-07-99058-8](https://en.wikipedia.org/wiki/Special:BookSources/978-88-07-99058-8 "Special:BookSources/978-88-07-99058-8"). [OCLC](https://en.wikipedia.org/wiki/OCLC_\(identifier\) "OCLC (identifier)") [803610496](https://search.worldcat.org/oclc/803610496).

[^162]: Robert Conquest, Paul Hollander: Political violence: belief, behavior, and legitimation p.55, Palgrave Macmillan;(2008) [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-230-60646-3](https://en.wikipedia.org/wiki/Special:BookSources/978-0-230-60646-3 "Special:BookSources/978-0-230-60646-3")

[^163]: Toews, Gerhard; Vézina, Pierre-Louis (2025). ["Enemies of the People"](https://doi.org/10.1257%2Fmac.20220231). *American Economic Journal: Macroeconomics*. **17** (1): 310–342. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1257/mac.20220231](https://doi.org/10.1257%2Fmac.20220231). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [1945-7707](https://search.worldcat.org/issn/1945-7707).

[^164]: Zaks, Yulia (1979). "Soviet surveillance". *Index on Censorship*. **8** (6): 78. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/03064227908533010](https://doi.org/10.1080%2F03064227908533010).

[^165]: Prisoners of Conscience in the USSR (report). London: Amnesty International. 1975. EUR 46/001/1975.

[^166]: Weiner, Amir; Rahi-Tamm, Aigi (2012). "Getting to Know You: The Soviet Surveillance System, 1939–1957". *Kritika*. **13** (1): 5–45. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1353/kri.2012.0011](https://doi.org/10.1353%2Fkri.2012.0011).

[^167]: ["Release of Prisoners from the GULAG | Seventeen Moments in Soviet History"](https://soviethistory.msu.edu/1954/prisoners-return). *soviethistory.msu.edu*. Retrieved April 30, 2026.

[^168]: ["Gulag: Soviet Forced Labor Camps and the Struggle for Freedom"](https://gulaghistory.org/nps/onlineexhibit/dissidents/prisoners.php.html). *gulaghistory.org*. Retrieved April 30, 2026.

[^169]: Гальперович, Данила (June 27, 2010). ["Директор Государственного музея ГУЛАГа Антон Владимирович Антонов-Овсеенко"](https://web.archive.org/web/20111123080758/http://www.svobodanews.ru/content/transcript/2085640.html). *Радио Свобода*. [Radio Liberty](https://en.wikipedia.org/wiki/Radio_Liberty "Radio Liberty"). Archived from [the original](http://www.svobodanews.ru/content/transcript/2085640.html) on November 23, 2011. Retrieved August 19, 2011.

[^170]: Banerji, Arup (2008). [*Writing history in the Soviet Union: making the past work*](https://books.google.com/books?id=NqJS-H-odnYC&pg=PA271). [Berghahn Books](https://en.wikipedia.org/wiki/Berghahn_Books "Berghahn Books"). p. 271. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-81-87358-37-4](https://en.wikipedia.org/wiki/Special:BookSources/978-81-87358-37-4 "Special:BookSources/978-81-87358-37-4").

[^171]: ["About State Gulag Museum"](https://web.archive.org/web/20180625124244/http://www.gmig.ru/o-muzee). The State Gulag Museum. Archived from [the original](http://www.gmig.ru/o-muzee) on June 25, 2018. Retrieved August 19, 2011.

[^172]: ["Gulag – Museum on Communism"](https://web.archive.org/web/20220921212148/http://www.thegulag.org/). Archived from [the original](http://thegulag.org/) on September 21, 2022. Retrieved December 5, 2012.

[^173]: ["New Russian Gulag museum recreates Soviet terror"](https://www.bbc.com/news/world-europe-34675413). *BBC*. October 30, 2015.

[^174]: ["'The end of a life cycle' How the Russian authorities are 'quietly dissolving' the Gulag History Museum after its director, Roman Romanov, refused to censor an exhibition on Soviet-era repressions"](https://meduza.io/en/feature/2025/01/15/the-end-of-a-life-cycle). *[Meduza](https://en.wikipedia.org/wiki/Meduza_\(website\) "Meduza (website)")*. January 15, 2025.

[^175]: [Nikolay Epple](https://en.wikipedia.org/wiki/Nikolay_Epple?action=edit&redlink=1 "Nikolay Epple (page does not exist)"), [Власти переделывают Музей ГУЛАГа](https://holod.media/2025/01/26/vlasti-peredelyvayut-muzej-gulaga/), January 26, 2025

[^176]: [Музей истории ГУЛАГа станет Музеем памяти геноцида советского народа](https://www.rbc.ru/society/20/02/2026/699824569a79471a0a816d88?utm_referrer=https%3A%2F%2Fru.wikipedia.org%2F)