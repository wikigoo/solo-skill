---
title: "White torture"
source: "https://en.wikipedia.org/wiki/White_torture"
---
**White torture**, often referred to as **white room torture**, is a type of [psychological torture](https://en.wikipedia.org/wiki/Psychological_torture "Psychological torture") [^1] [^2] technique aimed at complete [sensory deprivation](https://en.wikipedia.org/wiki/Sensory_deprivation "Sensory deprivation") and isolation. A prisoner is held in a cell that is devoid of any color besides white; this method of torture is designed to deprive the prisoner of all senses and identity.[^2] [^3] [^4]

It is [particularly used in Iran](https://en.wikipedia.org/wiki/Human_rights_in_the_Islamic_Republic_of_Iran "Human rights in the Islamic Republic of Iran"); however, there is also evidence of its [use by intelligence services in the United States](https://en.wikipedia.org/wiki/Torture_and_the_United_States "Torture and the United States") and Venezuela.[^5] [^6]

## Methodology

Typically, prisoners will become [depersonalized](https://en.wikipedia.org/wiki/Depersonalization "Depersonalization") by losing [personal identity](https://en.wikipedia.org/wiki/Self-concept "Self-concept") for extended periods of isolation. Other effects can include [hallucinations](https://en.wikipedia.org/wiki/Hallucination "Hallucination") or [psychosis](https://en.wikipedia.org/wiki/Psychotic_break "Psychotic break").[^7]

## Allegations of use

### Iran

In Iran, white torture ([Persian](https://en.wikipedia.org/wiki/Persian_language "Persian language"): شكنجه سفيد) has been practiced on political prisoners by the Islamic republic regime.[^8] Most political prisoners who experience this type of torture are journalists [^9] held in the [Evin prison](https://en.wikipedia.org/wiki/Evin_prison "Evin prison").[^10] According to Hadi Ghaemi, founder of the Center for Human Rights in Iran (CHRI),[^11] such tortures in Evin are not necessarily authorized directly by the Iranian government.[^12]

It can include prolonged periods of solitary confinement, the use of continual illumination to deprive sleep (listed in the [Geneva Convention](https://en.wikipedia.org/wiki/Geneva_Convention "Geneva Convention") on Basic Human Rights, 1949), often in detention centers outside the control of the prison authorities, including Section 209 of Evin Prison.

[Ahmed Shaheed](https://en.wikipedia.org/wiki/Ahmed_Shaheed "Ahmed Shaheed"), the [United Nations](https://en.wikipedia.org/wiki/United_Nations "United Nations") special human rights rapporteur in Iran, claimed that human rights activist [Vahid Asghari](https://en.wikipedia.org/wiki/Vahid_Asghari "Vahid Asghari") was psychologically tortured by means of long-term detention in [solitary confinement](https://en.wikipedia.org/wiki/Solitary_confinement "Solitary confinement") and with threats to arrest, torture or rape his family members. He was also reportedly tortured with severe beatings for the purpose of eliciting confessions.[^13] [^14]

A 2004 [Amnesty International](https://en.wikipedia.org/wiki/Amnesty_International "Amnesty International") report [^3] documented the use of white torture on Amir Fakhravar by the [Revolutionary Guards](https://en.wikipedia.org/wiki/Islamic_Revolutionary_Guard_Corps "Islamic Revolutionary Guard Corps"), the first known example of white torture in Iran.[^15] It states that "his cells had no windows, and the walls and his clothes were white. His meals consisted of white rice on white plates. To use the toilet, he had to put a white piece of paper under the door. He was forbidden to speak, and the guards reportedly wore shoes that muffled sound".[^16] [^17] [^18]

In a telephone call to the [Human Rights Watch](https://en.wikipedia.org/wiki/Human_Rights_Watch "Human Rights Watch") in 2004, the Iranian journalist [Ebrahim Nabavi](https://en.wikipedia.org/wiki/Ebrahim_Nabavi "Ebrahim Nabavi") said:

> Since I left Evin, I have not been able to sleep without sleeping pills. It is terrible. The loneliness never leaves you, long after you are "free". Every door that is closed on you... This is why we call it "white torture". They get what they want without having to hit you. They know enough about you to control the information that you get: they can make you believe that the president has resigned, that they have your wife, that someone you trust has told them lies about you. You begin to break. And once you break, they have control. And then you begin to confess.[^19]

### United States

![](https://en.wikipedia.org/wiki/File:Camp_x-ray_detainees.jpg)

Detainees upon arrival at Camp X-Ray in January 2002, wearing goggles, masks, gloves, and earmuffs.

The United States has held [Guantanamo Bay detention camp](https://en.wikipedia.org/wiki/Guantanamo_Bay_detention_camp "Guantanamo Bay detention camp") prisoners under sensory deprivation, with their ears and eyes covered, hands and feet tied, hands in thick gloves, and held in cages without any privacy, always observed under a light that is on day and night. The organization of [European Democratic Lawyers](https://en.wikipedia.org/wiki/European_Democratic_Lawyers "European Democratic Lawyers") (EDL) said that this constitutes white torture and has accused the United States of violating prisoners' fundamental rights.[^20] Prisoners are also held in "extreme isolation", confined to windowless cells, going days "without seeing daylight", suffering what [Amnesty International](https://en.wikipedia.org/wiki/Amnesty_International "Amnesty International") and other international [human rights](https://en.wikipedia.org/wiki/Human_rights "Human rights") organizations have said are torture techniques approved by the [George W. Bush administration](https://en.wikipedia.org/wiki/George_W._Bush_administration "George W. Bush administration") [^21] [^22] under the euphemism " [enhanced interrogation](https://en.wikipedia.org/wiki/Enhanced_interrogation "Enhanced interrogation") ".[^23] [Rainer Mausfeld](https://en.wikipedia.org/wiki/Rainer_Mausfeld "Rainer Mausfeld"), a researcher in the field of psychology and cognitive science, has criticized the practice.[^24]

### Venezuela

According to human rights organizations and other NGOs, the [Bolivarian Intelligence Service](https://en.wikipedia.org/wiki/Bolivarian_Intelligence_Service "Bolivarian Intelligence Service") (SEBIN) of the Venezuelan government holds political prisoners in the lower levels of SEBIN's headquarters, which has been deemed by government officials [La Tumba](https://en.wikipedia.org/wiki/La_Tumba "La Tumba") "The Tomb".[^25] [^5] [^26] The cells are two by three meters (6 ft 7 in by 9 ft 10 in) with a cement bed, white walls, and security barriers between one another so that there is no interaction between prisoners.[^5] Such conditions have caused prisoners to become very ill, but they are denied medical treatment.[^26] Bright lights in the cells are kept on so prisoners lose their sense of time and the temperature is below freezing, with the only sounds heard being from the nearby [Caracas Metro](https://en.wikipedia.org/wiki/Caracas_Metro "Caracas Metro") trains.[^25] [^5] Reports of torture in La Tumba, specifically white torture, are also common, with some prisoners attempting to commit suicide.[^5] [^27] Such conditions according to the NGO Justice and Process are to make prisoners plead guilty to the crimes that they are accused of.[^5]

## In media

- German artist [Gregor Schneider](https://en.wikipedia.org/wiki/Gregor_Schneider "Gregor Schneider") based his room design of " *weiße Folter* " (lit. 'white torture') on this idea.[^28] [^29]
- *[The Brave (TV series)](https://en.wikipedia.org/wiki/The_Brave_\(TV_series\) "The Brave (TV series)")* Episode 10 "Desperate Measures" January 8, 2018. A team member is held in an Iranian [black site](https://en.wikipedia.org/wiki/Black_site "Black site") for interrogation. The room is all white, as is her clothing and the guards' clothing and the minimal furniture. The interrogator explains it is intended to cause sensory deprivation, and that bits of color will be added as she begins to cooperate.[^30] [^31]
- In the 2022 Indian film, *[Rorschach](https://en.wikipedia.org/wiki/Rorschach_\(film\) "Rorschach (film)")*, the protagonist Luke Antony is subjected to white room torture in Dubai Prison.

## References

[^1]: [Cesereanu, Ruxandra](https://en.wikipedia.org/wiki/Ruxandra_Cesereanu "Ruxandra Cesereanu") (Summer 2006). ["An Overview of Political Torture in the Twentieth Century"](https://web.archive.org/web/20160303181139/http://www.jsri.ro/new/?download=jsri_14_articol_12_ruxandra_cesereanu.pdf) (PDF). *Journal for the Study of Religions and Ideologies*. Archived from [the original](http://www.jsri.ro/new/?download=jsri_14_articol_12_ruxandra_cesereanu.pdf) (PDF) on 2016-03-03. Retrieved 2023-05-05.

[^2]: Canadian Centre for Victims of Torture (CCVT) (2004). ["In Our Midst: Educational Aids to Work with Survivors of Torture and Organized Violence"](http://www.psicosocial.net/historico/index.php?option=com_docman&view=download&alias=585-in-our-midst-educational-aids-to-work-with-survivors-of-torture-and-organized-violence&category_slug=tortura&Itemid=100225) (3rd ed.). p. 50 – via Grupo de Accion Comunitaria / Psicosocial.net.

[^3]: ["Helping to break the Silence: Urgent Actions on Iran"](https://www.amnesty.org/download/Documents/88000/act600082004en.pdf) (PDF). [Amnesty International](https://en.wikipedia.org/wiki/Amnesty_International "Amnesty International"). 31 March 2004. p. 2. Retrieved 2 April 2021.

[^4]: Beehner, Lionel (9 August 2006). ["Iran's Waning Human Rights"](https://www.cfr.org/backgrounder/irans-waning-human-rights). [Council on Foreign Relations](https://en.wikipedia.org/wiki/Council_on_Foreign_Relations "Council on Foreign Relations") (CFR). Retrieved 2 April 2021.

[^5]: Vinogradoff, Ludmila (10 February 2015). [""La tumba", siete celdas de tortura en el corazón de Caracas"](http://www.abc.es/internacional/20150210/abci-tumba-celdas-tortura-venezuela-201502091144.html). [ABC](https://en.wikipedia.org/wiki/ABC_\(newspaper\) "ABC (newspaper)"). Retrieved 29 July 2015.

[^6]: ["European Democratic Lawyers (EDL) statement on Guantanamo Bay and other detention centres"](https://www.statewatch.org/news/2004/july/statewatch-news-online-european-democratic-lawyers-edl-statement-on-guantanamo-bay-and-other-detention-centres/). *www.statewatch.org*. July 2004.

[^7]: David Morgan, [Violations of human...rights of the Kurds in Turkey](http://www.kurdmedia.com/articles.asp%3Fid%3D10156+%22white+torture%22&hl=en&ct=clnk&cd=97&gl=uk), Kurdish Media, March 22, 2005.

[^8]: Vick, Karl (June 7, 2004). ["Report Cites 'Climate of Fear' in Iran"](https://www.washingtonpost.com/wp-dyn/articles/A20714-2004Jun6.html). *[The Washington Post](https://en.wikipedia.org/wiki/The_Washington_Post "The Washington Post")*.

[^9]: ["UN human rights commission urged to sanction Iran"](http://www.rsf.org/article.php3?id_article=12878). *rsf.org*. [Reporters Without Borders](https://en.wikipedia.org/wiki/Reporters_Without_Borders "Reporters Without Borders"). March 15, 2005.

[^10]: ["Iran:... Kianoosh Sanjari"](https://web.archive.org/web/20071012110838/http://web.amnesty.org/library/Index/ENGMDE130012007?open&of=ENG-IRN). *amnesty.org*. Amnesty International. January 10, 2007. Archived from [the original](http://web.amnesty.org/library/Index/ENGMDE130012007?open&of=ENG-IRN) on 2007-10-12.

[^11]: ["Bio: Hadi Ghaemi"](https://iranhumanrights.org/bio-hadi-ghaemi/). *Center for Human Rights in Iran*. 2026-03-25. Retrieved 2026-03-30.

[^12]: Saunders, Doug (February 19, 2007). ["Few know who is held behind the tiled walls of Tehran's Evin prison"](https://web.archive.org/web/20070222035604/https://www.theglobeandmail.com/servlet/story/RTGAM.20070219.wiran19/BNStory/International/home). *[The Globe and Mail](https://en.wikipedia.org/wiki/The_Globe_and_Mail "The Globe and Mail")*. Archived from [the original](https://www.theglobeandmail.com/servlet/story/RTGAM.20070219.wiran19/BNStory/International/home) on February 22, 2007.

[^13]: ["Vahid Asghari was beaten to make confess"](http://www.bcrgroup.us/vahid-asghari-was-sentenced-to-18-years-imprisonment.html). *bcrgroup.us*. Human Rights Group in US. Retrieved 2019-09-10.

[^14]: ["United Nations Report"](https://web.archive.org/web/20150702070815/http://www.iranhrdc.org/english/human-rights-documents/united-nations-reports/un-reports/1000000196-report-of-the-special-rapporteur-on-the-situation-of-human-rights-in-the-islamic-republic-of-iran-13-september-2012.html). *IranHRDC.org*. Archived from [the original](http://www.iranhrdc.org/english/human-rights-documents/united-nations-reports/un-reports/1000000196-report-of-the-special-rapporteur-on-the-situation-of-human-rights-in-the-islamic-republic-of-iran-13-september-2012.html) on 2015-07-02. Retrieved 2015-07-06.

[^15]: Baxter, Sarah (May 21, 2006). ["Fugitive pleads with US to 'liberate' Iran"](https://web.archive.org/web/20080211110748/http://www.timesonline.co.uk/article/0,,2089-2189887,00.html). *[The Sunday Times](https://en.wikipedia.org/wiki/The_Sunday_Times_\(UK\) "The Sunday Times (UK)")*. Archived from [the original](http://www.timesonline.co.uk/article/0,,2089-2189887,00.html) on February 11, 2008. Retrieved March 10, 2007.

[^16]: ["Country Reports on Human Rights Practices - Iran in 2006"](https://2001-2009.state.gov/g/drl/rls/hrrpt/2006/78852.htm). *state.gov*. Bureau of Democracy, Human Rights, and Labor; [United States Department of State](https://en.wikipedia.org/wiki/United_States_Department_of_State "United States Department of State"). March 6, 2007. Retrieved May 7, 2024.

[^17]: McCann, Cathy (March 17, 2004). ["Student/Journalist Ill-treated in Jail"](https://web.archive.org/web/20070928055539/http://www.nearinternational.org/alerts/iran1320040317000000en.php). NEAR International. Archived from [the original](http://www.nearinternational.org/alerts/iran1320040317000000en.php) on 2007-09-28. Retrieved May 7, 2024.

[^18]: Lake, Eli (May 9, 2006). ["Iranian Dissident to Seek Support For Opposition"](https://web.archive.org/web/20210814010632/https://www.nysun.com/foreign/iranian-dissident-to-seek-support-for-opposition/32367/). *[The New York Sun](https://en.wikipedia.org/wiki/The_New_York_Sun "The New York Sun")*. Archived from [the original](https://www.nysun.com/foreign/iranian-dissident-to-seek-support-for-opposition/32367/) on August 14, 2021. Retrieved August 14, 2021.

[^19]: ["Like the Dead...Crushing of dissidents in Iran"](https://hrw.org/reports/2004/iran0604/5.htm). *hrw.org*. [Human Rights Watch](https://en.wikipedia.org/wiki/Human_Rights_Watch "Human Rights Watch"). June 2004.

[^20]: ["European Democratic Lawyers (EDL) statement on Guantanamo Bay and other detention centres"](https://www.statewatch.org/news/2004/july/statewatch-news-online-european-democratic-lawyers-edl-statement-on-guantanamo-bay-and-other-detention-centres/). *www.statewatch.org*. July 2004.

[^21]: [Guantanemo conditions 'worsening'](http://news.bbc.co.uk/2/hi/americas/6526589.stm). [BBC News](https://en.wikipedia.org/wiki/BBC_News "BBC News") April 4, 2007

[^22]: [US: Did President Bush Order Torture](https://hrw.org/english/docs/2004/12/21/usint9925.htm) Human Rights Watch, Dec. 21, 2004

[^23]: ["These Are The 13 'Enhanced Interrogation Techniques' The CIA Used On Detainees"](https://www.businessinsider.com/the-13-enhanced-interrogation-techniques-the-cia-used-on-detainees-2014-12). *Business Insider*. Associated Press. Retrieved 2019-08-21.

[^24]: [Mausfeld, Rainer](https://en.wikipedia.org/wiki/Rainer_Mausfeld "Rainer Mausfeld") (2009). ["Psychologie, 'weiße Folter' und die Verantwortlichkeit von Wissenschaftlern"](https://www.uni-kiel.de/psychologie/mausfeld/pubs/Mausfeld_Psychologie%20%27weisse%20Folter%27%20und%20die%20Verantwortlichkeit%20von%20Wissenschaftlern_2009.pdf) (PDF). *Psychologische Rundschau* (in German). **60** (4): 229–240. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1026/0033-3042.60.4.229](https://doi.org/10.1026%2F0033-3042.60.4.229). Retrieved 21 August 2019. Translated as ["Psychology, 'White Torture' and the Responsibility of Scientists"](https://www.uni-kiel.de/psychologie/mausfeld/pubs/Mausfeld_Psychology%20%27white%20torture%27%20and%20the%20responsibility%20of%20scientists_2009.pdf) (PDF). *Psychologische Rundschau*. Translated by Ekrol, Vebjörn. Retrieved 21 August 2019.

[^25]: ["Un calabozo macabro"](http://huelladigital.univisionnoticias.com/venezuela-los-rostros-de-la-represion/category/la-tumba/). [Univision](https://en.wikipedia.org/wiki/Univision "Univision"). 2015. Retrieved 28 July 2015.

[^26]: ["Statement of Santiago A. Canton Executive Director, RFK Partners for Human Rights Robert F. Kennedy Human Rights"](https://web.archive.org/web/20150729035041/http://www.foreign.senate.gov/imo/media/doc/031715_Canton_Testimony.pdf) (PDF). *[United States Senate](https://en.wikipedia.org/wiki/United_States_Senate "United States Senate")*. Archived from [the original](http://www.foreign.senate.gov/imo/media/doc/031715_Canton_Testimony.pdf) (PDF) on July 29, 2015. Retrieved 29 July 2015.

[^27]: ["Political protesters are left to rot in Venezuela's secretive underground prison"](https://web.archive.org/web/20151021131605/http://www.news.com.au/finance/economy/political-protesters-are-left-to-rot-in-venezuelas-secretive-underground-prison/story-fnu2pycd-1227457672139). [News.com.au](https://en.wikipedia.org/wiki/News.com.au "News.com.au"). 25 July 2015. Archived from [the original](http://www.news.com.au/finance/economy/political-protesters-are-left-to-rot-in-venezuelas-secretive-underground-prison/story-fnu2pycd-1227457672139) on 21 October 2015. Retrieved 29 July 2015.

[^28]: ["Visual Arts - Exhibitions and Artist Portraits - Goethe-Institut"](https://web.archive.org/web/20131202222437/http://www.goethe.de/kue/bku/kpa/en2192661.htm). 2013-12-02. Archived from [the original](http://www.goethe.de/kue/bku/kpa/en2192661.htm) on 2013-12-02. Retrieved 2023-05-12.

[^29]: ARTSGATE, [News](http://www.artsgate.net/us/actu.asp) [Archived](https://web.archive.org/web/20070202141725/http://www.artsgate.net/us/actu.asp) 2007-02-02 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), March 17, 2007.

[^30]: ["Twitter"](https://twitter.com/deangeorgaris/status/943675669204033536). *Twitter*. Retrieved 2021-11-22.

[^31]: ["The Brave – Desperate Measures"](http://starrymag.com/the-brave-desperate-measures/). 15 January 2018. Retrieved 2021-11-22.