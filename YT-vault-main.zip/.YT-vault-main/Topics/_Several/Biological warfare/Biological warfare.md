---
title: "Biological warfare"
source: "https://en.wikipedia.org/wiki/Biological_warfare"
---
![](https://en.wikipedia.org/wiki/File:U.S._Air_Force_Master_Sgt._Jess_V._Hernandez,_right,_assigned_to_the_119th_Maintenance_Squadron,_leads_Airmen_through_extreme_cold,_harsh_winds_and_snow_on_their_way_to_chemical_and_biological_warfare_training_080209-F-WA217-049.jpg)

U.S. Air Force Master Sgt. Jess V. Hernandez, right, assigned to the 119th Maintenance Squadron, leads Airmen through extreme cold, harsh winds and snow on their way to chemical and biological warfare training

**Biological warfare**, also known as **germ warfare**, is the use of [biological toxins](https://en.wikipedia.org/wiki/Biological_toxin "Biological toxin") or [infectious agents](https://en.wikipedia.org/wiki/Pathogen "Pathogen") such as [bacteria](https://en.wikipedia.org/wiki/Bacteria "Bacteria") (**bacteriological warfare**), [viruses](https://en.wikipedia.org/wiki/Virus "Virus"), [insects](https://en.wikipedia.org/wiki/Insects "Insects"), and [fungi](https://en.wikipedia.org/wiki/Fungus "Fungus") with the intent to kill, harm or incapacitate humans, animals or plants as an act of [war](https://en.wikipedia.org/wiki/War "War").[^1] [^2] [Biological weapons](https://en.wikipedia.org/wiki/Biological_agent "Biological agent") (often termed "bio-weapons", "biological threat agents", or "bio-agents") are living [organisms](https://en.wikipedia.org/wiki/Organism "Organism") or replicating entities (i.e. [viruses](https://en.wikipedia.org/wiki/Virus "Virus"), which are not universally considered "alive"). [Entomological (insect) warfare](https://en.wikipedia.org/wiki/Entomological_warfare "Entomological warfare") is a subtype of biological warfare.

Biological warfare is subject to a forceful [normative](https://en.wikipedia.org/wiki/Social_norm "Social norm") prohibition.[^3] [^4] Offensive biological warfare in international armed conflicts is a [war crime](https://en.wikipedia.org/wiki/War_crime "War crime") under the 1925 [Geneva Protocol](https://en.wikipedia.org/wiki/Geneva_Protocol "Geneva Protocol") and several [international humanitarian law](https://en.wikipedia.org/wiki/International_humanitarian_law "International humanitarian law") [treaties](https://en.wikipedia.org/wiki/Treaty "Treaty").[^5] [^6] In particular, the 1972 [Biological Weapons Convention](https://en.wikipedia.org/wiki/Biological_Weapons_Convention "Biological Weapons Convention") (BWC) bans the development, production, acquisition, transfer, stockpiling and use of biological weapons.[^7] [^8] In contrast, [defensive biological research](https://en.wikipedia.org/wiki/Biodefense "Biodefense") for prophylactic, protective or other peaceful purposes is not prohibited by the BWC.[^9]

Biological warfare is distinct from warfare involving other types of [weapons of mass destruction](https://en.wikipedia.org/wiki/Weapon_of_mass_destruction "Weapon of mass destruction") (WMD), including [nuclear warfare](https://en.wikipedia.org/wiki/Nuclear_warfare "Nuclear warfare"), [chemical warfare](https://en.wikipedia.org/wiki/Chemical_warfare "Chemical warfare"), and [radiological warfare](https://en.wikipedia.org/wiki/Radiological_warfare "Radiological warfare"). None of these are considered [conventional weapons](https://en.wikipedia.org/wiki/Conventional_weapons "Conventional weapons"), which are deployed primarily for their [explosive](https://en.wikipedia.org/wiki/Explosion "Explosion"), [kinetic](https://en.wikipedia.org/wiki/Kinetic_energy "Kinetic energy"), or [incendiary](https://en.wikipedia.org/wiki/Incendiary_device "Incendiary device") potential.

Biological weapons may be employed in various ways to gain a strategic or [tactical](https://en.wikipedia.org/wiki/Tactic_\(method\) "Tactic (method)") advantage over the enemy, either by threats or by actual deployments. Like some [chemical weapons](https://en.wikipedia.org/wiki/Chemical_weapon "Chemical weapon"), biological weapons may also be useful as [area denial weapons](https://en.wikipedia.org/wiki/Area_denial_weapon "Area denial weapon"). These agents may be lethal or [non-lethal](https://en.wikipedia.org/wiki/Non-lethal_weapon "Non-lethal weapon"), and may be targeted against a single individual, a group of people, or even an entire population. They may be developed, acquired, stockpiled or deployed by [nation states](https://en.wikipedia.org/wiki/Nation_state "Nation state") or by non-national groups. In the latter case, or if a nation-state uses it [clandestinely](https://en.wikipedia.org/wiki/Clandestine_operation "Clandestine operation"), it may also be considered [bioterrorism](https://en.wikipedia.org/wiki/Bioterrorism "Bioterrorism").[^10]

Biological warfare and chemical warfare overlap to an extent, as the use of [toxins](https://en.wikipedia.org/wiki/Toxin "Toxin") produced by some living organisms is considered under the provisions of both the BWC and the [Chemical Weapons Convention](https://en.wikipedia.org/wiki/Chemical_Weapons_Convention "Chemical Weapons Convention"). Toxins and [psychochemical weapons](https://en.wikipedia.org/wiki/Psychochemical_warfare "Psychochemical warfare") are often referred to as *mid spectrum agents*. Unlike bioweapons, these midspectrum agents do not reproduce in their host and are typically characterized by shorter incubation periods.[^11]

## Overview

A biological attack could conceivably result in large numbers of [civilian casualties](https://en.wikipedia.org/wiki/Civilian_casualties "Civilian casualties") and cause severe disruption to economic and societal infrastructure.[^12]

A nation or group that can pose a credible threat of mass casualty has the ability to alter the terms under which other nations or groups interact with it. When indexed to weapon mass and cost of development and storage, biological weapons possess destructive potential and loss of life far in excess of nuclear, chemical or conventional weapons. Accordingly, biological agents are potentially useful as strategic deterrents, in addition to their utility as offensive weapons on the battlefield.[^13]

As a tactical weapon for military use, a significant problem with biological warfare is that it would take days to be effective, and therefore might not immediately stop an opposing force. Some biological agents ([smallpox](https://en.wikipedia.org/wiki/Smallpox "Smallpox"), [pneumonic plague](https://en.wikipedia.org/wiki/Pneumonic_plague "Pneumonic plague")) have the capability of person-to-person [transmission](https://en.wikipedia.org/wiki/Transmission_\(medicine\) "Transmission (medicine)") via [aerosolized](https://en.wikipedia.org/wiki/Bioaerosol "Bioaerosol") [respiratory droplets](https://en.wikipedia.org/wiki/Respiratory_droplet "Respiratory droplet"). This feature can be undesirable, as the agent(s) may be transmitted by this mechanism to unintended populations, including neutral or even friendly forces. Worse still, such a weapon could "escape" the laboratory where it was developed, even if there was no intent to use it – for example by infecting a researcher who then transmits it to the outside world before realizing that they were infected. Several cases are known of researchers becoming infected and dying of [Ebola](https://en.wikipedia.org/wiki/Ebola "Ebola"),[^14] [^15] which they had been working with in the lab (though nobody else was infected in those cases) – though there is no evidence that their work was directed towards biological warfare.

## History

### Antiquity and Middle Ages

Rudimentary forms of biological warfare have been practiced since antiquity.[^16] The earliest documented incident of the intention to use biological weapons is recorded in [Hittite](https://en.wikipedia.org/wiki/Hittite_language "Hittite language") texts of 1500–1200 BC, in which victims of an [unknown plague](https://en.wikipedia.org/wiki/Hittite_plague "Hittite plague") (possibly [tularemia](https://en.wikipedia.org/wiki/Tularemia "Tularemia")) were driven into enemy lands, causing an epidemic.[^17] The Assyrians poisoned enemy wells with the fungus [ergot](https://en.wikipedia.org/wiki/Ergot "Ergot"), though with unknown results. [Scythian](https://en.wikipedia.org/wiki/Scythians "Scythians") archers dipped their arrows and Roman soldiers their swords into excrements and cadavers – victims were commonly infected by [tetanus](https://en.wikipedia.org/wiki/Tetanus "Tetanus") as result.[^18] In 1346, the bodies of [Mongol](https://en.wikipedia.org/wiki/Mongol "Mongol") warriors of the [Golden Horde](https://en.wikipedia.org/wiki/Golden_Horde "Golden Horde") who had died of [plague](https://en.wikipedia.org/wiki/Plague_\(disease\) "Plague (disease)") were thrown over the walls of the [besieged Crimean city of Kaffa](https://en.wikipedia.org/wiki/Siege_of_Caffa "Siege of Caffa"). Specialists disagree about whether this operation was responsible for the spread of the [Black Death](https://en.wikipedia.org/wiki/Black_Death "Black Death") into Europe, Near East and North Africa, resulting in the deaths of approximately 25 million Europeans.[^19] [^20] [^21] [^22]

Biological agents were extensively used in many parts of Africa from the sixteenth century AD, most of the time in the form of poisoned arrows, or powder spread on the war front as well as poisoning of horses and water supply of the enemy forces.[^23] [^24] In [Borgu](https://en.wikipedia.org/wiki/Borgu "Borgu"), there were specific mixtures to kill, [hypnotize](https://en.wikipedia.org/wiki/Hypnosis "Hypnosis"), make the enemy bold, and to act as an antidote against the poison of the enemy as well. The creation of biologicals was reserved for a specific and professional class of medicine-men.[^24]

### 18th to 19th century

During the [French and Indian War](https://en.wikipedia.org/wiki/French_and_Indian_War "French and Indian War"), in June 1763 a group of [Native Americans](https://en.wikipedia.org/wiki/Native_Americans_in_the_United_States "Native Americans in the United States") laid [siege](https://en.wikipedia.org/wiki/Siege_of_Fort_Pitt "Siege of Fort Pitt") to British-held [Fort Pitt](https://en.wikipedia.org/wiki/Fort_Pitt_\(Pennsylvania\) "Fort Pitt (Pennsylvania)").[^25] Following instructions of his superior, Colonel [Henry Bouquet](https://en.wikipedia.org/wiki/Henry_Bouquet "Henry Bouquet"), the commander of Fort Pitt, [Swiss-born](https://en.wikipedia.org/wiki/Switzerland "Switzerland") Captain Simeon Ecuyer, ordered his men to take smallpox-infested blankets from the infirmary and give it to a Lenape delegation during the siege.[^26] [^27] [^28] A reported outbreak that began the spring before left as many as one hundred Native Americans dead in [Ohio Country](https://en.wikipedia.org/wiki/Ohio_Country "Ohio Country") from 1763 to 1764. It is not clear whether the smallpox was a result of the Fort Pitt incident or the virus was already present among the [Delaware people](https://en.wikipedia.org/wiki/Lenape "Lenape") as outbreaks happened on their own every dozen or so years [^29] and the delegates were met again later and seemingly had not contracted smallpox.[^30] [^31] [^32] During the [American Revolutionary War](https://en.wikipedia.org/wiki/American_Revolutionary_War "American Revolutionary War"), [Continental Army](https://en.wikipedia.org/wiki/Continental_Army "Continental Army") officer [George Washington](https://en.wikipedia.org/wiki/George_Washington "George Washington") mentioned to the [Continental Congress](https://en.wikipedia.org/wiki/Continental_Congress "Continental Congress") that he had heard a rumor from a sailor that his opponent during the [Siege of Boston](https://en.wikipedia.org/wiki/Siege_of_Boston "Siege of Boston"), General [William Howe](https://en.wikipedia.org/wiki/William_Howe,_5th_Viscount_Howe "William Howe, 5th Viscount Howe"), had deliberately sent civilians out of the city in the hopes of spreading the [ongoing smallpox epidemic](https://en.wikipedia.org/wiki/1775%E2%80%931782_North_American_smallpox_epidemic "1775–1782 North American smallpox epidemic") to American lines; Washington, remaining unconvinced, wrote that he "could hardly give credit to" the claim. Washington had already inoculated his soldiers, diminishing the effect of the epidemic.[^33] [^34] Some historians have claimed that a detachment of the [Corps of Royal Marines](https://en.wikipedia.org/wiki/Royal_Marines "Royal Marines") stationed in [New South Wales](https://en.wikipedia.org/wiki/New_South_Wales "New South Wales"), Australia, deliberately used [smallpox](https://en.wikipedia.org/wiki/Smallpox "Smallpox") there in 1789.[^35] Dr Seth Carus states: "Ultimately, we have a strong circumstantial case supporting the theory that someone deliberately introduced smallpox in the Aboriginal population." [^36]

### World War I

By 1900 the [germ theory](https://en.wikipedia.org/wiki/Germ_theory "Germ theory") and advances in [bacteriology](https://en.wikipedia.org/wiki/Bacteriology "Bacteriology") brought a new level of sophistication to the techniques for possible use of [bio-agents](https://en.wikipedia.org/wiki/Bio-agent "Bio-agent") in war. Biological sabotage in the form of [anthrax](https://en.wikipedia.org/wiki/Anthrax "Anthrax") and [glanders](https://en.wikipedia.org/wiki/Glanders "Glanders") was undertaken on behalf of the [Imperial German](https://en.wikipedia.org/wiki/German_Empire "German Empire") government during [World War I](https://en.wikipedia.org/wiki/World_War_I "World War I") (1914–1918), with indifferent results.[^37] The [Geneva Protocol](https://en.wikipedia.org/wiki/Geneva_Protocol "Geneva Protocol") of 1925 prohibited the first use of chemical and biological weapons against enemy nationals in international armed conflicts.[^38]

### World War II

With the onset of [World War II](https://en.wikipedia.org/wiki/World_War_II "World War II"), the [Ministry of Supply](https://en.wikipedia.org/wiki/Ministry_of_Supply "Ministry of Supply") in the [United Kingdom](https://en.wikipedia.org/wiki/United_Kingdom "United Kingdom") established a biological warfare program at [Porton Down](https://en.wikipedia.org/wiki/Porton_Down "Porton Down"), headed by the microbiologist [Paul Fildes](https://en.wikipedia.org/wiki/Paul_Fildes "Paul Fildes"). The research was championed by [Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill "Winston Churchill") and soon [tularemia](https://en.wikipedia.org/wiki/Tularemia "Tularemia"), [anthrax](https://en.wikipedia.org/wiki/Anthrax_disease "Anthrax disease"), [brucellosis](https://en.wikipedia.org/wiki/Brucellosis "Brucellosis"), and [botulism](https://en.wikipedia.org/wiki/Botulism "Botulism") toxins had been effectively weaponized. In particular, [Gruinard Island](https://en.wikipedia.org/wiki/Gruinard_Island "Gruinard Island") in Scotland, was contaminated with anthrax during a series of extensive tests for the next 56 years. Although the UK never offensively used the biological weapons it developed, its program was the first to successfully weaponize a variety of deadly pathogens and bring them into industrial production.[^39] Other nations, notably France and Japan, had begun their own biological weapons programs.[^40]

When the United States entered the war, Allied resources were pooled at the request of the British. The US then established a large research program and industrial complex at [Fort Detrick, Maryland](https://en.wikipedia.org/wiki/Fort_Detrick,_Maryland "Fort Detrick, Maryland"), in 1942 under the direction of [George W. Merck](https://en.wikipedia.org/wiki/George_W._Merck "George W. Merck").[^41] The biological and chemical weapons developed during that period were tested at the [Dugway Proving Grounds](https://en.wikipedia.org/wiki/Dugway_Proving_Grounds "Dugway Proving Grounds") in [Utah](https://en.wikipedia.org/wiki/Utah "Utah"). Soon there were facilities for the mass production of anthrax spores, [brucellosis](https://en.wikipedia.org/wiki/Brucellosis "Brucellosis"), and [botulism](https://en.wikipedia.org/wiki/Botulism "Botulism") toxins, although the war was over before these weapons could be of much operational use.[^42]

![](https://en.wikipedia.org/wiki/File:Shiro-ishii.jpg)

Shirō Ishii, commander of Unit 731, which performed human vivisections and other biological experimentation

The most notorious program of the period was run by the secret [Imperial Japanese Army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army") [Unit 731](https://en.wikipedia.org/wiki/Unit_731 "Unit 731") during the [war](https://en.wikipedia.org/wiki/Sino-Japanese_War_\(1937%E2%80%931945\) "Sino-Japanese War (1937–1945)"), based at [Pingfang](https://en.wikipedia.org/wiki/Pingfang "Pingfang") in [Manchuria](https://en.wikipedia.org/wiki/Manchuria "Manchuria") and commanded by Lieutenant General [Shirō Ishii](https://en.wikipedia.org/wiki/Shir%C5%8D_Ishii "Shirō Ishii"). This biological warfare research unit conducted often fatal [human experiments](https://en.wikipedia.org/wiki/Human_experimentation "Human experimentation") on prisoners, and produced biological weapons for combat use.[^43] Although the Japanese effort lacked the technological sophistication of the American or British programs, it far outstripped them in its widespread application and indiscriminate brutality. Biological weapons were used against Chinese soldiers and civilians in several military campaigns.[^44] In 1940, the Japanese Army Air Force bombed [Ningbo](https://en.wikipedia.org/wiki/Ningbo "Ningbo") with ceramic bombs full of fleas carrying the [bubonic plague](https://en.wikipedia.org/wiki/Bubonic_plague "Bubonic plague").[^45] Many of these operations were ineffective due to inefficient delivery systems,[^43] although up to 200,000 people may have died.[^46] During the [Zhejiang-Jiangxi Campaign](https://en.wikipedia.org/wiki/Zhejiang-Jiangxi_Campaign "Zhejiang-Jiangxi Campaign") in 1942, around 1,700 Japanese troops died out of a total 10,000 Japanese soldiers who fell ill with disease when their own biological weapons attack rebounded on their own forces.[^47] [^48]

During the final months of World War II, Japan planned to use plague as a biological weapon against US civilians in [San Diego](https://en.wikipedia.org/wiki/San_Diego "San Diego"), [California](https://en.wikipedia.org/wiki/California "California"), during [Operation Cherry Blossoms at Night](https://en.wikipedia.org/wiki/Operation_Cherry_Blossoms_at_Night "Operation Cherry Blossoms at Night"). The plan was set to launch on 22 September 1945, but it was not executed because of [Japan's surrender](https://en.wikipedia.org/wiki/Japan's_surrender "Japan's surrender") on 15 August 1945.[^49] [^50] [^51]

### Arab–Israeli conflict

According to historians [Benny Morris](https://en.wikipedia.org/wiki/Benny_Morris "Benny Morris") and [Benjamin Kedar](https://en.wikipedia.org/wiki/Benjamin_Kedar "Benjamin Kedar"), Israel conducted a biological warfare operation codenamed [Operation Cast Thy Bread](https://en.wikipedia.org/wiki/Operation_Cast_Thy_Bread "Operation Cast Thy Bread") during the [1948 Arab–Israeli War](https://en.wikipedia.org/wiki/1948_Arab%E2%80%93Israeli_War "1948 Arab–Israeli War"). The Haganah initially used [typhoid bacteria](https://en.wikipedia.org/wiki/Typhoid_bacteria "Typhoid bacteria") to contaminate water wells in newly cleared Arab villages to prevent the population including militiamen from returning. Later, the biological warfare campaign expanded to include Jewish settlements that were in imminent danger of being captured by Arab troops and inhabited Arab towns not slated for capture. There was also plans to expand the biological warfare campaign into other Arab states including Egypt, Lebanon and Syria, but they were not carried out.[^52]

Some British soldiers were also poisoned: causing the event to gain international attention.[^53]

Later, in the 1970s, Israel [poisoned](https://en.wikipedia.org/wiki/Poison "Poison") Palestinian land in the [West Bank](https://en.wikipedia.org/wiki/West_Bank "West Bank") so they could establish [Israeli settlements](https://en.wikipedia.org/wiki/Israeli_settlement "Israeli settlement").[^54]

### Cold War

In Britain, the 1950s saw the weaponization of [plague](https://en.wikipedia.org/wiki/Bubonic_plague "Bubonic plague"), [brucellosis](https://en.wikipedia.org/wiki/Brucellosis "Brucellosis"), [tularemia](https://en.wikipedia.org/wiki/Tularemia "Tularemia") and later [equine encephalomyelitis](https://en.wikipedia.org/wiki/Eastern_equine_encephalitis_virus "Eastern equine encephalitis virus") and [vaccinia](https://en.wikipedia.org/wiki/Vaccinia "Vaccinia") viruses, but the programme was unilaterally cancelled in 1956. The [United States Army Biological Warfare Laboratories](https://en.wikipedia.org/wiki/United_States_Army_Biological_Warfare_Laboratories "United States Army Biological Warfare Laboratories") weaponized [anthrax](https://en.wikipedia.org/wiki/Anthrax "Anthrax"), [tularemia](https://en.wikipedia.org/wiki/Tularemia "Tularemia"), [brucellosis](https://en.wikipedia.org/wiki/Brucellosis "Brucellosis"), [Q-fever](https://en.wikipedia.org/wiki/Q-fever "Q-fever") and others.[^55]

In 1969, US President [Richard Nixon](https://en.wikipedia.org/wiki/Richard_Nixon "Richard Nixon") decided to [unilaterally terminate](https://en.wikipedia.org/wiki/Statement_on_Chemical_and_Biological_Defense_Policies_and_Programs "Statement on Chemical and Biological Defense Policies and Programs") the [offensive biological weapons program of the US](https://en.wikipedia.org/wiki/United_States_biological_weapons_program "United States biological weapons program"), allowing only scientific research for defensive measures.[^56] This decision increased the momentum of the negotiations for a ban on biological warfare, which took place from 1969 to 1972 in the United Nations' [Conference of the Committee on Disarmament](https://en.wikipedia.org/wiki/Conference_of_the_Committee_on_Disarmament "Conference of the Committee on Disarmament") in Geneva.[^57] These negotiations resulted in the [Biological Weapons Convention](https://en.wikipedia.org/wiki/Biological_Weapons_Convention "Biological Weapons Convention"), which was opened for signature on 10 April 1972 and entered into force on 26 March 1975 after its ratification by 22 states.[^57]

Despite being a party and depositary to the BWC, the [Soviet Union](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union") continued and expanded its massive [offensive biological weapons program](https://en.wikipedia.org/wiki/Soviet_biological_weapons_program "Soviet biological weapons program"), under the leadership of the allegedly civilian institution [Biopreparat](https://en.wikipedia.org/wiki/Biopreparat "Biopreparat").[^58] The Soviet Union attracted international suspicion after the 1979 [Sverdlovsk anthrax leak](https://en.wikipedia.org/wiki/Sverdlovsk_anthrax_leak "Sverdlovsk anthrax leak") killed approximately 65 to 100 people.[^59]

## International law

![](https://en.wikipedia.org/wiki/File:Biological_Weapons_Convention_original_document.png)

The Biological Weapons Convention 60

International restrictions on biological warfare began with the 1925 [Geneva Protocol](https://en.wikipedia.org/wiki/Geneva_Protocol "Geneva Protocol"), which prohibits the use but not the possession or development of biological and chemical weapons in international armed conflicts.[^38] [^61] Upon ratification of the Geneva Protocol, several countries made [reservations](https://en.wikipedia.org/wiki/Reservation_\(law\) "Reservation (law)") regarding its applicability and use in retaliation.[^62] Due to these reservations, it was in practice a " [no-first-use](https://en.wikipedia.org/wiki/No_first_use "No first use") " agreement only.[^63]

The 1972 [Biological Weapons Convention](https://en.wikipedia.org/wiki/Biological_Weapons_Convention "Biological Weapons Convention") (BWC) supplements the Geneva Protocol by prohibiting the development, production, acquisition, transfer, stockpiling and use of biological weapons.[^7] Having entered into force on 26 March 1975, the BWC was the first multilateral disarmament treaty to ban the production of an entire category of weapons of mass destruction.[^7] As of March 2021, [183 states have become party to the treaty](https://en.wikipedia.org/wiki/List_of_parties_to_the_Biological_Weapons_Convention "List of parties to the Biological Weapons Convention").[^64] The BWC is considered to have established a strong global norm against biological weapons,[^65] which is reflected in the treaty's preamble, stating that the use of biological weapons would be "repugnant to the conscience of mankind".[^66] The BWC's effectiveness has been limited due to insufficient institutional support and the absence of any formal verification regime to monitor compliance.[^67]

In 1985, the [Australia Group](https://en.wikipedia.org/wiki/Australia_Group "Australia Group") was established, a multilateral export control regime of 43 countries aiming to prevent the proliferation of chemical and biological weapons.[^68]

In 2004, the [United Nations Security Council](https://en.wikipedia.org/wiki/United_Nations_Security_Council "United Nations Security Council") passed [Resolution 1540](https://en.wikipedia.org/wiki/United_Nations_Security_Council_Resolution_1540 "United Nations Security Council Resolution 1540"), which obligates all UN Member States to develop and enforce appropriate legal and regulatory measures against the proliferation of [chemical](https://en.wikipedia.org/wiki/Chemical_weapon "Chemical weapon"), biological, [radiological](https://en.wikipedia.org/wiki/Radiological_weapon "Radiological weapon"), and [nuclear weapons](https://en.wikipedia.org/wiki/Nuclear_weapon "Nuclear weapon") and their means of delivery, in particular, to prevent the spread of weapons of mass destruction to [non-state actors](https://en.wikipedia.org/wiki/Non-state_actor "Non-state actor").[^69]

## Bioterrorism

Biological weapons are difficult to detect, economical and easy to use, making them appealing to terrorists. The cost of a biological weapon is estimated to be about 0.05 percent the cost of a conventional weapon in order to produce similar numbers of mass casualties per kilometer square.[^70] Moreover, their production is very easy as common technology can be used to produce biological warfare agents, like that used in production of vaccines, foods, spray devices, beverages and antibiotics. A major factor in biological warfare that attracts terrorists is that they can easily escape before the government agencies or secret agencies have even started their investigation. This is because the potential organism has an incubation period of 3 to 7 days, after which the results begin to appear, thereby giving terrorists a lead.

A technique called Clustered, Regularly Interspaced, Short Palindromic Repeat ([CRISPR-Cas9](https://en.wikipedia.org/wiki/CRISPR-Cas9 "CRISPR-Cas9")) is now so cheap and widely available that scientists fear that amateurs will start experimenting with them. In this technique, a DNA sequence is cut off and replaced with a new sequence, e.g. one that codes for a particular protein, with the intent of modifying an organism's traits. Concerns have emerged regarding do-it-yourself biology research organizations due to their associated risk that a rogue amateur DIY researcher could attempt to develop dangerous bioweapons using genome editing technology.[^71]

In 2002, when CNN went through Al-Qaeda's (AQ's) experiments with crude poisons, they found out that AQ had begun planning ricin and cyanide attacks with the help of a loose association of terrorist cells.[^72] The associates had infiltrated many countries like Turkey, Italy, Spain, France and others. In 2015, to combat the threat of bioterrorism, a National Blueprint for Biodefense was issued by the Blue-Ribbon Study Panel on Biodefense.[^73] Also, 233 potential exposures of select biological agents outside of the primary barriers of the biocontainment in the US were described by the annual report of the Federal Select Agent Program.[^74]

Though a verification system can reduce bioterrorism, an employee, or a lone terrorist having adequate knowledge of a bio-technology company's facilities, can cause potential danger by using, without proper oversight and supervision, that company's resources. Moreover, it has been found that about 95% of accidents that have occurred due to low security have been done by employees or those who had a security clearance.[^75]

## Entomology

Entomological warfare (EW) is a type of biological warfare that uses insects to attack the enemy. The concept has existed for centuries and research and development have continued into the modern era. EW has been used in battle by Japan and several other nations have developed and been accused of using an entomological warfare program. EW may employ insects in a direct attack or as vectors to deliver a [biological agent](https://en.wikipedia.org/wiki/Biological_agent "Biological agent"), such as [plague](https://en.wikipedia.org/wiki/Plague_\(disease\) "Plague (disease)"). Essentially, EW exists in three varieties. One type of EW involves infecting insects with a [pathogen](https://en.wikipedia.org/wiki/Pathogen "Pathogen") and then dispersing the insects over target areas.[^76] The insects then act as a [vector](https://en.wikipedia.org/wiki/Vector_\(epidemiology\) "Vector (epidemiology)"), infecting any person or animal they might bite. Another type of EW is a direct insect attack against crops; the insect may not be infected with any pathogen but instead represents a threat to agriculture. The final method uses uninfected insects, such as bees or wasps, to directly attack the enemy.[^77]

## Genetics

Theoretically, novel approaches in biotechnology, such as synthetic biology could be used in the future to design novel types of biological warfare agents.[^78] [^79] [^80] [^81]

1. Would demonstrate how to render a vaccine ineffective;
2. Would confer resistance to therapeutically useful antibiotics or antiviral agents;
3. Would enhance the virulence of a pathogen or render a nonpathogen virulent;
4. Would increase the transmissibility of a pathogen;
5. Would alter the host range of a pathogen;
6. Would enable the evasion of diagnostic/detection tools;
7. Would enable the weaponization of a biological agent or toxin.

Most of the biosecurity concerns in synthetic biology are focused on the role of DNA synthesis and the risk of producing genetic material of lethal viruses (e.g. 1918 Spanish flu, polio) in the lab.[^82] [^83] [^84] Recently, the [CRISPR/Cas system](https://en.wikipedia.org/wiki/CRISPR_gene_editing "CRISPR gene editing") has emerged as a promising technique for gene editing. It was hailed by The Washington Post as "the most important innovation in the synthetic biology space in nearly 30 years." [^85] While other methods take months or years to edit gene sequences, CRISPR speeds that time up to weeks.[^7] Due to its ease of use and accessibility, it has raised a number of ethical concerns, especially surrounding its use in the biohacking space.[^85] [^86] [^87]

Synthetic biology provides the technical capacity to fundamentally alter the bioweapons landscape by enabling the reconstitution of an eradicated or extinct human pathogen. Reports highlight the immediate security concern of "re-creating known pathogen viruses". This capability drastically lowers the barrier to entry for acquiring highly dangerous agents. The deliberate synthesis of the Horsepox virus, an Orthopoxvirus, from commercially acquired DNA segments, stands as a critical academic demonstration of this dual-use capability. This experiment proved that highly complex pox viruses could be engineered.[^88] [^89]

## By target

### Anti-personnel

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c0/Biohazard_symbol.svg/250px-Biohazard_symbol.svg.png?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

The international biological hazard symbol

Ideal characteristics of a biological agent to be used as a weapon against humans are high [infectivity](https://en.wikipedia.org/wiki/Infectivity "Infectivity"), high [virulence](https://en.wikipedia.org/wiki/Virulence "Virulence"), non-availability of [vaccines](https://en.wikipedia.org/wiki/Vaccine "Vaccine") and availability of an effective and efficient [delivery system](https://en.wikipedia.org/wiki/Delivery_system "Delivery system"). Stability of the weaponized agent (the ability of the agent to retain its infectivity and virulence after a prolonged period of storage) may also be desirable, particularly for military applications, and the ease of creating one is often considered. Control of the spread of the agent may be another desired characteristic.

The primary difficulty is not the production of the biological agent, as many biological agents used in weapons can be manufactured relatively quickly, cheaply and easily. Rather, it is the weaponization, storage, and delivery in an effective vehicle to a vulnerable target that pose significant problems.

For example, *[Bacillus anthracis](https://en.wikipedia.org/wiki/Bacillus_anthracis "Bacillus anthracis")* is considered an effective agent for several reasons. First, it forms hardy [spores](https://en.wikipedia.org/wiki/Spore "Spore"), perfect for dispersal aerosols. Second, this organism is not considered transmissible from person to person, and thus rarely if ever causes secondary infections. A pulmonary anthrax infection starts with ordinary [influenza](https://en.wikipedia.org/wiki/Influenza "Influenza") -like symptoms and progresses to a lethal [hemorrhagic](https://en.wikipedia.org/wiki/Hemorrhagic "Hemorrhagic") [mediastinitis](https://en.wikipedia.org/wiki/Mediastinitis "Mediastinitis") within 3–7 days, with a fatality rate that is 90% or higher in untreated patients.[^90] Finally, friendly personnel and civilians can be protected with suitable [antibiotics](https://en.wikipedia.org/wiki/Antibiotic "Antibiotic").

Agents considered for weaponization, or known to be weaponized, include bacteria such as *Bacillus anthracis*, *[Brucella](https://en.wikipedia.org/wiki/Brucella "Brucella")* spp., *[Burkholderia mallei](https://en.wikipedia.org/wiki/Burkholderia_mallei "Burkholderia mallei")*, *[Burkholderia pseudomallei](https://en.wikipedia.org/wiki/Burkholderia_pseudomallei "Burkholderia pseudomallei")*, *[Chlamydophila psittaci](https://en.wikipedia.org/wiki/Chlamydophila_psittaci "Chlamydophila psittaci")*, *[Coxiella burnetii](https://en.wikipedia.org/wiki/Coxiella_burnetii "Coxiella burnetii")*, *[Francisella tularensis](https://en.wikipedia.org/wiki/Francisella_tularensis "Francisella tularensis")*, some of the [Rickettsiaceae](https://en.wikipedia.org/wiki/Rickettsiaceae "Rickettsiaceae") (especially *[Rickettsia prowazekii](https://en.wikipedia.org/wiki/Rickettsia_prowazekii "Rickettsia prowazekii")* and *[Rickettsia rickettsii](https://en.wikipedia.org/wiki/Rickettsia_rickettsii "Rickettsia rickettsii")*), *[Shigella](https://en.wikipedia.org/wiki/Shigella "Shigella")* spp., *[Vibrio cholerae](https://en.wikipedia.org/wiki/Vibrio_cholerae "Vibrio cholerae")*, and *[Yersinia pestis](https://en.wikipedia.org/wiki/Yersinia_pestis "Yersinia pestis")*. Many viral agents have been studied and weaponized, including some of the [Bunyaviridae](https://en.wikipedia.org/wiki/Bunyaviridae "Bunyaviridae") (especially [Rift Valley fever virus](https://en.wikipedia.org/wiki/Rift_Valley_fever "Rift Valley fever")), [Ebolavirus](https://en.wikipedia.org/wiki/Ebola "Ebola"), many of the [Flaviviridae](https://en.wikipedia.org/wiki/Flaviviridae "Flaviviridae") (especially [Japanese encephalitis virus](https://en.wikipedia.org/wiki/Japanese_encephalitis "Japanese encephalitis")), [Machupo virus](https://en.wikipedia.org/wiki/Bolivian_hemorrhagic_fever "Bolivian hemorrhagic fever"), [Coronaviruses](https://en.wikipedia.org/wiki/Coronaviruses "Coronaviruses"), [Marburg virus](https://en.wikipedia.org/wiki/Marburg_virus "Marburg virus"), Variola virus, and [yellow fever virus](https://en.wikipedia.org/wiki/Yellow_fever "Yellow fever"). Fungal agents that have been studied include *[Coccidioides](https://en.wikipedia.org/wiki/Coccidioides "Coccidioides")* spp.[^58] [^91]

Toxins that can be used as weapons include [ricin](https://en.wikipedia.org/wiki/Ricin "Ricin"), [staphylococcal enterotoxin B](https://en.wikipedia.org/wiki/Staphylococcal_Enterotoxin_B "Staphylococcal Enterotoxin B"), [botulinum toxin](https://en.wikipedia.org/wiki/Botulinum_toxin "Botulinum toxin"), [saxitoxin](https://en.wikipedia.org/wiki/Saxitoxin "Saxitoxin"), and many [mycotoxins](https://en.wikipedia.org/wiki/Mycotoxin "Mycotoxin"). These toxins and the organisms that produce them are sometimes referred to as [select agents](https://en.wikipedia.org/wiki/Select_agent "Select agent"). In the United States, their possession, use, and transfer are regulated by the [Centers for Disease Control and Prevention](https://en.wikipedia.org/wiki/Centers_for_Disease_Control_and_Prevention "Centers for Disease Control and Prevention") 's Select Agent Program.

The former [US biological warfare program](https://en.wikipedia.org/wiki/US_biological_warfare_program "US biological warfare program") categorized its weaponized anti-personnel bio-agents as either **Lethal Agents** (*Bacillus anthracis*, *Francisella tularensis*, Botulinum toxin) or **Incapacitating Agents** (*Brucella suis*, *Coxiella burnetii*, Venezuelan equine encephalitis virus, Staphylococcal enterotoxin B).

### Anti-agriculture

#### Anti-crop/anti-vegetation/anti-fisheries

The United States developed an anti-crop capability during the [Cold War](https://en.wikipedia.org/wiki/Cold_War "Cold War") that used plant diseases ([bioherbicides](https://en.wikipedia.org/wiki/Bioherbicide "Bioherbicide"), or [mycoherbicides](https://en.wikipedia.org/wiki/Mycoherbicide "Mycoherbicide")) for destroying enemy agriculture. Biological weapons also target fisheries as well as water-based vegetation. It was believed that the destruction of enemy agriculture on a strategic scale could thwart [Sino-Soviet](https://en.wikipedia.org/wiki/Sino-Soviet_relations "Sino-Soviet relations") aggression in a general war. Diseases such as [wheat blast](https://en.wikipedia.org/wiki/Wheat_blast "Wheat blast") and [rice blast](https://en.wikipedia.org/wiki/Rice_blast "Rice blast") were weaponized in aerial spray tanks and cluster bombs for delivery to enemy watersheds in agricultural regions to initiate epiphytotic (epidemics among plants). On the other hand, some sources report that these agents were *stockpiled* but never *weaponized*.[^92] When the United States renounced its offensive biological warfare program in 1969 and 1970, the vast majority of its biological arsenal was composed of these plant diseases.[^93] Enterotoxins and Mycotoxins were not affected by Nixon's order.

Though herbicides are chemicals, they are often grouped with biological warfare and chemical warfare because they may work in a similar manner as [biotoxins](https://en.wikipedia.org/wiki/Biotoxin "Biotoxin") or bioregulators. The Army Biological Laboratory tested each agent and the Army's Technical Escort Unit was responsible for the transport of all chemical, biological, radiological (nuclear) materials.

Biological warfare can also specifically target plants to destroy crops or defoliate vegetation. The United States and Britain discovered plant growth regulators (i.e., [herbicides](https://en.wikipedia.org/wiki/Herbicide "Herbicide")) during the Second World War, which were then used by the UK in the counterinsurgency operations of the [Malayan Emergency](https://en.wikipedia.org/wiki/Malayan_Emergency "Malayan Emergency"). Inspired by the use in Malaysia, the US military effort in the [Vietnam War](https://en.wikipedia.org/wiki/Vietnam_War "Vietnam War") included a [mass dispersal](https://en.wikipedia.org/wiki/Operation_Ranch_Hand "Operation Ranch Hand") of a [variety of herbicides](https://en.wikipedia.org/wiki/Rainbow_Herbicides "Rainbow Herbicides"), famously [Agent Orange](https://en.wikipedia.org/wiki/Agent_Orange "Agent Orange"), with the aim of destroying farmland and defoliating forests used as cover by the [Viet Cong](https://en.wikipedia.org/wiki/Viet_Cong "Viet Cong").[^94] Sri Lanka deployed military defoliants in its prosecution of the [Eelam War](https://en.wikipedia.org/wiki/Sri_Lankan_civil_war "Sri Lankan civil war") against Tamil insurgents.[^95]

#### Anti-livestock

During World War I, German saboteurs used [anthrax](https://en.wikipedia.org/wiki/Anthrax "Anthrax") and [glanders](https://en.wikipedia.org/wiki/Glanders "Glanders") to sicken cavalry horses in US and France, sheep in Romania, and livestock in Argentina intended for the [Entente forces](https://en.wikipedia.org/wiki/Entente_forces "Entente forces").[^96] One of these German saboteurs was [Anton Dilger](https://en.wikipedia.org/wiki/Anton_Dilger "Anton Dilger"). Also, Germany itself became a victim of similar attacks – horses bound for Germany were infected with [Burkholderia](https://en.wikipedia.org/wiki/Burkholderia "Burkholderia") by French operatives in Switzerland.[^97]

During World War II, the US and Canada secretly investigated the use of [rinderpest](https://en.wikipedia.org/wiki/Rinderpest "Rinderpest"), a highly lethal disease of cattle, as a bioweapon.[^96] [^98]

In the 1980s Soviet Ministry of Agriculture had successfully developed variants of [foot-and-mouth disease](https://en.wikipedia.org/wiki/Foot-and-mouth_disease "Foot-and-mouth disease"), and [rinderpest](https://en.wikipedia.org/wiki/Rinderpest "Rinderpest") against cows, [African swine fever](https://en.wikipedia.org/wiki/African_swine_fever "African swine fever") for pigs, and [psittacosis](https://en.wikipedia.org/wiki/Psittacosis "Psittacosis") for chickens. These agents were prepared to spray them down from tanks attached to airplanes over hundreds of miles. The secret program was code-named "Ecology".[^58]

During the [Mau Mau Uprising](https://en.wikipedia.org/wiki/Mau_Mau_Uprising "Mau Mau Uprising") in 1952, the poisonous [latex](https://en.wikipedia.org/wiki/Latex "Latex") of the [African milk bush](https://en.wikipedia.org/wiki/Euphorbia_grantii "Euphorbia grantii") was used to kill cattle.[^99]

## Defensive operations

### Medical countermeasures

In 2010 at The Meeting of the States Parties to the Convention on the Prohibition of the Development, Production and Stockpiling of Bacteriological (Biological) and Toxin Weapons and Their Destruction in [Geneva](https://en.wikipedia.org/wiki/Geneva "Geneva") [^100] the [sanitary epidemiological reconnaissance](https://en.wikipedia.org/wiki/Sanitary_epidemiological_reconnaissance "Sanitary epidemiological reconnaissance") was suggested as well-tested means for enhancing the monitoring of infections and parasitic agents, for the practical implementation of the [International Health Regulations](https://en.wikipedia.org/wiki/International_Health_Regulations "International Health Regulations") (2005). The aim was to prevent and minimize the consequences of natural outbreaks of dangerous infectious diseases as well as the threat of alleged use of biological weapons against BTWC States Parties.

Many countries require their active-duty [military](https://en.wikipedia.org/wiki/Military "Military") personnel to get vaccinated for certain diseases that may potentially be used as a bioweapon such as anthrax, smallpox, and various other vaccines depending on the Area of Operations of the individual military units and commands.[^101]

### Public health and disease surveillance

Most classical and modern biological weapons' pathogens can be obtained from a plant or an animal which is naturally infected.[^102]

In the largest biological weapons accident known—the anthrax outbreak in Sverdlovsk (now [Yekaterinburg](https://en.wikipedia.org/wiki/Yekaterinburg "Yekaterinburg")) in the [Soviet Union](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union") in 1979—sheep became ill with anthrax as far as 200 kilometers (120 mi) from the release point of the organism from a military facility in the southeastern portion of the city and still off-limits to visitors today, (see [Sverdlovsk Anthrax leak](https://en.wikipedia.org/wiki/Sverdlovsk_Anthrax_leak "Sverdlovsk Anthrax leak")).[^103]

Thus, a robust surveillance system involving human clinicians and veterinarians may identify a bioweapons attack early in the course of an epidemic, permitting the prophylaxis of disease in the vast majority of people (and animals) exposed but not yet ill.[^104]

For example, in the case of anthrax, it is likely that by 24–36 hours after an attack, some small percentage of individuals (those with the compromised immune system or who had received a large dose of the organism due to proximity to the release point) will become ill with classical symptoms and signs (including a virtually unique [chest X-ray](https://en.wikipedia.org/wiki/Chest_X-ray "Chest X-ray") finding, often recognized by public health officials if they receive timely reports).[^105] The incubation period for humans is estimated to be about 11.8 days to 12.1 days. This suggested period is the first model that is independently consistent with data from the largest known human outbreak. These projections refine previous estimates of the distribution of early-onset cases after a release and support a recommended 60-day course of prophylactic antibiotic treatment for individuals exposed to low doses of anthrax.[^106] By making these data available to local public health officials in real time, most models of anthrax epidemics indicate that more than 80% of an exposed population can receive antibiotic treatment before becoming symptomatic, and thus avoid the moderately high mortality of the disease.[^105]

### Common epidemiological warnings

From most specific to least specific:[^107]

1. Single cause of a certain disease caused by an uncommon agent, with lack of an epidemiological explanation.
2. Unusual, rare, genetically engineered strain of an agent.
3. High morbidity and mortality rates in regards to patients with the same or similar symptoms.
4. Unusual presentation of the disease.
5. Unusual geographic or seasonal distribution.
6. Stable endemic disease, but with an unexplained increase in relevance.
7. Rare transmission (aerosols, food, water).
8. No illness presented in people who were/are not exposed to "common ventilation systems (have separate closed ventilation systems) when illness is seen in persons in close proximity who have a common ventilation system."
9. Different and unexplained diseases coexisting in the same patient without any other explanation.
10. Rare illness that affects a large, disparate population (respiratory disease might suggest the pathogen or agent was inhaled).
11. Illness is unusual for a certain population or age-group in which it takes presence.
12. Unusual trends of death and illness in animal populations, previous to or accompanying illness in humans.
13. Many affected reaching out for treatment at the same time.
14. Similar genetic makeup of agents in affected individuals.
15. Simultaneous collections of similar illness in non-contiguous areas, domestic, or foreign.
16. An abundance of cases of unexplained diseases and deaths.

### Bioweapon identification

The goal of [biodefense](https://en.wikipedia.org/wiki/Biodefense "Biodefense") is to integrate the sustained efforts of the national and homeland security, medical, public health, intelligence, diplomatic, and law enforcement communities. Health care providers and public health officers are among the first lines of defense. In some countries private, local, and provincial (state) capabilities are being augmented by and coordinated with federal assets, to provide layered defenses against biological weapon attacks. During the [first Gulf War](https://en.wikipedia.org/wiki/Gulf_War "Gulf War") the United Nations activated a biological and chemical response team, [Task Force Scorpio](https://en.wikipedia.org/wiki/Task_Force_Scorpio "Task Force Scorpio"), to respond to any potential use of weapons of mass destruction on civilians.

The traditional approach toward protecting agriculture, food, and water: focusing on the natural or unintentional introduction of a disease is being strengthened by focused efforts to address current and anticipated future biological weapons threats that may be deliberate, multiple, and repetitive.

The growing threat of biowarfare agents and bioterrorism has led to the development of specific field tools that perform on-the-spot analysis and identification of encountered suspect materials. One such technology, being developed by researchers from the [Lawrence Livermore National Laboratory](https://en.wikipedia.org/wiki/Lawrence_Livermore_National_Laboratory "Lawrence Livermore National Laboratory") (LLNL), employs a "sandwich immunoassay", in which fluorescent dye-labeled antibodies aimed at specific [pathogens](https://en.wikipedia.org/wiki/Pathogen "Pathogen") are attached to silver and gold nanowires.[^108]

In the [Netherlands](https://en.wikipedia.org/wiki/Netherlands "Netherlands"), the company [TNO](https://en.wikipedia.org/wiki/Netherlands_Organisation_for_Applied_Scientific_Research "Netherlands Organisation for Applied Scientific Research") has designed [Bioaerosol Single Particle Recognition eQuipment](https://en.wikipedia.org/wiki/BiosparQ?action=edit&redlink=1 "BiosparQ (page does not exist)") (BiosparQ). This system would be implemented into the national response plan for bioweapon attacks in the Netherlands.[^109]

Researchers at [Ben Gurion University](https://en.wikipedia.org/wiki/Ben_Gurion_University "Ben Gurion University") in Israel are developing a different device called the BioPen, essentially a "Lab-in-a-Pen", which can detect known biological agents in under 20 minutes using an adaptation of the [ELISA](https://en.wikipedia.org/wiki/ELISA "ELISA"), a similar widely employed immunological technique, that in this case incorporates fiber optics.[^110]

## List of programs, projects and sites by country

### United States

- [Fort Detrick](https://en.wikipedia.org/wiki/Fort_Detrick "Fort Detrick"), Maryland![](https://en.wikipedia.org/wiki/File:B-w-scientists.jpg)
	Researchers working in Class III cabinets at the US Army Biological Warfare Laboratories, Camp Detrick Maryland (1940s).
	- [US Army Biological Warfare Laboratories](https://en.wikipedia.org/wiki/United_States_Army_Biological_Warfare_Laboratories "United States Army Biological Warfare Laboratories") (1943–69)
		- [Building 470](https://en.wikipedia.org/wiki/Building_470 "Building 470")
				- [One-Million-Liter Test Sphere](https://en.wikipedia.org/wiki/One-Million-Liter_Test_Sphere "One-Million-Liter Test Sphere")
				- [Operation Sea-Spray](https://en.wikipedia.org/wiki/Operation_Sea-Spray "Operation Sea-Spray")
				- [Operation Whitecoat](https://en.wikipedia.org/wiki/Operation_Whitecoat "Operation Whitecoat") (1954–73)
		- [US entomological warfare program](https://en.wikipedia.org/wiki/Entomological_warfare#United_States "Entomological warfare")
		- [Operation Big Itch](https://en.wikipedia.org/wiki/Operation_Big_Itch "Operation Big Itch")
				- [Operation Big Buzz](https://en.wikipedia.org/wiki/Operation_Big_Buzz "Operation Big Buzz")
				- [Operation Drop Kick](https://en.wikipedia.org/wiki/Operation_Drop_Kick "Operation Drop Kick")
				- [Operation May Day](https://en.wikipedia.org/wiki/Operation_May_Day "Operation May Day")
- [Project Bacchus](https://en.wikipedia.org/wiki/Project_Bacchus "Project Bacchus")
- [Project Clear Vision](https://en.wikipedia.org/wiki/Project_Clear_Vision "Project Clear Vision")
- [Project SHAD](https://en.wikipedia.org/wiki/Project_SHAD "Project SHAD")
- [Project 112](https://en.wikipedia.org/wiki/Project_112 "Project 112")
- [Horn Island Testing Station](https://en.wikipedia.org/wiki/Horn_Island_Testing_Station "Horn Island Testing Station")
- [Fort Terry](https://en.wikipedia.org/wiki/Fort_Terry "Fort Terry")
- [Granite Peak Installation](https://en.wikipedia.org/wiki/Granite_Peak_Installation "Granite Peak Installation")
- [Vigo Ordnance Plant](https://en.wikipedia.org/wiki/Vigo_Ordnance_Plant "Vigo Ordnance Plant")

### United Kingdom

- [Porton Down](https://en.wikipedia.org/wiki/Porton_Down "Porton Down")
- [Gruinard Island](https://en.wikipedia.org/wiki/Gruinard_Island "Gruinard Island")
- [Nancekuke](https://en.wikipedia.org/wiki/RRH_Portreath "RRH Portreath")
- [Operation Vegetarian](https://en.wikipedia.org/wiki/Operation_Vegetarian "Operation Vegetarian") (1942–1944)
- **Open-air field tests:**
	- [Operation Harness](https://en.wikipedia.org/wiki/Operation_Harness_\(UK_biological_warfare\) "Operation Harness (UK biological warfare)") off [Antigua](https://en.wikipedia.org/wiki/Antigua "Antigua"), 1948–1950.
		- [Operation Cauldron](https://en.wikipedia.org/wiki/Operation_Cauldron "Operation Cauldron") off [Stornoway](https://en.wikipedia.org/wiki/Stornoway,_Outer_Hebrides "Stornoway, Outer Hebrides"), 1952.
		- [Operation Hesperus](https://en.wikipedia.org/wiki/Operation_Hesperus?action=edit&redlink=1 "Operation Hesperus (page does not exist)") off [Stornoway](https://en.wikipedia.org/wiki/Stornoway "Stornoway"), 1953.
		- [Operation Ozone](https://en.wikipedia.org/wiki/Operation_Ozone?action=edit&redlink=1 "Operation Ozone (page does not exist)") off [Nassau](https://en.wikipedia.org/wiki/Nassau,_Bahamas "Nassau, Bahamas"), 1954.
		- [Operation Negation](https://en.wikipedia.org/wiki/Operation_Negation?action=edit&redlink=1 "Operation Negation (page does not exist)") off Nassau, 1954–5.

### Soviet Union and Russia

- [Biopreparat](https://en.wikipedia.org/wiki/Biopreparat "Biopreparat") (18 labs and production centers)
	- [Stepnogorsk Scientific and Technical Institute for Microbiology](https://en.wikipedia.org/wiki/Stepnogorsk_Scientific_and_Technical_Institute_for_Microbiology "Stepnogorsk Scientific and Technical Institute for Microbiology"), [Stepnogorsk](https://en.wikipedia.org/wiki/Stepnogorsk "Stepnogorsk"), northern [Kazakhstan](https://en.wikipedia.org/wiki/Kazakhstan "Kazakhstan")
		- [Institute of Ultra Pure Biochemical Preparations](https://en.wikipedia.org/wiki/Vladimir_Pasechnik "Vladimir Pasechnik"), [Leningrad](https://en.wikipedia.org/wiki/Leningrad "Leningrad"), a weaponized plague center
		- [Vector State Research Center of Virology and Biotechnology](https://en.wikipedia.org/wiki/Vector_State_Research_Center_of_Virology_and_Biotechnology "Vector State Research Center of Virology and Biotechnology") (VECTOR), a weaponized smallpox center
		- [Institute of Applied Biochemistry](https://en.wikipedia.org/wiki/Institute_of_Applied_Biochemistry "Institute of Applied Biochemistry"), [Omutninsk](https://en.wikipedia.org/wiki/Omutninsk "Omutninsk")
		- [Kirov bioweapons production facility](https://en.wikipedia.org/wiki/Kirov_bioweapons_production_facility "Kirov bioweapons production facility"), [Kirov, Kirov Oblast](https://en.wikipedia.org/wiki/Kirov,_Kirov_Oblast "Kirov, Kirov Oblast")
		- [Zagorsk smallpox production facility](https://en.wikipedia.org/wiki/Zagorsk_smallpox_production_facility "Zagorsk smallpox production facility"), [Zagorsk](https://en.wikipedia.org/wiki/Zagorsk "Zagorsk")
		- [Berdsk bioweapons production facility](https://en.wikipedia.org/wiki/Berdsk_bioweapons_production_facility?action=edit&redlink=1 "Berdsk bioweapons production facility (page does not exist)"), [Berdsk](https://en.wikipedia.org/wiki/Berdsk "Berdsk")
		- [Bioweapons research facility](https://en.wikipedia.org/wiki/Bioweapons_research_facility?action=edit&redlink=1 "Bioweapons research facility (page does not exist)"), [Obolensk](https://en.wikipedia.org/wiki/Obolenskoye,_Zhukovsky_District,_Kaluga_Oblast "Obolenskoye, Zhukovsky District, Kaluga Oblast")
		- [Sverdlovsk bioweapons production facility](https://en.wikipedia.org/wiki/Sverdlovsk_Anthrax_leak "Sverdlovsk Anthrax leak") (Military Compound 19), [Sverdlovsk](https://en.wikipedia.org/wiki/Yekaterinburg "Yekaterinburg"), a weaponized anthrax center
- [Institute of Virus Preparations](https://en.wikipedia.org/wiki/Institute_of_Virus_Preparations "Institute of Virus Preparations")
- [Poison laboratory of the Soviet secret services](https://en.wikipedia.org/wiki/Poison_laboratory_of_the_Soviet_secret_services "Poison laboratory of the Soviet secret services")
- [Vozrozhdeniya](https://en.wikipedia.org/wiki/Vozrozhdeniya "Vozrozhdeniya")
- [Project Bonfire](https://en.wikipedia.org/wiki/Project_Bonfire?action=edit&redlink=1 "Project Bonfire (page does not exist)")
- [Project Factor](https://en.wikipedia.org/wiki/Project_Factor?action=edit&redlink=1 "Project Factor (page does not exist)")

### Japan

![](https://en.wikipedia.org/wiki/File:Unit_731_victim.jpg)

US authorities granted Unit 731 officials immunity from prosecution in return for access to their research.

- [Unit 731](https://en.wikipedia.org/wiki/Unit_731 "Unit 731")
- [Zhongma Fortress](https://en.wikipedia.org/wiki/Zhongma_Fortress "Zhongma Fortress")
- [Kaimingjie germ weapon attack](https://en.wikipedia.org/wiki/Kaimingjie_germ_weapon_attack "Kaimingjie germ weapon attack")
- [Khabarovsk War Crime Trials](https://en.wikipedia.org/wiki/Khabarovsk_War_Crime_Trials "Khabarovsk War Crime Trials")
- [Epidemic Prevention and Water Purification Department](https://en.wikipedia.org/wiki/Epidemic_Prevention_and_Water_Purification_Department "Epidemic Prevention and Water Purification Department")

### Iraq

- [Al Hakum](https://en.wikipedia.org/wiki/Al_Hakum_\(Iraq\) "Al Hakum (Iraq)")
- [Salman Pak facility](https://en.wikipedia.org/wiki/Salman_Pak_facility "Salman Pak facility")
- [Al Manal](https://en.wikipedia.org/wiki/Al_Manal?action=edit&redlink=1 "Al Manal (page does not exist)") facility

### South Africa

- [Project Coast](https://en.wikipedia.org/wiki/Project_Coast "Project Coast")
- [Delta G Scientific Company](https://en.wikipedia.org/wiki/Delta_G_Scientific_Company "Delta G Scientific Company")
- [Roodeplaat Research Laboratories](https://en.wikipedia.org/wiki/Roodeplaat_Research_Laboratories "Roodeplaat Research Laboratories")
- [Protechnik](https://en.wikipedia.org/wiki/Protechnik "Protechnik")

### Rhodesia

### Canada

- [Grosse Isle, Quebec](https://en.wikipedia.org/wiki/Grosse_Isle,_Quebec "Grosse Isle, Quebec"), site (1939–45) of research into anthrax and other agents
- [DRDC Suffield](https://en.wikipedia.org/wiki/DRDC_Suffield "DRDC Suffield"), [Suffield, Alberta](https://en.wikipedia.org/wiki/Suffield,_Alberta "Suffield, Alberta")

## List of associated people

***Bioweaponeers:***

*Includes scientists and administrators*

- Shyh-Ching Lo [^111] [^112]
- [Kanatjan Alibekov](https://en.wikipedia.org/wiki/Kanatjan_Alibekov "Kanatjan Alibekov"), known as Ken Alibek [^113]
- [Ira Baldwin](https://en.wikipedia.org/wiki/Ira_Baldwin "Ira Baldwin") [^114]
- [Wouter Basson](https://en.wikipedia.org/wiki/Wouter_Basson "Wouter Basson")
- [Kurt Blome](https://en.wikipedia.org/wiki/Kurt_Blome "Kurt Blome") [^115]
- Eugen von Haagen [^116]
- [Anton Dilger](https://en.wikipedia.org/wiki/Anton_Dilger "Anton Dilger") [^117]
- [Paul Fildes](https://en.wikipedia.org/wiki/Paul_Fildes "Paul Fildes") [^118]
- [Arthur Galston](https://en.wikipedia.org/wiki/Arthur_Galston "Arthur Galston") (unwittingly)
- Kurt Gutzeit [^119]
- [Riley D. Housewright](https://en.wikipedia.org/wiki/Riley_D._Housewright "Riley D. Housewright")
- [Shirō Ishii](https://en.wikipedia.org/wiki/Shir%C5%8D_Ishii "Shirō Ishii")
- [Elvin A. Kabat](https://en.wikipedia.org/wiki/Elvin_A._Kabat "Elvin A. Kabat")
- [George W. Merck](https://en.wikipedia.org/wiki/George_W._Merck "George W. Merck")
- [Frank Olson](https://en.wikipedia.org/wiki/Frank_Olson "Frank Olson")
- [Vladimir Pasechnik](https://en.wikipedia.org/wiki/Vladimir_Pasechnik "Vladimir Pasechnik") [^120]
- [William C. Patrick III](https://en.wikipedia.org/wiki/William_C._Patrick_III "William C. Patrick III") [^121]
- [Sergei Popov](https://en.wikipedia.org/wiki/Sergei_Popov_\(bioweaponeer\) "Sergei Popov (bioweaponeer)") [^122]
- [Theodor Rosebury](https://en.wikipedia.org/wiki/Theodor_Rosebury "Theodor Rosebury")
- [Rihab Rashid Taha](https://en.wikipedia.org/wiki/Rihab_Rashid_Taha "Rihab Rashid Taha") [^123]
- [Prince Tsuneyoshi Takeda](https://en.wikipedia.org/wiki/Prince_Tsuneyoshi_Takeda "Prince Tsuneyoshi Takeda")
- [Huda Salih Mahdi Ammash](https://en.wikipedia.org/wiki/Huda_Salih_Mahdi_Ammash "Huda Salih Mahdi Ammash")
- [Nassir al-Hindawi](https://en.wikipedia.org/wiki/Nassir_al-Hindawi?action=edit&redlink=1 "Nassir al-Hindawi (page does not exist)")
- [Erich Traub](https://en.wikipedia.org/wiki/Erich_Traub "Erich Traub") [^124]
- [Auguste Trillat](https://en.wikipedia.org/wiki/Auguste_Trillat?action=edit&redlink=1 "Auguste Trillat (page does not exist)")
- [Baron Otto von Rosen](https://en.wikipedia.org/wiki/Baron_Otto_von_Rosen?action=edit&redlink=1 "Baron Otto von Rosen (page does not exist)") [^125]
- [Yujiro Wakamatsu](https://en.wikipedia.org/wiki/Yujiro_Wakamatsu?action=edit&redlink=1 "Yujiro Wakamatsu (page does not exist)")
- [Yazid Sufaat](https://en.wikipedia.org/wiki/Yazid_Sufaat "Yazid Sufaat")

***Writers and activists:***

- [Jack Trudel](https://en.wikipedia.org/wiki/Jack_Trudel?action=edit&redlink=1 "Jack Trudel (page does not exist)") [^126]
- [Daniel Barenblatt](https://en.wikipedia.org/wiki/Daniel_Barenblatt?action=edit&redlink=1 "Daniel Barenblatt (page does not exist)")
- [Leonard A. Cole](https://en.wikipedia.org/wiki/Leonard_A._Cole "Leonard A. Cole")
- Stephen Endicott
- [Arthur Galston](https://en.wikipedia.org/wiki/Arthur_Galston "Arthur Galston")
- [Jeanne Guillemin](https://en.wikipedia.org/wiki/Jeanne_Guillemin "Jeanne Guillemin") [^127]
- [Edward Hagerman](https://en.wikipedia.org/wiki/Edward_Hagerman "Edward Hagerman")
- [Sheldon H. Harris](https://en.wikipedia.org/wiki/Sheldon_H._Harris "Sheldon H. Harris") [^128]
- [Nicholas D. Kristof](https://en.wikipedia.org/wiki/Nicholas_D._Kristof "Nicholas D. Kristof")
- [Joshua Lederberg](https://en.wikipedia.org/wiki/Joshua_Lederberg "Joshua Lederberg") [^129]
- [Matthew Meselson](https://en.wikipedia.org/wiki/Matthew_Meselson "Matthew Meselson") [^130]
- [Toby Ord](https://en.wikipedia.org/wiki/Toby_Ord "Toby Ord")
- [Richard Preston](https://en.wikipedia.org/wiki/Richard_Preston "Richard Preston")
- [Ed Regis](https://en.wikipedia.org/wiki/Ed_Regis_\(author\) "Ed Regis (author)")
- [Mark Wheelis](https://en.wikipedia.org/wiki/Mark_Wheelis "Mark Wheelis")
- [David Willman](https://en.wikipedia.org/wiki/David_Willman "David Willman")
- [Aaron Henderson](https://en.wikipedia.org/wiki/Aaron_Henderson?action=edit&redlink=1 "Aaron Henderson (page does not exist)")

## In popular culture

[^1]: Berger, Tamar; Eisenkraft, Arik; Bar-Haim, Erez; Kassirer, Michael; Aran, Adi Avniel; Fogel, Itay (2016). ["Toxins as biological weapons for terror-characteristics, challenges and medical countermeasures: a mini-review"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5330008). *Disaster and Military Medicine*. **2** 7: 7 MI. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1186/s40696-016-0017-4](https://doi.org/10.1186%2Fs40696-016-0017-4). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [2054-314X](https://search.worldcat.org/issn/2054-314X). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [5330008](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5330008). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [28265441](https://pubmed.ncbi.nlm.nih.gov/28265441).

[^2]: Clark, David P.; Pazdernik, Nanette J. (2016). "Chapter 22 - Biological Warfare: Infectious Disease and Bioterrorism". *Biotechnology: Applying the Genetic Revolution* (2nd ed.). Academic Cell. pp. 687–719. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1016/B978-0-12-385015-7.00022-3](https://doi.org/10.1016%2FB978-0-12-385015-7.00022-3). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-12-385015-7](https://en.wikipedia.org/wiki/Special:BookSources/978-0-12-385015-7 "Special:BookSources/978-0-12-385015-7").

[^3]: Bentley, Michelle (2024). [*The Biological Weapons Taboo*](https://books.google.com/books?id=eOvXEAAAQBAJ). Oxford University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-889215-1](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-889215-1 "Special:BookSources/978-0-19-889215-1").

[^4]: Bentley, Michelle (18 October 2023). ["The Biological Weapons Taboo"](https://warontherocks.com/2023/10/the-biological-weapons-taboo/). *War on the Rocks*.

[^5]: [Rule 73. The use of biological weapons is prohibited.](https://ihl-databases.icrc.org/customary-ihl/eng/docs/v1_rul_rule73) [Archived](https://web.archive.org/web/20170412143836/https://ihl-databases.icrc.org/customary-ihl/eng/docs/v1_rul_rule73) 12 April 2017 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), *Customary IHL Database*, [International Committee of the Red Cross](https://en.wikipedia.org/wiki/International_Committee_of_the_Red_Cross "International Committee of the Red Cross") (ICRC)/ [Cambridge University Press](https://en.wikipedia.org/wiki/Cambridge_University_Press "Cambridge University Press").

[^6]: *Customary Internal Humanitarian Law, Vol. II: Practice*, Part 1 (eds. Jean-Marie Henckaerts & Louise Doswald-Beck: Cambridge University Press, 2005), pp. 1607–10.

[^7]: ["Biological Weapons Convention"](https://www.un.org/disarmament/biological-weapons/). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. [Archived](https://web.archive.org/web/20210215200800/https://www.un.org/disarmament/biological-weapons) from the original on 15 February 2021. Retrieved 2 March 2021.

[^8]: Alexander Schwarz, "War Crimes" in *[The Law of Armed Conflict and the Use of Force: The Max Planck Encyclopedia of Public International Law](https://books.google.com/books?id=boWuDQAAQBAJ&pg=PA1317)* ([Archived](https://web.archive.org/web/20170412144548/https://books.google.com/books?id=boWuDQAAQBAJ&pg=PA1317) 12 April 2017 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")) (eds. Frauke Lachenmann & Rüdiger Wolfrum: Oxford University Press, 2017), p. 1317.

[^9]: Article I, Biological Weapons Convention. [Wikisource](https://en.wikisource.org/wiki/Biological%20Weapons%20Convention#Article_I "wikisource:Biological Weapons Convention").

[^10]: Wheelis M, Rózsa L, Dando M (2006). *Deadly Cultures: Biological Weapons Since 1945*. Harvard University Press. pp. 284–293, 301–303. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-674-01699-6](https://en.wikipedia.org/wiki/Special:BookSources/978-0-674-01699-6 "Special:BookSources/978-0-674-01699-6").

[^11]: Gray C (2007). *Another Bloody Century: Future Warfare*. Phoenix. pp. 265–266. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-304-36734-4](https://en.wikipedia.org/wiki/Special:BookSources/978-0-304-36734-4 "Special:BookSources/978-0-304-36734-4").

[^12]: Koblentz, Gregory (2003). "Pathogens as Weapons: The International Security Implications of Biological Warfare". *International Security*. **28** (3): 84–122. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1162/016228803773100084](https://doi.org/10.1162%2F016228803773100084). [hdl](https://en.wikipedia.org/wiki/Hdl_\(identifier\) "Hdl (identifier)"):[1721.1/28498](https://hdl.handle.net/1721.1%2F28498). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0162-2889](https://search.worldcat.org/issn/0162-2889). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [4137478](https://www.jstor.org/stable/4137478). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [57570499](https://api.semanticscholar.org/CorpusID:57570499).

[^13]: [Archived](https://web.archive.org/web/20110430190200/http://www.allacademic.com/meta/p_mla_apa_research_citation/0/7/3/6/4/p73644_index.html) 30 April 2011 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^14]: Borisevich, I. V.; Markin, V. A.; Firsova, I. V.; Evseey, A. A.; Khamitov, R. A.; Maksimov, V. A. (2006). "Hemorrhagic (Marburg, Ebola, Lassa, and Bolivian) fevers: Epidemiology, clinical pictures, and treatment". *Voprosy Virusologi*. **51** (5): 8–16. [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [17087059](https://pubmed.ncbi.nlm.nih.gov/17087059).

[^15]: \[Akinfeyeva L. A., Aksyonova O. I., Vasilyevich I. V., et al. A case of Ebola hemorrhagic fever. Infektsionnye Bolezni (Moscow). 2005;3(1):85–88 \[Russian\].\]

[^16]: Mayor A (2003). *Greek Fire, Poison Arrows & Scorpion Bombs: Biological and Chemical Warfare in the Ancient World*. Woodstock, N.Y.: Overlook Duckworth. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-58567-348-3](https://en.wikipedia.org/wiki/Special:BookSources/978-1-58567-348-3 "Special:BookSources/978-1-58567-348-3").

[^17]: Trevisanato SI (2007). "The 'Hittite plague', an epidemic of tularemia and the first record of biological warfare". *Med Hypotheses*. **69** (6): 1371–4. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1016/j.mehy.2007.03.012](https://doi.org/10.1016%2Fj.mehy.2007.03.012). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [17499936](https://pubmed.ncbi.nlm.nih.gov/17499936).

[^18]: Croddy, Eric; Perez-Armendariz, Clarissa; Hart, John (2002). [*Chemical and biological warfare: a comprehensive survey for the concerned citizen*](https://archive.org/details/chemicalbiologic00crod/page/214,219). Copernicus Books. p. [214,219](https://archive.org/details/chemicalbiologic00crod/page/214,219). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-387-95076-1](https://en.wikipedia.org/wiki/Special:BookSources/0-387-95076-1 "Special:BookSources/0-387-95076-1").

[^19]: Wheelis M (September 2002). ["Biological warfare at the 1346 siege of Caffa"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2732530). *Emerging Infectious Diseases*. **8** (9): 971–5. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.3201/eid0809.010536](https://doi.org/10.3201%2Feid0809.010536). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [2732530](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2732530). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [12194776](https://pubmed.ncbi.nlm.nih.gov/12194776).

[^20]: Barras V, Greub G (June 2014). ["History of biological warfare and bioterrorism"](https://doi.org/10.1111%2F1469-0691.12706). *Clinical Microbiology and Infection*. **20** (6): 497–502. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1111/1469-0691.12706](https://doi.org/10.1111%2F1469-0691.12706). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [24894605](https://pubmed.ncbi.nlm.nih.gov/24894605).

[^21]: Andrew G. Robertson, and Laura J. Robertson. "From asps to allegations: biological warfare in history," *Military medicine* (1995) 160#8 pp: 369-373.

[^22]: Rakibul Hasan, "Biological Weapons: covert threats to Global Health Security." *Asian Journal of Multidisciplinary Studies* (2014) 2#9 p 38. [online](http://www.ajms.co.in/sites/ajms/index.php/ajms/article/viewFile/559/488) [Archived](https://web.archive.org/web/20141217124035/http://www.ajms.co.in/sites/ajms/index.php/ajms/article/viewFile/559/488) 17 December 2014 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^23]: John K. Thornton (November 2002). [*Warfare in Atlantic Africa, 1500-1800*](https://books.google.com/books?id=7_qNAgAAQBAJ). Routledge. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-135-36584-4](https://en.wikipedia.org/wiki/Special:BookSources/978-1-135-36584-4 "Special:BookSources/978-1-135-36584-4").

[^24]: Akinwumi, Olayemi (1995). "Biologically-Based Warfare in the Pre-Colonial Borgu Society of Nigeria and Republic of Benin1". *Transafrican Journal of History*. **24**: 123–130. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0251-0391](https://search.worldcat.org/issn/0251-0391). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [24328658](https://www.jstor.org/stable/24328658).

[^25]: White, Phillip M. (2 June 2011). *American Indian Chronology: Chronologies of the American Mosaic*. [Greenwood Publishing Group](https://en.wikipedia.org/wiki/Greenwood_Publishing_Group "Greenwood Publishing Group"). p. 44.

[^26]: Calloway CG (2007). *The Scratch of a Pen: 1763 and the Transformation of North America (Pivotal Moments in American History)*. Oxford University Press. p. 73. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-533127-1](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-533127-1 "Special:BookSources/978-0-19-533127-1").

[^27]: Jones DS (2004). *Rationalizing Epidemics*. Harvard University Press. p. 97. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-674-01305-6](https://en.wikipedia.org/wiki/Special:BookSources/978-0-674-01305-6 "Special:BookSources/978-0-674-01305-6").

[^28]: McConnel MN (1997). *A Country Between: The Upper Ohio Valley and Its Peoples, 1724-1774*. University of Nebraska Press. p. 195.

[^29]: King, J. C. H. (2016). *Blood and Land: The Story of Native North America*. Penguin UK. p. 73. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-84614-808-8](https://en.wikipedia.org/wiki/Special:BookSources/978-1-84614-808-8 "Special:BookSources/978-1-84614-808-8").

[^30]: Ranlet, P (2000). "The British, the Indians, and smallpox: what actually happened at Fort Pitt in 1763?". *Pennsylvania History*. **67** (3): 427–441. [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [17216901](https://pubmed.ncbi.nlm.nih.gov/17216901).

[^31]: Barras V, Greub G (June 2014). ["History of biological warfare and bioterrorism"](https://doi.org/10.1111%2F1469-0691.12706). *Clinical Microbiology and Infection*. **20** (6): 497–502. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1111/1469-0691.12706](https://doi.org/10.1111%2F1469-0691.12706). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [24894605](https://pubmed.ncbi.nlm.nih.gov/24894605). However, in the light of contemporary knowledge, it remains doubtful whether his hopes were fulfilled, given the fact that the transmission of smallpox through this kind of vector is much less efficient than respiratory transmission, and that Native Americans had been in contact with smallpox >200 years before Ecuyer's trickery, notably during Pizarro's conquest of South America in the 16th century. As a whole, the analysis of the various 'pre-microbiological" attempts at biological warfare illustrate the difficulty of differentiating attempted biological attack from naturally occurring epidemics.

[^32]: [*Medical Aspects of Biological Warfare*](https://books.google.com/books?id=nm_AVg4hmJQC&pg=PA3). Government Printing Office. 2007. p. 3. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-16-087238-9](https://en.wikipedia.org/wiki/Special:BookSources/978-0-16-087238-9 "Special:BookSources/978-0-16-087238-9"). In retrospect, it is difficult to evaluate the tactical success of Captain Ecuyer's biological attack because smallpox may have been transmitted after other contacts with colonists, as had previously happened in New England and the South. Although scabs from smallpox patients are thought to be of low infectivity as a result of binding of the virus in fibrin metric, and transmission by fomites has been considered inefficient compared with respiratory droplet transmission.

[^33]: Mary V. Thompson. ["Smallpox"](https://www.mountvernon.org/library/digitalhistory/digital-encyclopedia/article/smallpox/). Mount Vernon Estate and Gardens.

[^34]: ["Gen. George Washington - A Threat of Bioterrorism, 1775"](https://www.archives.gov/exhibits/eyewitness/html.php?section=4). *Eyewitness -- American Originals from the National Archives*. US National Archives.

[^35]: Christopher W (2013). "Smallpox at Sydney Cove – Who, When, Why". *Journal of Australian Studies*. **38**: 68–86. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/14443058.2013.849750](https://doi.org/10.1080%2F14443058.2013.849750). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [143644513](https://api.semanticscholar.org/CorpusID:143644513). See also [History of biological warfare#New South Wales](https://en.wikipedia.org/wiki/History_of_biological_warfare#New_South_Wales "History of biological warfare"), [First Fleet#First Fleet smallpox](https://en.wikipedia.org/wiki/First_Fleet#First_Fleet_smallpox "First Fleet"), and [History wars#Controversy over smallpox in Australia](https://en.wikipedia.org/wiki/Australian_history_wars#Controversy_over_smallpox_in_Australia "Australian history wars").

[^36]: Carus WS (August 2015). "The history of biological weapons use: what we know and what we don't". *Health Security*. **13** (4): 219–55. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1089/hs.2014.0092](https://doi.org/10.1089%2Fhs.2014.0092). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [26221997](https://pubmed.ncbi.nlm.nih.gov/26221997).

[^37]: Koenig, Robert (2006), *The Fourth Horseman: One Man's Secret Campaign to Fight the Great War in America*, PublicAffairs.

[^38]: Baxter RR, Buergenthal T (28 March 2017). ["Legal Aspects of the Geneva Protocol of 1925"](https://www.cambridge.org/core/journals/american-journal-of-international-law/article/legal-aspects-of-the-geneva-protocol-of-1925/26453DA22053FCBB08BB4A520FFE9964). *The American Journal of International Law*. **64** (5): 853–879. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/2198921](https://doi.org/10.2307%2F2198921). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [2198921](https://www.jstor.org/stable/2198921). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [147499122](https://api.semanticscholar.org/CorpusID:147499122). [Archived](https://web.archive.org/web/20171027233302/https://www.cambridge.org/core/journals/american-journal-of-international-law/article/legal-aspects-of-the-geneva-protocol-of-1925/26453DA22053FCBB08BB4A520FFE9964) from the original on 27 October 2017. Retrieved 27 October 2017.

[^39]: Prasad SK (2009). [*Biological Agents, Volume 2*](https://books.google.com/books?id=SoDwO-dl-i0C). Discovery Publishing House. p. 36. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-81-8356-381-9](https://en.wikipedia.org/wiki/Special:BookSources/978-81-8356-381-9 "Special:BookSources/978-81-8356-381-9").

[^40]: Garrett L (2003). [*Betrayal of Trust: The Collapse of Global Public Health*](https://books.google.com/books?id=teMYnJoVolkC&pg=PA340). Oxford University Press. pp. 340–341. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-852683-4](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-852683-4 "Special:BookSources/978-0-19-852683-4").

[^41]: Covert NM (2000). [*A History of Fort Detrick, Maryland*](https://web.archive.org/web/20120121062629/http://www.detrick.army.mil/cutting_edge/index.cfm?chapter=contents) (4th ed.). Archived from [the original](http://www.detrick.army.mil/cutting_edge/index.cfm?chapter=contents) on 21 January 2012. Retrieved 20 December 2011.

[^42]: Guillemin J (July 2006). ["Scientists and the history of biological weapons. A brief historical overview of the development of biological weapons in the twentieth century"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1490304). *EMBO Reports*. 7 Spec No (Spec No): S45-9. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1038/sj.embor.7400689](https://doi.org/10.1038%2Fsj.embor.7400689). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [1490304](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1490304). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [16819450](https://pubmed.ncbi.nlm.nih.gov/16819450).

[^43]: Williams P, Wallace D (1989). *Unit 731: Japan's Secret Biological Warfare in World War II*. Free Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-02-935301-1](https://en.wikipedia.org/wiki/Special:BookSources/978-0-02-935301-1 "Special:BookSources/978-0-02-935301-1").

[^44]: Gold H (1996). Unit 731 testimony (Report). pp. 64–66.

[^45]: Barenblatt D (2004). *A Plague upon Humanity*. HarperCollins. pp. 220–221.

[^46]: Kristof, NICHOLAS D. (17 March 1995). ["Unmasking Horror -- A special report.; Japan Confronting Gruesome War Atrocity"](https://web.archive.org/web/20190714031133/https://www.nytimes.com/1995/03/17/world/unmasking-horror-a-special-report-japan-confronting-gruesome-war-atrocity.html). *[New York Times](https://en.wikipedia.org/wiki/New_York_Times "New York Times")*. Archived from [the original](https://www.nytimes.com/1995/03/17/world/unmasking-horror-a-special-report-japan-confronting-gruesome-war-atrocity.html) on 14 July 2019.

[^47]: Chevrier MI, Chomiczewski K, Garrigue H, Granasztói G, Dando MR, Pearson GS, eds. (July 2004). ["Johnston Atoll"](https://books.google.com/books?id=ZzlNgS70OHAC&pg=PA171). *The Implementation of Legally Binding Measures to Strengthen the Biological and Toxin Weapons Convention, Proceedings of the NATO Advanced Study Institute, held in Budapest, Hungary, 2001*. Springer Science & Business Media. p. 171. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-4020-2096-4](https://en.wikipedia.org/wiki/Special:BookSources/978-1-4020-2096-4 "Special:BookSources/978-1-4020-2096-4").

[^48]: Croddy E, Wirtz JJ (2005). *Weapons of Mass Destruction*. ABC-CLIO. p. 171. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-85109-490-5](https://en.wikipedia.org/wiki/Special:BookSources/978-1-85109-490-5 "Special:BookSources/978-1-85109-490-5").

[^49]: Baumslag N (2005). [*Murderous Medicine: Nazi Doctors, Human Experimentation, and Typhus*](https://archive.org/details/murderousmedicin0000baum). pp. [207](https://archive.org/details/murderousmedicin0000baum/page/207).

[^50]: Stewart A (25 April 2011). ["Where To Find The World's Most 'Wicked Bugs': Fleas"](https://www.npr.org/2011/04/25/135638924/where-to-find-the-worlds-most-wicked-bugs). National Public Radio. [Archived](https://web.archive.org/web/20180426075831/https://www.npr.org/2011/04/25/135638924/where-to-find-the-worlds-most-wicked-bugs) from the original on 26 April 2018. Retrieved 5 April 2018.

[^51]: Russell Working (5 June 2001). ["The trial of Unit 731"](http://www.japantimes.co.jp/opinion/2001/06/05/commentary/world-commentary/the-trial-of-unit-731/). *The Japan Times*. [Archived](https://web.archive.org/web/20141221090020/http://www.japantimes.co.jp/opinion/2001/06/05/commentary/world-commentary/the-trial-of-unit-731/) from the original on 21 December 2014. Retrieved 26 December 2014.

[^52]: Morris, Benny; Kedar, Benjamin Z. (1 January 2022). ["'Cast thy bread': Israeli biological warfare during the 1948 War"](http://www.scopus.com/inward/record.url?scp=85138258079&partnerID=8YFLogxK). *Middle Eastern Studies*. **59** (5): 752–776. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/00263206.2022.2122448](https://doi.org/10.1080%2F00263206.2022.2122448). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0026-3206](https://search.worldcat.org/issn/0026-3206). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [252389726](https://api.semanticscholar.org/CorpusID:252389726).

[^53]: ["'Place the Material in the Wells': Docs Point to Israeli Army's 1948 Biological Warfare"](https://www.haaretz.com/israel-news/2022-10-14/ty-article-magazine/.highlight/documents-confirm-israelis-poisoned-arab-wells-in-1948/00000183-d2b2-d8cc-afc7-fefed64d0000). *Haaretz*. 14 October 2022.

[^54]: Aderet, Ofer (23 June 2023). ["Israel Poisoned Palestinian Land to Build West Bank Settlement in 1970s, Documents Reveal"](https://www.haaretz.com/israel-news/2023-06-23/ty-article-magazine/.premium/israel-poisoned-palestinian-land-to-build-west-bank-settlement-in-1970s-documents-reveal/00000188-e8aa-df52-a79d-fcabdd200000). Haaretz. Retrieved 24 June 2023.

[^55]: Clark WR (15 May 2008). *Bracing for Armageddon?: The Science and Politics of Bioterrorism in America*. USA: Oxford University Press.

[^56]: [Richard Nixon](https://en.wikipedia.org/wiki/Richard_Nixon "Richard Nixon") (1969), [Statement on Chemical and Biological Defense Policies and Programs](https://en.wikipedia.org/wiki/Statement_on_Chemical_and_Biological_Defense_Policies_and_Programs "Statement on Chemical and Biological Defense Policies and Programs"). [Wikisource link](https://en.wikisource.org/wiki/Statement%20on%20Chemical%20and%20Biological%20Defense%20Policies%20and%20Programs "wikisource:Statement on Chemical and Biological Defense Policies and Programs").

[^57]: ["History of the Biological Weapons Convention"](https://www.un.org/disarmament/biological-weapons/about/history/). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. [Archived](https://web.archive.org/web/20210216203033/https://www.un.org/disarmament/biological-weapons/about/history) from the original on 16 February 2021. Retrieved 2 March 2021.

[^58]: Alibek K, Handelman S (2000). [*Biohazard: The Chilling True Story of the Largest Covert Biological Weapons Program in the World – Told from Inside by the Man Who Ran it*](https://en.wikipedia.org/wiki/Biohazard_\(book\) "Biohazard (book)"). Delta. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-385-33496-9](https://en.wikipedia.org/wiki/Special:BookSources/978-0-385-33496-9 "Special:BookSources/978-0-385-33496-9").

[^59]: Meselson, M.; Guillemin, J.; Hugh-Jones, M.; Langmuir, A.; Popova, I.; Shelokov, A.; Yampolskaya, O. (18 November 1994). ["The Sverdlovsk anthrax outbreak of 1979"](https://www.science.org/doi/10.1126/science.7973702). *Science*. **266** (5188): 1202–1208. [Bibcode](https://en.wikipedia.org/wiki/Bibcode_\(identifier\) "Bibcode (identifier)"):[1994Sci...266.1202M](https://ui.adsabs.harvard.edu/abs/1994Sci...266.1202M). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1126/science.7973702](https://doi.org/10.1126%2Fscience.7973702). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0036-8075](https://search.worldcat.org/issn/0036-8075). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [7973702](https://pubmed.ncbi.nlm.nih.gov/7973702).

[^60]: United Nations (1972). [Biological Weapons Convention](https://front.un-arm.org/wp-content/uploads/2020/12/BWC-text-English.pdf).

[^61]: ["Text of the 1925 Geneva Protocol"](https://web.archive.org/web/20210209134308/http://disarmament.un.org/treaties/t/1925/text). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. Archived from [the original](http://disarmament.un.org/treaties/t/1925/text) on 9 February 2021. Retrieved 2 March 2021.

[^62]: ["Disarmament Treaties Database: 1925 Geneva Protocol"](https://web.archive.org/web/20190521142454/http://disarmament.un.org/treaties/t/1925). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. Archived from [the original](http://disarmament.un.org/treaties/t/1925) on 21 May 2019. Retrieved 2 March 2021.

[^63]: Beard, Jack M. (April 2007). ["The Shortcomings of Indeterminacy in Arms Control Regimes: The Case of the Biological Weapons Convention"](https://www.cambridge.org/core/journals/american-journal-of-international-law/article/abs/shortcomings-of-indeterminacy-in-arms-control-regimes-the-case-of-the-biological-weapons-convention/F0FCA907A496B488DEE91630C812C6DE). *American Journal of International Law*. **101** (2): 277. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1017/S0002930000030098](https://doi.org/10.1017%2FS0002930000030098). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0002-9300](https://search.worldcat.org/issn/0002-9300). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [8354600](https://api.semanticscholar.org/CorpusID:8354600).

[^64]: ["Disarmament Treaties Database: Biological Weapons Convention"](https://web.archive.org/web/20210202055505/http://disarmament.un.org/treaties/t/bwc). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. Archived from [the original](http://disarmament.un.org/treaties/t/bwc) on 2 February 2021. Retrieved 2 March 2021.

[^65]: Cross, Glenn; Klotz, Lynn (3 July 2020). ["Twenty-first century perspectives on the Biological Weapon Convention: Continued relevance or toothless paper tiger"](https://doi.org/10.1080%2F00963402.2020.1778365). *Bulletin of the Atomic Scientists*. **76** (4): 185–191. [Bibcode](https://en.wikipedia.org/wiki/Bibcode_\(identifier\) "Bibcode (identifier)"):[2020BuAtS..76d.185C](https://ui.adsabs.harvard.edu/abs/2020BuAtS..76d.185C). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/00963402.2020.1778365](https://doi.org/10.1080%2F00963402.2020.1778365). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0096-3402](https://search.worldcat.org/issn/0096-3402). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [221061960](https://api.semanticscholar.org/CorpusID:221061960).

[^66]: ["Preamble, Biological Weapons Convention"](https://web.archive.org/web/20190909114226/http://disarmament.un.org/treaties/t/bwc/text). *[United Nations Office for Disarmament Affairs](https://en.wikipedia.org/wiki/United_Nations_Office_for_Disarmament_Affairs "United Nations Office for Disarmament Affairs")*. Archived from [the original](http://disarmament.un.org/treaties/t/bwc/text) on 9 September 2019. Retrieved 2 March 2021.

[^67]: Dando, Malcolm (2006). *Chapter 9: The Failure of Arms Control, In Bioterror and Biowarfare: A Beginner's Guide*. Oneworld. pp. 146–165. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-85168-447-2](https://en.wikipedia.org/wiki/Special:BookSources/978-1-85168-447-2 "Special:BookSources/978-1-85168-447-2").

[^68]: ["The Origins of the Australia Group"](https://www.dfat.gov.au/publications/minisite/theaustraliagroupnet/site/en/origins.html). *Australian Department of Foreign Affairs and Trade*. [Archived](https://web.archive.org/web/20210302091850/https://www.dfat.gov.au/publications/minisite/theaustraliagroupnet/site/en/index.html) from the original on 2 March 2021. Retrieved 2 March 2021.

[^69]: ["1540 Committee"](https://www.un.org/en/sc/1540/about-1540-committee/general-information.shtml). *[United Nations](https://en.wikipedia.org/wiki/United_Nations "United Nations")*. [Archived](https://web.archive.org/web/20200220050416/https://www.un.org/en/sc/1540/about-1540-committee/general-information.shtml) from the original on 20 February 2020. Retrieved 2 March 2021.

[^70]: ["Overview of Potential Agents of Biological Terrorism | SIU School of Medicine"](https://www.siumed.edu/im/overview-potential-agents-biological-terrorism.html). *SIU School of Medicine*. [Archived](https://web.archive.org/web/20171119070804/http://www.siumed.edu/im/overview-potential-agents-biological-terrorism.html) from the original on 19 November 2017. Retrieved 15 November 2017.

[^71]: Millet, P., Kuiken, T., & Grushkin, D. (18 March 2014). Seven Myths and Realities about Do-It-Yourself Biology. Retrieved from [http://www.synbioproject.org/publications/6676/](http://www.synbioproject.org/publications/6676/) [Archived](https://web.archive.org/web/20170914115608/http://www.synbioproject.org/publications/6676/) 14 September 2017 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^72]: ["Al Qaeda's Pursuit of Weapons of Mass Destruction"](https://foreignpolicy.com/2010/01/25/al-qaedas-pursuit-of-weapons-of-mass-destruction/). *Foreign Policy*. 25 January 2010. [Archived](https://web.archive.org/web/20171114211242/http://foreignpolicy.com/2010/01/25/al-qaedas-pursuit-of-weapons-of-mass-destruction/) from the original on 14 November 2017. Retrieved 15 November 2017.

[^73]: ["A NATIONAL BLUEPRINT FOR BIODEFENSE: LEADERSHIP AND MAJOR REFORM NEEDED TO OPTIMIZE EFFORTS"](https://www.ecohealthalliance.org/wp-content/uploads/2016/03/A-National-Blueprint-for-Biodefense-October-2015.pdf) (PDF). *ecohealthalliance.org*. [Archived](https://web.archive.org/web/20170301213815/http://ecohealthalliance.org/wp-content/uploads/2016/03/A-National-Blueprint-for-Biodefense-October-2015.pdf) (PDF) from the original on 1 March 2017. Retrieved 15 November 2017.

[^74]: ["Federal Select Agent Program"](https://www.selectagents.gov/). *www.selectagents.gov*. [Archived](https://web.archive.org/web/20171124150908/https://www.selectagents.gov/) from the original on 24 November 2017. Retrieved 15 November 2017.

[^75]: Wagner D (2 October 2017). ["Biological Weapons and Virtual Terrorism"](https://www.huffingtonpost.com/entry/biological-weapons-and-virtual-terrorism_us_59d23151e4b034ae778d4c3c). *HuffPost*. [Archived](https://web.archive.org/web/20171104183637/https://www.huffingtonpost.com/entry/biological-weapons-and-virtual-terrorism_us_59d23151e4b034ae778d4c3c) from the original on 4 November 2017. Retrieved 3 November 2017.

[^76]: " [An Introduction to Biological Weapons, Their Prohibition, and the Relationship to Biosafety](http://www.sunshine-project.org/publications/bk/pdf/bk10en.pdf) [Archived](https://web.archive.org/web/20130512163809/http://www.sunshine-project.org/publications/bk/pdf/bk10en.pdf) 12 May 2013 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") ", *[The Sunshine Project](https://en.wikipedia.org/wiki/The_Sunshine_Project "The Sunshine Project")*, April 2002. Retrieved 25 December 2008.

[^77]: Lockwood JA (2008). [*Six-legged Soldiers: Using Insects as Weapons of War*](https://en.wikipedia.org/wiki/Six-legged_Soldiers:_Using_Insects_as_Weapons_of_War "Six-legged Soldiers: Using Insects as Weapons of War"). Oxford University Press. pp. 9–26. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-533305-3](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-533305-3 "Special:BookSources/978-0-19-533305-3").

[^78]: Kelle A (2009). "Security issues related to synthetic biology. Chapter 7.". In Schmidt M, Kelle A, Ganguli-Mitra A, de Vriend H (eds.). *Synthetic biology. The technoscience and its societal consequences*. Berlin: Springer.

[^79]: Garfinkel MS, Endy D, Epstein GL, Friedman RM (December 2007). ["Synthetic genomics: options for governance"](https://dspace.mit.edu/bitstream/1721.1/39141/1/Synthetic%20Genomics%20Options%20for%20Governance.pdf) (PDF). *Industrial Biotechnology*. **3** (4): 333–65. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1089/ind.2007.3.333](https://doi.org/10.1089%2Find.2007.3.333). [hdl](https://en.wikipedia.org/wiki/Hdl_\(identifier\) "Hdl (identifier)"):[1721.1/39141](https://hdl.handle.net/1721.1%2F39141). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [18081496](https://pubmed.ncbi.nlm.nih.gov/18081496).

[^80]: ["Addressing Biosecurity Concerns Related to Synthetic Biology"](https://web.archive.org/web/20150903211656/http://osp.od.nih.gov/office-biotechnology-activities/biosecurity/pdf/NSABB%20SynBio%20-DRAFT%20Report-FINAL%20\(2\)_6-7-10.pdf.). National Security Advisory Board on Biotechnology (NSABB). 2010. Archived from [the original](http://oba.od.nih.gov/biosecurity/pdf/NSABB%20SynBio%20-DRAFT%20Report-FINAL%20\(2\)_6-7-10.pdf.) on 3 September 2015. Retrieved 4 September 2010.

[^81]: Buller M (21 October 2003). *The potential use of genetic engineering to enhance orthopoxviruses as bioweapons*. International Conference "Smallpox Biosecurity. Preventing the Unthinkable. Geneva, Switzerland.

[^82]: Tumpey TM, Basler CF, Aguilar PV, Zeng H, Solórzano A, Swayne DE, et al. (October 2005). ["Characterization of the reconstructed 1918 Spanish influenza pandemic virus"](https://web.archive.org/web/20130626020959/http://birdflubook.com/resources/0Tumpey77.pdf) (PDF). *Science*. **310** (5745). New York, N.Y.: 77–80. [Bibcode](https://en.wikipedia.org/wiki/Bibcode_\(identifier\) "Bibcode (identifier)"):[2005Sci...310...77T](https://ui.adsabs.harvard.edu/abs/2005Sci...310...77T). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1126/science.1119392](https://doi.org/10.1126%2Fscience.1119392). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [16210530](https://pubmed.ncbi.nlm.nih.gov/16210530). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [14773861](https://api.semanticscholar.org/CorpusID:14773861). Archived from [the original](http://birdflubook.com/resources/0Tumpey77.pdf) (PDF) on 26 June 2013. Retrieved 23 September 2019.

[^83]: Cello J, Paul AV, Wimmer E (August 2002). ["Chemical synthesis of poliovirus cDNA: generation of infectious virus in the absence of natural template"](https://doi.org/10.1126%2Fscience.1072266). *Science*. **297** (5583): 1016–8. [Bibcode](https://en.wikipedia.org/wiki/Bibcode_\(identifier\) "Bibcode (identifier)"):[2002Sci...297.1016C](https://ui.adsabs.harvard.edu/abs/2002Sci...297.1016C). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1126/science.1072266](https://doi.org/10.1126%2Fscience.1072266). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [12114528](https://pubmed.ncbi.nlm.nih.gov/12114528). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [5810309](https://api.semanticscholar.org/CorpusID:5810309).

[^84]: Wimmer E, Mueller S, Tumpey TM, Taubenberger JK (December 2009). ["Synthetic viruses: a new opportunity to understand and prevent viral disease"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2819212). *Nature Biotechnology*. **27** (12): 1163–72. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1038/nbt.1593](https://doi.org/10.1038%2Fnbt.1593). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [2819212](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2819212). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [20010599](https://pubmed.ncbi.nlm.nih.gov/20010599).

[^85]: Basulto D (4 November 2015). ["Everything you need to know about why CRISPR is such a hot technology"](https://www.washingtonpost.com/news/innovations/wp/2015/11/04/everything-you-need-to-know-about-why-crispr-is-such-a-hot-technology/). *The Washington Post*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0190-8286](https://search.worldcat.org/issn/0190-8286). [Archived](https://web.archive.org/web/20160201131108/https://www.washingtonpost.com/news/innovations/wp/2015/11/04/everything-you-need-to-know-about-why-crispr-is-such-a-hot-technology/) from the original on 1 February 2016. Retrieved 24 January 2016.

[^86]: Kahn J (9 November 2015). ["The Crispr Quandary"](https://www.nytimes.com/2015/11/15/magazine/the-crispr-quandary.html). *The New York Times*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0362-4331](https://search.worldcat.org/issn/0362-4331). [Archived](https://web.archive.org/web/20170219040840/https://www.nytimes.com/2015/11/15/magazine/the-crispr-quandary.html) from the original on 19 February 2017. Retrieved 24 January 2016.

[^87]: Ledford H (June 2015). ["CRISPR, the disruptor"](https://doi.org/10.1038%2F522020a). *Nature*. **522** (7554): 20–4. [Bibcode](https://en.wikipedia.org/wiki/Bibcode_\(identifier\) "Bibcode (identifier)"):[2015Natur.522...20L](https://ui.adsabs.harvard.edu/abs/2015Natur.522...20L). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1038/522020a](https://doi.org/10.1038%2F522020a). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [26040877](https://pubmed.ncbi.nlm.nih.gov/26040877).

[^88]: Committee on the Evaluation of the Updated Site-Specific Risk Assessment for the National Bio- and Agro-Defense Facility in Manhattan, Kansas; Sciences, Board on Life; Resources, Board on Agriculture and Natural; Studies, Division on Earth and Life; Council, National Research (15 June 2012), ["Evaluation of Biosafety Level 4 Assessment"](https://www.ncbi.nlm.nih.gov/books/NBK207375/), *Evaluation of the Updated Site-Specific Risk Assessment for the National Bio- and Agro-Defense Facility in Manhattan, Kansas*, National Academies Press (US), retrieved 3 October 2025

[^89]: ["Challenges and Opportunities to Investigating the Origins of Pandemics and Other Biological Events | Johns Hopkins Center for Health Security"](https://centerforhealthsecurity.org/our-work/testimonies-briefings/challenges-and-opportunities-to-investigating-the-origins-of-pandemics). *centerforhealthsecurity.org*. Retrieved 3 October 2025.

[^90]: ["Anthrax Facts | UPMC Center for Health Security"](https://web.archive.org/web/20130302063353/http://www.upmc-biosecurity.org/website/our_work/biological-threats-and-epidemics/fact_sheets/anthrax.html). Upmc-biosecurity.org. Archived from [the original](http://www.upmc-biosecurity.org/website/our_work/biological-threats-and-epidemics/fact_sheets/anthrax.html) on 2 March 2013. Retrieved 5 September 2013.

[^91]: Hassani M, Patel MC, Pirofski LA (April 2004). "Vaccines for the prevention of diseases caused by potential bioweapons". *Clinical Immunology*. **111** (1): 1–15. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1016/j.clim.2003.09.010](https://doi.org/10.1016%2Fj.clim.2003.09.010). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [15093546](https://pubmed.ncbi.nlm.nih.gov/15093546).

[^92]: Bellamy, R.J.; Freedman, A.R. (1 April 2001). ["Bioterrorism"](https://doi.org/10.1093%2Fqjmed%2F94.4.227). *[QJM](https://en.wikipedia.org/wiki/QJM "QJM")*. **94** (4). [Association of Physicians of Great Britain and Ireland](https://en.wikipedia.org/wiki/Association_of_Physicians_of_Great_Britain_and_Ireland?action=edit&redlink=1 "Association of Physicians of Great Britain and Ireland (page does not exist)") ([OUP](https://en.wikipedia.org/wiki/Oxford_University_Press "Oxford University Press")): 227–234. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1093/qjmed/94.4.227](https://doi.org/10.1093%2Fqjmed%2F94.4.227). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [1460-2393](https://search.worldcat.org/issn/1460-2393). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [11294966](https://pubmed.ncbi.nlm.nih.gov/11294966).

[^93]: Franz D. ["The U.S. Biological Warfare and Biological Defense Programs"](https://web.archive.org/web/20180219221907/http://www.au.af.mil/au/awc/awcgate/medaspec/Ch-19electrv699.pdf) (PDF). *Arizona University*. Archived from [the original](http://www.au.af.mil/au/awc/awcgate/medaspec/Ch-19electrv699.pdf) (PDF) on 19 February 2018. Retrieved 14 June 2018.

[^94]: ["Vietnam's war against Agent Orange"](http://news.bbc.co.uk/1/hi/health/3798581.stm). *BBC News*. 14 June 2004. [Archived](https://web.archive.org/web/20090111171055/http://news.bbc.co.uk/1/hi/health/3798581.stm) from the original on 11 January 2009. Retrieved 17 April 2010.

[^95]: ["Critics accuse Sri Lanka of using scorched earth tactics against Tamils"](https://www.thenationalnews.com/world/Asia/critics-accuse-sri-lanka-of-using-scorched-earth-tactics-against-tamils-1.524770). *The National*. 20 May 2010. Retrieved 18 March 2019.

[^96]: ["Biowarfare Against Agriculture"](https://fas.org/biosecurity/education/dualuse-agriculture/1.-agroterrorism-and-foodsafety/biowarfare-against-agriculture.html). *fas.org*. Federation of American Scientists. Retrieved 15 February 2020.

[^97]: Croddy, Eric; Perez-Armendariz, Clarissa; Hart, John (2002). [*Chemical and biological warfare: a comprehensive survey for the concerned citizen*](https://archive.org/details/chemicalbiologic00crod/page/223). Copernicus Books. p. [223](https://archive.org/details/chemicalbiologic00crod/page/223). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-387-95076-1](https://en.wikipedia.org/wiki/Special:BookSources/0-387-95076-1 "Special:BookSources/0-387-95076-1").

[^98]: ["Chemical and Biological Weapons: Possession and Programs Past and Present"](http://www.nonproliferation.org/wp-content/uploads/2016/03/2008-Chemical-and-Biological-Weapons_-Possession-and-Programs-Past-and-Present.pdf) (PDF). *James Martin Center for Nonproliferation Studies*. [Archived](https://web.archive.org/web/20160909085128/http://www.nonproliferation.org/wp-content/uploads/2016/03/2008-Chemical-and-Biological-Weapons_-Possession-and-Programs-Past-and-Present.pdf) (PDF) from the original on 9 September 2016. Retrieved 17 March 2020.

[^99]: Verdcourt B, Trump EC, Church ME (1969). *Common poisonous plants of East Africa*. London: Collins. p. 254.

[^100]: European Union cooperative Initiatives to improve Biosafety and Biosecurity (12 August 2010). ["Meeting of the States Parties to the Convention on the Prohibition of the Development, Production and Stockpiling of Bacteriological (Biological) and Toxin Weapons and on Their Destruction"](https://digitallibrary.un.org/record/708897/files/BWC_MSP_2010_MX_WP.5-EN.pdf) (PDF).

[^101]: ["Vaccines for Military Members"](https://www.hhs.gov/immunization/who-and-when/military-members/index.html). 26 April 2021.

[^102]: Ouagrham-Gormley S. Dissuading Biological Weapons Proliferation. Contemporary Security Policy \[serial online\]. December 2013;34(3):473–500. Available from: Humanities International Complete, Ipswich, MA. Accessed 28 January 2015.

[^103]: Guillemin J (2013). *The Soviet Biological Weapons Program: A History. Politics & The Life Sciences*. Vol. 32. pp. 102–105. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2990/32\_1\_102](https://doi.org/10.2990%2F32_1_102). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [155063789](https://api.semanticscholar.org/CorpusID:155063789).

[^104]: Ryan CP (2008). ["Zoonoses likely to be used in bioterrorism"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2289981). *Public Health Reports*. **123** (3): 276–81. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/003335490812300308](https://doi.org/10.1177%2F003335490812300308). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [2289981](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2289981). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [19006970](https://pubmed.ncbi.nlm.nih.gov/19006970).

[^105]: Wilkening DA (2008). "Modeling the incubation period of inhalational anthrax". *Medical Decision Making*. **28** (4): 593–605. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/0272989X08315245](https://doi.org/10.1177%2F0272989X08315245). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [18556642](https://pubmed.ncbi.nlm.nih.gov/18556642). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [24512142](https://api.semanticscholar.org/CorpusID:24512142).

[^106]: Toth DJ, Gundlapalli AV, Schell WA, Bulmahn K, Walton TE, Woods CW, Coghill C, Gallegos F, Samore MH, Adler FR (August 2013). ["Quantitative models of the dose-response and time course of inhalational anthrax in humans"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3744436). *PLOS Pathogens*. **9** (8) e1003555. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1371/journal.ppat.1003555](https://doi.org/10.1371%2Fjournal.ppat.1003555). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [3744436](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3744436). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [24058320](https://pubmed.ncbi.nlm.nih.gov/24058320).

[^107]: Treadwell TA, Koo D, Kuker K, Khan AS (March–April 2003). ["Epidemiologic clues to bioterrorism"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1497515). *Public Health Reports*. **118** (2): 92–8. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1093/phr/118.2.92](https://doi.org/10.1093%2Fphr%2F118.2.92) (inactive 16 July 2025). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [1497515](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC1497515). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [12690063](https://pubmed.ncbi.nlm.nih.gov/12690063).

[^108]: ["Physorg.com, "Encoded Metallic Nanowires Reveal Bioweapons", 12:50 EST, 10 August 2006"](http://www.physorg.com/news74433040.html). [Archived](https://web.archive.org/web/20110605231844/http://www.physorg.com/news74433040.html) from the original on 5 June 2011. Retrieved 24 October 2014.

[^109]: ["BiosparQ features"](http://www.tno.nl/content.cfm?context=markten&content=case&laag1=178&item_id=832). [Archived](https://web.archive.org/web/20131113041020/http://www.tno.nl/content.cfm?context=markten&content=case&laag1=178&item_id=832) from the original on 13 November 2013. Retrieved 24 October 2014.

[^110]: Genuth I, Fresco-Cohen L (13 November 2006). ["BioPen Senses BioThreats"](https://web.archive.org/web/20070430131012/http://www.tfot.info/content/view/96/56/). *The Future of Things*. Archived from [the original](http://www.tfot.info/content/view/96/56/) on 30 April 2007.

[^111]: ["Shyh-Ching Lo"](https://www.google.com.pr/?gws_rd=cr,ssl#q=Shyh-Ching+Lo). [Archived](https://web.archive.org/web/20151231205603/https://www.google.com.pr/?gws_rd=cr,ssl&ei=n2tIVsOmGMTGeoK1ubgP#q=Shyh-Ching+Lo) from the original on 31 December 2015. Retrieved 15 November 2015.

[^112]: ["Pathogenic mycoplasma"](https://patents.google.com/patent/US5242820). [Archived](https://web.archive.org/web/20151117034437/http://www.google.com/patents/US5242820) from the original on 17 November 2015. Retrieved 16 November 2015.

[^113]: ["Interview: Dr Kanatjan Alibekov"](https://www.pbs.org/wgbh/pages/frontline/shows/plague/interviews/alibekov.html). *[Frontline](https://en.wikipedia.org/wiki/Frontline_\(U.S._TV_series\) "Frontline (U.S. TV series)")*. [PBS](https://en.wikipedia.org/wiki/Public_Broadcasting_Service "Public Broadcasting Service"). [Archived](https://web.archive.org/web/20100608073922/http://www.pbs.org/wgbh/pages/frontline/shows/plague/interviews/alibekov.html) from the original on 8 June 2010. Retrieved 8 March 2010.

[^114]: ["Dr. Ira Baldwin: Biological Weapons Pioneer"](http://www.historynet.com/dr-ira-baldwin-biological-weapons-pioneer.htm). American History. 12 June 2006. [Archived](https://web.archive.org/web/20090410044336/http://www.historynet.com/dr-ira-baldwin-biological-weapons-pioneer.htm) from the original on 10 April 2009. Retrieved 8 March 2009.

[^115]: Ute Deichmann (1996). [*Biologists Under Hitler*](https://books.google.com/books?id=gPrtE4K0WC8C&pg=PA173). Harvard University Press. p. 173. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-674-07405-7](https://en.wikipedia.org/wiki/Special:BookSources/978-0-674-07405-7 "Special:BookSources/978-0-674-07405-7").

[^116]: Leyendecker B, Klapp F (December 1989). "\[Human hepatitis experiments in the 2d World War\]". *Zeitschrift für die Gesamte Hygiene und Ihre Grenzgebiete*. **35** (12): 756–60. [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [2698560](https://pubmed.ncbi.nlm.nih.gov/2698560).

[^117]: Maksel R (14 January 2007). ["An American waged germ warfare against U.S. in WWI"](https://www.sfgate.com/books/article/An-American-waged-germ-warfare-against-U-S-in-WWI-2657341.php). *[SF Gate](https://en.wikipedia.org/wiki/SF_Gate "SF Gate")*. [Archived](https://web.archive.org/web/20110511192855/http://articles.sfgate.com/2007-01-14/books/17227292_1_anton-dilger-german-great-war) from the original on 11 May 2011. Retrieved 7 March 2010.

[^118]: Chauhan SS (2004). [*Biological Weapons*](https://books.google.com/books?id=MGZwgxoHxCAC&pg=PA194). APH Publishing. p. 194. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-81-7648-732-0](https://en.wikipedia.org/wiki/Special:BookSources/978-81-7648-732-0 "Special:BookSources/978-81-7648-732-0").

[^119]: Office of U.S. Chief of Counsel for the American Military Tribunals at Nurember, 1946. [http://www.mazal.org/NO-series/NO-0124-000.htm](http://www.mazal.org/NO-series/NO-0124-000.htm) [Archived](https://web.archive.org/web/20110501105128/http://www.mazal.org/NO-series/NO-0124-000.htm) 1 May 2011 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")

[^120]: ["Obituary: Vladimir Pasechnik"](https://www.telegraph.co.uk/news/obituaries/1363752/Vladimir-Pasechnik.html). *The Daily Telegraph*. London. 29 November 2001. [Archived](https://web.archive.org/web/20100303235824/http://www.telegraph.co.uk/news/obituaries/1363752/Vladimir-Pasechnik.html) from the original on 3 March 2010. Retrieved 8 March 2010.

[^121]: ["Anthrax attacks"](http://news.bbc.co.uk/1/hi/programmes/newsnight/archive/1873368.stm). *[Newsnight](https://en.wikipedia.org/wiki/Newsnight "Newsnight")*. BBC. 14 March 2002. [Archived](https://web.archive.org/web/20090407000929/http://news.bbc.co.uk/1/hi/programmes/newsnight/archive/1873368.stm) from the original on 7 April 2009. Retrieved 16 March 2010.

[^122]: ["Interviews With Biowarriors: Sergei Popov"](https://www.pbs.org/wgbh/nova/bioterror/biow_popov.html) [Archived](https://web.archive.org/web/20170618153502/http://www.pbs.org/wgbh/nova/bioterror/biow_popov.html) 18 June 2017 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), (2001) *[NOVA Online](https://en.wikipedia.org/wiki/Nova_\(American_TV_series\) "Nova (American TV series)")*.

[^123]: ["US welcomes 'Dr Germ' capture"](http://news.bbc.co.uk/1/hi/world/middle_east/3021981.stm). BBC. 13 May 2003. [Archived](https://web.archive.org/web/20061019042857/http://news.bbc.co.uk/1/hi/world/middle_east/3021981.stm) from the original on 19 October 2006. Retrieved 8 March 2010.

[^124]: Jackson PJ, Siegel J (2005). [*Intelligence and Statecraft: The Use and Limits of Intelligence in International Society*](https://books.google.com/books?id=I3Q3_Ww-5SMC&pg=PA194). Greenwood Publishing Group. p. 194. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-275-97295-0](https://en.wikipedia.org/wiki/Special:BookSources/978-0-275-97295-0 "Special:BookSources/978-0-275-97295-0").

[^125]: ["Jamie Bisher, "Baron von Rosen's 1916 Anthrax Mission," 2014"](http://anthrax1916.weebly.com/). *Baron von Rosen's 1916 Anthrax Mission*. [Archived](https://web.archive.org/web/20140413125850/http://anthrax1916.weebly.com/) from the original on 13 April 2014. Retrieved 24 October 2014.

[^126]: Trudel, Jack (January 2025). "Weaponization Risks of Mirror Bacteria: Feasibility, Consequences, and Mitigation Strategies". [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.13140/RG.2.2.14865.34401](https://doi.org/10.13140%2FRG.2.2.14865.34401).

[^127]: ["MIT Security Studies Program (SSP): Jeanne Guillemin"](http://web.mit.edu/ssp/people/guillemin/fellow_guillemin.html). [MIT](https://en.wikipedia.org/wiki/MIT "MIT"). [Archived](https://web.archive.org/web/20091128145354/http://web.mit.edu/ssp/people/guillemin/fellow_guillemin.html) from the original on 28 November 2009. Retrieved 8 March 2010.

[^128]: Lewis P (4 September 2002). ["Sheldon Harris, 74, Historian of Japan's Biological Warfare"](https://www.nytimes.com/2002/09/04/us/sheldon-harris-74-historian-of-japan-s-biological-warfare.html). *The New York Times*. [Archived](https://web.archive.org/web/20110511113121/http://www.nytimes.com/2002/09/04/us/sheldon-harris-74-historian-of-japan-s-biological-warfare.html?pagewanted=1) from the original on 11 May 2011. Retrieved 8 March 2010.

[^129]: Miller J (2001). [*Biological Weapons and America's Secret War*](https://archive.org/details/germsbiologicalw00mill/page/67). New York: Simon & Schuster. p. [67](https://archive.org/details/germsbiologicalw00mill/page/67). [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-684-87158-5](https://en.wikipedia.org/wiki/Special:BookSources/978-0-684-87158-5 "Special:BookSources/978-0-684-87158-5").

[^130]: ["Matthew Meselson – Harvard – Belfer Center for Science and International Affairs"](http://belfercenter.ksg.harvard.edu/experts/148/matthew_meselson.html). Harvard. [Archived](https://web.archive.org/web/20080905075527/http://belfercenter.ksg.harvard.edu/experts/148/matthew_meselson.html) from the original on 5 September 2008. Retrieved 8 March 2010.