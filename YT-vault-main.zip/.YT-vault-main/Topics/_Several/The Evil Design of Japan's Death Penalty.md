
today most of the developed world has
ended the death penalty but in 2024
there are still two countries in the
oecd that use it the United States of
America and
Japan but while the US has been
transparent about its ultimate
punishment Japan has kept its practices
secret for years it was only in 2010
that the world was finally shown the
evil design of Japan's death penalty
July 26 2022 Tomy her oato is sitting in
a Cell in the Tokyo Detention
Center 14 years ago he killed seven
people and injured 10
in 2011 tomato was sentenced to
death every day he wakes up at 7:00 a.m.
and heads to bed at 9:00 p.m. in a Cell
that's the size of about four tatami
mats he has a sink a commode bedding and
a small
desk in Japan death row inmates can wait
decades for an execution but unlike the
US they wait for a day they never really
know is
coming any random morning the inmate can
be taken to the execution chamber
they're given no more than a few hours
notice the Japanese state says that this
helps with emotional stability that it
reduces the chances of an inmate taking
life some argue it's Justice their
victims weren't given notice
either others say it's inhumane for 34
years a man named Menda Saka
didn't know which day would be his last
in 1983 he was
freed the police officer who arrested
him revealed that he had concealed
sakai's Alibi that proved he was
innocent 12,410 mornings with an
unjustified fear for
execution in 2014 iwa hakamada was also
released and given a retrial due to
possibly falsified
evidence he was the longest serving
death row inmate on the planet kamada
spent more than 45 years in prison
waiting in the Tokyo Detention Center
Kato sits in his cell he's surrounded by
objects purposely made rounder so that
he can't finish off his sentence earlier
than expected on July 26th 2022 after 14
years of waiting he hears more noises
than usual outside of his
door today the majority of the developed
world has outlawed the death penalty but
Japan is
strange this book explains why even
though it's still legal in the US it's
debatable the United States is a federal
divided country many states have phased
out the death penalty
entirely Japan on the other hand is a
centralized state where polls have shown
that the public supports it with a clear
majority the US's death penalty is
intimately connected with its history of
racial discrimination and
enslavement Japan is ethnically
homogeneous and has less
inequality the fall of an authoritarian
leader like Hitler melini Salazar and
Franco all led to the abolition of the
death penalty in their respective
countries Japan's authoritarian State
also fell but the death penalty
remained in Austria Great Britain and
France the election of a left-wing
government all led to the abolition of
capital punishment in 2009 Japan elected
the center left democ atic party of
Japan the death penalty stayed but what
makes Japan's situation even stranger is
how uniquely brutal it
is its homicide rate is a fraction of
that found in the US and it's lower than
all the European countries which have
abolish the death
penalty nevertheless the percentage of
murder offenders sentenced to death in
Japan and the US are around the
same in 2018 15 Japanese prisoners were
killed with about6 16 inmates on death
row that's 10 less than the US is 25
which had more than 10 times the amount
of inmates on death
row seven of the 15 executions were part
of the AUM shrio doomsday cult the
Japanese State sometimes executes in
batches all seven were killed on the
same
morning while the US explicitly treats
the death penalty differently from other
criminal sentencing in Japan it's
treated like other criminal
punishments to be put the death in the
US you must go through a b furic trial
system there is a criminal trial for
determining guilt or innocence which
requires
unanimity after if determined to be
guilty it goes to another trial for
deciding the punishment here you must
receive again a unanimous agreement from
the jury then the judge can serve you
the death
penalty Florida and Alabama are the only
exceptions but these two states are
outliers in the US context and they
still require a super
majority in Japan it's
different under the cin system citizens
act like judges they sit alongside
professional ones to determine both the
verdict and the sentence of a crime all
that is required for the death penalty
is a
majority in theory five judges on the
panel can believe the defendant is
guilty and deserves the death penalty
while the other four could believe the
defendant is innocent and deserves no
punishment whatsoever with this close of
a
vote the defendant can be sentenced to
death in Japan there are seven detention
centers that execute the death penalty
it's the Justice Minister who decides
when it will take
place 5 days after he or she signs the
warrant The Prisoner is put to death
these are usually signed right before
political recess moments where media
coverage is
limited the executions are not made
clear to the family members and lawyers
of the inmates they only learn after
it's taken
place Kato is brought into a prayer room
here he is read his last rights by a
spiritual adviser he is given time to
write a will and maybe to consume some
snacks or even smoke a
cigarette afterwards he's taken into
another small room with an altar if
they're Buddhist it will be a figure of
the Buddha if they're one of the few
Christians in the country a
crucifix in this room the execution
order is officially read out by the
prison Warden the last thing Kato sees
are the blue curtains covering the Next
Room the guards wrap a bleached white
blindfold around his eyes throw a black
hood over his head handcuff his hands
behind his back and tie his knees
together he is taken to the next and
final
room in the US lethal injection is the
primary method of executing the death
penalty in Japan hanging is the only
method at the center of the room room
are two red squares an inmate is made to
stand in the
center beneath is a trap door connected
to an adjacent room when the inmate is
in place three officers enter this room
they do not see the prisoner what they
see instead are three identical buttons
two do nothing but the third opens the
trap
door the three officers do not know
which one is the kill
switch this divides the responsibility
between all three it's also been
mentioned that there is a delayed
circuit to hide who pressed the kill
button if they were pressed at different
times but I could not find a good source
to confirm
this for their service all three
officers received 20,000 yen about $180
each watching the execution are a few
officials the head of the Detention
Center a medical officer and the
prosecutors
the medical officer waits for 5 minutes
until confirming the death after the
body is cleaned the families are
notified the body will be cremated
unless the family specifies
otherwise in the case of some
high-profile inmates the ashes are kept
in state
custody it was only in 2007 that the
Japanese government even released the
names of those put to death currently
there are 106 inmates awaiting their
execution in
Japan the last person sentenced to the
death row killed 36 people in an arson
attack tomato was the last person
executed in the country I only felt
comfortable putting this video in
production after it was confirmed that a
very specific organization would sponsor
it if topics like this one make you feel
eager for positive change in the world
you should check out 880,000
hours it's an independent nonprofit that
understands that your time is limited
and it wants to help you find a career
with more positive impact
it helps you identify the most pressing
problems which careers make a difference
on those problems and how you personally
might be able to make the most
difference you can access their
completely free career guide for
practical research-driven advice on how
to plan a career that's fulfilling and
meaningful check out their free career
guide at 8000 hour.org hoo