De l'arrachage des yeux des gens à la
dévoration des fils chéris par les
pères. De l'étirement sur le chevalet
à l'arrachage des bras. Voici comment
la torture a évolué au fil des ans.
Attachez vos ceintures. Cela va être
brutal. Dans les années 1980, un
groupe d'archéologues est tombé sur
quelque chose dans le sol qui les a
excités, mais qui leur a aussi donné
un petit choc. Ce qu'ils ont vu a
révélé quelque chose qu'ils
soupçonnaient depuis longtemps. À
savoir que certains des premiers
peuples à passer de la chasse et de la
cueillette à l'agriculture étaient
indubitablement, parfois, très
méchants les uns envers les autres.
Ces gens ont pratiqué la torture
pendant très longtemps. Divers
intellectuels avaient parlé du
soi-disant bon sauvage. Ces premières
sociétés, disaient-ils, étaient pour
la plupart pacifiques. Ils disaient que
les gens ne sont devenus violents que
plus tard, lorsqu'ils ont été
corrompus par la civilisation, par le
capitalisme naissant. Ces gens ne
croyaient pas ce que le philosophe
britannique Thomas Hobbes avait dit un
jour sur l'état de la nature humaine.
c'était que les gens étaient toujours
en guerre les uns contre les autres,
que l'état naturel des choses était
sacrément impitoyable. Hobbes était
célèbre pour avoir dit que la vie
était solitaire, pauvre, méchante,
brutale et courte. Ce n'était pas le
genre de choses que beaucoup de gens
voulaient entendre. Ils préféraient
le point de vue noble et sauvage, selon
lequel les humains sont
fondamentalement gentils, et que ce
sont les systèmes dans lesquels ils
vivent qui les rendent cruels et
belliqueux. Mais ce que les
archéologues ont trouvé semble
suggérer que certaines personnes de
ces premiers temps de la civilisation
n'étaient pas du tout gentilles. En
fait, elles étaient pourries jusqu'à
la moelle. Ces personnes avaient
voyagé de ce qui est aujourd'hui la
Turquie jusqu'en Europe centrale. Nous
les appelons aujourd'hui les peuples du
Néolithique. Des gens qui ont
commencé à cultiver la terre et à
apprécier les choses modernes comme
décorer leurs pots. Ils aimaient aussi
un peu de violence extrême de temps en
temps. Nous le savons parce que les
archéologues ont trouvé des fosses
communes en Allemagne et en Autriche.
Les corps étaient au nombre d'une
centaine. Mais ce qui était étrange,
c'est que les familles n'avaient pas
été enterrées ensemble, ce qui
était généralement le cas à
l'époque. Ces personnes avaient été
simplement jetées, semble-t-il, sans
aucune cérémonie. Il y avait eu un
massacre. Mais ce sont les tortures
qu'elles avaient subies avant de mourir
qui ont vraiment choqué les
scientifiques. Des adultes, hommes et
femmes, et pas mal d'enfants avaient eu
le crâne fracassé. Mais avant ce coup
final, il semblait que quelqu'un leur
avait cassé les tibias. Nous ne savons
pas pourquoi, mais les archéologues
pensent que celui qui les avait tués
voulait qu'ils souffrent le plus
possible. Nous parlons de briser
littéralement des gens, des familles
entières. Bien sûr, il est possible
que les choses ne se soient pas
passées ainsi. Peut-être, ont
déclaré certains scientifiques, les
familles avaient-elles été brisées
après leur mort. Peut-être pour que
leurs fantômes ne puissent pas
poursuivre leurs assassins. Mais il
reste certain qu'ils avaient été
tués de manière très brutale. La
torture ne remonte pas à aussi loin.
Du moins, d'après ce que nous en
savons. Après cette période de bris
de tibias, la torture a vraiment pris
son essor. Et comme vous le verrez
aujourd'hui, elle était souvent très
extrême. Si vous vous demandez ce qui
définit réellement la torture, nous
pouvons examiner ce qu'en disent les
Nations unies. Elles stipulent que la
torture est tout acte par lequel une
douleur ou des souffrances aiguës,
physiques ou mentales, sont
intentionnellement infligées à une
personne dans le but d'obtenir d'elle
ou d'une tierce personne des
informations ou des aveux la punissant
d'un acte qu'elle ou une tierce
personne a commis ou est soupçonnée
d'avoir commis. C'est assez vague. On
pourrait dire qu'être forcé de
regarder un concert de Justin Bieber
encore et encore et encore est une
forme de torture. Les peuples anciens
n'avaient pas ce genre de pouvoir à
portée de main, ils devaient donc se
contenter de méthodes de torture à
l'ancienne. Nous savons que la torture
pendant les interrogatoires était une
pratique courante dans l'Empire
archaïmide, parfois appelé le premier
Empire perse. Il a été fondé par
Cyrus le Grand en 550 av. J.-C. De
Perse, ils se sont répandus dans les
Balkans et en Europe de l'Est. C'était
une civilisation avancée pour
l'époque, mais ils avaient aussi un
goût prononcé pour le sang. Alexandre
le Grand l'a découvert lorsqu'il a
envahi la quasi-totalité de leur
empire. Le roi Cyrus était admiré par
ces Grecs de l'Antiquité, et il était
même connu pour son soutien aux droits
de l'homme. Mais cela ne voulait pas
dire qu'il était contre la torture. Il
aurait probablement adopté le dicton :
« Si tu veux faire une omelette, il
faut casser quelques œufs, ou plutôt
des têtes. » Une des histoires
raconte à son sujet que sa femme s'est
un jour énervée contre l'un des
uniques du palais. C'étaient les
gardes castrés du palais. Elle a dit
à Cyrus que cet homme devait être
puni. En fait, elle a dit qu'il devait
être tué trois fois. Nous ne savons
pas ce qui l'a mise en colère à ce
point, mais nous savons ce qui est
arrivé à ce pauvre unique. Selon le
récit, elle a ordonné qu'on lui
arrache les yeux. Cela s'est produit,
mais il a ensuite été laissé un
moment pour qu'il aille mieux. Une fois
qu'il s'est senti mieux, bien
qu'aveugle comme une chauve-souris,
elle lui a fait écorcher la peau. Elle
lui permit ensuite de se faire soigner
une fois de plus pour qu'il retrouve un
semblant de santé. Ce n'est qu'à ce
moment-là qu'elle lui permit de mourir
pour la troisième et dernière fois.
Une mort par crucifixion, ce qui est
une torture en soi. Ce genre de torture
avait un nom. On l'appelait la triple
mort. Cela ne se passait pas toujours
comme ce qui était arrivé à
l'infortuné unique. Mais le but était
toujours le même : faire ressentir à
quelqu'un autant de douleur que
possible avant qu'il ne meure. Puis il
y eut l'histoire racontée par le grand
philosophe et historien grec Plutarque.
Dans son livre, La vie d'Artiserxès,
il écrivit que Cyrus le Jeune s'était
battu avec son frère, Artiserxès II,
pour pouvoir monter sur le trône. Ce
genre de chose n'était pas rare à
l'époque. Il y eut une bataille et
Cyrus le Jeune fut tué. Un jeune
soldat perse du nom de Mithratis courut
au palais et dit à tout le monde qu'il
avait porté le coup fatal, mais il
s'avéra que ce n'était pas le cas. Il
pensait juste que c'était le cas. La
mère de Cyrus, Parisadus, avait
entendu parler de ce personnage de
Mithrati, et disons qu'elle s'en est
prise à lui assez durement. Il existe
plusieurs histoires sur ce qui lui est
arrivé, mais elles impliquent toutes
des tortures extrêmes. Une histoire
raconte qu'il a d'abord été pendu à
une roue et laissé au soleil pendant
10 jours, puis qu'on lui a arraché les
yeux, et que la résistance du PSD
consistait à lui verser de l'or moulé
dans les oreilles. L'autre histoire
raconte qu'elle a ordonné qu'il meure
par scaisme. Cela consistait à
attacher la victime entre des bateaux,
puis à la gaver de lait et de miel
pendant un bon moment. Et à la fin, le
type était dévoré de l'intérieur
par tous les insectes qui allaient se
régaler de ses excréments et de ses
vomissures. C'est pourquoi le scaisme
figure dans notre top 10 des pires
façons de mourir. Donc, en matière de
torture, les Perses étaient un peuple
assez remarquable. Jusqu'ici, nous
avons parlé de leurs tortures
physiques, mais certains d'entre eux
étaient réputés pour leurs tortures
mentales. Une histoire concernait le
roi Auees. Ce type était le chef de
l'Empire mède jusqu'à ce que son
petit-fils Cyrus le Grand lui monte sur
le trône. Avant cela, le roi Osteaggas
était peut-être un peu paranoïaque.
Il avait de bonnes raisons d'être
ainsi, nous ne le critiquerons donc pas
trop pour cela. Une nuit, il rêva que
son petit-fils allait un jour le
vaincre et monter sur le trône. Comme
vous le savez, cela s'est réellement
produit. Après avoir fait ce rêve, il
ordonna à un général nommé
Harpeggus de tuer le nourrisson.
Arpeggus n'y parvint tout simplement
pas, alors il confia l'enfant à un
berger et mentit en disant qu'il
l'avait tué. Ce n'est qu'une décennie
plus tard qu'Oiegas découvrit qu'il
avait été trompé par son général
habituellement digne de confiance. Il
n'était pas très content et il voulut
punir Harpeggus de la pire des
manières. Alors, comme tout le monde
l'aurait fait, il trancha la gorge du
fils d'Harpeggus. Il le découpa
ensuite en morceaux et fit cuire sa
chair à la broche lors d'un banquet.
Peu connu pour sa tolérance, Oiegas
invita alors Harpeggus à se joindre au
banquet et à goûter à la délicieuse
viande qu'il avait achetée chez le
boucher local. Alors qu'Harpeggus se
remplissait l'estomac et savourait
quelques verres de vin, Odue murmura à
l'oreille d'un de ses serviteurs et lui
dit de sortir la tête du garçon et de
la poser sur la table devant Harpeggus.
On ne peut qu'imaginer le choc que cela
provoqua, surtout lorsqu'Oiega dit à
Harpe : « Sais-tu de quelle viande de
bête tu as mangé ? » En lui-même,
Harpegasus avait envie de planter son
couteau dans la gorge de son patron.
Mais bien sûr, s'il montrait la
moindre trace de colère, il mourrait
lui-même bientôt. Il rassembla ses
pensées et dit au roi : « Je sais, et
tout ce que fait le roi est agréable.
» Il dit que le plat était si bon
qu'il aimait emporter un doggy bag chez
lui. De retour chez lui, il enterra ce
qui restait de son fils derrière la
maison. Ces Perses étaient peut-être
doués pour construire des routes et
inventer des systèmes postaux, mais en
matière de torture, ils n'étaient pas
très progressistes. Et au bout du
compte, les subalternes étaient
généralement tenus responsables de
tout. Les dirigeants n'avaient aucun
scrupule à accepter pleinement les
inégalités. Un jour, la mère du roi
Artisert II tua sa propre femme. On
aurait pu penser qu'il aurait déversé
sa colère sur sa mère, mais ce genre
de chose n'arrivait généralement pas.
Au lieu de cela, il fit exécuter tous
ses serviteurs. Ce fut une mort lente
et horrible pour chacun d'eux,
consistant à se faire écraser
lentement la tête avec de grosses
pierres. Malgré la menace de violence,
les gens enfreignaient encore la loi de
temps en temps. Cela consistait souvent
à s'allonger sur une route et à
sauter au passage d'une personne
transportant des objets de valeur.
Naturellement, les gens riches
détestaient cela. Ils inventèrent
donc des punitions très brutales pour
les voleurs. L'une d'elles consistait
à trouver deux arbres assez proches
l'un de l'autre. Une fois qu'ils
avaient les bons arbres, les soldats
les tiraient l'un vers l'autre de
toutes leurs forces. Ils attachaient
ensuite des cordes à chaque arbre et
attachaient les mains du prisonnier à
chaque corde. Une fois le prisonnier en
place, ils laissaient les arbres
reprendre leur position naturelle, et
le prisonnier était déchiré en deux,
ou du moins ses membres étaient
séparés de son corps. Ils étaient
laissés ainsi pour que quiconque
envisageait de voler puisse voir ce qui
lui arriverait s'il était pris. Il y
avait aussi des tortures plus
insensées. Une fois, un juge perse fut
écorché vif pour avoir accepté un
pot-de-vin et sa peau fut transformée
en tissu pour une chaise. Son fils fut
alors nommé juge et il dut s'asseoir
sur cette chaise tous les jours.
C'était une torture mentale. D'autres
fois, les chefs perses jetaient les
gens dans des cendres chaudes. Dans un
cas documenté, une reine était
contrariée et elle ordonna que 12
femmes nobles soient enterrées
vivantes. Aucune raison ne fut donnée
quant à la raison de son acte. Selon
l'historien grec Hérodote, une
maîtresse, l'épouse du roi Xerxès le
Grand, ordonna d'enterrer vivants 14
enfants de femmes nobles. Mais devinez
quelle en était la raison ? Hérodote
affirma que c'était simplement parce
qu'elle voulait montrer sa gratitude
envers son dieu pour lui avoir accordé
une longue vie. Il est difficile
d'imaginer ce que les parents des
enfants en pensaient, mais vous pouvez
être sûrs qu'ils n'ont pas hérité
de leurs griefs. La torture n'était
donc pas toujours pratiquée pour
obtenir des aveux de quelqu'un. Elle
était également utilisée pour faire
un exemple en lui administrant une mort
lente, qu'elle soit physique ou mentale
. Il s'agissait pour quelqu'un de faire
étalage de ses muscles, de faire
savoir aux gens qui était aux
commandes. Passons maintenant aux
Perses. Les Grecs anciens le faisaient
aussi, mais généralement uniquement
contre les étrangers et les esclaves.
En fait, dans la loi athénienne, il
était stipulé que si quelqu'un devait
avouer, cela devait être fait sous la
torture. Les législateurs grecs ont
d'ailleurs déclaré que cette méthode
était la plus démocratique. Oui,
c'est effectivement insensé. Et ces
Grecs de l'Antiquité n'étaient pas
vraiment stupides non plus. Dans un
texte, il est écrit : « Vous, les
jurés, considérez la torture comme la
preuve la plus fiable dans les affaires
privées comme publiques. Et lorsque
des esclaves et des personnes libres
sont disponibles, et que vous devez
découvrir un fait sous enquête, vous
n'utilisez pas le témoignage des
personnes libres, mais vous soumettez
les esclaves à la torture. » L'auteur
a déclaré que c'était la meilleure
façon et la plus démocratique de
faire les choses, car certaines
personnes libres mentent parfois au
tribunal. Il a ajouté : « Il n'a
jamais été prouvé qu'une personne
soumise à la torture ait menti. » Eh
bien, nous pensons que cet homme était
complètement à côté de la plaque
avec cette remarque. Il est difficile
d'imaginer une civilisation aussi
merveilleuse et révolutionnaire ne pas
comprendre que la torture n'est peut-
être pas le meilleur moyen d'amener
quelqu'un à vous dire la vérité. Les
gens diront généralement n'importe
quoi lorsqu'ils seront confrontés à
une torture extrême, ce qui rend les
aveux très peu fiables. Tout comme les
Perses, les Grecs libres, dotés de
tout le pouvoir, pensaient qu'ils
valaient mieux que les esclaves ou les
étrangers. Ils vous riraient au nez si
vous pouviez remonter le temps et leur
dire qu'ils n'étaient pas supérieurs
à ces gens. Les Romains étaient
pareils à cet égard. Les étrangers
et les profanes étaient considérés
comme beaucoup moins civilisés. On les
appelait des sauvages. Ainsi, lorsque
Néron attachait les gens à des
poteaux et les recouvrait d'une
substance inflammable pour pouvoir tous
les allumer et faire un grand spectacle
de chandelles romaines, il ne pensait
pas faire quelque chose de mal. Si vous
torturiez l'esclave de quelqu'un
d'autre pour ce que vous considériez
comme une transgression, vous deviez
peut-être payer une somme d'argent au
propriétaire de l'esclave si vous le
tuiez ou le rendiez infirme
accidentellement. La partie lésée
n'obtenait rien. Bien sûr, le
problème ne concernait que les
personnes libres. Les esclaves
n'avaient absolument aucun pouvoir dans
de telles situations. En l'an 61 après
J.-C., un esclave tua son maître
romain. Devinez ce qui s'est passé en
guise de punition ? 400 esclaves ont
été tués. C'était parce que les
Romains voulaient faire passer un
message. C'était exagéré, mais les
esclaves étaient vraiment considérés
comme des personnes inférieures.
Fouetter, marquer au fer rouge et
battre les esclaves n'était pas
seulement légal, mais c'était aussi
une pratique courante si l'esclave ne
remplissait pas son devoir. Les Romains
faisaient parfois combattre les
esclaves contre des bêtes sauvages
dans l'arène ou les attachaient
parfois dans un sac avec un chien, un
coq ou un singe, puis jetaient ce sac
dans un plan d'eau. Il s'agissait de
condamnations à mort, mais elles
étaient également censées être une
forme de torture, tout comme la
crucifixion. Dans la Chine ancienne, on
coupait les gens en deux. On écorchait
leur chair. Parfois, on leur coupait
simplement les pieds ou on leur
écorchait le visage. Ces actes
étaient également censés être de la
torture, et pas seulement une peine de
mort. Être exécuté rapidement était
considéré comme une forme de
miséricorde à l'époque. Et si les
autorités ou le dirigeant voulaient
obtenir des informations du condamné,
une mort lente et douloureuse pouvait
toujours s'avérer utile. C'est du
moins ce qu'ils pensaient. C'était le
cas du lingchi chinois, ou « tranchage
lent » en français. Le condamné
avait le choix. Faire des aveux
complets et recevoir un coup mortel ou
ne pas parler et recevoir de très
nombreuses coupures douloureuses. Les
Chinois ont introduit cette méthode
vers l'an 900, mais elle était encore
pratiquée au XXe siècle.
Concentrons-nous maintenant sur une
forme de torture qui était réputée
dans certaines régions d'Europe au
Moyen Âge. Vous la connaissez
certainement tous : le chevalet. Il
s'agissait d'une machine de torture qui
utilisait des rouleaux, des cordes et
des poulies pour étirer une personne.
Lorsqu'elle était utilisée pendant un
interrogatoire, la personne pouvait
être étirée au point de se briser
lorsque ses membres étaient arrachés
de ses articulations. Comme vous pouvez
l'imaginer, c'était une méthode très
, très douloureuse. Le chevalet
existait déjà dans la Grèce et la
Rome antiques. Mais nous en avons
déjà parlé, alors choisissons une
autre destination. Nous choisirons la
Grande-Bretagne où, chaque 5 novembre,
les gens célèbrent cet événement en
allumant des feux de joie et en y
jetant une effigie. Cette effigie
représente le corps d'un homme nommé
Guy Fox. Il semble assez dingue que les
Britanniques se tiennent autour d'un
feu déchaîné, enfants et adultes
mangeant des pommes d'amour, des tartes
et des petits pois, passant un bon
moment tout en célébrant l'exécution
d'un homme à qui on avait arraché
l'estomac et amputé les membres. Ils
ont même regardé des feux d'artifice
appelés roues de Catherine, inspirés
de la roue brisée où les gens
étaient matraqués à mort. C'est peut
-être pour cela que les Britanniques
ont parfois un sens de l'humour assez
noir. Les enfants des écoles primaires
avaient même l'habitude de chanter des
chansons sur la mort par la peste. Une
bague, une bague de roses, une poche
pleine de bouquets, un mouchoir, un
mouchoir, nous tombons tous. C'est
assez dingue pour une chanson pour
enfants. Quoi qu'il en soit, Guy Fox,
il a fait partie d'un complot visant à
faire exploser le Parlement, l'endroit
désormais connu pour ses politiciens,
sa consommation de cocaïne et le
Brexit. Mais à l'époque de Fox, au
XVIe siècle, les politiciens
n'étaient pas aussi louches. Ils n'ont
cependant pas pris la chose à la
légère lorsqu'ils ont découvert le
complot visant à les réduire en
miettes. Ils torturèrent Fox et lui
ordonnèrent de leur donner les noms de
ses complices. Au début, Fox se montra
si dur que même le roi Jacques
remarqua son impressionnante
détermination. Le roi ordonna alors
que Fox soit emmené à la redoutable
Tour de Londres, où il devait
légalement être torturé. Le roi
déclara qu'ils devaient y aller
doucement avec lui au début, mais que
s'il ne parlait pas, ils devraient
passer aux choses sérieuses. Fox
résista pendant le premier jour de
torture, mais le deuxième jour, cela
s'avéra trop dur pour lui. Petit à
petit, il cracha le morceau. Nous ne
savons pas avec certitude si le
chevalet a été utilisé dans ce cas,
mais la plupart des historiens pensent
que c'était parce que l'écriture de
ses aveux donnait l'impression qu'elle
avait été écrite par un homme qui
avait passé par là. Les choses
n'allaient pas s'arranger non plus. Les
hommes reçurent une sentence assez
sévère. Tout d'abord, ils devaient
être pendus, mais de manière à ce
qu'ils puissent encore vivre quelques
minutes. Ensuite, leurs parties
génitales devaient être arrachées
avec un couteau bien aiguisé et
brûlées devant eux. Puis venait
l'ablation de leurs entrailles et de
leur cœur. Enfin, on leur coupait la
tête et on découpait leur corps en
quartiers. C'était donc aussi une
forme de torture. C'était censé être
une héroïne, pas seulement pour la
victime, mais aussi pour les
spectateurs. Ces spectacles d'une
brutalité absolue étaient censés
envoyer un message. Le chevalet
lui-même existait en Grande-Bretagne
depuis le XVe siècle. Il était
considéré comme un outil très utile
lorsqu'il était utilisé pour amener
les commerçants, les conspirateurs ou
même les hérétiques à dénoncer
d'autres personnes ou au moins à
admettre qu'ils avaient fait quelque
chose de mal. Il n'était pas souvent
utilisé dans le sens extrême du terme
, et on pense que la simple vue de
l'objet faisait parler les gens. Avant
même d'entendre leurs membres craquer,
ils racontaient généralement tout. Ce
n'était pas le cas d'une femme
courageuse nommée Anne Akew. Elle
était prédicatrice et soutenait
Martin Luther. Il est connu pour avoir
lancé la Réforme protestante. Pour
faire court, un skuw prêchait beaucoup
. Elle allait parler du protestantisme
aux gens, ce qui lui valut d'être
arrêtée à plusieurs reprises. En
1546, un an seulement avant la mort du
roi Henri VIII, elle se retrouva à la
Tour de Londres. Ses interrogateurs lui
demandèrent qui avait également
prêché la parole du protestantisme,
mais elle refusa de donner des noms.
Les femmes n'étaient pas souvent
torturées à cette époque, mais elle
fut soumise à la torture, aux entraves
et au supplice. Nous savons ce qui
s'est passé parce qu'elle a pris des
notes. Elle écrivit : « Alors Maître
Rich et un membre du conseil me
chargèrent, sur mon obéissance, de
leur montrer si je connaissais un homme
ou une femme de ma secte. Ma réponse
fut que je n'en connaissais aucun. Ils
me dirent que le roi avait été
informé que je pouvais nommer, si je
le voulais, un grand nombre de membres
de ma secte. Je répondis que le roi
s'était aussi bien trompé à ce sujet
qu'il avait dissimulé dans d'autres
affaires. » Elle fut ensuite emmenée
au cachot. Là, Sir Anthony Kingston
ordonna au geôlier de la mettre au
supplice. Il pensait que dès que son
corps le toucherait, elle se mettrait
à parler, mais ce ne fut pas le cas.
Il ordonna donc au geôlier de
l'étirer. Le Lord Chancelier était
également là. Le geôlier ne voulait
pas le faire. La vue de ses grimaces et
des hurlements silencieux qui sortaient
de ses lèvres était tout simplement
trop pour lui. On lui rappela alors que
s'il ne tournait pas la roue, le roi le
découvrirait et qu'il finirait
probablement par être lui-même
condamné à une lourde peine. Juste
avant qu'ils ne commencent vraiment à
l'étirer. Elle lui demanda si elle
était enceinte. Elle répondit : «
Vous n'aurez pas besoin de vous
épargner pour cela, mais faites ce que
vous voulez de moi. » Traduit en
langage moderne, cela signifie : ne
vous inquiétez pas pour cela.
Continuez. Faites de votre mieux. Elle
écrivit plus tard : « Ils m'ont
ensuite mise au supplice parce que je
n'avais avoué aucune dame ou aucun
monsieur être de mon avis, et ils
m'ont gardée longtemps à ce sujet ;
et comme je restais allongée sans
bouger et ne pleurais pas, mon Lord
Chancelier et Maître Rich ont pris la
peine de me torturer de leurs propres
mains jusqu'à ce que je sois presque
morte. » Un type qui a vu ce qui s'est
passé ensuite a écrit plus tard à ce
sujet, disant : « Ses os étaient
presque arrachés. » Ses cris
pouvaient être entendus dans le
bâtiment voisin où une femme était
assise avec son enfant. C'était une
chose horrible à entendre. » Ils lui
ont alors demandé à nouveau avec qui
elle travaillait. Elle n'a rien dit.
Elle écrivit plus tard : « Mon
Seigneur Dieu m'a donné la grâce de
persévérer et je le ferai, je
l'espère, jusqu'au bout. « Le roi
apprit plus tard ce qui s'était passé
et ne fut apparemment pas très heureux
que cette femme ait été torturée de
la sorte. Elle fut tellement battue
après son étirement qu'il fallut
l'emmener sur une chaise. Pourtant,
comme vous le savez sans doute, le roi
Henri VIII n'était pas vraiment contre
l'exécution. Le jour où elle devait
être brûlée vive, elle ne pouvait
toujours pas marcher et dut être
conduite à l'échafaud sur une chaise.
Il fut écrit plus tard : «
Lorsqu'elle fut conduite sur le bûcher
, elle fut attachée par la taille avec
une chaîne qui retenait son corps. »
Lorsque tout fut prêt, les lettres de
pardon du roi furent apportées, par
lesquelles il lui offrait la sauvegarde
de sa vie, si elle se rétractait, ce
qu'elle ne voulait ni recevoir, ni
même daigner regarder une seule fois.
» « Comme c'était souvent le cas
dans ces affaires, le bourreau a tenté
de rendre la mort plus rapide en lui
mettant de la poudre à canon autour du
cou. Il a ensuite allumé le feu et il
y a eu bientôt une conflagration impie
autour de son corps. Des témoins ont
remarqué qu'elle n'a pas crié avant
que les flammes ne commencent à lui
brûler la chair de la poitrine. Vous
vous demandez peut-être maintenant si
quelqu'un est réellement mort sur le
chevalet en Grande-Bretagne ? La
réponse est oui. C'est arrivé à un
homme du nom de Nicholas Owen. Preuve
de la folie et de la folie dont
l'humanité peut parfois faire preuve.
Il n'a pas été mis sur le chevalet en
raison de sa dévotion au
protestantisme, mais parce qu'il était
un catholique fervent. C'était en fait
un très bon tailleur de pierre et un
charpentier. Et il a utilisé ses
compétences pour créer des cachettes
pour les prêtres. On les appelait des
trous de prêtres. Nous sommes sûrs
que vous en avez peut-être vu un dans
un film ou à la télévision. Une
personne d'une religion différente
devait se cacher dans une boîte ou une
petite pièce secrète au cas où les
hommes du roi viendraient la chercher.
En tant que personne douée pour créer
ces pièces secrètes, Owen est devenu
une personne recherchée. homme,
surtout quand des rumeurs ont circulé
selon lesquelles il aurait aidé un
type à s'évader de prison. Owens a
finalement été arrêté et accusé du
crime d'avoir creusé ces trous de
prêtres. À l'époque, le secrétaire
d'État Robert Cecil a déclaré : «
C'est incroyable la joie causée par
son arrestation, sachant le grand
talent d'Owen pour construire des
cachettes et le nombre incalculable de
trous sombres qu'il avait conçus pour
cacher des prêtres dans toute
l'Angleterre. Ils pensaient qu'Owen
cachait des gens depuis des années.
Alors, avec un peu d'aide du chevalet,
ils pensaient pouvoir lui faire dire
où se trouvaient tous les prêtres.
Ils l'ont emmené à la Tour de Londres
et lui ont présenté un chevalet qui
avait été créé par un célèbre
chasseur de prêtres nommé Richard
Topcliffe. Le problème, c'est qu'Owen
était vraiment en très mauvais état.
Il était partiellement handicapé
après une chute de cheval, et il avait
également une grosse hernie. Donc, à
peine le maître du chevalet a-t-il
commencé à tourner la roue que les
intestins d'Owen semblaient sur le
point d'exploser hors de son estomac.
Pas du genre à faire preuve de
beaucoup de compassion, le maître du
rack attrapa simplement un gros morceau
de plaque de fer et le posa sur le
ventre d'Owen. Lorsqu'il fut un peu
plus étiré, la hernie se gonfla et
fut tranchée par la plaque, ce qui ne
finit pas très bien. Owen mourut peu
après. Il fut plus tard érigé en
martyr, car s'il avait crié sur
l'emplacement de son prêtre, des
dizaines de personnes auraient
probablement été exécutées. À peu
près à la même époque, il existait
un autre type d'appareil qui
fonctionnait de manière similaire.
C'était le strapado. Cette machine
était appelée une sorte de pendaison
inversée. C'est parce que les hommes
avaient les mains attachées dans le
dos, puis ils étaient tirés vers le
haut par une corde attachée à leurs
poignets. La douleur devait être
atroce, d'autant plus que la torture
disloquait presque toujours les
articulations des épaules. On dit
qu'une personne pouvait avoir des
blessures à vie en étant tirée vers
le haut de cette façon. Donc, c'était
tout aussi terrible que le rack, voire
pire. Comme vous le savez sans doute,
être tiré par les mains attachées
dans le dos ne nécessite pas
forcément un gros dispositif. Parfois,
les gens étaient simplement suspendus
par des crochets. Les nazis le
faisaient parfois dans leurs camps de
concentration. Pendant la guerre du
Vietnam, certains soldats américains
ont subi ce châtiment alors qu'ils
étaient incarcérés dans une prison
nord-vietnamienne. Quelque chose de
similaire a pu arriver au sénateur
John McCain lorsqu'il a été capturé
et torturé pendant la guerre. Des
décennies plus tard, des agents de la
CIA ont fait presque exactement la
même chose lorsqu'ils torturaient des
terroristes présumés à la prison
d'Abu Grae. En fait, un prisonnier du
nom de Manadel Aljamadi est mort après
avoir été pendu par les poignets.
Cela nous amène aux formes de torture
les plus modernes, qui ne sont pas
censées laisser de blessures visibles.
L'aspect psychologique joue désormais
un rôle prépondérant par rapport à
l'aspect physique. C'est peut-être un
progrès, mais utiliser les termes
progrès et torture dans la même
phrase ne semble pas tout à fait juste
. Vous devez maintenant entendre parler
de l'une des pires formes de torture
moderne : la torture en salle blanche.
pires punitions de l'histoire de
l'humanité ou laissez-vous déranger
à l'intérieur de la terrifiante
chambre à coucher de la CIA.

https://www.youtube.com/watch?v=LFofzEY9qbA