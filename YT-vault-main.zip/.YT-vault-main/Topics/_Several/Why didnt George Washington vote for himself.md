The first U.S presidential election was held
on January 7, 1789, and George Washington was
elected president. But hardly anyone voted for
him in that election, even Washington himself.
He could not vote for himself. He didn't
have the option. Let me show you what I mean.
Here is Washington's diary entry for that day:
"Thermometer at 32 in the morning, 39 at noon,
and 39 at night. Calm all day but raw and chilly.
Went up to the election of an elector for
this district of president and vice president,
when the candidates polled for being
Dr Stewart and Colonel Blackburn.
The first received 216 votes from the freeholders
of this county and the second 16 votes.
Dined with a large company on venison at
Page's Tavern and came home in the evening."
So notice who Washington is voting for here.
He has the choice between Stuart and Blackburn.
The president is elected by electors, not by
the voters, not by the citizenry of the country,
but by a small group of people
called electors who we refer to
in the collective as the Electoral College.
According to the Constitution, each state is
assigned a certain number of electors, and
then it's up to that state how they choose
their electors. And in these early elections
for president back in the 1700s, 1800s,
it was common for states to have a variety of ways
of choosing their electors. The state legislature
itself could choose the electors, they could
leave it up to the governor-- Now in Virginia
in the 1789 election, it so happens that they left
it up to a popular vote. But the way they did it
was, Virginia was assigned 12 electors, and the
legislature divided Virginia up into 12 districts,
and in each district the eligible voters
in that district would choose one elector.
[NARRATOR] "Here it is in the privacy of this
curtain space that the American voters every four
years on the first Tuesday after the first Monday
in November choose their national government."
[PREMODERNIST] Nowadays in modern American
elections we actually kind of do the same thing,
although we kind of hide it from ourselves.
We play this game with ourselves and pretend
that we're directly electing the president,
because nowadays when you go and you vote,
on the ballot it'll list the nominees
from the different parties as if you
were selecting the nominee directly. But
in actuality what you're doing is you're
voting for a slate of electors that you don't
see on the ballot, and they are the ones who
will vote for the president five weeks
later in December of the election year.
The point I'm getting at is, this diary entry
of Washington is a little glimpse into a very
different electoral culture in America, the
way it was back in the 1700s. Because back
then they didn't try to hide the existence of the
Electoral College. They didn't try to pretend it
wasn't there and imagine that they were voting
for the president directly. They were quite
frank with themselves that "we are electing
electors and then the electors are going to
choose the president." That's how the Constitution
envisioned it and everyone just accepted that.
It's only been this evolution in American
political life over the past two centuries
where we've gotten this attitude that, "oh no,
the voters should be choosing the president,"
but that's not what the Constitution says.
So now we have to go through this kind of
smoke and mirrors where we're going to
pretend it's something else. Anyway.
I'm currently working on a much
bigger video on the election of 1789.
And in the course of researching that video I came
across this diary entry from Washington, which
I thought was a great little glimpse into the
way the election was run in Virginia that year.
And it's a great illustration, I think, of the
fact that people in 1789 took the Electoral
College seriously and treated it as an actual
functioning part of the American political system.
But I couldn't find a way to organically fit
that into that video, so I just decided to make
a separate video about it. I was going to make
a short on this, actually, but I couldn't figure
out how to fit it all into the short length
of time of a short. So, hence, this video.
But anyway, thanks for dropping by. See you later.



https://youtu.be/NRH1O2TBhVM?si=lci6WY-68w8jUMwH