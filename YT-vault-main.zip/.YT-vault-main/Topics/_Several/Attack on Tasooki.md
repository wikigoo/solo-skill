---
title: "Attack on Tasooki"
source: "https://en.wikipedia.org/wiki/Attack_on_Tasooki"
---
The **attack of Tasooki** was a terrorist attack against Iran. It took place at 21:00 on 25 [Esfand](https://en.wikipedia.org/wiki/Esfand "Esfand") 1384 (March 16, 2006) in [Zabol](https://en.wikipedia.org/wiki/Zabol "Zabol") - [Zahedan](https://en.wikipedia.org/wiki/Zahedan "Zahedan") road near the police station.[^1] The perpetrators were members of the Baloch religio-political insurgency named [Jundallah (Iran)](https://en.wikipedia.org/wiki/Jundallah_\(Iran\) "Jundallah (Iran)").[^2] The attack left 22 [^3] dead and 7 captured.[^4] in that night the forces of jundallah and Abdolmalek rigi attacked several passing vehicles, mostly buses, in the guise of police and killed 21 Shia male passengers in front of their wives and children.

After tying the hands and feet of women and children and leaving them in the street, the Rigi forces took a number of ordinary people and military forces as hostages.

## Jundallah (Iran)

Jundallah (Iran) was a group of "Baloch religio-political insurgency" active in Iran from 2004 to 2010. By executing the leader, [Abdolmalek Rigi](https://en.wikipedia.org/wiki/Abdolmalek_Rigi "Abdolmalek Rigi"), Jundallah was destroyed. They believed that they could administer justice for the people of [Balochestan](https://en.wikipedia.org/wiki/Balochestan "Balochestan") by using violence. From 2006 to 2014, Jundallah organized 25 assaults in [Balochestan](https://en.wikipedia.org/wiki/Balochestan "Balochestan").[^5] [^6]

## Event

Tasooki's police station is located near the [Iran](https://en.wikipedia.org/wiki/Iran "Iran") / [Afghanistan](https://en.wikipedia.org/wiki/Afghanistan "Afghanistan") border. Due to the presence of terrorist groups and smugglers, policed inspected border crossers. On 16 March 2006, [Abdolmalek Rigi](https://en.wikipedia.org/wiki/Abdolmalek_Rigi "Abdolmalek Rigi") led a group of his followers wearing police uniforms. They closed the road and stopped cars en route. They divided passengers into [Baloch](https://en.wikipedia.org/wiki/Baloch_people "Baloch people"), [Shia](https://en.wikipedia.org/wiki/Shia_Islam "Shia Islam") and [Sunni](https://en.wikipedia.org/wiki/Sunni_Islam "Sunni Islam") and others. They then executed the Shia travelers (except of children and women).[^7]

22 citizens (including a student, a worker, an employee, a soldier, a reporter and a businessman) were killed. Six were injured and seven taken hostage. The hostages were released after 200 days.[^6] [^8] [^5]

During the attack, government officials were killed and Hasan ali Nouri, the Governor of [Zahedan](https://en.wikipedia.org/wiki/Zahedan "Zahedan") was injured.[^1]

[Abdolmalek Rigi](https://en.wikipedia.org/wiki/Abdolmalek_Rigi "Abdolmalek Rigi") said that the reason for the attack was that they would have nothing to do with Sunni or Shia until Baloch people were no longer threatened by Iran's government. However six more Baloch from [Nootizahi](https://en.wikipedia.org/wiki/Nootizahi?action=edit&redlink=1 "Nootizahi (page does not exist)") and [Shahbakhsh](https://en.wikipedia.org/wiki/Eslamabad,_Nishapur "Eslamabad, Nishapur") tribe were killed by Iranian security forces. The attack on Tasooki was revenge for those deaths.[^5]

## Reaction

![](https://en.wikipedia.org/wiki/File:Attack_of_Tasooki_02.jpg)

Citizens who were killed during the attack of Tasooki

Iranian government officials labeled the attackers as "rebels" with political motivations. The group requested the Iranian government to release members of Jundallah from prison. Iranian officials claimed that the [United Kingdom](https://en.wikipedia.org/wiki/United_Kingdom "United Kingdom") and [United States](https://en.wikipedia.org/wiki/United_States "United States") had supported Jundallah groups. The UK denied the accusation.[^1] [^9] Following the attack student Reza Lakzaei was held hostage for five months. He described the attack the book *Tasooki, Memories of a Hostage*.[^8]

[^1]: ["the releasing of two hostages"](https://www.bbc.com/persian/iran/story/2006/07/060713_mf_tassouki.shtml). BBC. Retrieved 13 January 2006.

[^2]: Morshedi, Arsalan. ["آمریکا و گروه‌های تروریستی"](http://revolution.pchi.ir/show.php?page=contents&id=11079) \[America and terrorist groups\]. *Hamshahri*. Retrieved 14 December 2010.

[^3]: Roggio, Bill. ["Jundallah suicide attack targets Iran's Revolutonary \[*sic*\] Guards Corps"](https://www.longwarjournal.org/archives/2010/07/jundallah_suicide_at.php). *longwarjournal*. Retrieved 16 July 2010.

[^4]: ["The Secret War: Notable Jundullah Attacks"](https://www.timetoast.com/timelines/the-secret-war-notable-jundullah-attacks-oppressionorg). *timetoast*.

[^5]: Taheri, Ahmad Reza (13 July 2016). [*A Sociopolitical Study of Iranian Baloch Elites (1979-2013)*](https://books.google.com/books?id=1lfpBgAAQBAJ&dq=tasooki+rigi&pg=PA104). lulu.com. p. 105. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-312-34968-1](https://en.wikipedia.org/wiki/Special:BookSources/978-1-312-34968-1 "Special:BookSources/978-1-312-34968-1").

[^6]: Chalk, Peter (21 November 2012). [*Encyclopedia of Terrorism \[2 volumes\]*](https://books.google.com/books?id=czK7lIU7m1oC&dq=tasooki+rigi&pg=PT544). ABC-CLIO. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0313308956](https://en.wikipedia.org/wiki/Special:BookSources/978-0313308956 "Special:BookSources/978-0313308956").

[^7]: ["review the attack of Tasooki"](http://www.habilian.ir/fa/vije/vijenameha/Vijenameha/v012_tasoki/page01.html). *habilian*.

[^8]: ["Tasooki, the memories of a hostage"](https://shahrestanadab.com/Content/ID/6305/%DA%A9%D8%AA%D8%A7%D8%A8-%D8%AA%D8%A7%D8%B3%D9%88%DA%A9%DB%8C-%D8%AE%D8%A7%D8%B7%D8%B1%D8%A7%D8%AA-%DB%8C%DA%A9-%DA%AF%D8%B1%D9%88%DA%AF%D8%A7%D9%86). *shahrestanadab*.

[^9]: ["گاهشمار ناامنی در سیستان و بلوچستان"](https://www.bbc.com/persian/iran/2009/07/090714_ra_sistan_baluch_timeline). BBC. Retrieved 15 December 2010.