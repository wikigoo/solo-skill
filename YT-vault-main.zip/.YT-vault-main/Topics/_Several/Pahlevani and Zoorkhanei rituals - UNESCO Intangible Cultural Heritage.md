---
title: "Pahlevani and Zoorkhanei rituals - UNESCO Intangible Cultural Heritage"
source: "https://ich.unesco.org/en/RL/pahlevani-and-zoorkhanei-rituals-00378?RL=00378"
---
[Iran (Islamic Republic of)](https://ich.unesco.org/en/state/iran-islamic-republic-of-IR)

Inscribed in 2010 ([5.COM](https://ich.unesco.org/en/5com)) on the Representative List of the Intangible Cultural Heritage of Humanity**© 2009 Iranian Cultural Heritage, Handicrafts and Tourism Organization**

Pahlevani is an Iranian martial art that combines elements of Islam, Gnosticism and ancient Persian beliefs. It describes a ritual collection of gymnastic and callisthenic movements performed by ten to twenty men, each wielding instruments symbolizing ancient weapons. The ritual takes place in a *Zoorkhane,* a sacred domed structure with an octagonal sunken arena and audience seats. The *Morshed* (master) who leads the Pahlevani ritual performs epic and Gnostic poems and beats out time on a *zarb* goblet drum. The poems he recites transmit ethical and social teachings and constitute part of Zoorkhanei literature. Participants in the Pahlevani ritual may be drawn from any social strata or religious background, and each group has strong ties to its local community, working to assist those in need. During training, students are instructed in ethical and chivalrous values under the supervision of a *Pīshkesvat* (champion). Those who master the individual skills and arts, observe religious principles and pass ethical and moral stages of Gnosticism may acquire the prominent rank of *Pahlevanī* (hero), denoting rank and authority within the community. At present, there are 500 Zoorkhanes across Iran, each comprising practitioners, founders and a number of *Pīshkesvats.*

[![](https://ich.unesco.org/img/photo/thumb/02118-HUG.webp?t=1782997842)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02118)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02118-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02118)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02119-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02119)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02120-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02120)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02121-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02121)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02122-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02122)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02123-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02123)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02124-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02124)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02125-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02125)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02126-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02126)

© 2009- By Iranian Cultural Heritage, Handicrafts and Tourism Organization

[![](https://ich.unesco.org/img/photo/thumb/02127-SML.webp)](https://ich.unesco.org/en/photo-pop-up-00973?photoID=02127)

© 2009 by Iranian Cultural Heritage, Handicrafts and Tourism Organization

1. [Acrobatics](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-114&secondary_filter=1) (31)
2. [Athletes](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-6250&secondary_filter=1) (2)
3. [Epic poetry](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-995&secondary_filter=1) (52)
4. [Gnosticism](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-167&secondary_filter=1) (3)
5. [Islam](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-1694&secondary_filter=1) (25)
6. [Martial arts](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-125&secondary_filter=1) (12)
7. [Mysticism](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-2485&secondary_filter=1) (3)
8. [Percussion instruments](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-23&secondary_filter=1) (159)
9. [Religious practice](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-252&secondary_filter=1) (166)
10. [Religious syncretism](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-15&secondary_filter=1) (30)
11. [Rituals](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1322&secondary_filter=1) (98)
12. [Secret society](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-89&secondary_filter=1) (6)
13. [Symbols](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-1992&secondary_filter=1) (36)
14. [Vocal music](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-1&secondary_filter=1) (319)
15. [Weapons](https://ich.unesco.org/en/lists?term[]=vocabulary_thesaurus-2387&secondary_filter=1) (8)

### Sustainable Development Goals

1. [SDG 4: Quality Education](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1382&secondary_filter=1) (493)
2. [SDG 16: Peace, Justice and Strong Institutions](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1394&secondary_filter=1) (665)

### Biomes

1. [Non-ecosystem specific](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-930&secondary_filter=1) (92)

### Domains of the Convention

1. [Oral traditions and expressions](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1227&secondary_filter=1) (384)
2. [Performing arts](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1228&secondary_filter=1) (411)
3. [Social practices, rituals and festive events](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1229&secondary_filter=1) (584)
4. [Traditional craftsmanship](https://ich.unesco.org/en/lists?term[]=vocabulary_ich-1231&secondary_filter=1) (460)