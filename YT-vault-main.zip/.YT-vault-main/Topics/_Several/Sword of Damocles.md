---
title: "Sword of Damocles"
source: "https://en.wikipedia.org/wiki/Sword_of_Damocles"
---
The **Sword of Damocles** is an ancient Greek moral [anecdote](https://en.wikipedia.org/wiki/Anecdote "Anecdote"),[^2] [^3] an allusion to the imminent and ever-present peril faced by those in positions of [power](https://en.wikipedia.org/wiki/Power_\(social_and_political\) "Power (social and political)"). Its main character, **Damocles**,[^1] was based on a [courtier](https://en.wikipedia.org/wiki/Courtier "Courtier") in the court of [Dionysius I of Syracuse](https://en.wikipedia.org/wiki/Dionysius_I_of_Syracuse "Dionysius I of Syracuse"),[^4] a ruler of [Syracuse, Sicily](https://en.wikipedia.org/wiki/Syracuse,_Sicily "Syracuse, Sicily"), [Magna Graecia](https://en.wikipedia.org/wiki/Magna_Graecia "Magna Graecia"), during the [classical Greek](https://en.wikipedia.org/wiki/Classical_Greece "Classical Greece") era.

The anecdote apparently figured in the lost history of [Sicily](https://en.wikipedia.org/wiki/Sicily "Sicily") by [Timaeus of Tauromenium](https://en.wikipedia.org/wiki/Timaeus_\(historian\) "Timaeus (historian)") (c. 356 – c. 260 BC). The Roman orator [Cicero](https://en.wikipedia.org/wiki/Cicero "Cicero") (c. 106 – c. 43 BC),[^5] who may have read it in the texts of Greek historian [Diodorus Siculus](https://en.wikipedia.org/wiki/Diodorus_Siculus "Diodorus Siculus"), used it in his *[Tusculanae Disputationes](https://en.wikipedia.org/wiki/Tusculanae_Disputationes "Tusculanae Disputationes")*, 5. 61,[^2] by which means it passed into the European cultural mainstream.

## Plot

According to the story, Damocles was flattering his king, Dionysius, exclaiming that Dionysius was truly fortunate as a great man of power and authority without peer, surrounded by magnificence. In response, Dionysius offered to switch places with Damocles for one day so that Damocles could taste that fortune firsthand. Damocles eagerly accepted the king's proposal. Damocles sat on the king's throne amid embroidered rugs, fragrant perfumes, and the service of beautiful attendants. But Dionysius, who had made many enemies during his reign, arranged that a sword should hang above the throne, held at the [pommel](https://en.wikipedia.org/wiki/Hilt#Pommel "Hilt") only by a single [hair of a horse's tail](https://en.wikipedia.org/wiki/Horsehair "Horsehair") to evoke the sense of what it is like to be king: though having much fortune, always having to watch in anxiety against dangers that might try to overtake him, whether it be a jealous advisor or servant, a slanderous rumor, an enemy kingdom, a poor royal decision, or anything else. Damocles finally begged the king for permission to depart because he no longer wanted to be so fortunate, realizing that while he had everything he could ever want at his feet, it could not affect what was above his crown.

![Painting of the story of Damocles by British artist Herbert Gandy, featuring a Damocles surrounded by beautiful servants, lavish foods, gold, and riches, yet worriedly gazing up at an unsheathed sword above his head](https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d4/Sword_of_Damocles_%28Herbert_Gandy%29.JPG/250px-Sword_of_Damocles_%28Herbert_Gandy%29.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Painting of the story of Damocles by British artist Herbert Gandy, 6 featuring a Damocles surrounded by beautiful servants, lavish foods, gold, and riches, worriedly gazing up at an unsheathed sword above his head

## Interpretations

Cicero used this story as the last in a series of contrasting examples for concluding his fifth *[Disputation](https://en.wikipedia.org/wiki/Tusculan_Disputations "Tusculan Disputations")*, in which the theme is that having virtue is sufficient for living a happy life.[^7] [^8]

Cicero's meaning in the story of the Sword of Damocles has alternative interpretations. Cicero states, "Doesn't Dionysius seem to have made it plenty clear that nothing is happy for him over whom terror always looms?" arguing that those in positions of power can never rest and truly enjoy that power.[^9] Some take this and argue further, stating that the point was that death looms over all, but that it is vital to strive to be happy and enjoy life in spite of that terror.[^10] Others take the meaning to be something akin to "don't judge someone until you've walked a mile in their shoes," as it is impossible to know what someone is struggling with, even if their life seems to be perfect to the outside observer. Just as King Dionysius' life looked luxurious and flawless on the outside to Damocles, so too might the lives of others that one covets for oneself.[^10] One other interpretation sees the story of the sword of Damocles as explicitly meant for [Julius Caesar](https://en.wikipedia.org/wiki/Julius_Caesar "Julius Caesar"), implicitly suggesting that he should take care not to act the same way that King Dionysius did, making enemies and denying spiritual life, falling prey to the pitfalls of the [tyrant](https://en.wikipedia.org/wiki/Tyrant "Tyrant"), and mind the sword hanging ever-present over his neck.[^11]

## Use in culture, art, and literature

The sword of Damocles is frequently used in [allusion](https://en.wikipedia.org/wiki/Allusion "Allusion") to this tale, epitomizing the imminent and ever-present peril faced by those in positions of power. More generally, it is used to denote the sense of foreboding engendered by a precarious situation,[^12] especially one in which the onset of tragedy is restrained only by a delicate trigger or chance. William Shakespeare's *[Henry IV](https://en.wikipedia.org/wiki/Henry_IV,_Part_1 "Henry IV, Part 1")* expands on this theme: "Uneasy lies the head that wears a crown";[^13] compare the [Hellenistic](https://en.wikipedia.org/wiki/Hellenistic "Hellenistic") and [Roman](https://en.wikipedia.org/wiki/Ancient_Rome "Ancient Rome") imagery connected with the insecurity offered by [Tyche](https://en.wikipedia.org/wiki/Tyche "Tyche") and [Fortuna](https://en.wikipedia.org/wiki/Fortuna "Fortuna").

In *[The Canterbury Tales](https://en.wikipedia.org/wiki/The_Canterbury_Tales "The Canterbury Tales")*, Geoffrey Chaucer refers to the sword of Damocles, which the Knight describes as hanging over Conquest. When the Knight describes the three temples, he also pays special attention to the paintings, noticing one on the walls of the temple of [Mars](https://en.wikipedia.org/wiki/Mars_\(mythology\) "Mars (mythology)"):

And al above, depeinted in a tour,  
Saugh I Conquest, sitting in greet honour,  
With the sharpe swerd over his heed,  
Hanginge by a subtil twines threed.

Above, where seated in his tower,  
I saw Conquest depicted in his power  
There was a sharpened sword above his head  
That hung there by the thinnest simple thread.

—  Chaucer, *Canterbury Tales*, l. 2027–2030 [^14] [^15]

![A political cartoon from Clifford Berryman following World War I, depicting a German delegate shakily signing a peace treaty as directed by the large hand of the Allied Powers, while a large sword bearing the inscription "Peace of Justice" hangs by a thread above him](https://en.wikipedia.org/wiki/File:The_Sword_of_Damocles_-_DPLA_-_57510ac89ab98ff38f6555801defe4d5.jpg)

A political cartoon from Clifford Berryman following World War I, depicting a German delegate shakily signing a peace treaty as directed by the large hand of the Allied Powers, while a large sword bearing the inscription "Peace of Justice" hangs by a thread above him (1919)

The Roman 1st-century BC poet [Horace](https://en.wikipedia.org/wiki/Horace "Horace") also alluded to the sword of Damocles in Ode 1 of the *Third Book of Odes*, in which he extolled the virtues of living a simple, rustic life, favoring such an existence over the myriad threats and anxieties that accompany holding a position of power. In this appeal to his friend and patron, the aristocratic [Gaius Maecenas](https://en.wikipedia.org/wiki/Gaius_Maecenas "Gaius Maecenas"), Horace describes the *Siculae dapes* or "Sicilian feasts" as providing no savory pleasure to the man, "above whose impious head hangs a drawn sword (*destrictus ensis*)." [^16]

The phrase has also come to be used in describing any situation infused with a sense of impending doom, especially when the peril is visible and proximal—regardless of whether the victim is in a position of power. United States President [John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy#Presidency_\(1961%E2%80%931963\) "John F. Kennedy") compared the omnipresent threat of [nuclear annihilation](https://en.wikipedia.org/wiki/Nuclear_annihilation "Nuclear annihilation") to a sword of Damocles hanging over the people of the world.[^17] Soviet First Secretary [Nikita Khrushchev](https://en.wikipedia.org/wiki/Nikita_Khrushchev "Nikita Khrushchev") wanted the [Tsar Bomba](https://en.wikipedia.org/wiki/Tsar_Bomba "Tsar Bomba") to "hang like the sword of Damocles over the imperialists' heads".[^18]

![A scene from Keppler's Puck shows Damocles in a crown labeled "industry" standing beneath a sword labeled "coal strikes"](https://en.wikipedia.org/wiki/File:The_modern_sword_of_Damocles_-_Keppler._LCCN2010652211.jpg)

A scene from Joseph Keppler's Puck showing Damocles, wearing a crown labeled "Industry", standing beneath a large sword, labeled "Coal Strikes", which hangs above him by a thread, suggesting that the coal strikes at the beginning of the 20th century were the modern-day sword of Damocles (1903)

Woodcut images of the sword of Damocles as an emblem appear in 16th- and 17th-century European books of devices, with moralizing couplets or quatrains, with the import metus est plenus tyrannis.[^19] A small vignette shows Damocles under a canopy of state, at the festive table, with Dionysius seated nearby;[^20] the etching, with its clear political moral, was later used to illustrate the idea.[^21] [^22]

References to the sword of Damocles can also be found in cartoonist illustrations, such as in [Joseph Keppler](https://en.wikipedia.org/wiki/Joseph_Keppler "Joseph Keppler") 's magazine *[Puck](https://en.wikipedia.org/wiki/Puck_\(magazine\) "Puck (magazine)")*,[^23] a satiric periodical started in the late 1800s in the United States, and the sword can be used as a device to call attention to the peril that current events or contentious issues of the time place the world in.

The sword of Damocles frequently appears in popular culture, including novels, feature films, television series, video games, and music.[^24] Some notable examples include *[Damocles](https://en.wikipedia.org/wiki/Damocles_\(video_game\) "Damocles (video game)")*, a 16-bit video game from 1990 in which the player races to prevent the titular comet Damocles from destroying a planet,[^30] the song " [The Sword of Damocles](https://en.wikipedia.org/wiki/The_Rocky_Horror_Picture_Show_\(soundtrack\) "The Rocky Horror Picture Show (soundtrack)") " from *[The Rocky Horror Picture Show](https://en.wikipedia.org/wiki/The_Rocky_Horror_Picture_Show "The Rocky Horror Picture Show")*,[^25] and a virtual reality headset also called [The Sword of Damocles](https://en.wikipedia.org/wiki/The_Sword_of_Damocles_\(virtual_reality\) "The Sword of Damocles (virtual reality)"), developed by [Ivan Sutherland](https://en.wikipedia.org/wiki/Ivan_Sutherland "Ivan Sutherland") in 1968, named for its suspension from the ceiling of the lab in which it was developed and its foreboding appearance.[^24]

The *Damocles* is the name of the ship that is used in a [multi-episode plot-line](https://en.wikipedia.org/wiki/Ziva_David_captivity_storyline "Ziva David captivity storyline") that spanned multiple seasons of the television show *[NCIS](https://en.wikipedia.org/wiki/NCIS_\(TV_show\) "NCIS (TV show)")*.

The sword of Damocles is an oft-used symbol in modern [hip-hop](https://en.wikipedia.org/wiki/Hip-hop "Hip-hop"), an allusion used to impart the threat "kingly" [rappers](https://en.wikipedia.org/wiki/Rapping "Rapping") face of being deposed as the best of the best. It is referenced in the lyrics of the song "Zealots" by [The Fugees](https://en.wikipedia.org/wiki/Fugees "Fugees") in 1996.[^9] It also appears in the music of [Kanye West](https://en.wikipedia.org/wiki/Kanye_West "Kanye West"), both in the music video for his single " [Power](https://en.wikipedia.org/wiki/Power_\(Kanye_West_song\) "Power (Kanye West song)") " in 2010, where a sword is positioned above West's head as he stands amidst rows of [Ionic](https://en.wikipedia.org/wiki/Ionic_order "Ionic order") columns, and in later cover art for the song, which features the impaled head of a black man wearing a crown.[^9]

[^1]: [/ ˈ d æ m ə k l iː z /](https://en.wikipedia.org/wiki/Help:IPA/English "Help:IPA/English"); [Greek](https://en.wikipedia.org/wiki/Greek_language "Greek language"): Δαμοκλῆς, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Greek "Romanization of Greek"): *Dāmoklē̂s*, [lit.](https://en.wikipedia.org/wiki/Literal_translation "Literal translation") 'fame of the people'

[^2]: [Cicero](#CITEREFCicero).

[^3]: [Westall](#CITEREFWestall).

[^4]: ["Cicero's Tusculan Disputations, On the Nature of the Gods, On the Commonwealth"](https://www.gutenberg.org/files/14988/14988-h/14988-h.htm). *www.gutenberg.org*. Retrieved 2023-06-01.

[^5]: ["Marcus Tullius Cicero"](https://web.archive.org/web/20120807084722/http://www.utexas.edu:80/depts/classics/documents/Cic.html). 2012-08-07. Archived from [the original](http://www.utexas.edu/depts/classics/documents/Cic.html) on 2012-08-07. Retrieved 2021-06-07.

[^6]: ["HERBERT GANDY (BRITISH 1857-1934)"](https://shapiroauctions.com/auctions/international-fine-decorative-art-auction-2016-03-12/21-herbert-gandy-british-1857-1934/). *shapiroauctions.com*. Retrieved 2021-05-21.

[^7]: [Cicero](#CITEREFCicero), 5.1: "virtutem ad beate vivendum se ipse esse contentam"

[^8]: Jaeger, Mary (14 March 2012). "Cicero and Archimedes' tomb". *Journal of Roman Studies*. **92**: 49–61, esp. 51ff. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/3184859](https://doi.org/10.2307%2F3184859). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [3184859](https://www.jstor.org/stable/3184859). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [162402665](https://api.semanticscholar.org/CorpusID:162402665).

[^9]: Peralta, Dan-el Padilla (2017-11-14). ["From Damocles to Socrates"](https://eidolon.pub/from-damocles-to-socrates-fbda6e685c26). *Medium*. Retrieved 2021-06-07.

[^10]: Jaeger, Mary (November 2002). ["Cicero and Archimedes' Tomb"](https://dx.doi.org/10.2307/3184859). *Journal of Roman Studies*. **92**: 49–61. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2307/3184859](https://doi.org/10.2307%2F3184859). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0075-4358](https://search.worldcat.org/issn/0075-4358). [JSTOR](https://en.wikipedia.org/wiki/JSTOR_\(identifier\) "JSTOR (identifier)") [3184859](https://www.jstor.org/stable/3184859). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [162402665](https://api.semanticscholar.org/CorpusID:162402665).

[^11]: Verbaal, Wim (2006). ["Cicero and Dionysios the Elder, or the End of Liberty"](https://dx.doi.org/10.1353/clw.2006.0050). *Classical World*. **99** (2): 145–156. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1353/clw.2006.0050](https://doi.org/10.1353%2Fclw.2006.0050). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [1558-9234](https://search.worldcat.org/issn/1558-9234). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [161906192](https://api.semanticscholar.org/CorpusID:161906192).

[^12]: "Damocles". *[Benet's Reader's Encyclopedia](https://en.wikipedia.org/wiki/Benet's_Reader's_Encyclopedia "Benet's Reader's Encyclopedia")*. 1948. Evil foreboded or dreaded

[^13]: [Shakespeare, William](https://en.wikipedia.org/wiki/William_Shakespeare "William Shakespeare") (1597). [*Henry IV, Part II*](http://www.phrases.org.uk/meanings/396000.html) (Online quotation in context). The Phrase Finder.

[^14]: [Chaucer, Geoffrey](https://en.wikipedia.org/wiki/Geoffrey_Chaucer "Geoffrey Chaucer") (2005) \[late 14th–early 15th century\]. "The Knight's Tale". In Mann, Jill (ed.). *The Canterbury Tales*. London, England: Penguin Books.

[^15]: [Chaucer, Geoffrey](https://en.wikipedia.org/wiki/Geoffrey_Chaucer "Geoffrey Chaucer") (1475). ["The Knight's Tale"](https://web.archive.org/web/20151009054021/http://english.fsu.edu/canterbury/knight.html). *The Canterbury Tales* (online quotation in context). UK: Florida State University. Archived from [the original](http://english.fsu.edu/canterbury/knight.html) on 2015-10-09. Retrieved 2015-10-11 – via english.fsu.edu.

[^16]: ["Carmina (Horatius)"](https://la.wikisource.org/w/index.php?title=Carmina_\(Horatius\)/Liber_III/Carmen_I&oldid=58591). Latin Wikisource. liber III, carmen I – via Wikisource.

[^17]: [Kennedy, John Fitzgerald](https://en.wikipedia.org/wiki/John_F._Kennedy "John F. Kennedy") (25 September 1961). ["Address Before the General Assembly of the United Nations"](https://web.archive.org/web/20120901235625/http://www.jfklibrary.org/Research/Ready-Reference/JFK-Speeches/Address-Before-the-General-Assembly-of-the-United-Nations-September-25-1961.aspx). *Selected Speeches*. Columbia Point, Boston, Massachusetts: Presidential Library and Museum. Archived from [the original](http://www.jfklibrary.org/Research/Ready-Reference/JFK-Speeches/Address-Before-the-General-Assembly-of-the-United-Nations-September-25-1961.aspx) on 1 September 2012. Retrieved 5 August 2011. Today, every inhabitant of this planet must contemplate the day when this planet may no longer be habitable. Every man, woman, and child lives under a nuclear sword of Damocles, hanging by the slenderest of threads, capable of being cut at any moment by accident or miscalculation or by madness.

[^18]: Isaacs, Jeremy; Mitchell, Pat, eds. (1998). *The Cold War* (DVD). CNN.

[^19]: Some examples: La Perrière, Guillaume (1553). [*Morosophie*](http://www.emblems.arts.gla.ac.uk/french/emblem.php?id=FLPb030). Glasgow, Scotland, UK: Glasgow University. emblem 30. Paradin, Claude (1557). [*Coelitus impendet*](http://www.emblems.arts.gla.ac.uk/french/emblem.php?id=FPAb088) \[*It hangs from Heaven*\]. Devises heroïques (in Latin). Glasgow, Scotland, UK: Glasgow University. Boissard, Jean Jacques (1593). [*Emblematum Liber*](http://www.emblems.arts.gla.ac.uk/french/emblem.php?id=FBOb045). Glasgow, Scotland, UK: Glasgow University. emblem 45.

[^20]: [Hollar, Wenceslaus](https://en.wikipedia.org/wiki/Wenceslaus_Hollar "Wenceslaus Hollar") (n.d.). *Emblemata Nova*. London, UK.

[^21]: [Hobbes, Thomas](https://en.wikipedia.org/wiki/Thomas_Hobbes "Thomas Hobbes") (1651). *Philosophicall Rudiments Concerning Government and Society*. London.

[^22]: Pennington, Richard (1982). *A Descriptive Catalogue of the Etched Work of Wenceslaus Hollar, 1607–1677*. Cambridge University Press.

[^23]: ["U.S. Senate: Puck Magazine"](https://www.senate.gov/art-artifacts/historical-images/political-cartoons-caricatures/puck-intro.htm). *www.senate.gov*. Retrieved 2021-05-21.

[^24]: For example:

[^25]: **Literature:** Wodehouse, P. G. (1963). [*Stiff Upper Lip, Jeeves*](https://en.wikipedia.org/wiki/Stiff_Upper_Lip,_Jeeves "Stiff Upper Lip, Jeeves").; [Bohumil Hrabal](https://en.wikipedia.org/wiki/Bohumil_Hrabal "Bohumil Hrabal") (1990). [*Příliš hlučná samota*](https://en.wikipedia.org/wiki/Too_Loud_a_Solitude "Too Loud a Solitude") \[*Too Loud a Solitude*\]. [Hermans, W. F.](https://en.wikipedia.org/wiki/Willem_Frederik_Hermans "Willem Frederik Hermans") (1958). *De Donkere Kamer van Damocles* \[*[The Darkroom of Damocles](https://en.wikipedia.org/wiki/The_Darkroom_of_Damocles "The Darkroom of Damocles")*\].

[^26]: **Film:** *[Half-Wits Holiday](https://en.wikipedia.org/wiki/Half-Wits_Holiday "Half-Wits Holiday")* (1947), *[The Rocky Horror Picture Show](https://en.wikipedia.org/wiki/The_Rocky_Horror_Picture_Show "The Rocky Horror Picture Show")* (1975), *[Escape from L.A.](https://en.wikipedia.org/wiki/Escape_from_L.A. "Escape from L.A.")* (1996).

[^27]: **TV series**: *The 100* season 5, episodes 12 and 13. 2014. " [Burns Verkaufen der Kraftwerk](https://en.wikipedia.org/wiki/Burns_Verkaufen_der_Kraftwerk "Burns Verkaufen der Kraftwerk") ". *[The Simpsons](https://en.wikipedia.org/wiki/The_Simpsons "The Simpsons")*. Episode 11. 1991. "Jumping the Shark". *[Reno 911!](https://en.wikipedia.org/wiki/Reno_911! "Reno 911!")*. Episode 1. 2008. *[Code Geass](https://en.wikipedia.org/wiki/Code_Geass "Code Geass")* (TV broadcast). Vol. 2. 2008. [*K*](https://en.wikipedia.org/wiki/K_\(anime\) "K (anime)") (TV broadcast). 2012.

[^28]: **Video games:** *[Damocles](https://en.wikipedia.org/wiki/Mercenary_\(video_game\)#Damocles "Mercenary (video game)")* (1990), *[Tomb Raider](https://en.wikipedia.org/wiki/Tomb_Raider "Tomb Raider")* (1996); *[MechWarrior 3](https://en.wikipedia.org/wiki/MechWarrior_3 "MechWarrior 3")* (1999); *[Max Payne 2: The Fall of Max Payne](https://en.wikipedia.org/wiki/Max_Payne_2:_The_Fall_of_Max_Payne "Max Payne 2: The Fall of Max Payne")* (2003); *[E.Y.E.: Divine Cybermancy](https://en.wikipedia.org/wiki/E.Y.E.:_Divine_Cybermancy "E.Y.E.: Divine Cybermancy")* (2011); *[Ryse: Son of Rome](https://en.wikipedia.org/wiki/Ryse:_Son_of_Rome "Ryse: Son of Rome")* (2013); *[The Binding of Isaac: Repentance](https://en.wikipedia.org/wiki/The_Binding_of_Isaac:_Rebirth#Repentance "The Binding of Isaac: Rebirth")* (2021).

[^29]: **Music:** [Toto](https://en.wikipedia.org/wiki/Toto_\(band\) "Toto (band)") (1978). *[Toto](https://en.wikipedia.org/wiki/Toto_\(album\) "Toto (album)")* (audio recording). [Toto](https://en.wikipedia.org/wiki/Toto_\(band\) "Toto (band)") (1979). *[Hydra](https://en.wikipedia.org/wiki/Hydra_\(Toto_album\) "Hydra (Toto album)")* (audio recording). [Toto](https://en.wikipedia.org/wiki/Toto_\(band\) "Toto (band)") (1984). *[Toto IV](https://en.wikipedia.org/wiki/Toto_IV "Toto IV")* (audio recording). (see ["SWORD, THE"](http://www.toto99.com/blog2010/index.php?/archives/819-SWORD,-THE.html). May 2007.; [Reed, Lou](https://en.wikipedia.org/wiki/Lou_Reed "Lou Reed") (1992). *[Sword of Damocles Externally](https://en.wikipedia.org/wiki/Sword_of_Damocles_Externally "Sword of Damocles Externally")* (audio recording). The [Fugees](https://en.wikipedia.org/wiki/Fugees "Fugees") and [Wyclef Jean](https://en.wikipedia.org/wiki/Wyclef_Jean "Wyclef Jean") (1996). *[Zealots](https://en.wikipedia.org/wiki/The_Score_\(Fugees_album\) "The Score (Fugees album)")* (audio recording). [Nick Cave and the Bad Seeds](https://en.wikipedia.org/wiki/Nick_Cave_and_the_Bad_Seeds "Nick Cave and the Bad Seeds") (2001). *[Oh My Lord](https://en.wikipedia.org/wiki/Oh_My_Lord_\(Nick_Cave_song\) "Oh My Lord (Nick Cave song)")* (audio recording). [Iron Maiden](https://en.wikipedia.org/wiki/Iron_Maiden "Iron Maiden") (2013). *[Starblind](https://en.wikipedia.org/wiki/The_Final_Frontier_\(Iron_Maiden_album\) "The Final Frontier (Iron Maiden album)")* (audio recording).

[^30]: Guyart, S.; Hurt, A.; Garycki, P.; Berry, S.; Sachs, M. (2004). ["Hints and solution for Damocles"](http://mercenarysite.free.fr/damocles.htm#I1). *The Mercenary Site*. [Archived](https://web.archive.org/web/20050409061204/http://mercenarysite.free.fr:80/damocles.htm) from the original on 2005-04-09. Retrieved 2021-05-21.

[^31]: Ruhlmann, William, [*The Rocky Horror Picture Show \[Original Motion Picture Soundtrack\] - Various Artists | Songs, Reviews, Credits*](https://www.allmusic.com/album/the-rocky-horror-picture-show-original-motion-picture-soundtrack-mw0000200364), [AllMusic](https://en.wikipedia.org/wiki/AllMusic "AllMusic"), retrieved 2021-05-21