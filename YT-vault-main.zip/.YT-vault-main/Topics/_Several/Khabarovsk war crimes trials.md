---
title: "Khabarovsk war crimes trials"
source: "https://en.wikipedia.org/wiki/Khabarovsk_war_crimes_trials"
---
![](https://en.wikipedia.org/wiki/File:Otozo.Yamada.1949.jpg)

A Japanese army officer on trial, Khabarovsk, Russia, 1949

The **Khabarovsk war crimes trials** were the [Soviet](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union") [hearings](https://en.wikipedia.org/wiki/Hearing_\(law\) "Hearing (law)") of twelve [Japanese](https://en.wikipedia.org/wiki/Empire_of_Japan "Empire of Japan") [Kwantung Army](https://en.wikipedia.org/wiki/Kwantung_Army "Kwantung Army") [officers](https://en.wikipedia.org/wiki/Officer "Officer") and [medical staff](https://en.wikipedia.org/wiki/Medical_personnel "Medical personnel") [charged](https://en.wikipedia.org/wiki/Criminal_charge "Criminal charge") with the manufacture and use of [biological weapons](https://en.wikipedia.org/wiki/Biological_weapons "Biological weapons"), and human experimentation, during [World War II](https://en.wikipedia.org/wiki/World_War_II "World War II"). The war crimes trials were held between 25 and 31 December 1949 in the Soviet industrial city of [Khabarovsk](https://en.wikipedia.org/wiki/Khabarovsk "Khabarovsk") in the [Russian Far East](https://en.wikipedia.org/wiki/Russian_Far_East "Russian Far East").

The [Soviet Union](https://en.wikipedia.org/wiki/Soviet_Union "Soviet Union") and the [United States](https://en.wikipedia.org/wiki/United_States "United States") gathered data and evidence from the Unit after the fall of Japan. While twelve [Unit 731](https://en.wikipedia.org/wiki/Unit_731 "Unit 731") researchers arrested by [Soviet forces](https://en.wikipedia.org/wiki/Red_Army "Red Army") were tried at the December 1949 Khabarovsk war crimes trials, they were sentenced only to the Siberian labor camp from 2 to 25 years, seemingly in exchange for the information they held.[^1] Those captured by the [US military](https://en.wikipedia.org/wiki/Military_history_of_the_United_States_during_World_War_II "Military history of the United States during World War II") were secretly given [immunity](https://en.wikipedia.org/wiki/Immunity_from_prosecution_\(international_law\) "Immunity from prosecution (international law)"),[^2] while being covered up with [stipends](https://en.wikipedia.org/wiki/Stipend "Stipend") to the perpetrators. The US was purported to have co-opted the researchers' [bioweapons](https://en.wikipedia.org/wiki/Biological_warfare "Biological warfare") information and experience for use in their own [warfare program](https://en.wikipedia.org/wiki/United_States_biological_weapons_program "United States biological weapons program") (resembling [Operation Paperclip](https://en.wikipedia.org/wiki/Operation_Paperclip "Operation Paperclip")), and so did the Soviet Union in building their [bioweapons facility in Sverdlovsk](https://en.wikipedia.org/wiki/Sverdlovsk_anthrax_leak "Sverdlovsk anthrax leak") using documentation captured from the Unit in Manchuria.[^1] [^3] [^4] In 1956, those still serving their sentences were released and [repatriated](https://en.wikipedia.org/wiki/Repatriation "Repatriation") to Japan.

## History

During the trials, the accused, including [Major General](https://en.wikipedia.org/wiki/Major_general "Major general") Kiyoshi Kawashima, testified that as early as 1941, some 40 members of [Unit 731](https://en.wikipedia.org/wiki/Unit_731 "Unit 731") [air-dropped](https://en.wikipedia.org/wiki/Airdrop "Airdrop") [plague](https://en.wikipedia.org/wiki/Plague_\(disease\) "Plague (disease)") -contaminated fleas on [Changde](https://en.wikipedia.org/wiki/Changde "Changde"), [China](https://en.wikipedia.org/wiki/China_in_World_War_II "China in World War II"), causing [epidemic](https://en.wikipedia.org/wiki/Epidemic "Epidemic") plague outbreaks.[^5]

Judges found all twelve accused war criminals guilty, sentencing them to terms ranging from two to twenty-five years in labour camps. In 1956, those still serving their sentences were released and repatriated to Japan.[^6]

In 1950, the Soviet Union published official trial materials in English, titled *Materials on the Trial of Former Servicemen of the Japanese Army Charged with Manufacturing and Employing Bacteriological Weapons*.[^7] These included documents from the preliminary investigation (the [indictment](https://en.wikipedia.org/wiki/Indictment "Indictment"), some of the documentary evidence, and some [interrogation](https://en.wikipedia.org/wiki/Interrogation "Interrogation") records), testimony from both the accused and [witnesses](https://en.wikipedia.org/wiki/Witness "Witness"), final [pleas](https://en.wikipedia.org/wiki/Plea "Plea") of the accused, some expert findings, and speeches from the state [prosecutor](https://en.wikipedia.org/wiki/Prosecutor "Prosecutor") and [defense counsel](https://en.wikipedia.org/wiki/Defense_counsel "Defense counsel"), [verbatim](https://en.wiktionary.org/wiki/verbatim "wikt:verbatim"). Published by state-run [Foreign Languages Publishing House](https://en.wikipedia.org/wiki/Foreign_Languages_Publishing_House_\(Soviet_Union\) "Foreign Languages Publishing House (Soviet Union)"), the Soviet publication has long been out of print. But in November 2015, [Google Books](https://en.wikipedia.org/wiki/Google_Books "Google Books") determined it was now in the [public domain](https://en.wikipedia.org/wiki/Public_domain "Public domain") and published a [facsimile](https://en.wikipedia.org/wiki/Facsimile "Facsimile") of it online, also offering it for sale as an [ebook](https://en.wikipedia.org/wiki/Ebook "Ebook").[^7]

## Analysis

Speaking to the overall judicial integrity of the proceedings, [bioethics](https://en.wikipedia.org/wiki/Bioethics "Bioethics") expert Jing-Bao Nie said the following:

> Despite its strong [ideological tone](https://en.wikipedia.org/wiki/Ideology_of_the_Communist_Party_of_the_Soviet_Union "Ideology of the Communist Party of the Soviet Union") and many obvious shortcomings such as the lack of international participation, the trial established beyond reasonable doubt that the [Japanese army](https://en.wikipedia.org/wiki/Imperial_Japanese_Army "Imperial Japanese Army") had prepared and deployed [bacteriological weapons](https://en.wikipedia.org/wiki/Biological_warfare "Biological warfare") and that Japanese researchers had conducted [cruel experiments](https://en.wikipedia.org/wiki/Medical_torture "Medical torture") on [living human beings](https://en.wikipedia.org/wiki/Unethical_human_experimentation "Unethical human experimentation"). However, the trial, together with the evidence presented to the court and its major findings—which have proved remarkably accurate—was dismissed as [communist propaganda](https://en.wikipedia.org/wiki/Communist_propaganda "Communist propaganda") and totally ignored in [the West](https://en.wikipedia.org/wiki/Western_Bloc "Western Bloc") until the 1980s.[^8]

Historian [Sheldon Harris](https://en.wikipedia.org/wiki/Sheldon_H._Harris "Sheldon H. Harris") described the trial in his history of Unit 731:

> Evidence introduced during the hearings was based on eighteen volumes of interrogations and documentary material gathered in investigations over the previous four years. Some of the volumes included more than four hundred pages of depositions.... Unlike the [Moscow Show Trials](https://en.wikipedia.org/wiki/Moscow_Show_Trials "Moscow Show Trials") of the 1930s, the Japanese confessions made in the Khabarovsk trial were based on fact and not the fantasy of their handlers.[^9]

Yet the very wealth of trial documentation that tended to confirm that the Khabarovsk proceedings were no mere show trial also led Harris to question the relatively light punishment meted out there. All of the defendants (aside from one who died in prison and another who committed suicide) had been freed by 1956, a mere seven years after the trial took place.[^10] Chief trial translator Georgy Permyakov alleged that Soviet leader [Joseph Stalin](https://en.wikipedia.org/wiki/Joseph_Stalin "Joseph Stalin") may have initially feared that Japan would [execute](https://en.wikipedia.org/wiki/Execution "Execution") Soviet [prisoners of war](https://en.wikipedia.org/wiki/Prisoner_of_war "Prisoner of war") if the Khabarovsk defendants were [hanged](https://en.wikipedia.org/wiki/Hanged "Hanged").[^10] But Harris also claimed that "the Soviets made a deal with the Japanese similar to the one completed by the Americans: Information \[in exchange\] for... extremely light sentences":[^10]

> The Soviets and their successors never released the interrogation reports of the Japanese, some 18 volumes. This leads me to believe that the Japanese did arrange a deal, did yield some information, and the Soviets settled for the best goodies they could get.[^10]

Harris also noted other issues unleashed by the trial, which linked emperor [Hirohito](https://en.wikipedia.org/wiki/Hirohito "Hirohito") to the Japanese biological warfare program, as well as allegations that Japanese biological warfare experiments had also been conducted on Allied prisoners of war.

One of the experts called upon by Soviet prosecutors during the trial, N. N. Zhukov-Verezhnikov, later served on the panel of scientists, led by [Joseph Needham](https://en.wikipedia.org/wiki/Joseph_Needham "Joseph Needham"), investigating [Chinese](https://en.wikipedia.org/wiki/China "China") and [North Korean](https://en.wikipedia.org/wiki/North_Korea "North Korea") [allegations of US biological warfare in the Korean War](https://en.wikipedia.org/wiki/Allegations_of_biological_warfare_in_the_Korean_War "Allegations of biological warfare in the Korean War").[^11]

## Accused and their sentences

- 25 years imprisonment:
	- [General](https://en.wikipedia.org/wiki/General_officer "General officer") [Otozō Yamada](https://en.wikipedia.org/wiki/Otoz%C5%8D_Yamada "Otozō Yamada") (born 1881), former [Commander-in-Chief](https://en.wikipedia.org/wiki/Commander-in-chief "Commander-in-chief") of the [Kwantung Army](https://en.wikipedia.org/wiki/Kwantung_Army "Kwantung Army") (released from prison in 1956)
		- [Lieutenant General](https://en.wikipedia.org/wiki/Lieutenant_general "Lieutenant general") Kajitsuka Ryuji (born 1888), former Chief of Medical Administration (released from prison in 1956)
		- Lieutenant General Takahashi Takaatsu (born 1888), former Chief of [Veterinary](https://en.wikipedia.org/wiki/Veterinary_medicine "Veterinary medicine") Service (died in prison in 1951)
		- [Major General](https://en.wikipedia.org/wiki/Major_general "Major general") Kawashima Kiyoshi (born 1893), former Chief of [Unit 731](https://en.wikipedia.org/wiki/Unit_731 "Unit 731") (released from prison in 1956)
- 20 years imprisonment:
	- Major General [Sato Shunji](https://en.wikipedia.org/wiki/Sato_Shunji "Sato Shunji") (born 1896), former Chief of Medical Service, [5th Army](https://en.wikipedia.org/wiki/Fifth_Army_\(Japan\) "Fifth Army (Japan)") (released from prison in 1956)
		- [Major](https://en.wikipedia.org/wiki/Major_\(rank\) "Major (rank)") Karasawa Tomio (born 1911), former chief of a section of Unit 731 (killed himself in prison in 1956)
- 18 years imprisonment:
	- [Lieutenant Colonel](https://en.wikipedia.org/wiki/Lieutenant_colonel "Lieutenant colonel") Nishi Toshihide (born 1904), former chief of a division of Unit 731 (released from prison in 1956)
- 15 years imprisonment:
	- [Senior Sergeant](https://en.wikipedia.org/wiki/Sergeant "Sergeant") Mitomo Kazuo (born 1924), former member of [Unit 100](https://en.wikipedia.org/wiki/Unit_100 "Unit 100") (released from prison in 1956)
- 12 years imprisonment:
	- Major Onoue Masao (born 1910), former chief of a branch of Unit 731 (released from prison in 1956)
- 10 years imprisonment:
	- [Lieutenant](https://en.wikipedia.org/wiki/Lieutenant "Lieutenant") Hirazakura Zensaku (born 1916), former researcher of Unit 100 (released from prison in 1956)
- 3 years imprisonment:
	- Kurushima Yuji (born 1923), former [lab](https://en.wikipedia.org/wiki/Laboratory "Laboratory") [orderly](https://en.wikipedia.org/wiki/Orderly "Orderly") of Branch 162 of Unit 731 (released in 1952)
- 2 years imprisonment:
	- [Corporal](https://en.wikipedia.org/wiki/Corporal "Corporal") Kikuchi Norimitsu (born 1922), former medical orderly of Branch 643 of Unit 731 (released in 1951)

[^1]: Harris, S.H. (2002) *Factories of Death. Japanese Biological Warfare, 1932–1945, and the American Cover-up*, revised ed. Routledge, New York.

[^2]: Hal Gold, *Unit 731 Testimony*, 2003, p. 109.

[^3]: Kristof, Nicholas D. (1995-03-17). ["Unmasking Horror – A special report. Japan Confronting Gruesome War Atrocity"](https://www.nytimes.com/1995/03/17/world/unmasking-horror-a-special-report-japan-confronting-gruesome-war-atrocity.html). *The New York Times*. [Archived](https://web.archive.org/web/20190714031133/https://www.nytimes.com/1995/03/17/world/unmasking-horror-a-special-report-japan-confronting-gruesome-war-atrocity.html) from the original on 2019-07-14. Retrieved 2019-07-14.

[^4]: Brody, Howard; Leonard, Sarah E.; Nie, Jing-Bao; Weindling, Paul (2014). ["United States Responses to Japanese Wartime Inhuman Experimentation after World War II: National Security and Wartime Exigency"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4487829). *Cambridge Quarterly of Healthcare Ethics*. **23** (2): 220–230. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1017/S0963180113000753](https://doi.org/10.1017%2FS0963180113000753). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0963-1801](https://search.worldcat.org/issn/0963-1801). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [4487829](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC4487829). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [24534743](https://pubmed.ncbi.nlm.nih.gov/24534743).

[^5]: Daniel Barenblatt, *A Plague upon Humanity*, HarperCollins, 2004, pp. 220–221.

[^6]: ["Researching Japanese War Crimes Records: Introductory Essays"](https://www.archives.gov/files/iwg/japanese-war-crimes/introductory-essays.pdf) (PDF). *[National Archives and Records Administration](https://en.wikipedia.org/wiki/National_Archives_and_Records_Administration "National Archives and Records Administration")*. 2006. Retrieved December 16, 2024.

[^7]: ' [*Materials on the Trial of Former Servicemen of the Japanese Army Charged with Manufacturing and Employing Bacteriological Weapons*, Foreign Languages Publishing House, 1950](https://books.google.com/books?id=ARojAAAAMAAJ)

[^8]: Jing-Bao Nie, " [The West's Dismissal of the Khabarovsk trial as "Communist Propaganda": Ideology, evidence and international bioethics](https://link.springer.com/article/10.1007/BF02448905)," in *[Journal of Bioethical Inquiry](https://en.wikipedia.org/wiki/Journal_of_Bioethical_Inquiry "Journal of Bioethical Inquiry")*, April 2004, Volume 1, Issue 1, pp. 32–42.

[^9]: Sheldon H. Harris, "Factories of Death: Japanese Biological Warfare, 1932–1945, and the American Cover-up (rev. ed)", Routledge, 2002, p. 318.

[^10]: Working, Russell (2001-06-05). ["The trial of Unit 731"](https://www.japantimes.co.jp/opinion/2001/06/05/commentary/world-commentary/the-trial-of-unit-731/). *The Japan Times*. Retrieved 2022-02-11.

[^11]: G. Cameron Hurst III, "Biological Weapons: The United States and the Korean War," in "Dark Medicine: Rationalizing Unethical Medical Research" (eds. William R. LaFleur, Susumu Shimazono), Indiana University Press, 2008, pp. 105–120