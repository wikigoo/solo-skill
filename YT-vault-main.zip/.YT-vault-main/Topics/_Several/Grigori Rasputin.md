---
title: "Grigori Rasputin"
source: "https://en.wikipedia.org/wiki/Grigori_Rasputin"
description:
---
**Grigori Yefimovich Rasputin** [^1] (21 January \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 9 January\] 1869 – 30 December \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 17 December\] 1916) was a Russian [mystic](https://en.wikipedia.org/wiki/Christian_mysticism#Eastern_Orthodox_Christianity "Christian mysticism") and [faith healer](https://en.wikipedia.org/wiki/Faith_healing#Christianity "Faith healing"). He is best known for having befriended the [imperial family](https://en.wikipedia.org/wiki/House_of_Romanov "House of Romanov") of [Nicholas II](https://en.wikipedia.org/wiki/Nicholas_II "Nicholas II"), the last [Emperor of Russia](https://en.wikipedia.org/wiki/Emperor_of_Russia "Emperor of Russia"), through whom he gained considerable influence in the final years of the [Russian Empire](https://en.wikipedia.org/wiki/Russian_Empire "Russian Empire").

Rasputin was born to a family of [peasants](https://en.wikipedia.org/wiki/Peasant "Peasant") in the [Siberian](https://en.wikipedia.org/wiki/Siberia "Siberia") village of [Pokrovskoye](https://en.wikipedia.org/wiki/Pokrovskoye,_Tyumen_Oblast "Pokrovskoye, Tyumen Oblast"), located within [Tyumensky Uyezd](https://en.wikipedia.org/wiki/Tyumensky_Uyezd "Tyumensky Uyezd") in [Tobolsk Governorate](https://en.wikipedia.org/wiki/Tobolsk_Governorate "Tobolsk Governorate") (present-day [Yarkovsky District](https://en.wikipedia.org/wiki/Yarkovsky_District "Yarkovsky District") in [Tyumen Oblast](https://en.wikipedia.org/wiki/Tyumen_Oblast "Tyumen Oblast")). He had a religious conversion experience after embarking on a [pilgrimage](https://en.wikipedia.org/wiki/Christian_pilgrimage "Christian pilgrimage") to a monastery in 1897 and has been described as a monk or as a *[strannik](https://en.wikipedia.org/wiki/Russian_wandering "Russian wandering")* (wanderer or pilgrim), though he held no official position in the [Russian Orthodox Church](https://en.wikipedia.org/wiki/Russian_Orthodox_Church "Russian Orthodox Church"). Eventually gaining a reputation as a *[starets](https://en.wikipedia.org/wiki/Starets "Starets")*,[^3] in 1903 or in the winter of 1904–1905, he travelled to [Saint Petersburg](https://en.wikipedia.org/wiki/Saint_Petersburg "Saint Petersburg") and captivated several religious and social leaders, eventually becoming a prominent figure in Russian society. In November 1905, Rasputin met Nicholas II and his empress consort, [Alexandra Feodorovna](https://en.wikipedia.org/wiki/Alexandra_Feodorovna_\(Alix_of_Hesse\) "Alexandra Feodorovna (Alix of Hesse)").

In late 1906, Rasputin began acting as a faith healer for Nicholas and Alexandra's only son, [Alexei Nikolaevich](https://en.wikipedia.org/wiki/Alexei_Nikolaevich,_Tsarevich_of_Russia "Alexei Nikolaevich, Tsarevich of Russia"), who suffered from [haemophilia](https://en.wikipedia.org/wiki/Haemophilia "Haemophilia"). He was a divisive figure at court, seen by some Russians as a mystic, visionary, and prophet, and by others as a religious [charlatan](https://en.wikipedia.org/wiki/Charlatan "Charlatan"). The extent of Rasputin's power reached an all-time high in 1915, when Nicholas left Saint Petersburg to oversee the [Imperial Russian Army](https://en.wikipedia.org/wiki/Imperial_Russian_Army "Imperial Russian Army") as it was engaged in the [First World War](https://en.wikipedia.org/wiki/World_War_I "World War I"). In his absence, Rasputin and Alexandra consolidated their influence across the Russian Empire. However, as Russian military defeats mounted on the [Eastern Front](https://en.wikipedia.org/wiki/Eastern_Front_\(World_War_I\) "Eastern Front (World War I)"), both figures became increasingly unpopular. In the early morning of 30 December \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 17 December\] 1916, Rasputin was assassinated by a group of conservative Russian noblemen who opposed his influence over the imperial family.

Historians often suggest that Rasputin's scandalous and sinister reputation helped discredit the Tsarist government, thus precipitating the overthrow of the [House of Romanov](https://en.wikipedia.org/wiki/House_of_Romanov "House of Romanov") shortly after his assassination. Accounts of his life and influence were often based on common rumors; he remains a mysterious and captivating [figure in popular culture](https://en.wikipedia.org/wiki/Grigori_Rasputin_in_popular_culture "Grigori Rasputin in popular culture").[^4]

## Early life

![](https://en.wikipedia.org/wiki/File:Village_of_Pokrovskoe_on_the_Tura_River.jpg)

Pokrovskoye in 1912

![](https://en.wikipedia.org/wiki/File:Raspoutine_et_ses_enfants.jpg)

Rasputin with his children

Grigori Yefimovich Rasputin was born a [peasant](https://en.wikipedia.org/wiki/Peasant "Peasant") in the small village of [Pokrovskoye](https://en.wikipedia.org/wiki/Pokrovskoye,_Tyumen_Oblast "Pokrovskoye, Tyumen Oblast"), along the [Tura River](https://en.wikipedia.org/wiki/Tura_River "Tura River") in the [Tobolsk Governorate](https://en.wikipedia.org/wiki/Tobolsk_Governorate "Tobolsk Governorate") (now [Tyumen Oblast](https://en.wikipedia.org/wiki/Tyumen_Oblast "Tyumen Oblast")) in the [Russian Empire](https://en.wikipedia.org/wiki/Russian_Empire "Russian Empire").[^5] According to official records, he was born on 21 January \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 9 January\] 1869 and [christened](https://en.wikipedia.org/wiki/Infant_baptism "Infant baptism") the following day.[^6] He was named for [St. Gregory of Nyssa](https://en.wikipedia.org/wiki/St._Gregory_of_Nyssa "St. Gregory of Nyssa"), whose feast was celebrated on 10 January.[^7]

There are few records of Rasputin's parents. His father, Yefim (1842–1916),[^7] was a peasant farmer and church elder who had been born in Pokrovskoye and married Rasputin's mother, Anna Parshukova (c. 1840 – 1906), in 1863. Yefim also worked as a government courier, ferrying people and goods between [Tobolsk](https://en.wikipedia.org/wiki/Tobolsk "Tobolsk") and [Tyumen](https://en.wikipedia.org/wiki/Tyumen "Tyumen").[^8] [^7] The couple had seven other children, all of whom died in infancy and early childhood; there may have been a ninth child, Feodosiya. According to historian Joseph T. Fuhrmann, Rasputin was certainly close to Feodosiya and was [godfather](https://en.wikipedia.org/wiki/Godparent "Godparent") to her children, but "the records that have survived do not permit us to say more than that".[^8]

According to historian [Douglas Smith](https://en.wikipedia.org/wiki/Douglas_Smith_\(writer\) "Douglas Smith (writer)"), Rasputin's youth and early adulthood are "a black hole about which we know almost nothing", though the lack of reliable sources and information did not stop others from fabricating stories about Rasputin's parents and his youth after his rise to prominence.[^9] Historians agree, however, that like most [Siberian](https://en.wikipedia.org/wiki/Siberia "Siberia") peasants, including his mother and father, Rasputin was not formally educated and remained illiterate well into his early adulthood.[^7] [^10] Local archival records suggest that he had a somewhat unruly youth—possibly involving drinking, small thefts and disrespect for local authorities—but contain no evidence of his being charged with [stealing horses](https://en.wikipedia.org/wiki/Horse_theft "Horse theft"), [blasphemy](https://en.wikipedia.org/wiki/Blasphemy "Blasphemy") or bearing false witness, all major crimes later imputed to him as a young man.[^11]

In 1886, Rasputin traveled to [Abalak](https://en.wikipedia.org/wiki/Abalak,_Tyumen_Oblast "Abalak, Tyumen Oblast"), some 250 km east-northeast of Tyumen and 2,800 km east of [Moscow](https://en.wikipedia.org/wiki/Moscow "Moscow"), where he met a peasant girl named Praskovya Dubrovina. After a courtship of several months, they married in February 1887. Praskovya remained in Pokrovskoye throughout Rasputin's later travels and rise to prominence, and remained devoted to him until his death. The couple had seven children, though only three survived to adulthood: Dmitry (b. 1895), [Maria](https://en.wikipedia.org/wiki/Maria_Rasputin "Maria Rasputin") (b. 1898), and Varvara (b. 1900).[^12]

## Religious conversion

In 1897, Rasputin developed a renewed interest in religion and left Pokrovskoye to go on a [pilgrimage](https://en.wikipedia.org/wiki/Pilgrimage "Pilgrimage"). His reasons are unclear; according to some sources, he left the village to escape punishment for his role in horse theft.[^13] Other sources suggest Rasputin had a vision of the [Virgin Mary](https://en.wikipedia.org/wiki/Virgin_Mary "Virgin Mary") or of [St. Simeon of Verkhoturye](https://en.wikipedia.org/wiki/Simeon_of_Verkhoturye "Simeon of Verkhoturye"), while still others suggest that a young theological student, Melity Zaborovsky, inspired his pilgrimage.[^14] Whatever his reasons, Rasputin cast off his old life: he was 28 years old, married ten years, with an infant son and another child on the way. According to Smith, his decision "could only have been occasioned by some sort of emotional or spiritual crisis".[^15]

Rasputin had undertaken earlier, shorter pilgrimages to the Holy Znamensky Monastery at Abalak and to [Tobolsk's cathedral](https://en.wikipedia.org/wiki/Tobolsk_Kremlin "Tobolsk Kremlin"), but his visit to the St. Nicholas Monastery at [Verkhoturye](https://en.wikipedia.org/wiki/Verkhoturye "Verkhoturye") in 1897 transformed him.[^16] There, he met and was "profoundly humbled" by a *[starets](https://en.wikipedia.org/wiki/Starets "Starets")* (elder) known as Makary. Rasputin may have spent several months at Verkhoturye, and it was perhaps here that he learned to read and write. However, he later claimed that some of the monks at Verkhotuyre engaged in [homosexuality](https://en.wikipedia.org/wiki/Homosexuality "Homosexuality") and criticized monastic life as too coercive.[^17] He returned to Pokrovskoye a changed man, looking disheveled and behaving differently. He became a vegetarian, swore off alcohol, and prayed and sang much more fervently than he had in the past.[^18]

Rasputin spent the years that followed as a *strannik* (a holy wanderer or pilgrim), leaving Pokrovskoye for months or even years at a time to wander the country and visit a variety of holy sites.[^19] It is possible he wandered as far as [Mount Athos](https://en.wikipedia.org/wiki/Mount_Athos "Mount Athos") —the center of [Eastern Orthodox](https://en.wikipedia.org/wiki/Eastern_Orthodox_Church "Eastern Orthodox Church") monastic life—in 1900.[^20]

By the early 1900s, Rasputin had developed a small circle of followers, primarily family members and other local peasants, who prayed with him on Sundays and other holy days when he was in Pokrovskoye. Building a makeshift chapel in Yefim's root cellar—Rasputin was still living within his father's household at the time—the group held secret prayer meetings there. These meetings were the subject of some suspicion and hostility from the village priest and other villagers. It was rumored that female followers were ceremonially washing Rasputin before each meeting, that the group sang strange songs, and even that Rasputin had joined the [Khlysty](https://en.wikipedia.org/wiki/Khlysty "Khlysty"), a religious sect whose ecstatic rituals were rumored to include self- [flagellation](https://en.wikipedia.org/wiki/Flagellation "Flagellation") and sexual [orgies](https://en.wikipedia.org/wiki/Orgy "Orgy").[^21] [^22] According to Fuhrmann, however, "repeated investigations failed to establish that Rasputin was ever a member of the sect", and rumors that he was a Khlyst appear to have been unfounded.[^23]

## Rise to prominence

![](https://en.wikipedia.org/wiki/File:Makarij,_Theofan_of_Poltava_and_Rasputin,_1909_02.jpg)

Makary, Bishop Theofan and Rasputin, 1909

Word of Rasputin's activity and [charisma](https://en.wikipedia.org/wiki/Charisma "Charisma") began to spread in Siberia during the early 1900s.[^21] At some point during 1904 or 1905, he traveled to the city of [Kazan](https://en.wikipedia.org/wiki/Kazan "Kazan"), where he acquired a reputation as a wise *starets* who could help people resolve their spiritual crises and anxieties.[^24] Despite rumors that Rasputin was having sex with female followers,[^25] he made a favorable impression on several local religious leaders. Among these were [Archimandrite](https://en.wikipedia.org/wiki/Archimandrite "Archimandrite") Andrei and Bishop Chrysthanos, who gave Rasputin a letter of recommendation to Bishop Sergei, the rector of the [theological seminary](https://en.wikipedia.org/wiki/Theological_seminary "Theological seminary") at the [Alexander Nevsky Monastery](https://en.wikipedia.org/wiki/Alexander_Nevsky_Monastery "Alexander Nevsky Monastery"), and arranged for him to travel to [Saint Petersburg](https://en.wikipedia.org/wiki/Saint_Petersburg "Saint Petersburg").[^26] [^27] [^28]

Upon arriving at the [Alexander Nevsky Lavra](https://en.wikipedia.org/wiki/Alexander_Nevsky_Lavra "Alexander Nevsky Lavra"), Rasputin was introduced to church leaders, including [Archimandrite Theofan](https://en.wikipedia.org/wiki/Theofan_\(Bystrov\) "Theofan (Bystrov)"), inspector of the theological seminary, who was well-connected in Saint Petersburg society and later served as confessor to the imperial family.[^29] [^30] Theofan was so impressed with Rasputin that he invited him to stay in his home; he went on to become one of Rasputin's most essential friends in Saint Petersburg,[^29] gaining him entry to many of the influential [*salons*](https://en.wikipedia.org/wiki/Salon_\(gathering\) "Salon (gathering)") where the local aristocracy gathered for religious discussions. It was through these meetings that Rasputin attracted some of his early and influential followers—many of whom would later turn against him.[^31]

Alternative religious movements such as [spiritualism](https://en.wikipedia.org/wiki/Spiritualism_\(movement\) "Spiritualism (movement)") and [theosophy](https://en.wikipedia.org/wiki/Theosophy_\(Blavatskian\) "Theosophy (Blavatskian)") had become popular among Saint Petersburg's aristocracy before Rasputin's arrival, and many of the aristocracy were intensely curious about the [occult](https://en.wikipedia.org/wiki/Occult "Occult") and the supernatural.[^32] Rasputin's ideas and "strange manners" made him the subject of intense curiosity among the city's elite, who, according to Fuhrmann, were "bored, cynical, and seeking new experiences" during this period.[^29] Rasputin's appeal may have been enhanced by the fact that he was also a native Russian, unlike other self-described "holy men" such as [Nizier Anthelme Philippe](https://en.wikipedia.org/wiki/Nizier_Anthelme_Philippe "Nizier Anthelme Philippe") and [Gérard Encausse](https://en.wikipedia.org/wiki/G%C3%A9rard_Encausse "Gérard Encausse"), who had previously been popular in Saint Petersburg.[^30]

According to Fuhrmann, Rasputin stayed in Saint Petersburg for only a few months on his first visit and returned to Pokrovskoye in the fall of 1903.[^33] Smith, however, argues that it is impossible to know whether Rasputin stayed in Saint Petersburg or returned to Pokrovskoye at some point between his first arrival and 1905.[^34] Regardless, by 1905 Rasputin had formed friendships with several members of the aristocracy, including the "Black Princesses", [Militsa](https://en.wikipedia.org/wiki/Princess_Milica_of_Montenegro "Princess Milica of Montenegro") and [Anastasia](https://en.wikipedia.org/wiki/Princess_Anastasia_of_Montenegro "Princess Anastasia of Montenegro") of [Montenegro](https://en.wikipedia.org/wiki/Principality_of_Montenegro "Principality of Montenegro"), who had married cousins of Tsar [Nicholas II](https://en.wikipedia.org/wiki/Nicholas_II_of_Russia "Nicholas II of Russia") (Grand Duke [Peter Nikolaevich](https://en.wikipedia.org/wiki/Grand_Duke_Peter_Nikolaevich_of_Russia "Grand Duke Peter Nikolaevich of Russia") and Prince [George Maximilianovich Romanowsky](https://en.wikipedia.org/wiki/George_Maximilianovich,_6th_Duke_of_Leuchtenberg "George Maximilianovich, 6th Duke of Leuchtenberg")) and were instrumental in introducing Rasputin to the tsar and his family.[^30] [^35]

Rasputin first met Nicholas on 1 November 1905, at the [Peterhof Palace](https://en.wikipedia.org/wiki/Peterhof_Palace "Peterhof Palace"). The tsar recorded the event in his diary, writing that he and his empress consort, [Alexandra Feodorovna](https://en.wikipedia.org/wiki/Alexandra_Feodorovna_\(Alix_of_Hesse\) "Alexandra Feodorovna (Alix of Hesse)"), had "made the acquaintance of a man of God—Grigory, from Tobolsk province".[^34] Rasputin returned to Pokrovskoye shortly after their first meeting and did not return to Saint Petersburg until July 1906.[^36] On his return, he sent Nicholas a [telegram](https://en.wikipedia.org/wiki/Telegram "Telegram") asking to present the tsar with an icon of St. [Simeon of Verkhoturye](https://en.wikipedia.org/wiki/Simeon_of_Verkhoturye "Simeon of Verkhoturye"). He met with Nicholas and Alexandra on 18 July and again in October, when he first met their children.[^37]

At some point, Nicholas and Alexandra became convinced that Rasputin possessed the miraculous power to heal their only son, [Tsesarevich](https://en.wikipedia.org/wiki/Tsesarevich "Tsesarevich") [Alexei Nikolaevich](https://en.wikipedia.org/wiki/Alexei_Nikolaevich,_Tsarevich_of_Russia "Alexei Nikolaevich, Tsarevich of Russia"), who suffered from [haemophilia](https://en.wikipedia.org/wiki/Haemophilia_in_European_royalty "Haemophilia in European royalty"). Historians disagree over when this happened: according to [Orlando Figes](https://en.wikipedia.org/wiki/Orlando_Figes "Orlando Figes"), Rasputin was first introduced to the tsar and tsarina as a healer who could help their son in November 1905,[^38] while Joseph T. Fuhrmann has speculated that it was in October 1906 that Rasputin was first asked to pray for the health of Alexei.[^39]

## Healer to Alexei Nikolaevich

![](https://en.wikipedia.org/wiki/File:%CE%A1%CE%B1%CF%83%CF%80%CE%BF%CF%8D%CF%84%CE%B9%CE%BD.jpg)

Alexandra Feodorovna with her children, Rasputin and the nurse Maria Ivanova Vishnyakova, 1908

Much of Rasputin's influence with the imperial family stemmed from the belief by Alexandra and others that he had, on several occasions, eased Alexei's pain and stopped his bleeding. According to historian [Marc Ferro](https://en.wikipedia.org/wiki/Marc_Ferro "Marc Ferro"), the tsarina had a "passionate attachment" to Rasputin, believing he could heal her son's affliction.[^40] [Harold Shukman](https://en.wikipedia.org/wiki/Harold_Shukman "Harold Shukman") wrote that Rasputin became "an indispensable member of the royal entourage".[^41] It is unclear when Rasputin first learned of Alexei's haemophilia, or when he first acted as a healer. He may have been aware of Alexei's condition as early as October 1906,[^39] and was summoned by Alexandra to pray for the tsarevich when he had an [internal hemorrhage](https://en.wikipedia.org/wiki/Internal_hemorrhage "Internal hemorrhage") in the spring of 1907. Alexei recovered the next morning.[^42] Alexandra's friend [Anna Vyrubova](https://en.wikipedia.org/wiki/Anna_Vyrubova "Anna Vyrubova") became convinced that Rasputin had miraculous powers shortly thereafter and became one of his most influential advocates.[^43] [^44]

During the summer of 1912, Alexei developed a hemorrhage in his thigh and groin after a jolting carriage ride near the imperial hunting grounds at [Spała](https://en.wikipedia.org/wiki/Spa%C5%82a "Spała"), which caused a large [hematoma](https://en.wikipedia.org/wiki/Hematoma "Hematoma").[^45] In severe pain and delirious with fever, the tsarevich appeared close to death.[^46] In desperation, Alexandra asked Vyrubova to send Rasputin (who was in Siberia) a telegram, asking him to pray for Alexei.[^47] Rasputin wrote back quickly, telling the tsarina that "God has seen your tears and heard your prayers. Do not grieve. The Little One will not die. Do not allow the doctors to bother him too much." [^47] The next morning, Alexei's condition was unchanged, but Alexandra was encouraged by the message and regained some hope that he would survive. His bleeding stopped the following day.[^47] Dr. [S. P. Fedorov](https://en.wikipedia.org/wiki/Sergei_Fyodorov_\(surgeon\) "Sergei Fyodorov (surgeon)"), one of the physicians who attended Alexei, admitted that "the recovery was wholly inexplicable from a medical point of view." [^48] Later, Dr. Fedorov admitted that Alexandra could not be blamed for seeing Rasputin as a miracle man: "Rasputin would come in, walk up to the patient, look at him, and spit. The bleeding would stop in no time.... How could the empress not trust Rasputin after that?" [^49]

Historian [Robert K. Massie](https://en.wikipedia.org/wiki/Robert_K._Massie "Robert K. Massie") has called Alexei's recovery "one of the most mysterious episodes of the whole Rasputin legend".[^47] The cause of his recovery is unclear: Massie speculated that Rasputin's suggestion not to let doctors disturb Alexei had aided his recovery by allowing him to rest and heal, or that his message may have aided Alexei's recovery by calming his mother and reducing the tsarevich's emotional stress.[^50] Alexandra believed that Rasputin had performed a miracle, and concluded that he was essential to Alexei's survival.[^51] Some writers and historians, such as Massie and Ferro, suggest that Rasputin stopped Alexei's bleeding on other occasions through [hypnosis](https://en.wikipedia.org/wiki/Hypnosis "Hypnosis"), which some modern physicians say is effective in managing hemophilia.[^52] [^53] [^40] Still other historians—including memoirist [Pierre Gilliard](https://en.wikipedia.org/wiki/Pierre_Gilliard "Pierre Gilliard"), Alexei's French-language tutor—have speculated that Rasputin controlled Alexei's bleeding by disallowing the administration of [aspirin](https://en.wikipedia.org/wiki/Aspirin "Aspirin"), then widely used to relieve pain, but unknown as an anti-clotting agent until the 1950s.[^54]

## Relationship with the Imperial Children

![](https://en.wikipedia.org/wiki/File:Rasputin_listovka.jpg)

Caricature of Rasputin and the imperial couple, 1916

Alexei and his siblings were also taught to view Rasputin as "our friend" and to share confidences with him. In the autumn of 1907, their aunt, Grand Duchess [Olga Alexandrovna](https://en.wikipedia.org/wiki/Grand_Duchess_Olga_Alexandrovna_of_Russia "Grand Duchess Olga Alexandrovna of Russia"), was escorted to the nursery by Nicholas to meet Rasputin. Maria, her sisters and brother Alexei were all wearing their long white nightgowns. "All the children seemed to like him," Olga Alexandrovna recalled. "They were completely at ease with him." [^55]

Rasputin's friendship with the tsar's children was evident in the messages he sent to them. "My Dear Pearl M!" Rasputin wrote the nine-year-old [Maria](https://en.wikipedia.org/wiki/Grand_Duchess_Maria_Nikolaevna_of_Russia "Grand Duchess Maria Nikolaevna of Russia") in one telegram in 1908. "Tell me how you talked with the sea, with nature! I miss your simple soul. We will see each other soon! A big kiss." In a second telegram, Rasputin told the child, "My Dear M! My Little Friend! May the Lord help you to carry your cross with wisdom and joy in Christ. This world is like the day, look it's already evening. So it is with the cares of the world." [^56] In February 1909, Rasputin sent all of the children a telegram, advising them to, "Love the whole of God's nature, the whole of His creation in particular this earth. The Mother of God was always occupied with flowers and needlework." [^57]

One of the girls' [governesses](https://en.wikipedia.org/wiki/Governess "Governess"), [Sofia Ivanovna Tyutcheva](https://en.wikipedia.org/wiki/Sofia_Ivanovna_Tyutcheva "Sofia Ivanovna Tyutcheva"), was horrified in 1910 when Rasputin was permitted access to the nursery when the four girls were in their nightgowns. Tyutcheva wanted Rasputin barred from the nurseries. In response to her complaints, Nicholas asked Rasputin to end his nursery visits. "I am so afr(aid) that S.I. \[Tyutcheva\] can speak... about our friend something bad," Maria's twelve-year-old sister [Tatiana](https://en.wikipedia.org/wiki/Grand_Duchess_Tatiana_Nikolaevna_of_Russia "Grand Duchess Tatiana Nikolaevna of Russia") wrote to her mother on 8 March 1910, after begging Alexandra to forgive her for doing something she did not like. "I hope our nurse will be nice to our friend now." [^58] Alexandra eventually had Tyutcheva fired.[^59]

Tyutcheva took her story to other members of the imperial family, who were scandalized by the reports. However, Rasputin's contacts with the children were by all accounts completely innocent.[^60] Nicholas's sister, Grand Duchess [Xenia Alexandrovna](https://en.wikipedia.org/wiki/Grand_Duchess_Xenia_Alexandrovna_of_Russia "Grand Duchess Xenia Alexandrovna of Russia"), was horrified by Tyutcheva's story. Xenia wrote on 15 March 1910 that she could not understand "...the attitude of Alix and the children to that sinister Grigory (whom they consider to be almost a saint, when in fact he's only a *khlyst*!) He's always there, goes into the nursery, visits [Olga](https://en.wikipedia.org/wiki/Grand_Duchess_Olga_Nikolaevna_of_Russia "Grand Duchess Olga Nikolaevna of Russia") and Tatiana while they are getting ready for bed, sits there talking to them and *caressing* them. They are careful to hide him from Sofia Ivanovna, and the children don't dare talk to her about him. It's all quite unbelievable and beyond understanding." [^58]

Another of the nursery governesses claimed in the spring of 1910 that she was [raped](https://en.wikipedia.org/wiki/Rape "Rape") by Rasputin. Maria Ivanovna Vishnyakova had at first been a devotee of Rasputin, but later was disillusioned by him. Alexandra refused to believe Vishnyakova "and said that everything Rasputin does is holy". Grand Duchess Olga Alexandrovna was told that Vishnyakova's claim had been immediately investigated, but "they caught the young woman in bed with a [Cossack](https://en.wikipedia.org/wiki/Cossack "Cossack") of the [Imperial Guard](https://en.wikipedia.org/wiki/Russian_Imperial_Guard "Russian Imperial Guard")." Vishnyakova was dismissed from her post in 1913.[^61]

It was whispered in society that Rasputin had seduced not only Alexandra but also the four grand duchesses.[^62] Rasputin had released ardent letters written to him by the tsarina and the grand duchesses, which circulated throughout society and fueled the rumors. [Pornographic cartoons](https://en.wikipedia.org/wiki/Cartoon_pornography "Cartoon pornography") also circulated that depicted Rasputin having sexual relations with the tsarina, with her four daughters, and Anna Vyrubova nude in the background.[^63] Nicholas ordered Rasputin to leave Saint Petersburg for a time, much to Alexandra's displeasure, and Rasputin went on a pilgrimage to [Palestine](https://en.wikipedia.org/wiki/Palestine_\(region\) "Palestine (region)").[^64]

Despite the scandal, the imperial family's association with Rasputin continued until his murder on 17 December 1916. "Our Friend is so contented with our girlies, says they have gone through heavy 'courses' for their age and their souls have much developed," Alexandra wrote to Nicholas on 6 December 1916.[^65] In his memoirs, A. A. Mordvinov reported that the four grand duchesses appeared "cold and visibly terribly upset" by Rasputin's death and sat "huddled up closely together" on a sofa in one of their bedrooms on the night they received the news. Mordvinov reported that the young women were in a gloomy mood and seemed to sense the political upheaval that was about to be unleashed.[^66] Rasputin was buried with an icon signed on its reverse side by the grand duchesses and their mother.[^67]

## Controversies

![](https://en.wikipedia.org/wiki/File:Rasputin_Photo.jpg)

Rasputin among admirers, 1914

The imperial family's belief in Rasputin's healing powers brought him considerable status and power at court.[^68] Nicholas appointed Rasputin his *lampadnik* (lamplighter), charged with keeping the lamps lit before religious icons in the palace, which gained him regular access to the palace and imperial family.[^69] By December 1906, Rasputin had become close enough to ask a special favor of the tsar: that he be permitted to change his surname to Rasputin-Noviy (Rasputin-New). Nicholas granted the request, and the name change was speedily processed, suggesting that Rasputin already had the tsar's favor at that early date.[^39] Rasputin used his position to full effect, accepting [bribes](https://en.wikipedia.org/wiki/Bribery "Bribery") and sexual favors from admirers [^68] and working diligently to expand his influence.

Rasputin soon became a controversial figure; he was accused by his enemies of religious [heresy](https://en.wikipedia.org/wiki/Heresy_in_Christianity "Heresy in Christianity") and rape, was suspected of exerting undue political influence over the tsar, and was even rumored to be having an affair with the tsarina.[^70] Opposition to Rasputin's influence grew within the [Eastern Orthodox Church](https://en.wikipedia.org/wiki/Eastern_Orthodox_Church "Eastern Orthodox Church"). In 1907, the local clergy in Pokrovskoye denounced Rasputin as a heretic, and the Bishop of Tobolsk launched an inquest into his activities, accusing him of "spreading false, *[Khlyst](https://en.wikipedia.org/wiki/Khlyst "Khlyst") -like* doctrines".[^71] In Saint Petersburg, Rasputin faced opposition from even more prominent critics, including [Prime Minister](https://en.wikipedia.org/wiki/Prime_Minister_of_Russia "Prime Minister of Russia") [Pyotr Stolypin](https://en.wikipedia.org/wiki/Pyotr_Stolypin "Pyotr Stolypin") and the *[Okhrana](https://en.wikipedia.org/wiki/Okhrana "Okhrana")*, the tsar's [secret police](https://en.wikipedia.org/wiki/Secret_police "Secret police").[^72] Having ordered an investigation into Rasputin's activities, Stolypin confronted Nicholas but did not succeed in reining in Rasputin's influence or exiling him from Saint Petersburg.[^73]

Outside of the royal court, Rasputin preached that physical contact between him and others purified them; he engaged in drunken revels and extramarital affairs with a wide range of women from [prostitutes](https://en.wikipedia.org/wiki/Prostitute "Prostitute") to high-society ladies.[^74] [^75] In 1909, Khioniya Berlatskaya, one of Rasputin's early supporters, accused him of rape. Betlatskaya sought aid from Theofan, who became convinced that Rasputin was a danger to the monarchy.[^76] Rumors multiplied that Rasputin had assaulted female followers and behaved inappropriately on visits with the imperial family—and particularly with Nicholas's teenage daughters Olga and Tatiana.[^77] [^78]

During this period, the [First World War](https://en.wikipedia.org/wiki/World_War_I "World War I"), the dissolution of [feudalism](https://en.wikipedia.org/wiki/Feudalism "Feudalism"), and a meddling government bureaucracy all contributed to Russia's rapid economic decline. Many laid the blame on Alexandra and Rasputin. One outspoken member of the [Duma](https://en.wikipedia.org/wiki/State_Duma_\(Russian_Empire\) "State Duma (Russian Empire)"), far-right politician [Vladimir Purishkevich](https://en.wikipedia.org/wiki/Vladimir_Purishkevich "Vladimir Purishkevich"), stated in November 1916 that he held the tsar's ministers had "been turned into [marionettes](https://en.wikipedia.org/wiki/Marionette "Marionette"), marionettes whose threads have been taken firmly in hand by Rasputin and the Empress Alexandra Fyodorovna—the evil genius of Russia and the Tsarina... who has remained a German on the Russian throne and alien to the country and its people".[^79] (The tsarina had been born a German princess.)

## Failed assassination attempt

On 12 July \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 29 June\] 1914, a 33-year-old peasant woman named [Khioniya Guseva](https://en.wikipedia.org/wiki/Khioniya_Guseva "Khioniya Guseva") attempted to assassinate Rasputin by stabbing him in the stomach outside his home in Pokrovskoye.[^80] Rasputin had recently learnt from the Tsarina that Russia was preparing for war and had left his home to send a telegram urging the Tsar to avoid war.[^81] Rasputin was seriously wounded, and for a time it was not clear if he would survive.[^82] After surgery [^83] and some time in a hospital in Tyumen,[^84] he recovered.

Guseva was a follower of [Iliodor](https://en.wikipedia.org/wiki/Iliodor "Iliodor"), a former priest who had supported Rasputin before denouncing his sexual escapades and self-aggrandizement in December 1911.[^85] [^86] A radical conservative and [anti-semite](https://en.wikipedia.org/wiki/Antisemitism "Antisemitism"), Iliodor had been part of a group of establishment figures who had attempted to drive a wedge between Rasputin and the imperial family in 1911. When this effort failed, Iliodor was banished from Saint Petersburg and was ultimately [defrocked](https://en.wikipedia.org/wiki/Defrocking "Defrocking").[^85] [^87] Guseva claimed to have acted alone, having read about Rasputin in the newspapers and believing him to be a "false prophet and even an [Antichrist](https://en.wikipedia.org/wiki/Antichrist "Antichrist") ".[^88] Both the police and Rasputin, however, believed that Iliodor had instigated the assassination attempt.[^85] Iliodor fled the country before he could be questioned, and Guseva was found to be not responsible for her actions [by reason of insanity](https://en.wikipedia.org/wiki/Insanity_defense "Insanity defense").[^85]

## Death

![](https://en.wikipedia.org/wiki/File:BasementYusupovpalace.jpg)

Basement of the Yusupov Palace on the Moika where Rasputin was murdered

A group of nobles led by Purishkevich, Grand Duke [Dmitri Pavlovich](https://en.wikipedia.org/wiki/Dmitri_Pavlovich_of_Russia "Dmitri Pavlovich of Russia") and Prince [Felix Yusupov](https://en.wikipedia.org/wiki/Felix_Yusupov "Felix Yusupov") decided that Rasputin's influence over Alexandra threatened the Russian Empire. They concocted a plan in December 1916 to kill Rasputin, apparently by luring him to the Yusupovs' [Moika Palace](https://en.wikipedia.org/wiki/Moika_Palace "Moika Palace").[^89] [^90]

Rasputin was murdered during the early morning on 30 December \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 17 December\] 1916 at the home of Prince Yusupov. He died of three gunshot wounds, one of which was a close-range shot to his forehead. Little is certain about his death beyond this, and the circumstances of his death have been the subject of considerable speculation.[^91] According to Smith, "what really happened at the Yusupov home on 17 December will never be known".[^92] The story that Yusupov recounted in his memoirs, however, has become the most frequently told version of events.[^93]

![](https://en.wikipedia.org/wiki/File:PolshoiPetrovskyMost.jpg)

The wooden Bolshoy Petrovsky Bridge from which Rasputin's body was thrown into the Malaya Nevka River

According to Yusupov's account, Rasputin was invited to his palace shortly after midnight and ushered into the basement. Yusupov offered tea and cakes which had been laced with [cyanide](https://en.wikipedia.org/wiki/Cyanide "Cyanide"). After initially refusing the cakes, Rasputin began to eat them and, to Yusupov's surprise, appeared unaffected by the poison.[^94] Rasputin then asked for some [Madeira wine](https://en.wikipedia.org/wiki/Madeira_wine "Madeira wine") (which had also been poisoned) and drank three glasses, but still showed no sign of distress.[^2] At around 2:30 am, Yusupov excused himself to go upstairs, where his fellow conspirators were waiting. He took a [revolver](https://en.wikipedia.org/wiki/Revolver "Revolver") from Pavlovich, then returned to the basement and told Rasputin that he had "better look at the crucifix and say a prayer", referring to a crucifix in the room, then shot him once in the chest. The conspirators then drove to Rasputin's apartment, with Sukhotin wearing Rasputin's coat and hat in an attempt to make it look as though Rasputin had returned home that night.[^95] Upon returning to his palace, Yusupov went back to the basement to ensure that Rasputin was dead.[^96] Suddenly, Rasputin leaped up and attacked Yusupov, who freed himself with some effort and fled upstairs. Rasputin followed Yusupov into the palace's courtyard, where Purishkevich shot him. He collapsed into a snowbank. The conspirators then wrapped his body in cloth, drove it to the [Petrovsky Bridge](https://en.wikipedia.org/wiki/Bolshoy_Petrovsky_Bridge "Bolshoy Petrovsky Bridge") and dropped it into the [Little Nevka](https://en.wikipedia.org/wiki/Little_Nevka "Little Nevka") river.[^97]

In an unsubstantiated claim, Grand Duchess Tatiana, who was earlier alleged to have been raped by Rasputin, was present at the site of Rasputin's murder, "disguised as a lieutenant of the [Chevaliers-Gardes](https://en.wikipedia.org/wiki/Chevalier_Guard_Regiment "Chevalier Guard Regiment"), so that she could revenge herself on Rasputin who had tried to violate her". [Maurice Paléologue](https://en.wikipedia.org/wiki/Maurice_Pal%C3%A9ologue "Maurice Paléologue"), the French ambassador to Russia, wrote that Tatiana had supposedly witnessed Rasputin's [castration](https://en.wikipedia.org/wiki/Castration "Castration"), but he doubted the credibility of the rumor.[^98]

In a modern analysis of Rasputin's death, published on the 100th anniversary of the event, Dr. Carolyn Harris of the [University of Toronto](https://en.wikipedia.org/wiki/University_of_Toronto "University of Toronto") notes that the actual circumstances were less dramatic than Yusupov's account.[^99] Rasputin's daughter recorded that her father abstained from sweet food and would not have eaten the supposedly poisoned cakes.[^100] [^99] An autopsy account by the official surgeon involved has no record of poisoning or drowning, but records death by a single bullet fired into the head at close range.[^99]

### Aftermath

![](https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b3/EMPROS_19170112_p1_2_Raspoutin.JPG/250px-EMPROS_19170112_p1_2_Raspoutin.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

An excerpt about Rasputin's death from the Greek newspaper Empros.

News of Rasputin's murder spread quickly, even before his body was found. According to Smith, Purishkevich spoke openly about the murder to two soldiers and to a policeman who was investigating reports of shots shortly after the event, but urged them not to tell anyone else.[^101] An investigation was launched the next morning.[^102] The *Stock Exchange Gazette* ran a report of Rasputin's death "after a party in one of the most aristocratic homes in the center of the city" on the afternoon of 30 December \[[O.S.](https://en.wikipedia.org/wiki/Old_Style "Old Style") 17 December\] 1916.

![](https://en.wikipedia.org/wiki/File:Dead_Rasputin.jpg)

Rasputin's corpse on the ground with a bullet wound visible in his forehead

After two workmen discovered blood on the railing of the Petrovsky Bridge and a boot on the ice below, police began searching the area.[^103] Rasputin's body was found under the river ice on 1 January (O.S. 19 December), approximately 200 meters downstream from the bridge.[^104] Dmitry Kosorotov, the city's senior [autopsy](https://en.wikipedia.org/wiki/Autopsy "Autopsy") surgeon, examined the body. Kosorotov's report was lost, but he later stated that Rasputin's body had shown signs of severe trauma, including three gunshot wounds (one at close range to the forehead), a slice wound to his left side, and other injuries, many of which Kosorotov felt had been sustained post-mortem.[^105] Kosorotov found a single bullet in Rasputin's body but stated that it was too badly deformed and of a type too widely used to trace. He found no evidence that Rasputin had been poisoned.[^106] According to both Smith and Fuhrmann, Kosorotov found no water in Rasputin's lungs and reports that Rasputin had been thrown into the water alive were incorrect.[^107] [^108] Some later accounts claimed that Rasputin's penis had been severed, but Kosorotov found his genitals intact.[^106]

Rasputin was buried on 2 January (O.S. 21 December) at a small church that Vyrubova had been building at [Tsarskoye Selo](https://en.wikipedia.org/wiki/Tsarskoye_Selo "Tsarskoye Selo"). The funeral was attended only by the imperial family and a few of their intimates. Rasputin's wife, mistress, and children were not invited,[^109] although his daughters met with the imperial family at Vyrubova's home later that day.[^110] The imperial family planned to build a church over Rasputin's grave site.[^67] However, his body was [exhumed](https://en.wikipedia.org/wiki/Exhume "Exhume") and [burned](https://en.wikipedia.org/wiki/Posthumous_execution "Posthumous execution") by a detachment of soldiers on the orders of [Alexander Kerensky](https://en.wikipedia.org/wiki/Alexander_Kerensky "Alexander Kerensky") shortly after Nicholas abdicated the throne in March 1917,[^109] so that his grave would not become a rallying point for supporters of the old regime.[^111]

## Prominent children

![](https://en.wikipedia.org/wiki/File:Rasputindaughtercropped.jpg)

Rasputin with his daughter Maria (rightmost), in his St. Petersburg apartment, 1911

### Maria Rasputin

Rasputin's daughter, [Maria Rasputin](https://en.wikipedia.org/wiki/Maria_Rasputin "Maria Rasputin") (born Matryona Rasputina; 1898–1977), emigrated to France after the [October Revolution](https://en.wikipedia.org/wiki/October_Revolution "October Revolution") and then to the United States. There, she worked as a dancer and then a [lion tamer](https://en.wikipedia.org/wiki/Lion_tamer "Lion tamer") in a circus.[^112]

## Legacy

In more recent times, there has been a movement for Rasputin's [canonization](https://en.wikipedia.org/wiki/Canonization#Eastern_Orthodox_Church "Canonization") in the [Russian Orthodox Church](https://en.wikipedia.org/wiki/Russian_Orthodox_Church "Russian Orthodox Church"). Additionally, the Orthodox Church of the Sovereign Mother of God (OCSMG), founded by [John Bereslavsky](https://en.wikipedia.org/wiki/John_Bereslavsky "John Bereslavsky"), venerates Rasputin.[^113]

## In popular culture

- *[Rasputin and the Empress](https://en.wikipedia.org/wiki/Rasputin_and_the_Empress "Rasputin and the Empress")* (1932), a film directed by [Richard Boleslawski](https://en.wikipedia.org/wiki/Richard_Boleslawski "Richard Boleslawski") and [Charles Brabin](https://en.wikipedia.org/wiki/Charles_Brabin "Charles Brabin") starring [Lionel Barrymore](https://en.wikipedia.org/wiki/Lionel_Barrymore "Lionel Barrymore") as Grigori Rasputin, [Ralph Morgan](https://en.wikipedia.org/wiki/Ralph_Morgan "Ralph Morgan") as the Czar, [Ethel Barrymore](https://en.wikipedia.org/wiki/Ethel_Barrymore "Ethel Barrymore") as the Czarina and [John Barrymore](https://en.wikipedia.org/wiki/John_Barrymore "John Barrymore") as Prince Paul Chegodireff.
- *[Rasputin the Mad Monk](https://en.wikipedia.org/wiki/Rasputin_the_Mad_Monk "Rasputin the Mad Monk")* (1966), a Hammer horror film directed by [Don Sharp](https://en.wikipedia.org/wiki/Don_Sharp "Don Sharp") and starring [Christopher Lee](https://en.wikipedia.org/wiki/Christopher_Lee "Christopher Lee") as Grigori Rasputin, and [Barbara Shelley](https://en.wikipedia.org/wiki/Barbara_Shelley "Barbara Shelley").
- *[I Killed Rasputin](https://en.wikipedia.org/wiki/I_Killed_Rasputin "I Killed Rasputin")* (1967), an Italo-Franco biographical film directed by Robert Hossein about the death of Grigori Rasputin.
- *[Agony](https://en.wikipedia.org/wiki/Agony_\(1981_film\) "Agony (1981 film)")* (1973–1975, released only in 1981), a Soviet film directed by [Elem Klimov](https://en.wikipedia.org/wiki/Elem_Klimov "Elem Klimov"), with a score by [Alfred Schnittke](https://en.wikipedia.org/wiki/Alfred_Schnittke "Alfred Schnittke").
- " [Rasputin](https://en.wikipedia.org/wiki/Rasputin_\(song\) "Rasputin (song)") " (1978), a popular song by the German-Caribbean vocal group [Boney M.](https://en.wikipedia.org/wiki/Boney_M. "Boney M.")[^114]
- *[Anastasia](https://en.wikipedia.org/wiki/Anastasia_\(1997_film\) "Anastasia (1997 film)")* (1997), an animated musical starring [Christopher Lloyd](https://en.wikipedia.org/wiki/Christopher_Lloyd "Christopher Lloyd") as Grigori Rasputin.
- *[The King's Man](https://en.wikipedia.org/wiki/The_King's_Man "The King's Man")* (2021): [Rhys Ifans](https://en.wikipedia.org/wiki/Rhys_Ifans "Rhys Ifans") portrays Grigori Rasputin.
- *[Doctor Who](https://en.wikipedia.org/wiki/Doctor_Who "Doctor Who")* (2022): [The Master](https://en.wikipedia.org/wiki/The_Master_\(Doctor_Who\) "The Master (Doctor Who)") disguises himself as Grigori Rasputin and takes part in a dance sequence to Boney M’s single, [Rasputin](https://en.wikipedia.org/wiki/Rasputin_\(song\) "Rasputin (song)")

[^1]: In this name that follows [East Slavic naming customs](https://en.wikipedia.org/wiki/East_Slavic_naming_customs "East Slavic naming customs"), the [patronymic](https://en.wikipedia.org/wiki/Patronymic "Patronymic") is *Yefimovich* and the [family name](https://en.wikipedia.org/wiki/Surname "Surname") is *Rasputin*. In English, the name is pronounced [/ r æ ˈ s p j uː t ɪ n /](https://en.wikipedia.org/wiki/Help:IPA/English "Help:IPA/English") [*ra-SPEW-tin*](https://en.wikipedia.org/wiki/Help:Pronunciation_respelling_key "Help:Pronunciation respelling key"); Russian: Григорий Ефимович Распутин, pronounced [\[ɡrʲɪˈɡorʲɪj jɪˈfʲiməvʲɪtɕ rɐˈsputʲɪn\]](https://en.wikipedia.org/wiki/Help:IPA/Russian "Help:IPA/Russian").

[^2]: The claim that Stanislas Lazovert confessed on his deathbed that he applied mock-poison to the wine and pastries instead of cyanide to avoid violating the [Hippocratic Oath](https://en.wikipedia.org/wiki/Hippocratic_Oath "Hippocratic Oath") appears to be incorrect and likely originated with the book *The Ochrana: The Russian Secret Police*, in which the author merely assumes that Lazovert utilized mock-poison.

[^3]: ["Grigori Rasputin | Biography, Facts, & Death | Britannica"](https://www.britannica.com/biography/Grigory-Yefimovich-Rasputin). *www.britannica.com*. 24 August 2026. Retrieved 30 August 2026.

[^4]: ["Ra-Ra-Rasputin: The Definitive Historical Breakdown of Boney M's Classic Song"](https://www.historyhit.com/ra-ra-rasputin-boney-m/). *History Hit*. Retrieved 17 March 2022.

[^5]: [Wilson 1964](#CITEREFWilson1964), pp. 23–26.

[^6]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 7.

[^7]: [Smith 2016](#CITEREFSmith2016), p. 14.

[^8]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 6.

[^9]: [Smith 2016](#CITEREFSmith2016), pp. 14–15.

[^10]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 9.

[^11]: [Smith 2016](#CITEREFSmith2016), pp. 16–17.

[^12]: [Smith 2016](#CITEREFSmith2016), pp. 17–18.

[^13]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 14.

[^14]: [Smith 2016](#CITEREFSmith2016), pp. 20–21.

[^15]: [Smith 2016](#CITEREFSmith2016), p. 21.

[^16]: [Smith 2016](#CITEREFSmith2016), p. 22.

[^17]: [Smith 2016](#CITEREFSmith2016), pp. 23–25.

[^18]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 17.

[^19]: [Smith 2016](#CITEREFSmith2016), pp. 23, 26.

[^20]: [Smith 2016](#CITEREFSmith2016), pp. 25–26.

[^21]: [Smith 2016](#CITEREFSmith2016), p. 28.

[^22]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 19–20.

[^23]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 20.

[^24]: [Smith 2016](#CITEREFSmith2016), pp. 50–51.

[^25]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 25.

[^26]: [Smith 2016](#CITEREFSmith2016), pp. 50–53.

[^27]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 26.

[^28]: [Radzinsky 2010](#CITEREFRadzinsky2010), pp. 47–48.

[^29]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 29.

[^30]: [Smith 2016](#CITEREFSmith2016), p. 66.

[^31]: [Smith 2016](#CITEREFSmith2016), p. 57.

[^32]: [Figes 1998](#CITEREFFiges1998), p. 29.

[^33]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 30.

[^34]: [Smith 2016](#CITEREFSmith2016), p. 65.

[^35]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 29–30, 39.

[^36]: [Smith 2016](#CITEREFSmith2016), pp. 69–76.

[^37]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 41.

[^38]: [Figes 1998](#CITEREFFiges1998), p. 30.

[^39]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 41–42.

[^40]: [Ferro 1995](#CITEREFFerro1995), p. 137.

[^41]: [Shukman 1994](#CITEREFShukman1994), p. 370.

[^42]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 43.

[^43]: [Massie 2012](#CITEREFMassie2012), p. 168.

[^44]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 46.

[^45]: [Massie 2012](#CITEREFMassie2012), p. 192.

[^46]: [Massie 2012](#CITEREFMassie2012), pp. 193–195.

[^47]: [Massie 2012](#CITEREFMassie2012), p. 195.

[^48]: Julia P. Gelardi, *Born to Rule: Five Reigning Consorts, Granddaughters of Queen Victoria*, p. 176

[^49]: Julia P. Gelardi, *Born to Rule: Five Reigning Consorts, Granddaughters of Queen Victoria*, pp. 176–177

[^50]: [Massie 2012](#CITEREFMassie2012), pp. 197–198.

[^51]: [Massie 2012](#CITEREFMassie2012), p. 198.

[^52]: Haurani, Farid I. (2005). "Rasputin Used Hypnosis: Reply to 'Russia's Imperial Blood'". *American Journal of Hematology*. **80** (4): 309–310.

[^53]: Paredes, Ana Cristina (2019). ["Effectiveness of hypnosis for pain management and promotion of health-related quality-of-life among people with haemophilia: a randomised controlled pilot trial"](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6746787). *Scientific Reports*. **9** (1). [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1038/s41598-019-49827-1](https://doi.org/10.1038%2Fs41598-019-49827-1). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [6746787](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6746787). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [31527700](https://pubmed.ncbi.nlm.nih.gov/31527700).

[^54]: Hasic, Albinko (29 December 2016). ["5 Myths and Truths about Rasputin"](https://time.com/4606775/5-myths-rasputin/). *[Time](https://en.wikipedia.org/wiki/Time_\(magazine\) "Time (magazine)")*. Time-Life. Retrieved 15 November 2020.

[^55]: Massie (1967), pp. 199–200

[^56]: Maylunas and Mironenko (1997), p. 314

[^57]: Maylunas and Mironenko (1997), p. 321

[^58]: Maylunas and Mironenko (1997), p. 330

[^59]: Radzinsky (2000), p. 139

[^60]: Massie (1967), p. 208

[^61]: Radzinsky (2000), pp. 129–130.

[^62]: Mager (1998), p. 257

[^63]: Christopher et al. (1995), p. 115.

[^64]: Christopher et al. (1995), p. 116

[^65]: Maylunas and Mironenko (1997), p. 489

[^66]: Maylunas and Mironenko (1997), p. 507

[^67]: Maylunas and Mironenko (1997), p. 511

[^68]: [Figes 1998](#CITEREFFiges1998), p. 31.

[^69]: [Ferro 1995](#CITEREFFerro1995), p. 138.

[^70]: [Figes 1998](#CITEREFFiges1998), pp. 32–33.

[^71]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 52–53.

[^72]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 57.

[^73]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 58–59.

[^74]: " [Grigori Rasputin". *Britannica*, 2023.](https://www.britannica.com/biography/Grigory-Yefimovich-Rasputin)

[^75]: Harris, Carolyn (2016). " [The Murder of Rasputin, 100 Years Later](https://www.smithsonianmag.com/history/murder-rasputin-100-years-later-180961572/) ". Smithsonian Magazine.

[^76]: [Fuhrmann 2012](#CITEREFFuhrmann2012), p. 61.

[^77]: [Smith 2016](#CITEREFSmith2016), p. 168.

[^78]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 61–62.

[^79]: [Radzinsky 2010](#CITEREFRadzinsky2010), p. 434.

[^80]: [Fuhrmann 1990](#CITEREFFuhrmann1990), pp. 106–107.

[^81]: [Beevor 2022](#CITEREFBeevor2022).

[^82]: [Fuhrmann 1990](#CITEREFFuhrmann1990), p. 108.

[^83]: [Smith 2016](#CITEREFSmith2016), p. 332.

[^84]: [Smith 2016](#CITEREFSmith2016), pp. 360–361.

[^85]: [Smith 2017](#CITEREFSmith2017).

[^86]: [Fuhrmann 1990](#CITEREFFuhrmann1990), p. 82.

[^87]: [Fuhrmann 1990](#CITEREFFuhrmann1990), pp. 82–84.

[^88]: [Radzinsky 2010](#CITEREFRadzinsky2010), p. 256.

[^89]: [Farquhar 2001](#CITEREFFarquhar2001), p. 197.

[^90]: [Moorehead 1958](#CITEREFMoorehead1958), pp. 107–108.

[^91]: E.g.: Rooks, Nina (January–February 1989). ["The Coroner's Tale"](https://nyaspubs.onlinelibrary.wiley.com/doi/10.1002/j.2326-1951.1989.tb02129.x). Anecdotal Evidence. *The Sciences*. **29** (1): 2–5. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1002/j.2326-1951.1989.tb02129.x](https://doi.org/10.1002%2Fj.2326-1951.1989.tb02129.x). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0036-861X](https://search.worldcat.org/issn/0036-861X).

[^92]: [Smith 2016](#CITEREFSmith2016), pp. 590, 595.

[^93]: [Smith 2016](#CITEREFSmith2016), pp. 590–592.

[^94]: [Smith 2016](#CITEREFSmith2016), p. 590.

[^95]: [Smith 2016](#CITEREFSmith2016), pp. 590–591.

[^96]: [Smith 2016](#CITEREFSmith2016), p. 591.

[^97]: [Smith 2016](#CITEREFSmith2016), pp. 591–592.

[^98]: Maylunas and Mironenko, pp. 508–509

[^99]: Harris, Carolyn; and Sonja Anderson (March 4, 2024) \[December 27, 2016\]. " [What Really Happened During the Murder of Rasputin, Russia's 'Mad Monk'?](https://www.smithsonianmag.com/history/what-really-happened-during-murder-rasputin-russia-mad-monk-180961572/)". *[Smithsonian](https://en.wikipedia.org/wiki/Smithsonian_\(magazine\) "Smithsonian (magazine)")*.

[^100]: [Radzinsky 2010](#CITEREFRadzinsky2010), p. 478.

[^101]: [Smith 2016](#CITEREFSmith2016), pp. 597–598.

[^102]: [Smith 2016](#CITEREFSmith2016), p. 599.

[^103]: [Smith 2016](#CITEREFSmith2016), p. 600.

[^104]: [Smith 2016](#CITEREFSmith2016), p. 606.

[^105]: [Smith 2016](#CITEREFSmith2016), pp. 608–610.

[^106]: [Smith 2016](#CITEREFSmith2016), p. 610.

[^107]: [Smith 2016](#CITEREFSmith2016), p. 611.

[^108]: [Fuhrmann 2012](#CITEREFFuhrmann2012), pp. 217–219.

[^109]: [Rollins 1982](#CITEREFRollins1982), p. 197.

[^110]: [Smith 2016](#CITEREFSmith2016), p. 612.

[^111]: [Smith 2016](#CITEREFSmith2016), p. 650.

[^112]: Adams, Katherine H.; Keene, Michael L. (2012). [*Women of the American Circus, 1880–1940*](https://books.google.com/books?id=cp0Die6QcuIC&pg=PA162). McFarland. p. 162. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-4766-0079-6](https://en.wikipedia.org/wiki/Special:BookSources/978-1-4766-0079-6 "Special:BookSources/978-1-4766-0079-6").

[^113]: Markevich, Deacon Peter (4 May 2017). ["The Real Rasputin?: A Look at His Admirers' Revisionist History"](https://orthodoxlife.org/church-history/real-rasputin-revisionist-anashkin/). *Orthodox Life*. Retrieved 30 August 2026.

[^114]: Wright, J. M. II (2007). *"Russia's Greatest Love Machine": Disco, Exoticism, Subversion*. Doctoral dissertation. The University of North Carolina at Chapel Hill.