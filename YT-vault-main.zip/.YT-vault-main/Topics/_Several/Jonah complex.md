---
title: "Jonah complex"
source: "https://en.wikipedia.org/wiki/Jonah_complex"
---
![](https://thumb.wikimedia.org/wikipedia/commons/thumb/9/95/Pieter_Lastman_%281583-1633%29_-_Jonas_en_de_walvis_%281621%29_-_D%C3%BCsseldorf_Museum_Kunstpalast_15-08-2012_15-01-08.JPG/330px-Pieter_Lastman_%281583-1633%29_-_Jonas_en_de_walvis_%281621%29_-_D%C3%BCsseldorf_Museum_Kunstpalast_15-08-2012_15-01-08.JPG?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Jonah escapes from the belly of the great fish that has held him captive. 1 2

The **Jonah complex** is the fear of success or the fear of being one's best self. This fear prevents [self-actualization](https://en.wikipedia.org/wiki/Self-actualization "Self-actualization"), or the realization of one's own potential.[^3] [^4] It is the fear of one's own greatness, the evasion of one's destiny, or the avoidance of exercising one's talents.[^3] [^5] As the fear of achieving a personal worst may serve to motivate personal growth, likewise the fear of achieving a personal best may hinder achievement.[^3]

The Jonah complex is evident in [neurotic](https://en.wikipedia.org/wiki/Neuroticism "Neuroticism") people.[^6]

## Etymology

Although [Abraham Maslow](https://en.wikipedia.org/wiki/Abraham_Maslow "Abraham Maslow") is credited for the term, the name "Jonah complex" was originally suggested by Maslow's friend, Professor [Frank E. Manuel](https://en.wikipedia.org/wiki/Frank_E._Manuel "Frank E. Manuel").[^3] The name comes from the story of the Biblical prophet [Jonah](https://en.wikipedia.org/wiki/Jonah "Jonah") 's evasion of the destiny to prophesy the destruction of [Nineveh](https://en.wikipedia.org/wiki/Nineveh "Nineveh").[^7] Maslow states, "So often we run away from the responsibilities dictated (or rather suggested) by nature, by fate, even sometimes by accident, just as Jonah tried—in vain—to run away from *his* fate".[^3]

## Causes

Any dilemma, paradox or challenge faced by an individual may trigger reactions related to the "Jonah complex". These challenges may vary in degree and intensity. Such challenges may include career changes, beginning new stages in life, moving to new locations, interviews or auditions, and undertaking new interpersonal commitments such as marriage.[^8] The crux of the Jonah Complex distinguishes to the subject an inability to differentiate humility from self-helplessness. Other causes include:

- Fear of the sense of responsibility and work required that often attends recognizing one's own greatness, talents, potential
- Fear that an extraordinary life would be too much out of the ordinary, and hence not acceptable to others inciting xenophobic rejection
- Fear by association of the ability honed being heightened and elevated as subject to a traumatic unrelated event, complex or memory
- Fear of seeming arrogant, self-centered, etc.[^7]
- Difficulty envisioning oneself as a prominent or authoritative figure [^9]

[^1]: Orig. Hebrew (דָּג (גָּדוֹל.

[^2]: "Jonah ch. 2, vv. 1, 2, 11" in many versions ([MT](http://www.mechon-mamre.org/p/pt/pt1702.htm) ([Masoretic Text](https://en.wikipedia.org/wiki/Masoretic_Text "Masoretic Text")), [LXX](http://www.apostoliki-diakonia.gr/bible/bible.asp?contents=old_testament/contents_Ionas.asp&main=ionas&file=36.2.htm) ([Septuagint](https://en.wikipedia.org/wiki/Septuagint "Septuagint")), [D–R](http://www.biblegateway.com/passage/?search=Jonah+2&version=DRA) ([Douay–Rheims Bible](https://en.wikipedia.org/wiki/Douay%E2%80%93Rheims_Bible "Douay–Rheims Bible")), [NAB](https://www.vatican.va/archive/ENG0839/__PTX.HTM) ([New American Bible](https://en.wikipedia.org/wiki/New_American_Bible "New American Bible")), [NABRE](https://www.bible.com/bible/463/jon.2.1.nabre) ([New American Bible Revised Edition](https://en.wikipedia.org/wiki/New_American_Bible_Revised_Edition "New American Bible Revised Edition")), and others); "Jonah ch. 1, v. 17 and ch. 2, vv. 1, 10" in [KJV](http://www.biblegateway.com/passage/?search=Jonah+1-2&version=KJV) ([King James Version](https://en.wikipedia.org/wiki/King_James_Version "King James Version")) and many other Protestant translations.

[^3]: Abraham Maslow (October 1993). "The Jonah Complex". [*The Farther Reaches of Human Nature*](https://books.google.com/books?id=LRcSeVPS9ykC&q=jonah+complex). Penguin Publishing. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [9780140194708](https://en.wikipedia.org/wiki/Special:BookSources/9780140194708 "Special:BookSources/9780140194708").

[^4]: Department of Cognitive Science, Chris VerWys. Rensselaer Polytechnic Institute, [Personality Psychology](http://www.rpi.edu/~verwyc/MASLOWOH.htm), Abraham Maslow

[^5]: Haronian, Frank (15 December 1967). ["The Repression of the sublime"](http://synthesiscenter.org/articles/0130.pdf) (PDF). Retrieved 5 October 2011.

[^6]: [Feist, Gregory](https://en.wikipedia.org/wiki/Gregory_J._Feist "Gregory J. Feist"); Feist, Jess (2009). *Theories of personality* (7th ed.). New York McGraw-Hill Higher Education. p. 300. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-07-338270-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-07-338270-8 "Special:BookSources/978-0-07-338270-8").

[^7]: Eric Dodson. ["Course Notes for Humanistic Psychology (PSYC 2000)"](https://web.archive.org/web/20150920072942/https://www.westga.edu/~psydept/dodson-2000-maslow.html). *University of Western Georgia*. Archived from [the original](http://www.westga.edu/~psydept/dodson-2000-maslow.html) on 20 September 2015.

[^8]: Goud, N. (1994). Jonah Complex: The fear of growth. *Journal of Humanistic Education & Development, 32* (3), 98–111.

[^9]: Sumerlin, J. R.; Bundrick, C. M. (1996). "Brief index of self-actualization: A measure of Maslow's model". *Journal of Social Behavior and Personality*. **11** (2): 253–271. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.2466/pms.1998.87.1.115](https://doi.org/10.2466%2Fpms.1998.87.1.115). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [146163708](https://api.semanticscholar.org/CorpusID:146163708).