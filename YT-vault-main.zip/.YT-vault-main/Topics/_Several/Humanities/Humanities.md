---
title: "Humanities"
source: "https://en.wikipedia.org/wiki/Humanities"
---
**Humanities** are [academic disciplines](https://en.wikipedia.org/wiki/Academic_discipline "Academic discipline") that study aspects of [human](https://en.wikipedia.org/wiki/Human "Human") [society](https://en.wikipedia.org/wiki/Society "Society") and [culture](https://en.wikipedia.org/wiki/Culture "Culture"), including [certain fundamental questions asked by humans](https://en.wikipedia.org/wiki/Philosophy "Philosophy"). During the [Renaissance](https://en.wikipedia.org/wiki/Renaissance "Renaissance"), the term "humanities" referred to the study of classical literature and language, as opposed to the study of religion or the concept of " [divinity](https://en.wikipedia.org/wiki/Divinity "Divinity") ". The study of the humanities was a key part of the [secular](https://en.wikipedia.org/wiki/Secular "Secular") curriculum in universities at the time. Today, the humanities are more frequently defined as any fields of study outside of [natural sciences](https://en.wikipedia.org/wiki/Natural_sciences "Natural sciences"), [social sciences](https://en.wikipedia.org/wiki/Social_sciences "Social sciences"), [formal sciences](https://en.wikipedia.org/wiki/Formal_science "Formal science") (like [mathematics](https://en.wikipedia.org/wiki/Mathematics "Mathematics")), and [applied sciences](https://en.wikipedia.org/wiki/Applied_science "Applied science") (or [professional training](https://en.wikipedia.org/wiki/Professional_development "Professional development")). They use methods that are primarily [critical](https://en.wikipedia.org/wiki/Critical_theory "Critical theory"), speculative, or interpretative and have a significant historical element—as distinguished from the mainly [empirical](https://en.wikipedia.org/wiki/Empirical_method "Empirical method") approaches of [science](https://en.wikipedia.org/wiki/Science "Science").[^1]

The humanities include the academic study of [philosophy](https://en.wikipedia.org/wiki/Philosophy "Philosophy"), [religion](https://en.wikipedia.org/wiki/Religion "Religion"), [history](https://en.wikipedia.org/wiki/History "History"), [language arts](https://en.wikipedia.org/wiki/Language_arts "Language arts") ([literature](https://en.wikipedia.org/wiki/Literature "Literature"), [writing](https://en.wikipedia.org/wiki/Writing "Writing"), [oratory](https://en.wikipedia.org/wiki/Public_speaking "Public speaking"), [rhetoric](https://en.wikipedia.org/wiki/Rhetoric "Rhetoric"), [poetry](https://en.wikipedia.org/wiki/Poetry "Poetry"), etc.), the [performing arts](https://en.wikipedia.org/wiki/Performing_arts "Performing arts") ([theater](https://en.wikipedia.org/wiki/Theater "Theater"), [music](https://en.wikipedia.org/wiki/Music "Music"), [dance](https://en.wikipedia.org/wiki/Dance "Dance"), etc.), and the [visual arts](https://en.wikipedia.org/wiki/Visual_arts "Visual arts") ([painting](https://en.wikipedia.org/wiki/Painting "Painting"), [sculpture](https://en.wikipedia.org/wiki/Sculpture "Sculpture"), [photography](https://en.wikipedia.org/wiki/Photography "Photography"), [filmmaking](https://en.wikipedia.org/wiki/Filmmaking "Filmmaking"), etc.).[^2]

The word *humanities* comes from the [Renaissance Latin](https://en.wikipedia.org/wiki/Renaissance_Latin "Renaissance Latin") phrase *[studia humanitatis](https://en.wikipedia.org/wiki/Studia_humanitatis "Studia humanitatis")*, which translates to *study of humanity*. The *studia humanitatis* was a course of study comprising grammar, literature, rhetoric, history, and moral philosophy, primarily drawn from the study of Latin and Greek classics. The related Latin word *humanitas* inspired the Renaissance Italian neologism *umanisti*, or "humanists", which referred to scholars dedicated to these fields and were instrumental in reviving classical learning, a hallmark of " [Renaissance humanism](https://en.wikipedia.org/wiki/Renaissance_humanism "Renaissance humanism")." [^3] [^4] (The term *humanist* can also describe the philosophical position of [humanism](https://en.wikipedia.org/wiki/Humanism "Humanism"), which [antihumanist](https://en.wikipedia.org/wiki/Antihumanism "Antihumanism") scholars in the humanities reject.)

Historically, the humanities have been distinguished from the social sciences by their methods and objectives.[^1] While both fields study human behavior and culture, the humanities adopt an [idiographic](https://en.wikipedia.org/wiki/Nomothetic_and_idiographic "Nomothetic and idiographic") approach (focusing on the unique and context-specific), emphasizing critical, interpretative, and speculative methods, often with an emphasis on historical context and subjective meaning. In contrast, the social sciences employ a [nomothetic](https://en.wikipedia.org/wiki/Nomothetic_and_idiographic "Nomothetic and idiographic") approach (seeking general laws and patterns) through empirical and quantitative analysis, a distinction first conceptualized by philosopher [Wilhelm Windelband](https://en.wikipedia.org/wiki/Wilhelm_Windelband "Wilhelm Windelband").[^5] This methodological distinction, however, is not absolute. Although [sociology](https://en.wikipedia.org/wiki/Sociology "Sociology"), [anthropology](https://en.wikipedia.org/wiki/Anthropology "Anthropology"), [archaeology](https://en.wikipedia.org/wiki/Archaeology "Archaeology"), [linguistics](https://en.wikipedia.org/wiki/Linguistics "Linguistics"), and [psychology](https://en.wikipedia.org/wiki/Psychology "Psychology") are commonly classified as social sciences, these fields include scholars who employ qualitative methods closely related to those employed by humanities scholars, such as [narrative inquiry](https://en.wikipedia.org/wiki/Narrative_inquiry "Narrative inquiry"), [textual analysis](https://en.wikipedia.org/wiki/Close_reading "Close reading"), or [historical](https://en.wikipedia.org/wiki/Historical_method "Historical method") methods.[^6]

The humanities have also been justified as fostering self-reflection, civic responsibility, and cultural continuity. Though debates persist about the practical utility of the humanities, proponents argue that their unique focus on meaning, creativity, and critical inquiry contributes both to individual enrichment and the public sphere.[^7] [^8] [^9]

## Fields

### Classics

![](https://en.wikipedia.org/wiki/File:Homeros_Caetani_Louvre_Ma440_n2.jpg)

Bust of Homer, the most famous Greek poet

![](https://en.wikipedia.org/wiki/File:Head_Platon_Glyptothek_Munich_548.jpg)

The philosopher Plato depicted in a Roman copy of a work by Silanion for the Academia in Athens ( c. 370 BC )

[Classics](https://en.wikipedia.org/wiki/Classics "Classics"), in the [Western](https://en.wikipedia.org/wiki/Western_culture "Western culture") academic tradition, refers to the studies of the cultures of [classical antiquity](https://en.wikipedia.org/wiki/Classical_antiquity "Classical antiquity"), namely Ancient Greek and Latin and the Ancient [Greek](https://en.wikipedia.org/wiki/Ancient_Greece "Ancient Greece") and [Roman](https://en.wikipedia.org/wiki/Ancient_Rome "Ancient Rome") cultures. Classical studies are considered one of the cornerstones of the humanities; however, their popularity declined during the 20th century. Nevertheless, the influence of classical ideas on many humanities disciplines, such as philosophy and literature, remains strong.[^10]

### History

[History](https://en.wikipedia.org/wiki/History "History") is systematically collected [information](https://en.wikipedia.org/wiki/Information "Information") about the [past](https://en.wikipedia.org/wiki/Past "Past"). When used as the name of a [field of study](https://en.wikipedia.org/wiki/Field_of_study "Field of study"), *history* refers to the study and interpretation of the record of [humans](https://en.wikipedia.org/wiki/Human "Human"), [societies](https://en.wikipedia.org/wiki/Society "Society"), institutions, and any topic that has changed over time.[^11]

Traditionally, the study of history has been considered a part of the humanities.[^12] In modern academia, history can occasionally be classified as a [social science](https://en.wikipedia.org/wiki/Social_science "Social science"), though this definition is contested.

### Language

While the scientific study of language is known as [linguistics](https://en.wikipedia.org/wiki/Linguistics "Linguistics") and is generally considered a [social science](https://en.wikipedia.org/wiki/Social_science "Social science"),[^13] a [natural science](https://en.wikipedia.org/wiki/Natural_science "Natural science") [^14] or a [cognitive science](https://en.wikipedia.org/wiki/Cognitive_science "Cognitive science"),[^15] the study of languages is also central to the humanities. A good deal of twentieth- and twenty-first-century philosophy has been devoted to the analysis of language and to the question of whether, as [Wittgenstein](https://en.wikipedia.org/wiki/Wittgenstein "Wittgenstein") claimed, many of our philosophical confusions derive from the vocabulary we use; literary theory has explored the rhetorical, associative, and ordering features of language; and historical linguists have studied the development of languages across time. Literature, covering a variety of uses of language including [prose](https://en.wikipedia.org/wiki/Prose "Prose") forms (such as the [novel](https://en.wikipedia.org/wiki/Novel "Novel")), [poetry](https://en.wikipedia.org/wiki/Poetry "Poetry") and [drama](https://en.wikipedia.org/wiki/Drama "Drama"), also lies at the heart of the modern humanities curriculum. College-level programs in a foreign language usually include the study of important works of literature in that language, as well as the language itself.

### Law

![](https://en.wikipedia.org/wiki/File:Microcosm_of_London_Plate_058_-_Old_Bailey_edited.jpg)

A trial at a criminal court, the Old Bailey in London

In everyday language, [law](https://en.wikipedia.org/wiki/Law "Law") refers to a rule that is enforced by a governing institution, as opposed to a moral or ethical rule that is not subject to formal enforcement.[^16] The study of law can be seen as either a [social science](https://en.wikipedia.org/wiki/Social_science "Social science") or a humanities discipline, depending on one's perspective. Some see it as a social science because of its objective and measurable nature, while others view it as a humanities discipline because of its focus on values and interpretation. Law is not always enforceable, especially in the context of international relations. Law has been defined in various ways, such as "a system of rules",[^17] "an interpretive concept" for achieving justice,[^18] "an authority" to mediate between people's interests,[^19] or "the command of a sovereign" backed by the threat of punishment.[^20]

However one likes to think of law, it is a completely central social institution. The practical application of ideas from many social science and humanities disciplines, including philosophy, history, political science, economics, anthropology, and sociology, shapes legal policy. Law is [politics](https://en.wikipedia.org/wiki/Politics "Politics"), because politicians create it. Law is [philosophy](https://en.wikipedia.org/wiki/Philosophy "Philosophy"), because moral and ethical persuasions shape their ideas. Law tells many of history's stories, because statutes, case law, and codifications build up over time. Law is also economics, because any rule about [contract](https://en.wikipedia.org/wiki/Contract "Contract"), [tort](https://en.wikipedia.org/wiki/Tort "Tort"), [property law](https://en.wikipedia.org/wiki/Property_law "Property law"), [labour law](https://en.wikipedia.org/wiki/Labour_law "Labour law"), [company law](https://en.wikipedia.org/wiki/Company_law "Company law"), and many more can have long-lasting effects on how productivity is organised and the distribution of wealth. The noun *law* derives from the [Old English](https://en.wikipedia.org/wiki/Old_English_language "Old English language") *word lagu*, meaning something laid down or fixed,[^17] and the adjective *legal* comes from the Latin word *LEX*.[^18]

### Literature

![](https://en.wikipedia.org/wiki/File:First_Folio.jpg)

William Shakespeare authored some of the most acclaimed works in English literature.

Literature is a term that does not have a universally accepted definition, but which has variably included all written work; writing that possesses literary merit; and language that emphasizes its own literary features, as opposed to [ordinary language](https://en.wikipedia.org/wiki/Ordinary_language "Ordinary language"). [Etymologically](https://en.wikipedia.org/wiki/Etymology "Etymology") the term derives from the [Latin](https://en.wikipedia.org/wiki/Latin "Latin") word literatura */litteratura* which means "writing formed with letters", although some definitions include [spoken or sung texts](https://en.wikipedia.org/wiki/Oral_literature "Oral literature"). Literature can be classified as [fiction](https://en.wikipedia.org/wiki/Fiction "Fiction") or [non-fiction](https://en.wikipedia.org/wiki/Non-fiction "Non-fiction"); [poetry](https://en.wikipedia.org/wiki/Poetry "Poetry") or [prose](https://en.wikipedia.org/wiki/Prose "Prose"). It can be further distinguished according to major forms such as the [novel](https://en.wikipedia.org/wiki/Novel "Novel"), [short story](https://en.wikipedia.org/wiki/Short_story "Short story"), or [drama](https://en.wikipedia.org/wiki/Drama "Drama"). Works are often categorised according to historical periods or to their adherence to certain [aesthetic](https://en.wikipedia.org/wiki/Aesthetics "Aesthetics") features or expectations ([genre](https://en.wikipedia.org/wiki/Genre "Genre")).

### Philosophy

![](https://en.wikipedia.org/wiki/File:Kierkegaard.jpg)

The works of Søren Kierkegaard overlap into many fields of the humanities, such as philosophy, literature, theology, music, and classical studies.

Philosophy—etymologically, the "love of wisdom"—is generally the study of problems concerning matters such as existence, knowledge, justification, truth, justice, right and wrong, beauty, validity, mind, and language. Philosophy is distinguished from other ways of addressing these issues by its critical, generally systematic approach and its reliance on reasoned argument, rather than on experiments (with [experimental philosophy](https://en.wikipedia.org/wiki/Experimental_philosophy "Experimental philosophy") as an exception).[^19]

Philosophy used to be a very broad term, encompassing what have since become separate disciplines, such as [physics](https://en.wikipedia.org/wiki/Physics "Physics"). (As [Immanuel Kant](https://en.wikipedia.org/wiki/Immanuel_Kant "Immanuel Kant") noted, "Ancient Greek philosophy was divided into three sciences: physics, ethics, and logic.") [^20] Today, the main fields of philosophy are [logic](https://en.wikipedia.org/wiki/Logic "Logic"), [ethics](https://en.wikipedia.org/wiki/Ethics "Ethics"), [metaphysics](https://en.wikipedia.org/wiki/Metaphysics "Metaphysics"), and [epistemology](https://en.wikipedia.org/wiki/Epistemology "Epistemology"). Still, it overlaps with other disciplines. The field of [semantics](https://en.wikipedia.org/wiki/Semantics "Semantics"), for example, brings philosophy into contact with linguistics.

Since the early twentieth century, philosophy in English-speaking [universities](https://en.wikipedia.org/wiki/Universities "Universities") has moved away from the humanities and closer to the [formal sciences](https://en.wikipedia.org/wiki/Outline_of_formal_science "Outline of formal science"), becoming much more *analytic.* [Analytic philosophy](https://en.wikipedia.org/wiki/Analytic_philosophy "Analytic philosophy") is marked by emphasis on the use of logic and formal methods of reasoning, conceptual analysis, and the use of [symbolic](https://en.wikipedia.org/wiki/Symbolic_logic "Symbolic logic") and/or [mathematical logic](https://en.wikipedia.org/wiki/Mathematical_logic "Mathematical logic"), as contrasted with the [Continental style of philosophy](https://en.wikipedia.org/wiki/Continental_philosophy "Continental philosophy").[^21] This method of inquiry is largely indebted to the work of philosophers such as [Gottlob Frege](https://en.wikipedia.org/wiki/Gottlob_Frege "Gottlob Frege"), [Bertrand Russell](https://en.wikipedia.org/wiki/Bertrand_Russell "Bertrand Russell"), [G.E. Moore](https://en.wikipedia.org/wiki/G.E._Moore "G.E. Moore"), and [Ludwig Wittgenstein](https://en.wikipedia.org/wiki/Ludwig_Wittgenstein "Ludwig Wittgenstein").

### Religion

Based on current knowledge, it seems that all known cultures, both in the past and present, have some form of belief system or religious practice. While there may be isolated individuals or groups who do not practice any religion, it is unknown whether there has ever been a society entirely devoid of religious belief. The definition of religion is not universal, and different cultures may have different ideas about what constitutes religion. Religion may be characterized with a **community** since humans are [social animals](https://en.wikipedia.org/wiki/The_Social_Animal_\(Aronson_book\) "The Social Animal (Aronson book)").[^22] [^23] **[Rituals](https://en.wikipedia.org/wiki/Ritual "Ritual")** are used to bound the community together.[^24] [^25] Social animals require rules. **[Ethics](https://en.wikipedia.org/wiki/Ethics "Ethics")** is a requirement of society, but not a requirement of religion. Shinto, Daoism, and other folk or natural religions do not have ethical codes. While some religions do include the concept of deities, others do not. Therefore, the supernatural does not necessarily require the existence of deities. Rather, it can be broadly defined as any phenomenon that cannot be explained by science or reason.[^26] [^27] **[Magical thinking](https://en.wikipedia.org/wiki/Magical_thinking "Magical thinking")** creates explanations not available for empirical verification. **Stories** or [myths](https://en.wikipedia.org/wiki/Myth "Myth") are narratives being both didactic and entertaining.[^28] They are necessary for understanding the human predicament. Some other possible characteristics of religion are pollutions and purification,[^29] the sacred and the profane,[^30] sacred texts,[^31] religious institutions and organizations,[^32] [^33] and sacrifice and prayer. Some of the major problems that religions confront, and attempts to answer, are chaos, suffering, evil,[^34] and death.[^35]

The non-founder religions are [Hinduism](https://en.wikipedia.org/wiki/Hinduism "Hinduism"), [Shinto](https://en.wikipedia.org/wiki/Shinto "Shinto"), and [native or folk religions](https://en.wikipedia.org/wiki/Ethnic_religion "Ethnic religion"). Founder religions are [Judaism](https://en.wikipedia.org/wiki/Judaism "Judaism"), [Christianity](https://en.wikipedia.org/wiki/Christianity "Christianity"), [Islam](https://en.wikipedia.org/wiki/Islam "Islam"), [Confucianism](https://en.wikipedia.org/wiki/Confucianism "Confucianism"), [Daoism](https://en.wikipedia.org/wiki/Taoism "Taoism"), [Mormonism](https://en.wikipedia.org/wiki/Mormonism "Mormonism"), [Jainism](https://en.wikipedia.org/wiki/Jainism "Jainism"), [Zoroastrianism](https://en.wikipedia.org/wiki/Zoroastrianism "Zoroastrianism"), [Buddhism](https://en.wikipedia.org/wiki/Buddhism "Buddhism"), [Sikhism](https://en.wikipedia.org/wiki/Sikhism "Sikhism"), and the [Baháʼí Faith](https://en.wikipedia.org/wiki/Bah%C3%A1%CA%BC%C3%AD_Faith "Baháʼí Faith"). Religions must adapt over generations to remain relevant to their adherents. When traditional religions fail to address new concerns, then new religions will emerge.

### Performing arts

The [performing arts](https://en.wikipedia.org/wiki/Performing_art "Performing art") differ from the visual arts in that the former uses the artist's own body, face, and presence as a medium. The latter uses materials such as clay, metal, or paint, which can be molded or transformed to create a [work of art](https://en.wikipedia.org/wiki/Work_of_art "Work of art"). Performing arts include [acrobatics](https://en.wikipedia.org/wiki/Acrobatics "Acrobatics"), [comedy](https://en.wikipedia.org/wiki/Comedy "Comedy"), [dance](https://en.wikipedia.org/wiki/Dance "Dance"), [magic](https://en.wikipedia.org/wiki/Magic_\(illusion\) "Magic (illusion)"), [music](https://en.wikipedia.org/wiki/Music "Music"), [opera](https://en.wikipedia.org/wiki/Opera "Opera"), [juggling](https://en.wikipedia.org/wiki/Juggling "Juggling"), [marching arts](https://en.wikipedia.org/wiki/Marching_arts "Marching arts"), such as [brass bands](https://en.wikipedia.org/wiki/Brass_band "Brass band"), and [theatre](https://en.wikipedia.org/wiki/Theatre "Theatre").

Artists who participate in these arts in front of an audience are called performers, including actors, [comedians](https://en.wikipedia.org/wiki/Comedian "Comedian"), [dancers](https://en.wikipedia.org/wiki/Dancer "Dancer"), [musicians](https://en.wikipedia.org/wiki/Musician "Musician"), and [singers](https://en.wikipedia.org/wiki/Singer "Singer"). Performing arts are also supported by workers in related fields, such as [songwriting](https://en.wikipedia.org/wiki/Songwriting "Songwriting") and [stagecraft](https://en.wikipedia.org/wiki/Stagecraft "Stagecraft"). Performers often adapt their [appearance](https://en.wikipedia.org/wiki/Physical_appearance "Physical appearance"), such as through [costumes](https://en.wikipedia.org/wiki/Costume "Costume") and [stage makeup](https://en.wikipedia.org/wiki/Cosmetics "Cosmetics"). There is also a specialized form of [fine art](https://en.wikipedia.org/wiki/Fine_art "Fine art") in which the artists *perform* their work live to an audience. This is called [Performance art](https://en.wikipedia.org/wiki/Performance_art "Performance art"). Most performance art also involves some form of plastic art, perhaps in the creation of [props](https://en.wikipedia.org/wiki/Theatrical_property "Theatrical property"). Dance was often referred to as a *plastic art* during the [Modern dance](https://en.wikipedia.org/wiki/Modern_dance "Modern dance") era.

#### Musicology

![](https://en.wikipedia.org/wiki/File:Mozarteum_grosser_saal_buehne_mit_orchester.jpg)

A concert at Mozarteum University Salzburg in Salzburg, Austria

[Musicology](https://en.wikipedia.org/wiki/Musicology "Musicology") as an academic discipline can take several paths, including [historical musicology](https://en.wikipedia.org/wiki/Historical_musicology "Historical musicology"), music literature, [ethnomusicology](https://en.wikipedia.org/wiki/Ethnomusicology "Ethnomusicology"), and [music theory](https://en.wikipedia.org/wiki/Music_theory "Music theory"). Undergraduate music majors generally take courses in all of these areas, while graduate students focus on a particular path. In the [liberal arts](https://en.wikipedia.org/wiki/Liberal_arts "Liberal arts") tradition, musicology is also used to broaden the skills of non-musicians by teaching them skills such as concentration and listening.

#### Theatre

[Theatre](https://en.wikipedia.org/wiki/Theatre "Theatre") (or theater) (Greek "theatron", *θέατρον*) is the branch of the [performing arts](https://en.wikipedia.org/wiki/Performing_arts "Performing arts") concerned with [acting](https://en.wikipedia.org/wiki/Acting "Acting") out stories in front of an audience using combinations of speech, gesture, music, dance, sound and spectacle — indeed any one or more elements of the other performing arts. In addition to the standard narrative dialogue style, theatre takes such forms as [opera](https://en.wikipedia.org/wiki/Opera "Opera"), [ballet](https://en.wikipedia.org/wiki/Ballet "Ballet"), [mime](https://en.wikipedia.org/wiki/Mime_artist "Mime artist"), [kabuki](https://en.wikipedia.org/wiki/Kabuki "Kabuki"), [classical Indian dance](https://en.wikipedia.org/wiki/Classical_Indian_dance "Classical Indian dance"), [Chinese opera](https://en.wikipedia.org/wiki/Chinese_opera "Chinese opera"), [mummers' plays](https://en.wikipedia.org/wiki/Mummers'_play "Mummers' play"), and [pantomime](https://en.wikipedia.org/wiki/Pantomime "Pantomime").

#### Dance

[Dance](https://en.wikipedia.org/wiki/Dance "Dance") (from [Old French](https://en.wikipedia.org/wiki/Old_French "Old French") *dancier*, perhaps from [Frankish](https://en.wikipedia.org/wiki/Old_Frankish_language "Old Frankish language")) generally refers to human [movement](https://en.wikipedia.org/wiki/Motion_\(physics\) "Motion (physics)") either used as a form of [expression](https://en.wikipedia.org/wiki/Emotional_expression "Emotional expression") or presented in a [social](https://en.wikipedia.org/wiki/Social_environment "Social environment"), [spiritual](https://en.wikipedia.org/wiki/Spirituality "Spirituality") or [performance](https://en.wikipedia.org/wiki/Performance "Performance") setting. Dance is also used to describe methods of [non-verbal communication](https://en.wikipedia.org/wiki/Non-verbal_communication "Non-verbal communication") (see [body language](https://en.wikipedia.org/wiki/Body_language "Body language")) between humans or [animals](https://en.wikipedia.org/wiki/Animal "Animal") ([bee dance](https://en.wikipedia.org/wiki/Waggle_dance "Waggle dance"), mating dance), and [motion](https://en.wikipedia.org/wiki/Motion_\(physics\) "Motion (physics)") in inanimate objects (*the [leaves](https://en.wikipedia.org/wiki/Leaves "Leaves") danced in the [wind](https://en.wikipedia.org/wiki/Wind "Wind")*). [Choreography](https://en.wikipedia.org/wiki/Choreography "Choreography") is the process of creating dances, and the people who create choreography are known as choreographers. Choreographers use movement, [music](https://en.wikipedia.org/wiki/Music "Music"), and other elements to create expressive and artistic dances. They may work alone or with other artists to create new works, and their work can be presented in a variety of settings, from small dance studios to large theaters.

Definitions of what constitutes dance are dependent on [social](https://en.wikipedia.org/wiki/Society "Society"), [cultural](https://en.wikipedia.org/wiki/Culture "Culture"), [aesthetic](https://en.wikipedia.org/wiki/Aesthetic "Aesthetic"), [artistic](https://en.wikipedia.org/wiki/Artistic "Artistic"), and [moral](https://en.wikipedia.org/wiki/Moral "Moral") constraints and range from functional movement (such as [Folk dance](https://en.wikipedia.org/wiki/Folk_dance "Folk dance")) to codified, [virtuoso](https://en.wikipedia.org/wiki/Virtuoso "Virtuoso") techniques such as [ballet](https://en.wikipedia.org/wiki/Ballet "Ballet").

### Visual arts

#### History of visual arts

![](https://en.wikipedia.org/wiki/File:Quatrain_on_Heavenly_Mountain.jpg)

Quatrain on Heavenly Mountain by Emperor Gaozong (1107–1187) of Song dynasty; fan mounted as album leaf on silk, four columns in cursive script.

The great traditions in [art](https://en.wikipedia.org/wiki/Art "Art") have a foundation in the art of one of the ancient civilizations, such as [Ancient Japan](https://en.wikipedia.org/wiki/Ancient_Japan "Ancient Japan"), [Greece](https://en.wikipedia.org/wiki/Ancient_Greece "Ancient Greece") and [Rome](https://en.wikipedia.org/wiki/Ancient_Rome "Ancient Rome"), [China](https://en.wikipedia.org/wiki/China "China"), [India](https://en.wikipedia.org/wiki/Indus_Valley_civilisation "Indus Valley civilisation"), [Greater Nepal](https://en.wikipedia.org/wiki/Greater_Nepal "Greater Nepal"), [Mesopotamia](https://en.wikipedia.org/wiki/Mesopotamia "Mesopotamia") and [Mesoamerica](https://en.wikipedia.org/wiki/Mesoamerica "Mesoamerica").

Ancient Greek art saw a veneration of the human physical form and the development of equivalent skills to show musculature, poise, beauty, and anatomically correct proportions. [Ancient Roman](https://en.wikipedia.org/wiki/Roman_Empire "Roman Empire") art depicted gods as idealized humans, shown with characteristic distinguishing features (e.g., [Zeus](https://en.wikipedia.org/wiki/Zeus "Zeus") ' thunderbolt).[^36]

The emphasis on spiritual and religious themes in [Byzantine](https://en.wikipedia.org/wiki/Byzantine_Empire "Byzantine Empire") and [Gothic](https://en.wikipedia.org/wiki/Gothic_Revival_architecture "Gothic Revival architecture") art of the Middle Ages reflected the church's dominance. However, in the [Renaissance](https://en.wikipedia.org/wiki/Renaissance "Renaissance"), a renewed focus on the physical world was reflected in art forms that depicted the human body and landscape in a more naturalistic, three-dimensional manner.[^36]

[Eastern art](https://en.wikipedia.org/wiki/History_of_Asian_art "History of Asian art") has generally worked in a style akin to [Western medieval art](https://en.wikipedia.org/wiki/Medieval_art "Medieval art"), namely a concentration on surface patterning and local colour (meaning the plain colour of an object, such as basic red for a red robe, rather than the modulations of that colour brought about by light, shade and reflection). A characteristic of this style is that the local colour is often defined by an outline (a contemporary equivalent is the cartoon). This is evident, for example, in the art of India, Tibet, and Japan.

Religious [Islamic](https://en.wikipedia.org/wiki/Islam "Islam") art forbids iconography, and expresses religious ideas through geometry instead.[^37] The physical and rational certainties depicted by the 19th-century Enlightenment were shattered not only by discoveries of relativity by [Einstein](https://en.wikipedia.org/wiki/Albert_Einstein "Albert Einstein") [^38] and of unseen psychology by [Freud](https://en.wikipedia.org/wiki/Sigmund_Freud "Sigmund Freud"),[^39] but also by unprecedented technological development. Increasing [global](https://en.wikipedia.org/wiki/Globalization "Globalization") interaction during this time led to a comparable influence of other cultures on Western art.

#### Media types

##### Drawing

[Drawing](https://en.wikipedia.org/wiki/Drawing "Drawing") is a means of making a [picture](https://en.wikipedia.org/wiki/Image "Image"), using a wide variety of tools and techniques. It generally involves making marks on a surface by applying pressure with a tool or moving it across the surface. Common tools are graphite [pencils](https://en.wikipedia.org/wiki/Pencil "Pencil"), [pen and ink](https://en.wikipedia.org/wiki/Pen_and_ink "Pen and ink"), [inked](https://en.wikipedia.org/wiki/Ink "Ink") [brushes](https://en.wikipedia.org/wiki/Brush "Brush"), wax [color pencils](https://en.wikipedia.org/wiki/Color_pencil "Color pencil"), [crayons](https://en.wikipedia.org/wiki/Crayon "Crayon"), [charcoals](https://en.wikipedia.org/wiki/Charcoal "Charcoal"), [pastels](https://en.wikipedia.org/wiki/Pastel "Pastel"), and [markers](https://en.wikipedia.org/wiki/Marker_pen "Marker pen"). Digital tools that simulate these effects are also used. The main techniques used in drawing are: line drawing, [hatching](https://en.wikipedia.org/wiki/Hatching "Hatching"), crosshatching, random hatching, scribbling, [stippling](https://en.wikipedia.org/wiki/Stippling "Stippling"), and blending. A computer-aided designer who excels in [technical drawing](https://en.wikipedia.org/wiki/Technical_drawing "Technical drawing") is referred to as a *draftsman* or *draughtsman*.

##### Painting

![](https://en.wikipedia.org/wiki/File:Mona_Lisa,_by_Leonardo_da_Vinci,_from_C2RMF_retouched.jpg)

Mona Lisa, by Leonardo da Vinci, is one of the most recognizable artistic paintings in the world.

Literally, [painting](https://en.wikipedia.org/wiki/Painting "Painting") is the practice of applying [pigment](https://en.wikipedia.org/wiki/Pigment "Pigment") suspended in a carrier (or [medium](https://en.wikipedia.org/wiki/Paint#Components "Paint")) and a binding agent (a [glue](https://en.wikipedia.org/wiki/Adhesive "Adhesive")) to a surface (support) such as [paper](https://en.wikipedia.org/wiki/Paper "Paper"), [canvas](https://en.wikipedia.org/wiki/Canvas "Canvas") or a wall. However, when used in an artistic sense, it means the use of this activity in combination with [drawing](https://en.wikipedia.org/wiki/Drawing "Drawing"), [composition](https://en.wikipedia.org/wiki/Composition_\(visual_arts\) "Composition (visual arts)"), and other aesthetic considerations to manifest the expressive and conceptual intention of the practitioner. Painting has been used throughout history to express spiritual and religious ideas, from mythological scenes on pottery to the frescoes of the [Sistine Chapel](https://en.wikipedia.org/wiki/Sistine_Chapel "Sistine Chapel"), to body art.

Colour is highly subjective but has observable psychological effects that can differ from one culture to the next. Black is associated with mourning in the West, but elsewhere, white may be. Some painters, theoreticians, writers and scientists, including [Goethe](https://en.wikipedia.org/wiki/Goethe "Goethe"), [Kandinsky](https://en.wikipedia.org/wiki/Wassily_Kandinsky "Wassily Kandinsky"), [Isaac Newton](https://en.wikipedia.org/wiki/Isaac_Newton "Isaac Newton"), have written their own [colour theories](https://en.wikipedia.org/wiki/Colour_theory "Colour theory"). Moreover, the use of language is only a generalization for a colour equivalent. The word " [red](https://en.wikipedia.org/wiki/Red "Red") ", for example, can cover a wide range of variations on the pure red of the spectrum. Unlike music, where notes such as C or C# are universally accepted, there is no formalized register of colors. However, the [Pantone](https://en.wikipedia.org/wiki/Pantone "Pantone") system is widely used in the printing and design industry to standardize color reproduction.

Modern artists have extended the practice of painting considerably to include, for example, [collage](https://en.wikipedia.org/wiki/Collage "Collage"). This began with [cubism](https://en.wikipedia.org/wiki/Cubism "Cubism") and is not painting in a strict sense. Some modern painters incorporate different materials such as [sand](https://en.wikipedia.org/wiki/Sand "Sand"), [cement](https://en.wikipedia.org/wiki/Cement "Cement"), [straw](https://en.wikipedia.org/wiki/Straw "Straw") or [wood](https://en.wikipedia.org/wiki/Wood "Wood") for their texture. Examples of these are the works of [Jean Dubuffet](https://en.wikipedia.org/wiki/Jean_Dubuffet "Jean Dubuffet") or [Anselm Kiefer](https://en.wikipedia.org/wiki/Anselm_Kiefer "Anselm Kiefer"). Modern and contemporary art has moved away from the historic value of craft in favour of [concept](https://en.wikipedia.org/wiki/Concept "Concept") ([conceptual art](https://en.wikipedia.org/wiki/Conceptual_art "Conceptual art")); this has led some e.g., [Joseph Kosuth](https://en.wikipedia.org/wiki/Joseph_Kosuth "Joseph Kosuth") to say that painting, as a serious art form, is dead, although this has not deterred the majority of artists from continuing to practise it either as whole or part of their work.

[Sculpture](https://en.wikipedia.org/wiki/Sculpture "Sculpture") involves creating three-dimensional forms out of various materials. These typically include malleable substances like clay and metal, but may also extend to materials that are cut or shaved into the desired form, such as stone and wood.

## History of humanities

In the West, the history of the humanities can be traced to ancient Greece, where they formed the basis of a broad education for citizens.[^40] During Roman times, the concept of the seven [liberal arts](https://en.wikipedia.org/wiki/Liberal_arts "Liberal arts") evolved, involving [grammar](https://en.wikipedia.org/wiki/Grammar "Grammar"), [rhetoric](https://en.wikipedia.org/wiki/Rhetoric "Rhetoric") and [logic](https://en.wikipedia.org/wiki/Logic "Logic") (the [trivium](https://en.wikipedia.org/wiki/Trivium_\(education\) "Trivium (education)")), along with [arithmetic](https://en.wikipedia.org/wiki/Arithmetic "Arithmetic"), [geometry](https://en.wikipedia.org/wiki/Geometry "Geometry"), [astronomy](https://en.wikipedia.org/wiki/Astrology_and_astronomy "Astrology and astronomy") and [music](https://en.wikipedia.org/wiki/Music "Music") (the [quadrivium](https://en.wikipedia.org/wiki/Quadrivium "Quadrivium")).[^41] These subjects formed the bulk of [medieval](https://en.wikipedia.org/wiki/Medieval "Medieval") education, with the emphasis being on the humanities as skills or "ways of doing".

A major shift occurred with the [Renaissance humanism](https://en.wikipedia.org/wiki/Renaissance_humanism "Renaissance humanism") of the fifteenth century, when the humanities began to be regarded as subjects to study rather than practice, with a corresponding shift away from traditional fields into areas such as literature and history (*studia humaniora*). In the 20th century, this view was in turn challenged by the [postmodernist](https://en.wikipedia.org/wiki/Postmodernism "Postmodernism") movement, which sought to redefine the humanities in more [egalitarian](https://en.wikipedia.org/wiki/Egalitarianism "Egalitarianism") terms suitable for a [democratic](https://en.wikipedia.org/wiki/Democracy "Democracy") society since the Greek and Roman societies in which the humanities originated were elitist and aristocratic.[^42]

In China, the classical period from around 551 BCE to 220 CE had different categories of learning. One of these was the Four Branches, a traditional system for organizing written knowledge such as classical texts, present before scholarship was divided into the modern humanities disciplines. Another is known as the Six Arts, which includes a set of skills: ritual, music, archery, charioteering, writing, and mathematics. Although these don't fit the definition of humanities today, since then, humanities were officially recognized in the late 19th century. The modern university disciplines were established through multiple education reforms that took inspiration from Western and Japanese models.[^43]

A distinction is usually drawn between the [social sciences](https://en.wikipedia.org/wiki/Social_science "Social science") and the humanities. Classicist [Allan Bloom](https://en.wikipedia.org/wiki/Allan_Bloom "Allan Bloom") writes in *[The Closing of the American Mind](https://en.wikipedia.org/wiki/The_Closing_of_the_American_Mind "The Closing of the American Mind")* (1987):

> Social science and humanities have a mutual contempt for one another, the former looking down on the latter as unscientific, the latter regarding the former as [philistine](https://en.wikipedia.org/wiki/Philistinism "Philistinism"). \[…\] The difference comes down to the fact that social science really wants to be predictive, meaning that man is predictable, while the humanities say that he is not.[^44]

## Today

### Education and employment

For many decades, there has been a growing public perception that a humanities education inadequately prepares graduates for employment.[^45] The common belief is that graduates from such programs face underemployment and that incomes are too low for a humanities education to be worth the investment.[^46]

Humanities graduates find employment in a wide variety of management and professional occupations. In Britain, for example, over 11,000 humanities majors found employment in the following occupations:[^47]

- Education (25.8%)
- Management (19.8%)
- Media/literature/arts (11.4%)
- Law (11.3%)
- Finance (10.4%)
- Civil service (5.8%)
- Not-for-profit (5.2%)
- Marketing (2.3%)
- Medicine (1.7%)
- Other (6.4%)

Many humanities graduates may find themselves with no specific career goals upon graduation, which can lead to lower incomes in the early stages of their careers. On the other hand, graduates from more career-oriented programs often find jobs more quickly. However, the long-term career prospects of humanities graduates may be similar to those of other graduates, as research shows that by five years after graduation, they generally find a career path that appeals to them.[^48] [^49]

There is empirical evidence that graduates from humanities programs earn less than graduates from other university programs.[^50] [^51] [^52] However, the empirical evidence also shows that humanities graduates still earn notably higher incomes than workers with no postsecondary education, and have job satisfaction levels comparable to their peers from other fields.[^53] Humanities graduates also earn more as their careers progress; ten years after graduation, the income difference between humanities graduates and graduates from other university programs is no longer statistically significant.[^54] Humanities graduates can boost their incomes if they obtain advanced or professional degrees.[^55] [^56]

Humanities majors are sought after in many areas of business, specifically for their critical thinking and problem-solving skills.[^57] Research has shown that humanities majors are especially adept at "soft skills" such as "written and oral communication, creative problem-solving, teamwork, decision-making, self-management, and critical analysis".[^58]

### In the United States

#### The Humanities Indicators

The [Humanities Indicators](https://en.wikipedia.org/wiki/Humanities_Indicators "Humanities Indicators"), unveiled in 2009 by the [American Academy of Arts and Sciences](https://en.wikipedia.org/wiki/American_Academy_of_Arts_and_Sciences "American Academy of Arts and Sciences"), are the first comprehensive compilation of data about the humanities in the United States, providing scholars, policymakers and the public with detailed information on humanities education from primary to higher education, the humanities workforce, humanities funding and research, and public humanities activities.[^59] [^60] Modeled after the National Science Board's Science and Engineering Indicators, Humanities Indicators are a source of reliable benchmarks to guide analysis of the state of the humanities in the United States.

#### The Humanities in American Life

The 1980 United States Rockefeller Commission on the Humanities described the humanities in its report "The Humanities in American Life":

> Through the humanities we reflect on the fundamental question: What does it mean to be human? The humanities offer clues but never a complete answer. They reveal how people have tried to make moral, spiritual, and intellectual sense of a world where irrationality, despair, loneliness, and death are as conspicuous as birth, friendship, hope, and reason.

#### In liberal arts education

[The Commission on the Humanities and Social Sciences](https://en.wikipedia.org/wiki/The_Commission_on_the_Humanities_and_Social_Sciences "The Commission on the Humanities and Social Sciences") 2013 report, "The Heart of the Matter", supports the notion of a broad " [liberal arts education](https://en.wikipedia.org/wiki/Liberal_arts_colleges "Liberal arts colleges") " that includes study in disciplines ranging from the natural sciences to the arts and the humanities.[^61] [^62]

Many [colleges](https://en.wikipedia.org/wiki/Colleges "Colleges") provide such an education; some require it. The [University of Chicago](https://en.wikipedia.org/wiki/University_of_Chicago "University of Chicago") and [Columbia University](https://en.wikipedia.org/wiki/Columbia_University "Columbia University") were among the first schools to require an extensive [core curriculum](https://en.wikipedia.org/wiki/Core_curriculum "Core curriculum") in philosophy, literature, and the arts for all students.[^63] Other colleges with nationally recognized, mandatory programs in the liberal arts are [Fordham University](https://en.wikipedia.org/wiki/Fordham_University "Fordham University"), [St. John's College](https://en.wikipedia.org/wiki/St._John's_College_\(Annapolis/Santa_Fe\) "St. John's College (Annapolis/Santa Fe)"), [Saint Anselm College](https://en.wikipedia.org/wiki/Saint_Anselm_College "Saint Anselm College") and [Providence College](https://en.wikipedia.org/wiki/Providence_College "Providence College"). Prominent proponents of liberal arts in the United States have included [Mortimer J. Adler](https://en.wikipedia.org/wiki/Mortimer_J._Adler "Mortimer J. Adler") [^64] and [E. D. Hirsch, Jr.](https://en.wikipedia.org/wiki/E._D._Hirsch,_Jr. "E. D. Hirsch, Jr.")

#### As a major

In 1950, 1.2% of Americans aged 22 had earned a degree in the humanities. By 2010, this figure had risen to 2.6%. This represents a doubling of the number of Americans with degrees in the humanities over a 60-year period.[^65] The increase in the number of Americans with humanities degrees is in part due to the overall rise in college enrollment in the United States. In 1940, 4.6% of Americans had a four-year degree, but by 2016, this figure had risen to 33.4%. This means that the total number of Americans with college degrees has increased significantly, resulting in a greater number of people with degrees in the humanities as well.[^66] The proportion of degrees awarded in the humanities has declined in recent decades, even as the overall number of people with humanities degrees has increased. In 1954, 36% of Harvard undergraduates majored in the humanities, but in 2012, only 20% did so.[^67] As recently as 1993, the humanities accounted for 15% of the bachelor's degrees awarded by colleges and universities in the United States. As of 2022, they accounted for less than 9%.[^68]

#### In the Digital Age

Computing has been intersecting with the humanities since 1946, but it took until the 90s for technology to become particularly useful in this department through increased storage and processing capabilities.[^69] Now, researchers in the humanities have developed numerous large- and small-scale digital corporations, such as digitized libraries and collections of historical texts, along with digital tools and methods for analyzing them. Their aim is both to uncover new knowledge and to visualize research data in new and revealing ways. Much of this activity occurs in a field called the [digital humanities](https://en.wikipedia.org/wiki/Digital_humanities "Digital humanities").

#### STEM

Politicians in the United States currently espouse a need for increased funding of the [STEM fields](https://en.wikipedia.org/wiki/STEM_fields "STEM fields"), science, technology, engineering, and mathematics.[^70] Federal funding represents a much smaller fraction of funding for the humanities than other fields, such as STEM or medicine.[^71] The result was a decline in quality in both college and pre-college education in the humanities field.[^71]

Three-term Louisiana Governor [Edwin Edwards](https://en.wikipedia.org/wiki/Edwin_Edwards "Edwin Edwards") acknowledged the importance of the humanities in a 2014 video address [^72] to the academic conference "Revolutions in Eighteenth-Century Sociability",[^73] Edwards said:[^74]

> Without the humanities to teach us how history has succeeded or failed in directing the fruits of technology and science to the betterment of our tribe of *homo sapiens*, without the humanities to teach us how to frame the discussion and to properly debate the uses-and the costs-of technology, without the humanities to teach us how to safely debate how to create a more just society with our fellow man and woman, technology and science would eventually default to the ownership of—and misuse by—the most influential, the most powerful, the most feared among us.

### In Europe

#### The value of the humanities debate

The contemporary debate in the field of [critical university studies](https://en.wikipedia.org/wiki/Critical_university_studies "Critical university studies") centers around the declining value of the humanities.[^75] [^7] As in America, there is a perceived decline in interest within higher education policy in research that is qualitative and does not produce marketable products. This threat can be seen in a variety of forms across Europe, but much critical attention has been paid to research assessment in particular. For example, the UK \[Research Excellence Framework\] has been subject to criticism due to its assessment criteria from across the humanities and, indeed, the social sciences.[^76] In particular, the notion of "impact" has generated significant debate.[^77]

## Philosophical history

### Citizenship and self-reflection

Since the late 19th century, a central justification for the humanities has been that they aid and encourage self-reflection—a self-reflection that, in turn, helps develop personal consciousness or an active sense of civic duty.

[Wilhelm Dilthey](https://en.wikipedia.org/wiki/Wilhelm_Dilthey "Wilhelm Dilthey") and [Hans-Georg Gadamer](https://en.wikipedia.org/wiki/Gadamer "Gadamer") centered the humanities' attempt to distinguish itself from the natural sciences in [humankind](https://en.wikipedia.org/wiki/Humankind "Humankind") 's urge to understand its own experiences. This understanding, they claimed, ties like-minded people from similar cultural backgrounds together and provides a sense of cultural continuity with the philosophical past.[^78]

Scholars in the late 20th and early 21st centuries extended that "narrative imagination" [^79] to the ability to understand the records of lived experiences outside of one's own individual social and cultural context. Through that narrative [imagination](https://en.wikipedia.org/wiki/Imagination "Imagination"), it is claimed, humanities scholars and students develop a [conscience](https://en.wikipedia.org/wiki/Conscience "Conscience") more suited to the multicultural world we live in.[^9] That conscience might take the form of a passive one that allows more effective [self-reflection](https://en.wikipedia.org/wiki/Self-reflection "Self-reflection") [^80] or extend into active empathy that facilitates the dispensation of civic duties a responsible world citizen must engage in.[^9] There is disagreement, however, on the level of influence humanities study can have on an individual and whether or not the understanding produced in humanistic enterprise can guarantee an "identifiable positive effect on people".[^81]

### Humanistic theories and practices

There are three major branches of knowledge: [natural sciences](https://en.wikipedia.org/wiki/Natural_sciences "Natural sciences"), [social sciences](https://en.wikipedia.org/wiki/Social_sciences "Social sciences"), and the humanities. [Technology](https://en.wikipedia.org/wiki/Technology "Technology") is the practical extension of the natural sciences, as [politics](https://en.wikipedia.org/wiki/Politics "Politics") is the extension of the social sciences. Similarly, the humanities have their own practical extension, sometimes called "transformative humanities" (transhumanities) or "culturonics" ([Mikhail Epstein](https://en.wikipedia.org/wiki/Mikhail_Epstein "Mikhail Epstein") 's term):

- Nature – natural sciences – technology – transformation of nature
- Society – social sciences – politics – transformation of society
- Culture – [human sciences](https://en.wikipedia.org/wiki/Human_sciences "Human sciences") – culturonics – transformation of culture [^8]

Technology, politics, and culturonics are designed to transform what their respective disciplines study: nature, society, and culture. The field of transformative humanities includes various practicies and technologies, for example, [language planning](https://en.wikipedia.org/wiki/Language_planning "Language planning"), the construction of new languages, like [Esperanto](https://en.wikipedia.org/wiki/Esperanto "Esperanto"), and invention of new artistic and literary genres and movements in the genre of [manifesto](https://en.wikipedia.org/wiki/Manifesto "Manifesto"), like [Romanticism](https://en.wikipedia.org/wiki/Romanticism "Romanticism"), [Symbolism](https://en.wikipedia.org/wiki/Symbolism_\(arts\) "Symbolism (arts)"), or [Surrealism](https://en.wikipedia.org/wiki/Surrealism "Surrealism").

### Truth and meaning

The divide between humanistic study and the natural sciences also informs arguments about meaning in the humanities. What distinguishes the humanities from the [natural sciences](https://en.wikipedia.org/wiki/Natural_science "Natural science") is not a certain subject matter, but rather the mode of approach to any question. The humanities focus on understanding meaning, purpose, and goals, and further the appreciation of singular historical and social phenomena—an interpretive method of finding "truth"—rather than explaining the causality of events or uncovering the truth of the natural world.[^82] Apart from its societal application, narrative imagination is an important tool in the (re)production of understood meaning in history, culture, and literature.

Imagination, as part of the toolkit of artists or scholars, helps create meaning that invokes a response from an audience. Since a humanities scholar is always within the [nexus](https://en.wiktionary.org/wiki/nexus "wikt:nexus") of lived experiences, no "absolute" knowledge is theoretically possible; knowledge is instead a ceaseless procedure of inventing and reinventing the context a text is read in. [Poststructuralism](https://en.wikipedia.org/wiki/Poststructuralism "Poststructuralism") has problematized an approach to the humanistic study based on questions of meaning, intentionality, and authorship. In the wake of [the death of the author](https://en.wikipedia.org/wiki/Death_of_the_author "Death of the author") proclaimed by [Roland Barthes](https://en.wikipedia.org/wiki/Barthes "Barthes"), various theoretical currents such as [deconstruction](https://en.wikipedia.org/wiki/Deconstruction "Deconstruction") and [discourse](https://en.wikipedia.org/wiki/Discourse "Discourse") analysis seek to expose the ideologies and rhetoric operative in producing both the purportedly meaningful objects and the [hermeneutic](https://en.wikipedia.org/wiki/Hermeneutic "Hermeneutic") subjects of humanistic study. This exposure has opened up the interpretive structures of the humanities to criticism that humanities scholarship is "unscientific" and therefore unfit for inclusion in modern university curricula because of the very nature of its changing contextual meaning.

### Pleasure, the pursuit of knowledge and scholarship

Some, like [Stanley Fish](https://en.wikipedia.org/wiki/Stanley_Fish "Stanley Fish"), have claimed that the humanities can defend themselves best by refusing to make any claims of utility.[^83] (Fish may well be thinking primarily of literary study, rather than history and philosophy.) Any attempt to justify the humanities in terms of external benefits, such as social usefulness (say, increased productivity), or in terms of ennobling effects on the individual (such as greater wisdom or diminished prejudice) is, according to Fish, ungrounded and places impossible demands on the relevant academic departments. Furthermore, [critical thinking](https://en.wikipedia.org/wiki/Critical_thinking "Critical thinking"), while arguably a result of humanistic training, can be acquired in other contexts.[^84] And the humanities do not even provide any more the kind of social cachet (what sociologists sometimes call " [cultural capital](https://en.wikipedia.org/wiki/Cultural_capital "Cultural capital") ") that was helpful to succeed in Western society before the age of mass education following World War II.

Instead, scholars like Fish suggest that the humanities offer a unique kind of pleasure, a pleasure based on the common pursuit of knowledge (even if it is only disciplinary knowledge). Such pleasure contrasts with the increasing privatization of leisure and the instant gratification characteristic of Western culture; it thus meets [Jürgen Habermas](https://en.wikipedia.org/wiki/J%C3%BCrgen_Habermas "Jürgen Habermas") 's requirements of disregarding social status and of the rational problematization of previously unquestioned areas, which are necessary for an endeavor that takes place in the bourgeois [public sphere](https://en.wikipedia.org/wiki/Public_sphere "Public sphere"). In this argument, then, only the academic pursuit of pleasure can provide a link between the private and the public realm in modern Western consumer society and strengthen that public sphere that, according to many theorists, is the foundation for modern democracy.

Others, like [Mark Bauerlein](https://en.wikipedia.org/wiki/Mark_Bauerlein "Mark Bauerlein"), argue that professors in the humanities have increasingly abandoned proven methods of [epistemology](https://en.wikipedia.org/wiki/Epistemology "Epistemology") (*I care only about the quality of your arguments, not your conclusions.*) in favor of [indoctrination](https://en.wikipedia.org/wiki/Indoctrination "Indoctrination") (*I care only about your conclusions, not the quality of your arguments.*). The result is that professors and their students adhere rigidly to a limited set of viewpoints and have little interest in or understanding of opposing viewpoints. Once they obtain this intellectual self-satisfaction, persistent lapses in learning, research, and evaluation are common.[^85]

### Romanticization and rejection

Implicit in many of these arguments supporting the humanities are the makings of arguments against public support of the humanities. [Joseph Carroll](https://en.wikipedia.org/wiki/Joseph_Carroll_\(scholar\) "Joseph Carroll (scholar)") asserts that we live in a changing world, a world where "cultural capital" is replaced with *[scientific literacy](https://en.wikipedia.org/wiki/Scientific_literacy "Scientific literacy")*, and in which the romantic notion of a Renaissance humanities scholar is obsolete. Such arguments appeal to judgments and anxieties about the essential uselessness of the humanities, especially in an age when it is seemingly vitally important for scholars of literature, history, and the arts to engage in "collaborative work with experimental scientists or even simply to make "intelligent use of the findings from empirical science." [^86]

Despite many humanities-based arguments against the humanities, some within the exact sciences have called for their return. In 2017, Science popularizer [Bill Nye](https://en.wikipedia.org/wiki/Bill_Nye "Bill Nye") retracted previous claims about the supposed 'uselessness' of philosophy. As Bill Nye states, "People allude to Socrates and Plato and Aristotle all the time, and I think many of us who make those references don't have a solid grounding," he said. "It's good to know the history of philosophy." [^87] Scholars, such as biologist [Scott F. Gilbert](https://en.wikipedia.org/wiki/Scott_F._Gilbert "Scott F. Gilbert"), make the claim that it is in fact the increasing predominance, leading to exclusivity, of scientific ways of thinking that need to be tempered by historical and social context. Gilbert worries that the commercialization inherent in some ways of conceiving of science (the pursuit of funding, academic prestige, etc.) needs to be examined from the outside. Gilbert argues:

> First of all, there is a very successful alternative to science as a commercialized march to 'progress.' This is the approach taken by the liberal arts college, a model that takes pride in seeing science in context and in integrating science with the humanities and social sciences.[^88]

[^1]: "Humanity" 2.b, *Oxford English Dictionary*, 3rd ed. (2003).

[^2]: ["Humanities Studies | What Are The Humanities Subjects | AMACAD"](https://web.archive.org/web/20240904220304/https://www.amacad.org/humanities-indicators/scope-of-humanities). *www.amacad.org*. Archived from [the original](https://www.amacad.org/humanities-indicators/scope-of-humanities) on 2024-09-04. Retrieved 2025-01-28.

[^3]: ["humanism"](https://www.britannica.com/EBchecked/topic/275932/humanism). Encyclopædia Britannica Online. 11 Apr. 2012. [Archived](https://web.archive.org/web/20150605043400/http://www.britannica.com/EBchecked/topic/275932/humanism) 2015-06-05 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine").

[^4]: ["Humanist"](http://oed.com/viewdictionaryentry/Entry/89273), Oxford English Dictionary. [Archived](https://web.archive.org/web/20200616034110/https://oed.com/start;jsessionid=C09401B8C0D601AEA8C2CFCB5E8FF5D4?authRejection=true&url=%2Fviewdictionaryentry%2FEntry%2F89273) 2020-06-16 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine").

[^5]: Windelband, Wilhelm (1998). ["History and Natural Science"](https://journals.sagepub.com/doi/10.1177/0959354398081001). *Theory & Psychology*. **8** (1): 5–22. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/0959354398081001](https://doi.org/10.1177%2F0959354398081001). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0959-3543](https://search.worldcat.org/issn/0959-3543).

[^6]: Leavy, Patricia, ed. (2020). *The Oxford handbook of qualitative research*. Oxford handbooks (2nd ed.). New York, NY: Oxford University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-084738-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-084738-8 "Special:BookSources/978-0-19-084738-8").

[^7]: [Helen Small](https://en.wikipedia.org/wiki/Helen_Small "Helen Small"), "The Value of the Humanities"(Oxford University Press 2013)

[^8]: Mikhail Epstein. *The Transformative Humanities: A Manifesto*. New York and London: Bloomsbury Academic, 2012, p.12

[^9]: [Nussbaum, Martha](https://en.wikipedia.org/wiki/Martha_Nussbaum "Martha Nussbaum"). *[Cultivating Humanity](https://en.wikipedia.org/wiki/Martha_Nussbaum#Cultivating_Humanity "Martha Nussbaum")*.

[^10]: Macey, David (2004-12-02). [*The Penguin Dictionary of Critical Theory*](https://www.penguin.co.uk/books/38271/the-penguin-dictionary-of-critical-theory-by-david-macey/9780140513691).

[^11]: ["What is History? How do Historians study the past as contrasted with Non-historians?"](https://www.valdosta.edu/history/documents/what-is-history.pdf) (PDF). *valdosta.edu*. Retrieved June 29, 2025.

[^12]: ["Humanities | Description, History, Meaning, & Facts | Britannica"](https://www.britannica.com/topic/humanities). *www.britannica.com*. 2025-05-17. Retrieved 2025-06-29.

[^13]: ["Social Science Majors, University of Saskatchewan"](https://web.archive.org/web/20150906113657/http://artsandscience.usask.ca/arts-science/socialsciences.php). Archived from [the original](http://artsandscience.usask.ca/arts-science/socialsciences.php) on 2015-09-06. Retrieved 2016-02-06.

[^14]: Boeckx, Cedric. ["Language as a Natural Object; Linguistics as a Natural Science"](https://web.archive.org/web/20100723173105/http://dingo.sbs.arizona.edu/~massimo/publications/PDF/BoeckxMPPLingReview2005.pdf) (PDF). Archived from [the original](http://www.dingo.sbs.arizona.edu/~massimo/publications/PDF/BoeckxMPPLingReview2005.pdf) (PDF) on 2010-07-23.

[^15]: Thagard, Paul, [Cognitive Science](http://plato.stanford.edu/archives/fall2008/entries/cognitive-science/) [Archived](https://web.archive.org/web/20180715135221/http://plato.stanford.edu/archives/fall2008/entries/cognitive-science/) 2018-07-15 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine"), The Stanford Encyclopedia of Philosophy (Fall 2008 Edition), Edward N. Zalta (ed.).

[^16]: [Robertson, Geoffrey](https://en.wikipedia.org/wiki/Geoffrey_Robertson "Geoffrey Robertson") (2006). *Crimes Against Humanity*. Penguin. p. 90. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-14-102463-9](https://en.wikipedia.org/wiki/Special:BookSources/978-0-14-102463-9 "Special:BookSources/978-0-14-102463-9").

[^17]: 

[^18]: ["Merriam-Webster's Dictionary"](http://www.m-w.com/dictionary/legal). [Archived](https://web.archive.org/web/20071230025618/http://www.m-w.com/dictionary/legal) from the original on 2007-12-30. Retrieved 2007-08-14.

[^19]: Thomas Nagel (1987). *What Does It All Mean? A Very Short Introduction to Philosophy*. Oxford University Press, pp. 4–5.

[^20]: Kant, Immanuel (1785). *Groundwork of the Metaphysic of Morals*, the first line.

[^21]: See, e.g., Brian Leiter "'Analytic' philosophy today names a style of doing philosophy, not a philosophical program or a set of substantive views. Analytic philosophers, crudely speaking, aim for argumentative clarity and precision; draw freely on the tools of logic; and often identify, professionally and intellectually, more closely with the sciences and mathematics than with the humanities."

[^22]: Aristotle (1941). *Politica*. New York: Oxford. pp. 1253a.

[^23]: Berger, Peter (1969). *The Sacred Canopy*. New York: Doubleday and Company. p. 7. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0385073059](https://en.wikipedia.org/wiki/Special:BookSources/978-0385073059 "Special:BookSources/978-0385073059").

[^24]: Stephenson, Barry (2015). *Rituals*. New York: Oxford. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0199943524](https://en.wikipedia.org/wiki/Special:BookSources/978-0199943524 "Special:BookSources/978-0199943524").

[^25]: Bell, Catherine (2009). *Ritual*. New York: Oxford. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0199735105](https://en.wikipedia.org/wiki/Special:BookSources/978-0199735105 "Special:BookSources/978-0199735105").

[^26]: Hood, Bruce (2010). *The Science of Superstition*. New York: HarperOne. pp. xii. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0061452659](https://en.wikipedia.org/wiki/Special:BookSources/978-0061452659 "Special:BookSources/978-0061452659").

[^27]: Bowie, Fiona (2000-02-29). *The Anthropology of Religion: An Introduction*. Malden, Mass.: Wiley-Blackwell. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-631-20848-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-631-20848-8 "Special:BookSources/978-0-631-20848-8").

[^28]: Segal, Robert (2015). *Myth*. New York: Oxford. p. 3. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0198724704](https://en.wikipedia.org/wiki/Special:BookSources/978-0198724704 "Special:BookSources/978-0198724704").

[^29]: Douglas, Mary (2002). *Purity and Danger*. London and New York: Routledge. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0415289955](https://en.wikipedia.org/wiki/Special:BookSources/978-0415289955 "Special:BookSources/978-0415289955").

[^30]: Eliade, Mircea (1959). *The Sacred and the Profane*. New York: Harvest.

[^31]: Coward, Harold (1988). *Sacred Word and Sacred Text*. Maryknoll, NY: Orbis Books. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0883446041](https://en.wikipedia.org/wiki/Special:BookSources/978-0883446041 "Special:BookSources/978-0883446041").

[^32]: Berger, Peter (1990). *The Sacred Canopy*. New York: Anchor. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0385073059](https://en.wikipedia.org/wiki/Special:BookSources/978-0385073059 "Special:BookSources/978-0385073059").

[^33]: McGuire, Meredith (2002). *Religion: The Social Context*. Belmont, CA: Wadsworth. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-534-54126-7](https://en.wikipedia.org/wiki/Special:BookSources/0-534-54126-7 "Special:BookSources/0-534-54126-7").

[^34]: Kelly, Joseph (1989). *The Problem of Evil in the Western Tradition*. Collegeville, Minnesota: Liturgical Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [0-8146-5104-6](https://en.wikipedia.org/wiki/Special:BookSources/0-8146-5104-6 "Special:BookSources/0-8146-5104-6").

[^35]: Becker, Ernest (2009), *The denial of death*, Macmillan, pp. ix, [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0029023105](https://en.wikipedia.org/wiki/Special:BookSources/978-0029023105 "Special:BookSources/978-0029023105")

[^36]: Janson, Horst Woldemar; Janson, Anthony F. (2004). [*History of Art: The Western Tradition*](https://books.google.com/books?id=MMYHuvhWBH4C). Prentice Hall Professional. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-13-182895-7](https://en.wikipedia.org/wiki/Special:BookSources/978-0-13-182895-7 "Special:BookSources/978-0-13-182895-7").

[^37]: Ali, Nadia (2020-05-21), ["The royal veil: early Islamic figural art and the Bilderverbot reconsidered"](https://dx.doi.org/10.4324/9780429341588-6), *Exploring Aniconism*, Routledge, pp. 70–89, [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.4324/9780429341588-6](https://doi.org/10.4324%2F9780429341588-6), [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-429-34158-8](https://en.wikipedia.org/wiki/Special:BookSources/978-0-429-34158-8 "Special:BookSources/978-0-429-34158-8"), retrieved 2023-10-19

[^38]: Turney, Jon (2003-09-06). ["Does time fly?"](https://www.theguardian.com/books/2003/sep/06/featuresreviews.guardianreview9). *The Guardian*. London. Retrieved 2008-05-01.

[^39]: ["Internet Modern History Sourcebook: Darwin, Freud, Einstein, Dada"](http://www.fordham.edu/halsall/mod/modsbook36.html). www.fordham.edu. Retrieved 2008-05-01.

[^40]: Bod, Rens; *A New History of the Humanities*, Oxford University Press, Oxford, 2014.

[^41]: [Albert William Levi](https://en.wikipedia.org/wiki/Albert_William_Levi "Albert William Levi") (1970) *The Humanities Today*, [Indiana University Press](https://en.wikipedia.org/wiki/Indiana_University_Press "Indiana University Press")

[^42]: Walling, Donovan R.; *Under Construction: The Role of the Arts and Humanities in Postmodern Schooling* Phi Delta Kappa Educational Foundation, Bloomington, Indiana, 1997. Humanities comes from human

[^43]: Hui, Wang (2020). "The Humanities in China: History and Challenges". *History of Humanities*. **5** (2): 309–331. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1086/710276](https://doi.org/10.1086%2F710276).

[^44]: Bloom, Allan (2012). *The Closing of the American Mind*. Simon and Schuster. p. 357. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-1-4516-8320-2](https://en.wikipedia.org/wiki/Special:BookSources/978-1-4516-8320-2 "Special:BookSources/978-1-4516-8320-2").

[^45]: Hersh, Richard H. (1997-03-01). "Intention and Perceptions A National Survey of Public Attitudes Toward Liberal Arts Education". *Change: The Magazine of Higher Learning*. **29** (2): 16–23. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1080/00091389709603100](https://doi.org/10.1080%2F00091389709603100). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0009-1383](https://search.worldcat.org/issn/0009-1383).

[^46]: Williams, Mary Elizabeth (27 March 2014). ["Hooray for "worthless" education!"](http://www.salon.com/2014/03/27/hooray_for_worthless_education/). *Salon*. Retrieved 2017-02-28.

[^47]: Kreager, Philip. ["Humanities graduates and the British economy: The hidden impact"](https://web.archive.org/web/20180506125120/http://torch.ox.ac.uk/sites/torch/files/publications/Humanities%20Graduates%20and%20the%20British%20Economy%20-%20University%20of%20Oxford.pdf) (PDF). Archived from [the original](http://torch.ox.ac.uk/sites/torch/files/publications/Humanities%20Graduates%20and%20the%20British%20Economy%20-%20University%20of%20Oxford.pdf) (PDF) on 2018-05-06.

[^48]: Koc, Edwin W. (2010). ["The Liberal Arts Graduate College Hiring Market"](https://canvas.wisc.edu/files/77515/download?download_frd=1&verifier=yadEsAdLKIQpRNLKXPwePhZh1jVmeqF7AInh8qDc). *National Association of Colleges and Employers*: 14–21.

[^49]: ["Ten Years After College: Comparing the Employment Experiences of 1992–93 Bachelor's Degree Recipients With Academic and Career Oriented Majors"](https://nces.ed.gov/pubs2008/2008155.pdf) (PDF).

[^50]: ["The Cumulative Earnings of Postsecondary Graduates Over 20 Years: Results by Field of Study"](http://www.statcan.gc.ca/pub/11-626-x/11-626-x2014040-eng.htm). 28 October 2014.

[^51]: ["Earnings of Humanities Majors with a Terminal Bachelor's Degree"](http://www.humanitiesindicators.org/content/indicatordoc.aspx?i=64).

[^52]: ["Career earnings by college major"](http://www.hamiltonproject.org/charts/career_earnings_by_college_major/).

[^53]: *The State of the Humanities 2018: Graduates in the Workforce & Beyond*. Cambridge, Massachusetts: American Academy of Arts and Sciences. 2018. pp. 5–6, 12, 19.

[^54]: Adamuti-Trache, Maria; et al. (2006). ["The Labour Market Value of Liberal Arts and Applied Education Programs: Evidence from British Columbia"](http://journals.sfu.ca/cjhe/index.php/cjhe/article/view/183539/183484). *Canadian Journal of Higher Education*. **36** (2): 49–74. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.47678/cjhe.v36i2.183539](https://doi.org/10.47678%2Fcjhe.v36i2.183539).

[^55]: ["Boost in Median Annual Earnings Associated with Obtaining an Advanced Degree, by Gender and Field of Undergraduate Degree"](http://www.humanitiesindicators.org/content/indicatordoc.aspx?i=10777).

[^56]: ["Earnings of Humanities Majors with an Advanced Degree"](http://www.humanitiesindicators.org/content/indicatordoc.aspx?i=10780).

[^57]: ["Why Google Hires Humanities Majors?"](https://imagine.jhu.edu/blog/2024/02/15/why-google-hires-humanities-majors/). *Imagine*. Johns Hopkins University. 2024-02-15. Retrieved 2024-09-26.

[^58]: American Academy of Arts & Sciences (25 September 2024). ["Soft Skills and Humanities"](https://www.amacad.org/sites/default/files/media/document/2019-11/soft-skills-and-humanities.pdf) (PDF). *The Humanities in Our Lives*.

[^59]: ["American Academy of Arts & Sciences"](http://www.amacad.org/). Amacad.org. 2013-11-14. Retrieved 2014-01-04.

[^60]: ["Humanities Indicators"](http://www.humanitiesindicators.org/). Humanities Indicators. Retrieved 2014-01-04.

[^61]: Augustine, Norman; Skorton, David (Jun 18, 2013). ["Humanities, social sciences critical to our future"](https://www.usatoday.com/story/opinion/2013/06/18/humanities-social-sciences-column/2436093/). *[USA Today](https://en.wikipedia.org/wiki/USA_Today "USA Today")*. [Archived](https://web.archive.org/web/20181016114736/https://www.usatoday.com/story/opinion/2013/06/18/humanities-social-sciences-column/2436093/) from the original on 2018-10-16. Retrieved 2017-11-02.

[^62]: ["The Colbert Report: Richard Brodhead"](https://web.archive.org/web/20130909041842/http://www.colbertnation.com/the-colbert-report-videos/428644/august-15-2013/richard-brodhead). *Colbert Nation*. August 15, 2013. Archived from [the original](http://www.colbertnation.com/the-colbert-report-videos/428644/august-15-2013/richard-brodhead) on 2013-09-09. Retrieved 2013-09-09.

[^63]: [Louis Menand](https://en.wikipedia.org/wiki/Louis_Menand "Louis Menand"), "The Problem of General Education", in *The Marketplace of Ideas* (W. W. Norton, 2010), especially pp. 32–43.

[^64]: Adler, Mortimer J.; "A Guidebook to Learning: For the Lifelong Pursuit of Wisdom".

[^65]: Schmidt, Ben (10 June 2013). ["A Crisis in the Humanities? (10 June 2013)"](http://www.chronicle.com/blognetwork/edgeofthewest/2013/06/10/the-humanities-crisis/). *The Chronicle*. Retrieved 4 February 2018.

[^66]: Wilson, Reid (4 March 2017). ["Census: More Americans have college degrees than ever before"](https://thehill.com/homenews/state-watch/326995-census-more-americans-have-college-degrees-than-ever-before/). *The Hill*. Retrieved 4 February 2018.

[^67]: Schuessler, Jennifer (18 June 2013). ["Humanities Committee Sounds an Alarm"](https://www.nytimes.com/2013/06/19/arts/humanities-committee-sounds-an-alarm.html). *New York Times*. Retrieved 4 February 2018.

[^68]: ["Bachelor's Degrees in the Humanities"](https://www.amacad.org/humanities-indicators/higher-education/bachelors-degrees-humanities). *Humanities Indicators*. American Academy of Arts and Sciences. April 28, 2024. Retrieved May 26, 2024.

[^69]: Sula, Chris Alen; Hill, Heather V (2019-12-01). ["The early history of digital humanities: An analysis of Computers and the Humanities (1966–2004) and Literary and Linguistic Computing (1986–2004)"](https://doi.org/10.1093/llc/fqz072). *Digital Scholarship in the Humanities*. **34** (Supplement\_1): i190–i206. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1093/llc/fqz072](https://doi.org/10.1093%2Fllc%2Ffqz072). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [2055-7671](https://search.worldcat.org/issn/2055-7671).

[^70]: ["Whitehouse.gov"](https://web.archive.org/web/20141021222654/http://www.whitehouse.gov/issues/education/reform). Archived from [the original](https://www.whitehouse.gov/issues/education/reform) on 2014-10-21. Retrieved 2014-10-29.

[^71]: *America Is Raising A Generation Of Kids Who Can't Think Or Write Clearly*, [Business Insider](http://www.businessinsider.com/the-war-against-humanities-2013-6). [Archived](https://web.archive.org/web/20141029054524/http://www.businessinsider.com/the-war-against-humanities-2013-6) 2014-10-29 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine").

[^72]: ["Edwin W. Edwards Honorary Chair, Enlightenment Conference, Montreal, 18 Oct. 2014"](https://www.youtube.com/watch?v=GUY5c9IrAHE). *[YouTube](https://en.wikipedia.org/wiki/YouTube "YouTube")*. 21 October 2014. [Archived](https://web.archive.org/web/20150517203300/https://www.youtube.com/watch?v=GUY5c9IrAHE) from the original on 2015-05-17. Retrieved 2014-10-29.

[^73]: [2014 Annual Conference Revolutions in Eighteenth-Century Sociability](https://web.archive.org/web/20210228013512/http://scedhs2014.uqam.ca/). Université du Québec à Montréal.

[^74]: Eaton, Fernin. ["Introductory remarks by former four-term Louisiana Governor Edwin W. Edwards, Honorary Chair, Montreal Enlightenment Conference, October 18, 2014"](https://www.academia.edu/8919778). *Academia*. [Archived](https://web.archive.org/web/20181002050619/http://www.academia.edu/8919778/Introductory_remarks_by_former_four-term_Louisiana_Governor_Edwin_W._Edwards_Honorary_Chair_Montreal_Enlightenment_Conference_October_18_2014) from the original on 2018-10-02. Retrieved 2014-10-29.

[^75]: [Stefan Collini](https://en.wikipedia.org/wiki/Stefan_Collini "Stefan Collini"), "What Are Universities For?" (Penguin 2012)

[^76]: Ochsner, Michael; Hug, Sven; Galleron, Ioana (2017). ["The future of research assessment in the humanities: Bottom-up assessment procedures"](https://doi.org/10.1057%2Fpalcomms.2017.20). *Palgrave Communications*. **3** 17020. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1057/palcomms.2017.20](https://doi.org/10.1057%2Fpalcomms.2017.20). [hdl](https://en.wikipedia.org/wiki/Hdl_\(identifier\) "Hdl (identifier)"):[20.500.11850/227355](https://hdl.handle.net/20.500.11850%2F227355).

[^77]: Bulaitis, Zoe (31 October 2017). ["Measuring impact in the humanities: Learning from accountability and economics in a contemporary history of cultural value"](https://doi.org/10.1057%2Fs41599-017-0002-7). *Palgrave Communications*. **3** (1) 7. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1057/s41599-017-0002-7](https://doi.org/10.1057%2Fs41599-017-0002-7). [hdl](https://en.wikipedia.org/wiki/Hdl_\(identifier\) "Hdl (identifier)"):[10871/37325](https://hdl.handle.net/10871%2F37325).

[^78]: [Dilthey, Wilhelm](https://en.wikipedia.org/wiki/Dilthey "Dilthey"). *The Formation of the Historical World in the Human Sciences*, 103.

[^79]: von Wright, Moira. "Narrative imagination and taking the perspective of others", *Studies in Philosophy and Education* 21, 4–5 (July 2002), 407–416.

[^80]: Harpham, Geoffrey (2005). "Beneath and Beyond the Crisis of the Humanities". *[New Literary History](https://en.wikipedia.org/wiki/New_Literary_History "New Literary History")*. **36**: 21–36. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1353/nlh.2005.0022](https://doi.org/10.1353%2Fnlh.2005.0022). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [144177169](https://api.semanticscholar.org/CorpusID:144177169).

[^81]: Harpham, 31.

[^82]: [Dilthey, Wilhelm](https://en.wikipedia.org/wiki/Wilhelm_Dilthey "Wilhelm Dilthey"). *The Formation of the Historical World in the Human Sciences*, 103.

[^83]: [Fish, Stanley](https://en.wikipedia.org/wiki/Stanley_Fish "Stanley Fish") (January 6, 2008). ["Will the Humanities Save Us?"](https://web.archive.org/web/20090507015746/http://fish.blogs.nytimes.com/2008/01/06/will-the-humanities-save-us/#more-81). *The New York Times*. Archived from [the original](https://fish.blogs.nytimes.com/2008/01/06/will-the-humanities-save-us/#more-81) on 2009-05-07.

[^84]: [Alan Liu, " *The Laws of Cool: Knowledge Work and the Culture of Information* (Catalogue Copy & Table of Contents)", 2004](http://liu.english.ucsb.edu/the-laws-of-cool-knowledge-work-and-the-culture-of-information-catalogue-copy-and-table-of-contents/). [Archived](https://web.archive.org/web/20130828143856/http://liu.english.ucsb.edu/the-laws-of-cool-knowledge-work-and-the-culture-of-information-catalogue-copy-and-table-of-contents/) 2013-08-28 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine").

[^85]: Bauerlein, Mark (13 November 2014). ["Theory and the Humanities, Once More"](https://www.insidehighered.com/views/2014/11/13/essay-critiques-role-theory-humanities). *[Inside Higher Ed](https://en.wikipedia.org/wiki/Inside_Higher_Ed "Inside Higher Ed")*. Retrieved 27 February 2016. Jay treats it \[theory\] as transformative progress, but it impressed us as hack philosophizing, amateur social science, superficial learning, or just plain gamesmanship.

[^86]: ""Theory," Anti-Theory, and Empirical Criticism", *Biopoetics: Evolutionary Explorations in the Arts*, Brett Cooke and Frederick Turner, eds., Lexington, Kentucky: ICUS Books, 1999, pp. 144–145. 152.

[^87]: Goldhill, Olivia (2017-04-15). ["Bill Nye says I convinced him that philosophy is not just a load of self-indulgent crap"](https://qz.com/960303/bill-nye-on-philosophy-the-science-guy-says-he-has-changed-his-mind). *Quartz*. [Archived](https://web.archive.org/web/20191210213752/https://qz.com/960303/bill-nye-on-philosophy-the-science-guy-says-he-has-changed-his-mind/) from the original on 2019-12-10. Retrieved 2019-10-12.

[^88]: Gilbert, S. F. (n.d.). 'Health Fetishism among the Nacirema: A fugue on Jenny Reardon's The Postgenomic Condition: Ethics, Justice, and Knowledge after the Genome (Chicago University Press, 2017) and Isabelle Stengers' Another Science is Possible: A Manifesto for Slow Science (Polity Press, 2018). Retrieved from [https://ojs.uniroma1.it/index.php/Organisms/article/view/14346/14050.'](https://ojs.uniroma1.it/index.php/Organisms/article/view/14346/14050.) [Archived](https://web.archive.org/web/20191210213724/https://ojs.uniroma1.it/index.php/Organisms/article/view/14346/14050.%27) 2019-12-10 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine")