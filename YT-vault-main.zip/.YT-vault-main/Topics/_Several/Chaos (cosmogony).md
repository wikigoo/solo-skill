---
title: "Chaos (cosmogony)"
source: "https://en.wikipedia.org/wiki/Chaos_(cosmogony)"
---
![](https://en.wikipedia.org/wiki/File:Assistants_and_George_Frederic_Watts_-_Chaos_-_Google_Art_Project.jpg)

George Frederic Watts – Chaos

In the context of religious [cosmogony](https://en.wikipedia.org/wiki/Cosmogony "Cosmogony"), **Chaos** ([Ancient Greek](https://en.wikipedia.org/wiki/Ancient_Greek_language "Ancient Greek language"): χάος, [romanized](https://en.wikipedia.org/wiki/Romanization_of_Ancient_Greek "Romanization of Ancient Greek"): *kháos*) refers to the division of reality outside or in contrast to the ordered [cosmos](https://en.wikipedia.org/wiki/Cosmos "Cosmos"). As such it refers to a state, place, or time beyond the known, familiar, and reliable world, often said to be inhabited by strange, ominous, or demonic beings.[^4]

According to the [creation of the universe](https://en.wikipedia.org/wiki/Cosmogony "Cosmogony") (the cosmos) in [early Greek cosmology](https://en.wikipedia.org/wiki/Early_Greek_cosmology "Early Greek cosmology"), Chaos was the first being to exist.

## Etymology

Greek *kháos* ([χάος](https://en.wiktionary.org/wiki/%CF%87%CE%AC%CE%BF%CF%82#Ancient_Greek "wikt:χάος")) means ' [emptiness](https://en.wikipedia.org/wiki/Emptiness "Emptiness"), vast void, [chasm](https://en.wikipedia.org/wiki/Chasm "Chasm"), [abyss](https://en.wikipedia.org/wiki/Abyss_\(religion\) "Abyss (religion)") ',[^1] related to the verbs *kháskō* ([χάσκω](https://en.wiktionary.org/wiki/%CF%87%CE%AC%CF%83%CE%BA%CF%89#Ancient_Greek "wikt:χάσκω")) and *khaínō* ([χαίνω](https://en.wiktionary.org/wiki/%CF%87%CE%B1%CE%AF%CE%BD%CF%89#Ancient_Greek "wikt:χαίνω")) 'gape, be wide open', from [Proto-Indo-European](https://en.wikipedia.org/wiki/Proto-Indo-European_language "Proto-Indo-European language") \* *ǵʰeh₂n-*,[^5] cognate to [Old English](https://en.wikipedia.org/wiki/Old_English_language "Old English language") *geanian*, 'to gape', whence English *[yawn](https://en.wiktionary.org/wiki/yawn "wikt:yawn")*.[^6]

It may also mean space, the expanse of air, the nether abyss, or infinite [darkness](https://en.wikipedia.org/wiki/Darkness "Darkness").[^7] [Pherecydes of Syros](https://en.wikipedia.org/wiki/Pherecydes_of_Syros "Pherecydes of Syros") (fl. 6th century BC) interprets *chaos* as water, like something formless that can be differentiated.[^8]

## Greco-Roman tradition

[Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod") and the [pre-Socratics](https://en.wikipedia.org/wiki/Pre-Socratic_philosophy "Pre-Socratic philosophy") use the Greek term in the context of [cosmogony](https://en.wikipedia.org/wiki/Cosmogony "Cosmogony"). Hesiod's Chaos has been interpreted as either "the gaping void above the Earth created when Earth and Sky are separated from their primordial unity" or "the gaping space below the Earth on which Earth rests".[^9] Passages in Hesiod's *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")* suggest that Chaos was located below Earth but above [Tartarus](https://en.wikipedia.org/wiki/Tartarus "Tartarus").[^10] [^11] Primal Chaos was sometimes said to be the true foundation of reality, particularly by philosophers such as [Heraclitus](https://en.wikipedia.org/wiki/Heraclitus "Heraclitus").

### Early Greece

In [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod") 's *Theogony*, Chaos was the first thing to exist: "at first Chaos came to be" (or was),[^12] but next (possibly out of Chaos) came [Gaia](https://en.wikipedia.org/wiki/Gaia_\(mythology\) "Gaia (mythology)"), [Tartarus](https://en.wikipedia.org/wiki/Tartarus "Tartarus"), and [Eros](https://en.wikipedia.org/wiki/Eros "Eros") (elsewhere the name Eros is used for a son of [Aphrodite](https://en.wikipedia.org/wiki/Aphrodite "Aphrodite")).[^2] Unambiguously "born" from Chaos were [Erebus](https://en.wikipedia.org/wiki/Erebus "Erebus") and [Nyx](https://en.wikipedia.org/wiki/Nyx "Nyx").[^13] [^14] For Hesiod, Chaos, like Tartarus, though personified enough to have borne children, was also a place, far away, underground and "gloomy", beyond which lived the [Titans](https://en.wikipedia.org/wiki/Titan_\(mythology\) "Titan (mythology)");[^15] and, like the earth, the ocean, and the upper air, it was also capable of being affected by Zeus's thunderbolts.[^16]

The notion of the temporal infinity was familiar to the Greek mind from remote antiquity in the religious conception of [immortality](https://en.wikipedia.org/wiki/Immortality#Ancient_Greek_religion "Immortality").[^17] The main object of the first efforts to explain the world remained the description of its growth, from a beginning. They believed that the world arose out from a primal unity, and that this substance was the permanent base of all its being. [Anaximander](https://en.wikipedia.org/wiki/Anaximander "Anaximander") claims that the origin is [apeiron](https://en.wikipedia.org/wiki/Apeiron "Apeiron") (the unlimited), a divine and perpetual substance less definite than the common elements ([water](https://en.wikipedia.org/wiki/Water_\(classical_element\) "Water (classical element)"), [air](https://en.wikipedia.org/wiki/Air_\(classical_element\) "Air (classical element)"), [fire](https://en.wikipedia.org/wiki/Fire_\(classical_element\) "Fire (classical element)"), and [earth](https://en.wikipedia.org/wiki/Earth_\(classical_element\) "Earth (classical element)")) as they were understood to the early Greek philosophers. Everything is generated from *apeiron*, and must return there according to necessity.[^18] A conception of the nature of the world was that the earth below its surface stretches down indefinitely and has its roots on or above [Tartarus](https://en.wikipedia.org/wiki/Tartarus "Tartarus"), the lower part of the underworld.[^19] In a phrase of [Xenophanes](https://en.wikipedia.org/wiki/Xenophanes "Xenophanes"), "The upper limit of the earth borders on air, near our feet. The lower limit reaches down to the "apeiron" (i.e. the unlimited)." [^19] The sources and limits of the earth, the sea, the sky, Tartarus, and all things are located in a great windy-gap, which seems to be infinite, and is a later specification of "chaos".[^19] [^20]

### Classical Greece

In [Aristophanes](https://en.wikipedia.org/wiki/Aristophanes "Aristophanes") 's comedy *[Birds](https://en.wikipedia.org/wiki/The_Birds_\(play\) "The Birds (play)")*, first there was Chaos, Night, Erebus, and Tartarus, from Night came Eros, and from Eros and Chaos came the race of birds.

> At the beginning there was only Chaos, Night, dark Erebus, and deep Tartarus. Earth, the air and heaven had no existence. Firstly, blackwinged Night laid a germless egg in the bosom of the infinite deeps of Erebus, and from this, after the revolution of long ages, sprang the graceful Eros with his glittering golden wings, swift as the whirlwinds of the tempest. He mated in deep Tartarus with dark Chaos, winged like himself, and thus hatched forth our race, which was the first to see the light. That of the Immortals did not exist until Eros had brought together all the ingredients of the world, and from their marriage Heaven, Ocean, Earth, and the imperishable race of blessed gods sprang into being. Thus our origin is very much older than that of the dwellers in Olympus. We \[birds\] are the offspring of Eros; there are a thousand proofs to show it. We have wings and we lend assistance to lovers. How many handsome youths, who had sworn to remain insensible, have opened their thighs because of our power and have yielded themselves to their lovers when almost at the end of their youth, being led away by the gift of a quail, a waterfowl, a goose, or a cock.[^21]

In [Plato](https://en.wikipedia.org/wiki/Plato "Plato") 's *[Timaeus](https://en.wikipedia.org/wiki/Timaeus_\(dialogue\) "Timaeus (dialogue)"),* the main work of Platonic cosmology, the concept of chaos finds its equivalent in the Greek expression *chôra*, which is interpreted, for instance, as shapeless space (*chôra*) in which material traces (*ichnê*) of the elements are in disordered motion (Timaeus 53a–b). However, the Platonic *chôra* is not a variation of the [atomistic](https://en.wikipedia.org/wiki/Atomism "Atomism") interpretation of the origin of the world, as is made clear by Plato's statement that the most appropriate definition of the chôra is "a receptacle of all becoming – its wetnurse, as it were" (Timaeus 49a), notabene a receptacle for the creative act of the demiurge, the world-maker.[^22]

[Aristotle](https://en.wikipedia.org/wiki/Aristotle "Aristotle"), in the context of his investigation of the concept of space in physics, "problematizes the interpretation of Hesiod's chaos as 'void' or 'place without anything in it'.[^23] Aristotle understands chaos as something that exists independently of bodies and without which no perceptible bodies can exist. 'Chaos' is thus brought within the framework of an explicitly physical investigation. It has now outgrown the mythological understanding to a great extent and, in Aristotle's work, serves above all to challenge the atomists who assert the existence of empty space." [^22]

### Roman tradition

For [Ovid](https://en.wikipedia.org/wiki/Ovid "Ovid"), (43 BC – 17/18 AD), in his *[Metamorphoses](https://en.wikipedia.org/wiki/Metamorphoses "Metamorphoses")*, Chaos was an unformed mass, where all the elements were jumbled up together in a "shapeless heap".[^24]

> Before the ocean and the earth appeared—before the skies had overspread them all—  
> the face of Nature in a vast expanse was naught but Chaos uniformly waste.  
> It was a rude and undeveloped mass, that nothing made except a ponderous weight;  
> and all discordant elements confused, were there congested in a shapeless heap.[^25]

According to the *[Fabulae](https://en.wikipedia.org/wiki/Fabulae "Fabulae")* (c. 2nd century AD), attributed to [Hyginus](https://en.wikipedia.org/wiki/Gaius_Julius_Hyginus "Gaius Julius Hyginus"): "From Mist (*[Caligo](https://en.wikipedia.org/wiki/Achlys "Achlys")*) came Chaos. From Chaos and Mist, came Night (*[Nox](https://en.wikipedia.org/wiki/Nyx "Nyx")*), Day (*[Dies](https://en.wikipedia.org/wiki/Hemera "Hemera")*), Darkness (*[Erebus](https://en.wikipedia.org/wiki/Erebus "Erebus")*), and [Aether](https://en.wikipedia.org/wiki/Aether_\(mythology\) "Aether (mythology)")." [^26] [^3] An [Orphic tradition](https://en.wikipedia.org/wiki/Orphism_\(religion\) "Orphism (religion)") apparently had Chaos as the son of [Chronus](https://en.wikipedia.org/wiki/Chronus "Chronus") and [Ananke](https://en.wikipedia.org/wiki/Ananke_\(mythology\) "Ananke (mythology)").[^27]

## Old Testament studies

![](https://en.wikipedia.org/wiki/File:Wenceslas_Hollar_-_Chaos_(State_1).jpg)

Chaos by Wenceslaus Hollar (1607 – 1677).

Since the classic 1895 German work *Schöpfung und Chaos in Urzeit und Endzeit* by [Hermann Gunkel](https://en.wikipedia.org/wiki/Hermann_Gunkel "Hermann Gunkel"), various historians in the field of modern [biblical studies](https://en.wikipedia.org/wiki/Biblical_studies "Biblical studies") have associated the theme of chaos in the earlier Babylonian cosmology with the [Genesis creation narrative](https://en.wikipedia.org/wiki/Genesis_creation_narrative "Genesis creation narrative").[^28] One locus of focus has been with respect to the term *[abyss](https://en.wikipedia.org/wiki/Abyss_\(religion\) "Abyss (religion)")* / *[tohu wa-bohu](https://en.wikipedia.org/wiki/Tohu_wa-bohu "Tohu wa-bohu")* in [Genesis 1:2](https://en.wikipedia.org/wiki/Genesis_1:2 "Genesis 1:2"). The term may refer to a state of non-being before creation [^29] or to a formless state. In the [Book of Genesis](https://en.wikipedia.org/wiki/Book_of_Genesis "Book of Genesis"), the spirit of God is moving upon the face of the waters, displacing the earlier state of the universe that is likened to a "watery chaos" upon which there is *choshek* (which translated from the Hebrew is darkness/confusion).[^17] This model of a primordial [state of matter](https://en.wikipedia.org/wiki/State_of_matter "State of matter") has been opposed by the [Church Fathers](https://en.wikipedia.org/wiki/Church_Fathers "Church Fathers") from the 2nd century, who posited a [creation *ex nihilo*](https://en.wikipedia.org/wiki/Creatio_ex_nihilo "Creatio ex nihilo") by an omnipotent [God](https://en.wikipedia.org/wiki/God "God").[^30]

Some scholars, however, reject the association between biblical creation and notions of chaos from Babylonian myths. The basis is that the terms themselves in Genesis 1:2 are not semantically related to chaos, and that the entire cosmos exists in a state of chaos in Babylonian myth, whereas at most this can be said of the earth in Genesis.[^31] The [Septuagint](https://en.wikipedia.org/wiki/Septuagint "Septuagint") makes no use of χάος in the context of creation, instead using the term for גיא, "cleft, gorge, chasm", in [Micah](https://en.wikipedia.org/wiki/Book_of_Micah "Book of Micah") 1:6 and [Zachariah](https://en.wikipedia.org/wiki/Book_of_Zechariah "Book of Zechariah") 14:4.[^32] The [Vulgate](https://en.wikipedia.org/wiki/Vulgate "Vulgate"), however, renders the χάσμα μέγα or "great gulf" between [heaven](https://en.wikipedia.org/wiki/Heaven "Heaven") and [hell](https://en.wikipedia.org/wiki/Hell "Hell") in [Luke](https://en.wikipedia.org/wiki/Gospel_of_Luke "Gospel of Luke") 16:26 as *chaos magnum*.

## Gnosticism

According to the [Gnostic](https://en.wikipedia.org/wiki/Gnosticism "Gnosticism") *[On the Origin of the World](https://en.wikipedia.org/wiki/On_the_Origin_of_the_World "On the Origin of the World")* (late 3rd century AD?), Chaos was not the first thing to exist. When the nature of the immortal [aeons](https://en.wikipedia.org/wiki/Aeon_\(Gnosticism\) "Aeon (Gnosticism)") was completed, [Sophia](https://en.wikipedia.org/wiki/Sophia_\(Gnosticism\) "Sophia (Gnosticism)") desired something like the [light which first existed](https://en.wikipedia.org/wiki/Monad_\(Gnosticism\) "Monad (Gnosticism)") to come into being. Her desire appears as a likeness with incomprehensible greatness that covers the heavenly universe, diminishing its inner darkness while a shadow appears on the outside which causes Chaos to be formed. From Chaos, every deity including the [Demiurge](https://en.wikipedia.org/wiki/Demiurge#Gnosticism "Demiurge") is born.[^33]

## Hermeticism and alchemy

![](https://en.wikipedia.org/wiki/File:Lotto_Capoferri_Magnum_Chaos.jpg)

Magnum Chaos, wood-inlay by Giovan Francesco Capoferri at the Basilica di Santa Maria Maggiore in Bergamo, based on a design by Lorenzo Lotto

The Greco-Roman tradition of *prima materia*, notably including the 5th- and 6th-century [Orphic](https://en.wikipedia.org/wiki/Orphism_\(religion\) "Orphism (religion)") cosmogony, was merged with biblical notions (*[Tehom](https://en.wikipedia.org/wiki/Tehom "Tehom")*) in [Christianity](https://en.wikipedia.org/wiki/Christianity "Christianity") and inherited by [alchemy](https://en.wikipedia.org/wiki/Alchemy "Alchemy") and [Renaissance magic](https://en.wikipedia.org/wiki/Renaissance_magic "Renaissance magic").

The cosmic egg of Orphism was taken as the raw material for the alchemical [magnum opus](https://en.wikipedia.org/wiki/Magnum_opus_\(alchemy\) "Magnum opus (alchemy)") in early Greek alchemy. The first stage of the process of producing the [philosopher's stone](https://en.wikipedia.org/wiki/Philosopher's_stone "Philosopher's stone"), i.e., [nigredo](https://en.wikipedia.org/wiki/Nigredo "Nigredo"), was identified with chaos. Because of association with the [Genesis creation narrative](https://en.wikipedia.org/wiki/Genesis_creation_narrative "Genesis creation narrative"), where "the Spirit of God moved upon the face of the waters" (Gen. 1:2), Chaos was further identified with the [classical element](https://en.wikipedia.org/wiki/Classical_element "Classical element") of [Water](https://en.wikipedia.org/wiki/Water_\(classical_element\) "Water (classical element)").

[Ramon Llull](https://en.wikipedia.org/wiki/Ramon_Llull "Ramon Llull") (1232–1315) wrote a *Liber Chaos*, in which he identifies Chaos as the primal form or matter created by God. Swiss alchemist [Paracelsus](https://en.wikipedia.org/wiki/Paracelsus "Paracelsus") (1493–1541) uses *chaos* synonymously with "classical element" (because the primeval chaos is imagined as a formless congestion of all elements). Paracelsus thus identifies [Earth](https://en.wikipedia.org/wiki/Earth_\(classical_element\) "Earth (classical element)") as "the chaos of the *gnomi* ", i.e., the element of the [gnomes](https://en.wikipedia.org/wiki/Gnome "Gnome"), through which these spirits move unobstructed as fish do through water, or birds through air.[^34] An alchemical treatise by [Heinrich Khunrath](https://en.wikipedia.org/wiki/Heinrich_Khunrath "Heinrich Khunrath"), printed in Frankfurt in 1708, was entitled *Chaos*.[^35] The 1708 introduction states that the treatise was written in 1597 in Magdeburg, in the author's 23rd year of practicing alchemy.[^36] The treatise purports to quote Paracelsus on the point that "\[t\]he light of the soul, by the will of the Triune God, made all earthly things appear from the primal Chaos".[^37] [Martin Ruland the Younger](https://en.wikipedia.org/wiki/Martin_Ruland_the_Younger "Martin Ruland the Younger"), in his 1612 *Lexicon Alchemiae*, states, "A crude mixture of matter or another name for *Materia Prima* is *Chaos*, as it is in the Beginning."

The term *[gas](https://en.wikipedia.org/wiki/Gas "Gas")* in [chemistry](https://en.wikipedia.org/wiki/Chemistry "Chemistry") was coined by Dutch chemist [Jan Baptist van Helmont](https://en.wikipedia.org/wiki/Jan_Baptist_van_Helmont "Jan Baptist van Helmont") in the 17th century directly based on the [Paracelsian](https://en.wikipedia.org/wiki/Paracelsianism "Paracelsianism") notion of chaos. The *g* in *gas* is due to the Dutch pronunciation of this letter as a [spirant](https://en.wikipedia.org/wiki/Spirant "Spirant"), also employed to pronounce Greek [χ](https://en.wikipedia.org/wiki/Chi_\(letter\) "Chi (letter)").[^38]

## Hawaiian tradition

In [Hawaiian folklore](https://en.wikipedia.org/wiki/Hawaiian_religion "Hawaiian religion"), a triad of deities known as the "Ku-Kaua-Kahi" (a.k.a. "Fundamental Supreme Unity") were said to have existed before and during Chaos ever since eternity, or put in Hawaiian terms, *mai ka po mai*, meaning "from the time of night, darkness, Chaos". They eventually broke the surrounding *Po* ("night"), and light entered the universe. Next the group created three heavens for dwelling areas together with the Earth, Sun, Moon, stars, and assistant spirits.[^39]

## Modern usage

The term *[chaos](https://en.wiktionary.org/wiki/chaos "wikt:chaos")* has been adopted in modern [comparative mythology](https://en.wikipedia.org/wiki/Comparative_mythology "Comparative mythology") and [religious studies](https://en.wikipedia.org/wiki/Religious_studies "Religious studies") as referring to the primordial state before creation, strictly combining two separate notions of primordial waters or a primordial darkness from which a new order emerges and a primordial state as a merging of opposites, such as heaven and earth, which must be separated by a creator deity in an act of [cosmogony](https://en.wikipedia.org/wiki/Cosmogony "Cosmogony").[^40] In both cases, chaos referring to a notion of a primordial state contains the cosmos *in potentia* but needs to be formed by a [demiurge](https://en.wikipedia.org/wiki/Demiurge "Demiurge") before the world can begin its existence.

The use of *chaos* in the derived sense of "complete disorder or confusion" first appears in Elizabethan [Early Modern English](https://en.wikipedia.org/wiki/Early_Modern_English "Early Modern English"), originally implying satirical exaggeration.[^41] " [Chaos](https://en.wikipedia.org/wiki/Chaos_theory "Chaos theory") " in the well-defined sense of [chaotic complex system](https://en.wikipedia.org/wiki/Chaotic_complex_system "Chaotic complex system") is in turn derived from this usage.

[^1]: [West 1966](#CITEREFWest1966), p. 192 line 116, Χάος, "best translated Chasm"; English *chasm* is a loan from Greek [χάσμα](https://en.wiktionary.org/wiki/%CF%87%CE%AC%CF%83%CE%BC%CE%B1#Ancient_Greek "wikt:χάσμα"), which is root-cognate with χάος. [Most 2006](#CITEREFMost2006), p. 13, translates Χάος as "Chasm", and notes: (n. 7): "Usually translated as 'Chaos'; but that suggests to us, misleadingly, a jumble of disordered matter, whereas Hesiod's term indicates instead a gap or opening".

[^2]: According to [Gantz 1996](#CITEREFGantz1996), pp. 4–5: "With regard to all three of these figures – Gaia, Tartaros, and Eros – we should note that Hesiod does not say they arose *from* (as opposed to *after*) Chaos, although this is often assumed." For example, [Morford & Lenardon 2007](#CITEREFMorfordLenardon2007), p. 57, makes these three descendants of Chaos saying they came "presumably out of Chaos, just as Hesiod actually states that 'from Chaos' came Erebus and dark Night". [Tripp 1970](#CITEREFTripp1970), p. 159, says simply that Gaia, Tartarus and Eros, came *"out of Chaos, or together with it"*. [Caldwell 1987](#CITEREFCaldwell1987), pp. 33, n. 116–122, however, interprets Hesiod as saying that Chaos, Gaia, Tartarus, and Eros, all "are spontaneously generated without source or cause". Later writers commonly make Eros the son of [Aphrodite](https://en.wikipedia.org/wiki/Aphrodite "Aphrodite") and [Ares](https://en.wikipedia.org/wiki/Ares "Ares"), though several other parentages are also given.

[^3]: [Bremmer 2008](#CITEREFBremmer2008), p. [p. 5](https://books.google.com/books?id=YTfxZH4QnqgC&pg=PA5) translates *Caligo* as 'Darkness'; according to him:  
"Hyginus... started his *Fabulae* with a strange hodgepodge of Greek and Roman cosmogonies and early genealogies. It begins as follows:

*Ex Caligine Chaos. Ex Chao et Caligine Nox Dies Erebus* *Aether*. — (Praefatio 1)

His genealogy looks like a derivation from Hesiod, but it starts with the un-Hesiodic and un-Roman *Caligo*, 'Darkness'. Darkness probably did occur in a cosmogonic poem of Alcman, but it seems only fair to say that it was not prominent in Greek cosmogonies."

[^4]: [*Chaos*](https://referenceworks.brill.com/doi/10.1163/1872-5287_bdr_COM_00075), [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1163/1872-5287\_bdr\_COM\_00075](https://doi.org/10.1163%2F1872-5287_bdr_COM_00075), retrieved 2025-06-19

[^5]: [R. S. P. Beekes](https://en.wikipedia.org/wiki/Robert_S._P._Beekes "Robert S. P. Beekes"), *Etymological Dictionary of Greek*, Brill, 2009, pp. 1614 and 1616–7.

[^7]: Lidell-Scott, *[A Greek–English Lexicon](https://en.wikipedia.org/wiki/A_Greek%E2%80%93English_Lexicon "A Greek–English Lexicon")* [chaos](https://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.04.0057%3Aentry%3Dxa%2Fos1)

[^8]: [Kirk, Raven & Schofield 2003](#CITEREFKirkRavenSchofield2003), p. 57

[^9]: Moorton, Richard F. Jr. (2001). ["Hesiod as Precursor to the Presocratic Philosophers: A Voeglinian View"](https://web.archive.org/web/20081211142040/http://www.artsci.lsu.edu/voegelin/EVS/Panel42001.htm). Louisiana State University. Archived from [the original](http://www.artsci.lsu.edu/voegelin/EVS/Panel42001.htm) on 2008-12-11. Retrieved 2008-12-04.

[^10]: [Gantz 1996](#CITEREFGantz1996), p. 3.

[^11]: [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod"). *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")*. [813–814](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+814&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=814&highlight=Chaos), [700](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+700&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=700&highlight=Chaos), [740](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+729&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=729&highlight=gulf) – via Perseus, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University").

[^12]: [Gantz 1996](#CITEREFGantz1996), p. 3 says "the Greek will allow both".

[^13]: [Gantz 1996](#CITEREFGantz1996), pp. 4–5.

[^14]: [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod"). *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")*. [123](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+104&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=104&highlight=Chaos) – via Persius, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University").

[^15]: [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod"). *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")*. [814](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+814&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=814&highlight=Chaos) – via Persius, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University"). And beyond, away from all the gods, live the Titans, beyond gloomy Chaos

[^16]: [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod"). *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")*. [740](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+729&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=729&highlight=gulf) – via Perseus, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University").

[^17]: [Guthrie 2000](#CITEREFGuthrie2000), pp. 59, 60, 83.

[^18]: Nilsson, Vol.I, p.743; [Guthrie 1952](#CITEREFGuthrie1952), p. 87.

[^19]: [Kirk, Raven & Schofield 2003](#CITEREFKirkRavenSchofield2003), pp. 9, 10, 20.

[^20]: [Hesiod](https://en.wikipedia.org/wiki/Hesiod "Hesiod"). *[Theogony](https://en.wikipedia.org/wiki/Theogony "Theogony")*. [740–765](https://www.perseus.tufts.edu/hopper/text?doc=Hes.+Th.+729&fromdoc=Perseus%3Atext%3A1999.01.0130:chapter=729&highlight=gulf) – via Perseus, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University").

[^21]: [Aristophanes 1938](#CITEREFAristophanes1938), [693–699](https://www.perseus.tufts.edu/hopper/text?doc=Aristoph.+Birds+693&fromdoc=Perseus%3Atext%3A1999.01.0026:chapter=693&highlight=Chaos); [Morford & Lenardon 2007](#CITEREFMorfordLenardon2007), pp. 57–58. [Caldwell 1987](#CITEREFCaldwell1987), p. 2, describes this avian-declared theogony as "comedic parody".

[^22]: [Lobenhofer 2020](#CITEREFLobenhofer2020).

[^23]: [Aristotle](https://en.wikipedia.org/wiki/Aristotle "Aristotle"). *Physics*. IV 1 208b27–209a2 \[...\]

[^24]: [Ovid](https://en.wikipedia.org/wiki/Ovid "Ovid"). *[Metamorphoses](https://en.wikipedia.org/wiki/Metamorphoses "Metamorphoses")*. [1.5 ff.](https://www.perseus.tufts.edu/hopper/text?doc=Ov.+Met.+1.5&fromdoc=Perseus%3Atext%3A1999.02.0074:book=1:chapter=5&highlight=Chaos) – via Perseus, [Tufts University](https://en.wikipedia.org/wiki/Tufts_University "Tufts University").

[^25]: [Ovid & More 1922](#CITEREFOvidMore1922), [1.5ff](https://www.perseus.tufts.edu/hopper/text?doc=Ov.+Met.+1.5&fromdoc=Perseus%3Atext%3A1999.02.0028).

[^26]: [Gaius Julius Hyginus](https://en.wikipedia.org/wiki/Gaius_Julius_Hyginus "Gaius Julius Hyginus"). *[Fabulae](https://en.wikipedia.org/wiki/Fabulae "Fabulae")*. Translated by Smith; Trzaskoma. [Preface](https://topostext.org/work/206#0.2).

[^27]: [Ogden 2013](#CITEREFOgden2013), pp. 36–37.

[^28]: [Gunkel 1910](#CITEREFGunkel1910), HKAT I.1; [Tsumura 2022](#CITEREFTsumura2022), p. 254.

[^29]: [Westermann 1983](#CITEREFWestermann1983); [Tsumura 2005](#CITEREFTsumura2005).

[^30]: Gerhard May, *[Schöpfung aus dem Nichts. Die Entstehung der Lehre von der creatio ex nihilo](https://books.google.com/books?id=s6nao1QMXscC&pg=PA151)*, AKG 48, Berlin / New York, 1978, 151f.

[^31]: [Tsumura 2022](#CITEREFTsumura2022), p. 255, 281.

[^32]: ["Lexicon:: Strong's H1516 – gay'"](https://www.blueletterbible.org/lang/lexicon/lexicon.cfm?Strongs=H1516&t=KJV). *www.blueletterbible.org*.

[^33]: [Marvin Meyer](https://en.wikipedia.org/wiki/Marvin_Meyer "Marvin Meyer"); [Willis Barnstone](https://en.wikipedia.org/wiki/Willis_Barnstone "Willis Barnstone") (2009). "On the Origin of the World". [*The Gnostic Bible*](http://gnosis.org/naghamm/origin-Barnstone.html). [Shambhala](https://en.wikipedia.org/wiki/Shambhala_Publications "Shambhala Publications"). Retrieved 2021-10-14.

[^34]: De Nymphis etc. Wks. 1658 II. 391

[^35]: [Khunrath, Heinrich](https://en.wikipedia.org/wiki/Heinrich_Khunrath "Heinrich Khunrath") (1708). [*Vom Hylealischen, das ist Pri-materialischen Catholischen oder Allgemeinen Natürlichen Chaos der naturgemässen Alchymiae und Alchymisten: Confessio*](https://books.google.com/books?id=X1g6AAAAcAAJ).

[^36]: [Szulakowska 2000](#CITEREFSzulakowska2000), p. 79.

[^37]: [Szulakowska 2000](#CITEREFSzulakowska2000), p. 91, quoting [Khunrath 1708](#CITEREFKhunrath1708), p. 68.

[^38]: "halitum illum Gas vocavi, non longe a Chao veterum secretum." Ortus Medicinæ, ed. 1652, p. 59a, cited after the [Oxford English Dictionary](https://en.wikipedia.org/wiki/Oxford_English_Dictionary "Oxford English Dictionary").

[^39]: Thrum, Thomas (1907). [*Hawaiian Folk Tales*](https://www.sacred-texts.com/pac/hft/hft04.htm). [A. C. McClurg](https://en.wikipedia.org/wiki/A._C._McClurg "A. C. McClurg"). p. 15.

[^40]: [Mircea Eliade](https://en.wikipedia.org/wiki/Mircea_Eliade "Mircea Eliade"), article "Chaos" in *Religion in Geschichte und Gegenwart*, 3rd ed. vol. 1, Tübingen, 1957, 1640f.

[^41]: [Stephen Gosson](https://en.wikipedia.org/wiki/Stephen_Gosson "Stephen Gosson"), *The schoole of abuse, containing a plesaunt inuectiue against poets, pipers, plaiers, iesters and such like caterpillers of a commonwelth* (1579), p. 53 (cited after [OED](https://en.wikipedia.org/wiki/OED "OED")): "They make their volumes no better than \[...\] a huge Chaos of foule disorder."