We are used to thinking very highly of democracy
– and by extension, of Ancient Athens, the
civilisation that gave rise to it. The Parthenon
has become almost a byword for democratic
values, which is why so many leaders of democracies
like to be photographed there.
It’s therefore very striking to discover
that one of Ancient Greece’s great achievements,
Philosophy, was highly suspicious of its other
achievement, Democracy.
The founding father of Greek Philosophy
– Socrates – is portrayed, in the dialogues of Plato, as hugely pessimistic
about the whole business of democracy. In
Book Six of The Republic, Plato describes
Socrates falling into conversation with a
character called Adeimantus and trying to
get him to see the flaws of democracy by comparing
a society to a ship. If you were heading out
on a journey by sea, asks Socrates, who would
you ideally want deciding who was in charge
of the vessel? Just anyone or people educated
in the rules and demands of seafaring? The
latter of course, says Adeimantus, so why
then, responds Socrates, do we keep thinking
that any old person should be fit to judge
who should be a ruler of a country? Socrates’s
point is that voting in an election is a skill,
not a random intuition. And like any skill,
it needs to be taught systematically to people.
Letting the citizenry vote without an education
is as irresponsible as putting them in charge
of a trireme sailing to Samos in a storm.
Socrates was to have first hand, catastrophic
experience of the foolishness of voters. In
399 BC, the philosopher was put on trial on
trumped up charges of corrupting the youth
of Athens. A jury of 500 Athenians was invited
to weigh up the case and decided by a narrow
margin that the philosopher was guilty. He
was put to death by hemlock in a process which
is, for thinking people, every bit as tragic
as Jesus’s condemnation has been for Christians.
Crucially, Socrates was not elitist in the
normal sense. He didn’t believe that a narrow
few should only ever vote. He did, however,
insist that only those who had thought about
issues rationally and deeply should be let
near a vote. We have forgotten this distinction
between an intellectual democracy and a democracy
by birthright. We have given the vote to all
without connecting it to wisdom. And
Socrates knew exactly where that would lead:
to a system the Greeks feared above all, demagoguery.
Ancient Athens had painful experience of demagogues,
for example, the louche figure of Alcibiades,
a rich, charismatic, smooth-talking wealthy
man who eroded basic freedoms and helped to
push Athens to its disastrous military adventures
in Sicily. Socrates knew how easily people
seeking election could exploit our desire
for easy answers. He asked us to imagine an
election debate between two candidates, one
who was like a doctor and the other who was
like a sweet shop owner. The sweet shop owner
would say of his rival: Look, this person
here has worked many evils on you. He hurts
you, gives you bitter potions and tells you
he not to eat and drink whatever you like. He’ll
never serve you feasts of many and varied
pleasant things like I will. Socrates asks
us to consider the audience response: Do you
think the doctor would be able to reply effectively?
The true answer – ‘I cause you trouble,
and go against you desires in order to help
you’ would cause an uproar among the voters,
don’t you think? We have forgotten all about
Socrates’s salient warnings against democracy.
We have preferred to think of democracy as
an unambiguous good – rather than as something
that is only ever as effective as the education
system that surrounds it. As a result, we
have elected many sweet shop owners, and very
few doctors.