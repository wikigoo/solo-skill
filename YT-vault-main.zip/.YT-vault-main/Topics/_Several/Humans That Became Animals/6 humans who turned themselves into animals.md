---
title: "6 humans who turned themselves into animals"
source: "https://timesofindia.indiatimes.com/etimes/trending/6-humans-who-turned-themselves-into-animals/photostory/109817666.cms"
---
![Incredible transformations](https://static.toiimg.com/thumb/109817696.jpg?photoid=109817696&imgsize=70752&width=600&height=335&resizemode=75)

Incredible transformations

## Incredible transformations

The allure of the animal kingdom has fascinated humans for centuries, leading some to adopt the traits and appearances of various creatures. This article explores the lives of six individuals who have taken extraordinary measures to transform themselves into animals, each with a unique story that blurs the lines between human and beast.  
  
Image: Getty Images  

Read More

![Cat woman](https://static.toiimg.com/thumb/109817693.jpg?photoid=109817693&imgsize=47980&width=600&height=335&resizemode=75)

**2** /7

## Cat woman

Jocelyn Wildenstein, often referred to as “Catwoman,” has undergone numerous cosmetic surgeries to attain a feline appearance. Her transformation is one of the most publicized cases of human-animal resemblance, reflecting her deep admiration for big cats. Wildenstein’s procedures have dramatically altered her features, resulting in a visage that embodies her passion for these majestic creatures.  
  
Image: Getty Images  

Read More

![Parrot man](https://static.toiimg.com/thumb/109817692.jpg?photoid=109817692&imgsize=132506&width=600&height=335&resizemode=75)

Parrot man

**3** /7

## Parrot man

Ted Richards, affectionately known as “Parrotman,” has taken his love for parrots to extraordinary lengths. His journey into becoming a human parrot is marked by numerous body modifications. Richards has had his face tattooed with vibrant feathers in the five colors of his parrots, and in a daring move that risked his sight, he had his eyes colored with tattoo ink. Not stopping there, he underwent a surgical procedure to remove his ears, enhancing his resemblance to the birds. These physical changes are complemented by 110 tattoos, 50 piercings, and a split tongue, further solidifying his avian identity.  
  
Image: @thismorning/X  

Read More

![Lizard man](https://static.toiimg.com/thumb/109817689.jpg?photoid=109817689&imgsize=39138&width=600&height=335&resizemode=75)

Lizard man

**4** /7

## Lizard man

Erik Sprague, better known by his stage name “The Lizardman,” is a performance artist who has undergone extensive body modifications to resemble a lizard. Born on June 12, 1972, in Fort Campbell, Kentucky, Sprague has transformed his appearance with a full-body tattoo of green scales, a bifurcated tongue, subdermal implants, sharpened teeth, and green-inked lips. His modifications are not just for show; they are an integral part of his identity and performances. Sprague’s acts include classic sideshow feats like fire eating and breathing, sword swallowing, and the human blockhead. Beyond his performances, he is a prominent figure in the body modification community, contributing articles and engaging in public speaking. His band, Lizard Skynyrd, adds another dimension to his artistic expression.  
  
Image: Getty Images  

Read More

![Dog man](https://static.toiimg.com/thumb/109817685.jpg?photoid=109817685&imgsize=55524&width=600&height=335&resizemode=75)

**5** /7

## Dog man

In Japan, a man known as Toco has taken his love for dogs to an unparalleled level by investing in an intricately designed, custom-made collie costume. This costume, which cost him over 2 million yen (approximately $15,700), fulfilled his dream of experiencing life as a rough collie. Toco’s transformation journey began two years ago when he approached Zeppet, a company that specializes in creating realistic costumes and models for films, to craft his tailor-made suit. The suit, which took about 40 days to make, allows Toco to embody the physicality of a dog, complete with fur, a wagging tail, and a lifelike snout. When Toco ventures out in his costume, he does so sparingly to maintain his privacy and avoid drawing large crowds. Yet, on those special occasions, he captures the attention and affection of passersby, some of whom are familiar with his social media presence, where he shares his life as an animal with a growing audience.  
  
Image: ZeppetJP/X

Read More

![Dragon lady](https://static.toiimg.com/thumb/109817684.jpg?photoid=109817684&imgsize=46728&width=600&height=335&resizemode=75)

Dragon lady

**6** /7

## Dragon lady

Eva Tiamat Medusa’s transformation into ‘The Dragon Lady’ is a profound expression of her desire to transcend human identity and embody the mythical creature she resonates with. Born Richard Hernandez, Tiamat’s journey of metamorphosis is extensive and deeply personal. She has invested in radical body modifications, including horn implants on her forehead, the removal of her ears and nostrils, and the reshaping of her nose to resemble a dragon’s snout. Her eyes have been stained green, and her tongue has been split to enhance her dragon-like appearance. These physical changes are accompanied by full-body tattoos that mimic reptilian scales, modeled after the western diamondback rattlesnake—a creature that holds significant personal symbolism for Tiamat.  
  
Image: dragonladymedusa/Instagram  

Read More

![Zebra Man](https://static.toiimg.com/thumb/109817682.jpg?photoid=109817682&imgsize=46660&width=600&height=335&resizemode=75)

**7** /7

## Zebra Man

Horace Ridler, who became known as “The Great Omi” or “The Zebra Man,” was a British sideshow performer renowned for his extensive body modifications. Born into an upper-class family in 1882, Ridler initially pursued a military career, serving with distinction during World War I. However, after the war, he found himself in financial hardship and turned to the world of freak shows for a living. In a bid to stand out, he contacted the famous tattooist George Burchett and underwent over 150 hours of tattooing, covering his body with bold zebra-like stripes. This transformation was more than skin deep; it was a complete reinvention of his persona. Ridler’s act became a sensation, touring England and France, and he further augmented his appearance with stretched earlobes and a large septum piercing.  
  
Image: Tattoo Parlour/Facebook  

Read More