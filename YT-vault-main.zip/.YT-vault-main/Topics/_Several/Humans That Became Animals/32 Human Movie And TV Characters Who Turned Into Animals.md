---
title: "32 Human Movie And TV Characters Who Turned Into Animals"
source: "https://www.cinemablend.com/movies/human-movie-and-tv-characters-who-turned-into-animals"
---
Newsletter

I am both fascinated and horrified by the idea of being transformed into an animal. This is likely because I have seen numerous films and TV shows, such as the following, that depict human characters undergoing this process, either by choice or against their will.

Quick disclaimer: I wanted to keep this list exclusive to characters who, in most cases, fully metamorphosed into an Earthly non-human being, so there will be no half-human, half-creature hybrids like in *The Fly* or other [body horror flicks](https://www.cinemablend.com/movies/the-best-body-horror-movies-and-how-to-watch-them) of that nature, or mentions of [werewolf movies](https://www.cinemablend.com/streaming-news/10-movies-and-shows-about-werewolves-to-watch-streaming), for instance. Without further ado, let’s get wild!

![A dog looking at a man in The Shaggy Dog](https://cdn.mos.cms.futurecdn.net/tfuMDZ4FSFLAxQwkHpVqJk-1200-80.jpg.webp)

(Image credit: Disney)

## Wilby Daniels (The Shaggy Dog)

Some of the best [movies about talking dogs](https://www.cinemablend.com/movies/great-movies-with-talking-dogs) involve a canine who started off as human, such as *The Shaggy Dog*. Disney's live-action fantasy from 1959, which later spawned a sequel called *The Shaggy D.A.* and a remake with [Tim Allen](https://www.cinemablend.com/tag/tim-allen), stars Tommy Kirk as Wilby Daniels, a teenager who is cursed with an affliction that periodically transforms him into a sheepdog.

Latest Videos FromCinemablend

[Watch full video here: I Asked James Cameron How Ready He Is To Shoot 'Avatar 4' & '5,' And He Hinted At Other Ideas In The Works: ‘I Can't Plan The Next 25 Years’](https://www.cinemablend.com/video/G0ltqBkd/i-asked-james-cameron-how-ready-he-is-to-shoot-avatar-4-and-5-and-he-hinted-at-other-ideas-in-the-works-i-cant-plan-the-next-25-years)

![The main star of the original The Incredible Mr. Limpet.](https://cdn.mos.cms.futurecdn.net/scKTMTn3sjbTc4MdKDgd9Y-1200-80.jpg.webp)

(Image credit: Warner Bros.)

## Harry Limpet (The Incredible Mr. Limpet)

In 1964's *The Incredible Mr. Limpet*, Don Knotts plays the title character, who longs to live amongst the creatures of the sea. He receives his wish when he is magically transformed into an animated fish, which ends up giving him a better opportunity to assist the Navy during World War II than he had as a human.

![Tiana teaching Naveen how to mince in The Princess and the Frog.](https://cdn.mos.cms.futurecdn.net/BqZnZFKgsrwamoYnGZwPac-1200-80.jpg.webp)

(Image credit: Disney)

## Tiana And Naveen (The Princess And The Frog)

In the classic fairy tale that the 2009 [Disney animated film](https://www.cinemablend.com/news/2304282/every-walt-disney-animation-studios-feature-ranked) *[The Princess and the Frog](https://www.cinemablend.com/tag/the-princess-and-the-frog)* is based on, the prince returns to human form after receiving a kiss from the princess. However, in this reimaging, when New Orleans restaurant server Tiana (Anika Noni Rose) kisses Prince Naveen (Bruno Campos), she becomes a ribbiting amphibian as well.

![The teens looks ahead on Animorphs](https://cdn.mos.cms.futurecdn.net/GFUU5StRsLDeNy23w3JjyF-1200-80.jpg.webp)

(Image credit: Nickelodeon)

## The Kids From Animorphs (Animorphs)

From 1998 to 2000, Nickelodeon aired a TV show based on the *Animorphs* book series by Katherine Applegate and her husband, Michael Grant (writing together as K. A. Applegate). It follows a group of teens who are given the power to turn into any animal they touch by a group of aliens, in order to help them fight a war against a parasitic extraterrestrial race planning to infiltrate the human race.

![Maggie Smith as Professor McGonagall in Harry Potter and the Sorcerer&#039;s Stone](https://cdn.mos.cms.futurecdn.net/7MDd8FV56TLksVbXxP2R6f-1200-80.jpg.webp)

(Image credit: Warner Bros.)

## Professor Minerva McGonagall (Harry Potter And The Sorcerer's Stone)

Maggie Smith's character from the [*Harry Potter* movies](https://www.cinemablend.com/news/2495168/all-the-harry-potter-movies-in-order-from-sorcerers-stone-to-fantastic-beasts), Professor Minerva McGonagall, frequently uses a spell that transforms her into a cat. She demonstrates this in 2000's *[Harry Potter](https://www.cinemablend.com/tag/harry-potter) and the Sorcerer's Stone*, when the title hero (played by [Daniel Radcliffe](https://www.cinemablend.com/tag/daniel-radcliffe)) and Ron Weasley ([Rupert Grint](https://www.cinemablend.com/tag/rupert-grint)) assume they have made it to the Hogwarts instructor's class before she arrives, only to discover she was the feline sitting atop her desk.

![Beast Boy on Teen Titans](https://cdn.mos.cms.futurecdn.net/m5hcnCuu6yjDMvbPPXMsq3-1200-80.jpg.webp)

(Image credit: Warner Bros. / DC)

## Beast Boy (Teen Titans)

To save his life from an illness that West African green monkeys are immune to, young Garfield Logan's father temporarily transformed him into the animal with an untested experiment that ended up giving him the ability to shapeshift into any creature he chooses. The DC Comics superhero, better known as Beast Boy, would become a fan favorite on the [beloved animated series](https://www.cinemablend.com/television/the-75-best-animated-TV-shows-of-all-time), *Teen Titans*, as voiced by Greg Cipes.

![Two of the main characters of Brother Bear.](https://cdn.mos.cms.futurecdn.net/mPztThjt99LF8RRLUBYeJH-1200-80.png.webp)

(Image credit: Disney)

## Kenai (Brother Bear)

In 2003's Oscar-nominated animated film *Brother Bear,* Joaquin Phoenix voices a post-ice age Alaskan hunter named Kenai, who is magically turned into his worst enemy, a brown bear, but learns to embrace his fate after befriending a cub named Koda (Jeremy Suarez).

![The Wonder Twins on Super Friends](https://cdn.mos.cms.futurecdn.net/fpwYLe9TxYjJsySLH7XJb6-1200-80.jpg.webp)

(Image credit: DC)

## Jayna (Super Friends)

Popular DC Comics heroes The Wonder Twins were created specifically for the animated precursor to *[Justice League](https://www.cinemablend.com/tag/justice-league)*, *Super Friends*. While the male sibling, Zan, can only turn into water (including in liquid, solid, or gaseous form), his sister, Jayna, can transform into any animal existing on any planet, even including mythological creatures.

![Kuzco in The Emperor&#039;s New Groove](https://cdn.mos.cms.futurecdn.net/PNGJypmeDERRhQCUMD2E9-1200-80.jpg.webp)

(Image credit: Disney)

## Emperor Kuzco (The Emperor's New Groove)

In the funny cult favorite Disney animated film, *The Emperor's New Groove*, [David Spade](https://www.cinemablend.com/tag/david-spade) voices a selfish royal named Kuzco, who receives a much-needed crash course in humility in a most bizarre fashion. When he is mistakenly transformed into a llama by his vengeful former advisor, Yzma (Eartha Kitt), who really intended to poison him, he is forced to enlist the help of a peasant named Pacha ([John Goodman](https://www.cinemablend.com/tag/john-goodman)) to return to normal.

![Simon MacCorkindale cringing in a close up in Manimal.](https://cdn.mos.cms.futurecdn.net/yoRTjxuTpSDNEGCqEGPXE4-1200-80.jpg.webp)

(Image credit: NBC)

## Dr. Jonathan Chase (Manimal)

In the short-lived [science-fiction TV show from the 1980s](https://www.cinemablend.com/television/great-sci-fi-tv-shows-from-the-70s-and-80s), *Manimal*, Simon MacCorkindale stars as Dr. Jonathan Chase, who possesses the ability to shapeshift into any animal of his choosing. He uses this power to help the police solve crimes.

![Lampwick getting turned into a Donkey in Pinocchio.](https://cdn.mos.cms.futurecdn.net/Sc7kjLZieC2DYAdbFaHKLm-1200-80.jpg.webp)

(Image credit: Disney)

## Lampwick (Pinocchio)

In one of the most terrifying scenes from Disney's animated 1940 adaptation of *Pinocchio*, the sentient marionette befriends a troublemaker named Lampwick, who suffers the same fate as all boys who are sent to Pleasure Island and transforms into a donkey. One [wild movie fan theory](https://www.cinemablend.com/movies/32-crazy-fan-theories-about-your-favorite-movie-characters) suggests that this is what happened to [Eddie Murphy](https://www.cinemablend.com/tag/eddie-murphy) 's character from *Shrek*.

![Sabrina in Sabrina the Teenage Witch](https://cdn.mos.cms.futurecdn.net/WBBWZZpC99nuoUgEY5q42c-1200-80.jpg.webp)

(Image credit: Disney+)

## Sabrina Spellman (Sabrina The Teenage Witch)

Melissa Joan Hart's young, eponymous spellcaster from *Sabrina the Teenage Witch* turned into an animal various times during the ABC fantasy sitcom's run. Her transformations would either be by her own doing or through a strange situation that she would need to figure out how to reverse.

![Dog from Fluke](https://cdn.mos.cms.futurecdn.net/8VmgFxt72AMoNJ843tW2mL-1200-80.jpg.webp)

(Image credit: MGM)

## Thomas P. Johnson (Fluke)

*Fluke* is an interesting [movie about reincarnation](https://www.cinemablend.com/tag/tag/movies-about-past-lives), considering the main character is not resurrected into a new human body, but that of a dog. The 1995 film stars Matthew Modine as a selfish, workaholic family man who, after his untimely death, wakes up as Fluke, a dog named after his own breed, and struggles to reconnect with his family.

![Batman and Zatanna looking at Wonder Woman, now a pig, on Justice League Unlimited](https://cdn.mos.cms.futurecdn.net/rBLcXH6b3Ur3YYkrJYw3VU-1200-80.jpg.webp)

(Image credit: Warner Bros. / DC)

## Wonder Woman (Justice League Unlimited)

In one of the weirder episodes of *Justice League Unlimited*, called "This Little Piggy," Wonder Woman (Susan Eisenberg) is turned into a swine by Circe (Rachel York). In order to turn her back, Batman (legendary [Batman voice actor](https://www.cinemablend.com/superheroes/batman/the-10-best-batman-voice-actors-ranked) Kevin Conroy) must show an act of love toward her, and does so by serenading her at a club.

![Meilin as a big red panda](https://cdn.mos.cms.futurecdn.net/HFpbtVmdkumPS9CLmBd2PS-1200-80.jpg.webp)

(Image credit: Disney+)

## Meilin "Mei" Lee (Turning Red)

Roaslie Chiang voices the Chinese-Canadian teen Mei in the 2022 Pixar film, *Turning Red*, which is noted for its clever allusions to the struggles of female adolescence. The title refers to the unusual effects of a family curse that causes Mei to transform into a large Red Panda when she becomes flustered with strong emotions.

![The cat in Hocus Pocus.](https://cdn.mos.cms.futurecdn.net/wgwqAjuQfsQUzEabhgXqT3-1200-80.jpg.webp)

(Image credit: Disney)

## Thackery Binks (Hocus Pocus)

I don't think there is a single character from 1993's *Hocus Pocus* who has it worse than Thackery Binks (played in human form by Sean Murray and later voiced by Jason Marsden). Right after they drain the youth and life from his sister, Emily (Amanda Shepherd), the Sanderson Sisters (Bette Midler, [Sarah Jessica Parker](https://www.cinemablend.com/tag/sarah-jessica-parker), and Kathy Najimy) curse the 17th-century boy with both the form of a black cat and eternal life.

![Justin Long in Tusk](https://cdn.mos.cms.futurecdn.net/YAVcE5UVgoe5EBhFuQrMbD-1200-80.jpg.webp)

(Image credit: A24)

## Wallace Bryton (Tusk)

In writer and director Kevin Smith's absurdly quirky, but deeply unsettling 2014 [A24 horror movie](https://www.cinemablend.com/movies/the-best-a24-horror-movies-ranked), *Tusk*, Justin Long plays an arrogant podcast host who is transformed into a walrus. Instead of by some strange witchcraft, the metamorphosis is achieved through a surgical procedure and psychological conditioning orchestrated against his will by a crazed former sailor played by Michael Parks.

![Pigs from Spirited Away](https://cdn.mos.cms.futurecdn.net/X9pYNKEhALZBD9PcdHtGT6-1200-80.jpg.webp)

(Image credit: Studio Ghibli)

## Akio And Yūko (Spirited Away)

One of the most acclaimed Studio Ghibli films is Hayao Miyazaki's 2001 fantasy adventure, *Spirited Away*, in which young Chihiro finds herself trapped in a mystical realm where her parents are turned into pigs after greedily eating a feast not meant for them.

![Queen Elinor in Brave.](https://cdn.mos.cms.futurecdn.net/R54ntaFZKjCrF2QbJ5nzBY-1200-80.jpg.webp)

(Image credit: Pixar)

## Queen Elinor (Brave)

In Pixar's Oscar-winning animated fantasy epic, *Brave*, Princess Merida (Kelly Macdonald) must rely on her boldness and her impeccable archery skills to find a cure for a curse that has turned her mother, Queen Elinor (Emma Thompson), into a bear.

![Bob from The Lobster](https://cdn.mos.cms.futurecdn.net/kCMhapd7AkCwEnebHiquu3-1200-80.jpg.webp)

(Image credit: A24)

## Bob (The Lobster)

Yorgos Lanthimos' 2016 satirical fantasy *The Lobster* takes place in a dystopian society in which romantic partnerships are mandatory, and anyone still single by a certain time is required to be surgically transformed into the animal of their choosing. The recently divorced David (Colin Farrell) attends a retreat intended to help him find a mate, where he is accompanied by a dog, who is actually his brother, Bob, who "did not make it" through the same program.

![Irena looking into panther cage at the zoo in Cat People](https://cdn.mos.cms.futurecdn.net/iatuB3vGxRCf3WFzGpvfRP-1200-80.jpg.webp)

(Image credit: Prime Video)

## Irena Gallier (Cat People)

Based on a 1942 [horror movie classic](https://www.cinemablend.com/new/30-Best-Horror-Movies-All-Time-122567.html) of the same name, director Paul Schrader's 1982 thriller *Cat People* stars Nastassja Kinski and Malcolm McDowell as descendants of a people who turn into panthers after engaging in steamy encounters. The only way to revert back to their human form, however, is to commit murder.

![Sarah Michelle Gellar as The First Evil in Buffy the Vampire Slayer Season 7](https://cdn.mos.cms.futurecdn.net/bwLPrredzRr6FHXBPwpkr9-1200-80.png.webp)

(Image credit: 20th Century Fox Television)

## Buffy Summers (Buffy The Vampire Slayer)

In a Season 2 episode of *Buffy the Vampire Slayer*, the teen paranormal activity hunter (played by Sarah Michelle Gellar) is accidentally transformed into a rat after her friend, Xander Harris (Nicholas Brendon), botches a spell.

![Debbie Stevens in A Nightmare On Elm Street 4: The Dream Master](https://cdn.mos.cms.futurecdn.net/q7qM3UmqE49TC3XEUjUBNQ-1200-80.jpg.webp)

(Image credit: New Line Cinema)

## Debbie Stevens (A Nightmare On Elm Street 4: The Dream Master)

Technically, teen athlete Debbie Stevens (Brooke Theiss) experiences a transformation into a cockroach before she is caught and crushed by Freddy Krueger (Robert Englund) in a dream sequence from the fourth *A Nightmare on Elm Street* movie. Then again, however, the burned boogeyman kills a victim from within their subconscious becomes how they die in reality, so I'll count it.

![Benjean in Oh Heavenly Dog](https://cdn.mos.cms.futurecdn.net/VAGnD27dAyupdiqeUrYNsE-1200-80.jpg.webp)

(Image credit: 20th Century Fox)

## Benjamin Browning (Oh! Heavenly Dog)

In 1980's *Oh! Heavenly Dog*, Chevy Chase plays a recently deceased private investigator named Ben Browning who is given the chance to be sent back to Earth to solve his own murder case. However, he is reincarnated not in human form but in the body of a dog played by Benjean, who is the daughter of the original canine actor who played Benji, Higgins.

![Timothy Spall as Wormtail in Harry Potter and the Prisoner of Azkaban](https://cdn.mos.cms.futurecdn.net/LPdoXsgZ222MRsFWYsvr8J-1200-80.jpg.webp)

(Image credit: Warner Bros. Pictures)

## Peter Pettigrew (The Harry Potter Movies)

In *Harry Potter and the Prisoner of Azkaban*, Ron Weasley discovers that his pet rat, Scabbers, has been a disguised servant of Voldemort named Peter Pettigrew, played by Timothy Spall, the entire time.

![Merlin and Arthur are squrrels in The Sword in the Stone](https://cdn.mos.cms.futurecdn.net/uaXuoWPT4kStSpcfeoJcoZ-1200-80.jpg.webp)

(Image credit: Disney)

## Wart (The Sword In The Stone)

In Disney's 1963 animated fantasy film, *The Sword in the Stone*, Wart (voiced by Rickie Sorensen), the boy who would be King Arthur, is mentored by the powerful wizard, Merlin (Karl Swenson), through a series of lessons that involve being transformed into various animals, including fish and squirrels.

![Edmond after becoming a cat in Rock-a-Doodle](https://cdn.mos.cms.futurecdn.net/9QsP84o6sSFsCfFNp99ZhB-1200-80.jpg.webp)

(Image credit: The Samuel Goldwyn Company)

## Edmond (Rock-A-Doodle)

In Don Bluth's 1991 animated musical fantasy, *Rock-a-Doodle*, an 8-year-old farm boy named Edmond (Toby Scott Ganger) is magically transformed into a cat by the Grand Duke of Owls (Christopher Plummer), leading him to seek the help of an anthropomorphic, singing rooster named Chanticleer (Glenn Campbell).

![Luke as a rat in The Witches](https://cdn.mos.cms.futurecdn.net/hJC3Ds6RSvdrsjYEVHxoMX-1200-80.jpg.webp)

(Image credit: Warner Bros.)

## Luke Eveshim (The Witches)

In the 1990 [not-so-scary witch movie](https://www.cinemablend.com/movies/not-so-scary-witch-movies-to-watch) based on Roald Dahl's novel, *The Witches* (which is still pretty traumatizing for younger audiences), young Luke Eveshim (Jasen Fisher) is caught spying on a group of malevolent spellcasters who punish him by turning him into a mouse.

![Tanya Roberts in Sheena](https://cdn.mos.cms.futurecdn.net/EdwbtaSzY8TwjdBotQsqrP-1200-80.jpg.webp)

(Image credit: Columbia Pictures)

## Sheena (Sheena)

Tanya Roberts stars in the 1984 film, *Sheena*, which later spawned a series adaptation in the early 2000s, as an orphaned woman raised in the jungle since she was a child by a mystical woman who taught her the skill of shape-shifting into various wild beasts.

![The kids from DinoSquad in animal form](https://cdn.mos.cms.futurecdn.net/gTH6wVFR8FwFZNUqRAc3Nb-1200-80.jpg.webp)

(Image credit: DIC)

## The Kids From DinoSquad (DinoSquad)

One might say that the unofficial animated companion to *Animorphs* is a short-lived series called *DinoSquad*, which brings back animals from a bit further back in Earth's history. Airing from 2007 to 2008, the show followed a group of teens who fight crime with their ability to transform into prehistoric creatures.

![Cat from Nine Lives](https://cdn.mos.cms.futurecdn.net/u6sBW7C7ZKg52Ffyfru8KM-1200-80.jpg.webp)

(Image credit: EuropaCorp)

## Tom Brand (Nine Lives)

*Nine Lives* is one of those movies in which a selfish workaholic who never has enough time for his family is transformed into an animal so he can learn how to be a better version of his human self. The 2016 comedy from director Barry Sonnenfeld stars Kevin Spacey as the animalistic metamorphosis victim in question, who is turned into a cat by an eccentric pet shop owner played by Christopher Walken.

![Eddie speaks on 100 Deeds for Eddie McDowd](https://cdn.mos.cms.futurecdn.net/FRSy3QsrU3Uc3KzhKDGixF-1200-80.jpg.webp)

(Image credit: Nickelodeon)

## Eddie McDowd (100 Deeds For Eddie McDowd)

The [underrated Nickelodeon TV show](https://www.cinemablend.com/television/nickelodeon-shows-dont-get-talked-about-today) *100 Deeds for Eddie McDowd* is about a young troublemaker (voiced by Seth Green), who is transformed into a dog by a mystical drifter (played by Richard Moll). Before he can return to his human form, Eddie must complete 100 redemptive tasks, with help from the last kid he bullied (played by Brandon Gilberstadt), who is also the only one he can speak to, which is why he ends up adopting him into his family.