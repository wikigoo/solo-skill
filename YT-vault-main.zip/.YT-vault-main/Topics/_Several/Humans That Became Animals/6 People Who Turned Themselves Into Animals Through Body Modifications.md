---
title: "6 People Who Turned Themselves Into Animals Through Body Modifications"
source: "https://www.tattoodo.com/articles/6-people-who-turned-themselves-into-animals-through-body-modifications-6017"
---
[Body Modifications](https://www.tattoodo.com/c/body-modifications/ "Body Modifications")

Meet the faces who turned themselves into fascinating animals through heavy body modifications.

I'll tell you something; I've always had a thing for wolves. Even before I took one of those spirit animal quizzes, I've already been into them. They fascinate me. They're majestic. I consider getting a wolf tattoo one of these days and some days I feel like a rogue wolf when my introversion kicks in but I never really thought about being *the* wolf. It's quite different with these guys, though. These are the fascinating men and women who took body modifications a bit further than the rest of us, giving the word “spirit animal” a whole different meaning.

**Horace Ridler, The Zebra Man**

![Horace Ridler](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44598.jpg?max-w=1024)

Horace Ridler

Also known as The Great Omi, Horace Ridler is one of the most notable, heavily-tattooed men who ever lived. He started getting tattoos when he served in the British Army. Getting into financial troubles after he served the military made him turn to show business through tattoos.

![Horace Ridler](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44599.jpg?max-w=1024)

Horace Ridler

Ridler paid a visit to London's famed tattooist, George Burchett to make plans to turn himself into the finest tattoo attraction around. Soon after, the splendid work that was done on his body landed him several circus gigs and even a spot on Robert Ripley’s “Believe It Or Not”.

“Underneath it all, I’m just an ordinary man,” he wrote shortly before his death in 1969.

**Tom Woodbridge, Leopard Man**

![Tom Woodbridge](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44600.jpg?max-w=1024)

Tom Woodbridge

Tom Woodbridge (or as he refers to himself—Tom Leppard) was previously named the world’s most tattooed man by Guinness Book of World Records. He made headlines when he decided to spend over £5,000 modifying his body in order to resemble a leopard. He then went on to retire to the Isle of Skye in the Inner Hebridges in 1987, living in a small hut and making kayaking to the mainland only to restock supplies and pick up his pension.

![Tom Woodbridge](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44601.jpg?max-w=1024)

Tom Woodbridge

He left the bothy he lived in for two decades in 2008 but that did not change his mind about reclusion. A friend managed to change his mind and make him live in a larger house in the island and appreciate the convenience of electricity and well-cooked meals.

![Tom Woodbridge](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44602.jpg?max-w=1024)

Tom Woodbridge

“My life hasn’t changed much - I never bothered people when I lived in the bothy, and they didn’t bother me, and I’m not really that interested in what else is going on outside,” he said.

**Erik Sprague, The Lizardman**

![Erik Sprague](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44597.jpg?max-w=1024)

Erik Sprague

In order to pursue artistry, Erik left his doctoral program in philosophy. That decision paved the way to his infamous persona as The Lizardman. Anybody in the community can easily identify him through his green-hued, scale-like tattoos, stretched lobes, reptilian implants, filed teeth, and split tongue.

![Erik Sprague](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44603.jpg?max-w=1024)

Erik Sprague

Erik is well-known for his outstanding one-man shows. He had worked in suspension groups, written columns for BMENews, written a book, and he also has a band called Lizard Skynyrd.

![Erik Sprague](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44604.jpg?max-w=1024)

Erik Sprague

I don't know if it's just me but out of all the guys here, I'd pick this one to hang out with.

**Katzen Hobbes, Catwoman**

![Katzen Hobbes](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/43007.jpg?max-w=1024)

Katzen Hobbes

Katzen is the real-life Catwoman, with over 90% of her body tattooed with black, feline-like stripes. The “whiskers” on her face were made through scarification but Katzen once had genuine tiger whiskers sent to her by zoos around the world. The whiskers were implanted into her cheeks through piercing rings designed to hold them.

![Katzen Hobbes](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/43009.jpg?max-w=1024)

Katzen Hobbes

The transformation of the mother-of-two from Austin, Texas took over a decade. To get all her feline striped, Katzen had to go to more than 160 tattoo artists to complete them—with 23 tattoo artists working on her at the same time at one point. During one of the procedures, we're not surprised to hear she fainted on several occasions from the pain and the pressure put on her.

![Katzen Hobbes](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44605.jpg?max-w=1024)

Katzen Hobbes

Move over, Katy Perry. This one's bound to roar.

**Dennis Avner, Stalking Cat**

![Dennis Avner](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/1080/44606.jpg?max-w=1024)

Dennis Avner

The late Dennis Avner was one of the most recognised faces in body modifications. I remember seeing him in my favourite series of Ripley's all the time when I was a kid. He spent so many years trying to morph into looking like a female cat—a female tiger, to be exact.

![Dennis Avner](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/1080/44607.jpg?max-w=1024)

Dennis Avner

Which is why I was sorry to hear that he took his own life back in 2012. His wish to transform himself into a feline-like creature was sparked up by a conversation he had with a Native Indian chief, advising him to “follow the ways of the tiger.”

**Ted Richards, Parrot Man**

![Ted Richards](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/1080/44608.jpg?max-w=1024)

Ted Richards

Ted Richards is a retired shoe factory worker with a lot of love to give for his pet parrots. We mean it. It's not the usual love some pet owners over pour on their pets. You don't get it. Ted wants to look like his pets.

![Ted Richards](https://d1kq2dqeox7x40.cloudfront.net/images/news_uploads/legacy/0/44609.jpg?max-w=1024)

Ted Richards

That's exactly why he had several dermal implants, got both his ears cut off, and inked his eyeballs several shades of peculiar. The 56-year-old currently has 110 tattoos, 50 piercings, and a split tongue. He's currently looking for a surgeon who could turn his nose into a beak.