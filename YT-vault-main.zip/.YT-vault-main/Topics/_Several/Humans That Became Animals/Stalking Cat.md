---
title: "Stalking Cat"
source: "https://en.wikipedia.org/wiki/Stalking_Cat"
---
**Stalking Cat** (born **Dennis Avner**; August 27, 1958 – November 5, 2012) [^1] was an American man known for his extensive [body modifications](https://en.wikipedia.org/wiki/Body_modification "Body modification"), which were intended to increase his resemblance to a [tiger](https://en.wikipedia.org/wiki/Tiger "Tiger").[^2] For his 14 surgical procedures towards that goal, he held a [world record](https://en.wikipedia.org/wiki/World_record "World record") for "most permanent transformations to look like an animal".[^3] [^4] [^5] "Stalking Cat" was his chosen name.

## Biography

Avner was born in [Flint, Michigan](https://en.wikipedia.org/wiki/Flint,_Michigan "Flint, Michigan"), and grew up in [Suttons Bay, Michigan](https://en.wikipedia.org/wiki/Suttons_Bay_Township,_Michigan "Suttons Bay Township, Michigan"). As an adult, he joined the [Navy](https://en.wikipedia.org/wiki/United_States_Navy "United States Navy") as a [sonar technician](https://en.wikipedia.org/wiki/Sonar_technician "Sonar technician"). He left his Navy post around 1981. He then began working as a computer programmer and technician in [San Diego, California](https://en.wikipedia.org/wiki/San_Diego,_California "San Diego, California").

In the early 1980s, guided by his personal vision and [feelings of affinity for](https://en.wikipedia.org/wiki/Power_animal "Power animal") the tigress, Stalking Cat began tattooing and surgically modifying his face.[^6] In interviews, he repeatedly stated that he chose to alter his physical appearance in accordance with what he believed was an ancient [Wyandot](https://en.wikipedia.org/wiki/Wyandot_people "Wyandot people") tradition;[^2] however, this was his personal belief, not traditional practice. He also told people he grew up in a tribe and had been told to change his form to that of a tiger by a [medicine man](https://en.wikipedia.org/wiki/Medicine_man "Medicine man").[^2] Due to various medical laws, the procedures he had were performed without anaesthetic.[^7]

While living in San Diego, he met Tess Calhoun at a [furry convention](https://en.wikipedia.org/wiki/Furry_convention "Furry convention"). Over several years, he formed a close friendship with Calhoun and her husband, Rick Weiss.[^8] In 2005, Weiss's job with [Boeing](https://en.wikipedia.org/wiki/Boeing "Boeing") required the couple to move to [Washington](https://en.wikipedia.org/wiki/Washington_\(state\) "Washington (state)"), and they asked Stalking Cat, then aged 47, to join them. The trio moved to [Freeland, Washington](https://en.wikipedia.org/wiki/Freeland,_Washington "Freeland, Washington"), on [Whidbey Island](https://en.wikipedia.org/wiki/Whidbey_Island "Whidbey Island"), where Stalking Cat helped fix up their house.[^9]

Stalking Cat, Calhoun, and Weiss were active in the [furry community](https://en.wikipedia.org/wiki/Furry_fandom "Furry fandom"), both online and at conventions. They held monthly gatherings for members of the furry community at their home. He had financial troubles, and in August 2007, he posted publicly on his online journal that he needed a new place to live. Calhoun posted that she and her husband simply could not afford to support him anymore.[^10] [^11] She also posted that they would be throwing him a send-off party.[^12] In September 2007, at age 49, Stalking Cat moved to [Tonopah, Nevada](https://en.wikipedia.org/wiki/Tonopah,_Nevada "Tonopah, Nevada").

## Death

On November 5, 2012, Stalking Cat was found dead in his garage, with a gun on the floor.[^13] [^14] He was 54 years old. News of the death became public one week later. In an online post, *[BMEzine](https://en.wikipedia.org/wiki/BMEzine "BMEzine")* founder [Shannon Larratt](https://en.wikipedia.org/wiki/Shannon_Larratt "Shannon Larratt") wrote that his death was a [suicide](https://en.wikipedia.org/wiki/Suicide "Suicide").[^2]

## Body modifications

### Description of modifications

Many of Stalking Cat's [body modifications](https://en.wikipedia.org/wiki/Body_modification "Body modification") were performed by [Arizona](https://en.wikipedia.org/wiki/Arizona "Arizona") -based artist [Steve Haworth](https://en.wikipedia.org/wiki/Steve_Haworth "Steve Haworth"). The first artist to begin the extensive tattoo work on Stalking Cat's face was Larry Hanks in [San Diego, California](https://en.wikipedia.org/wiki/San_Diego,_California "San Diego, California"), who started the work in 1985.[^15] He had over 14 types of modifications,[^6] including:

- Extensive [tattooing](https://en.wikipedia.org/wiki/Tattoo "Tattoo"), including facial tattooing
- Facial [subdermal implants](https://en.wikipedia.org/wiki/Subdermal_implant "Subdermal implant") to change the shape of his brow, forehead, and the bridge of his nose
- Flattening his nose, via septum relocation
- Silicone injection in his [lips](https://en.wikipedia.org/wiki/Lip "Lip"), [cheeks](https://en.wikipedia.org/wiki/Cheeks "Cheeks"), [chin](https://en.wikipedia.org/wiki/Chin "Chin"), and other parts of his face
- Bifurcating (splitting) his upper lip
- Filing and capping his teeth
- Surgically [shaping his ears](https://en.wikipedia.org/wiki/Ear_shaping "Ear shaping"), making his ears pointed and his earlobes elongated
- Surgical hairline modification
- [Piercing](https://en.wikipedia.org/wiki/Lip_piercing "Lip piercing") his upper lip and [transdermal implants](https://en.wikipedia.org/wiki/Transdermal_implant "Transdermal implant") on his forehead, to facilitate wearing [whiskers](https://en.wikipedia.org/wiki/Whiskers "Whiskers")
- Wearing green [contact lenses](https://en.wikipedia.org/wiki/Contact_lenses "Contact lenses") with slit irises
- Wearing a robotic tail

Future modification plans included implants on top of his head, to facilitate the mounting of tiger-like ears.[^16]

### Medical ethics concerns

Glenn McGee, director of the Center for Bioethics at [Albany Medical College](https://en.wikipedia.org/wiki/Albany_Medical_College "Albany Medical College") in New York, said: "Cosmetic surgery is a practice based on informed consent that needs to balance the risks with the benefits. It is possible to have a coherent view that is nonetheless detrimental to one's well-being. This is a patient who's being harmed by medicine in the interest of his tradition." [^8]

[^1]: Parry, Laurence "GreenReaper" (2012-11-12). ["Stalking Cat confirmed dead at 54"](https://www.flayrah.com/4432/stalking-cat-confirmed-dead-54). *Flayrah*. Retrieved 2013-10-16.

[^2]: Larratt, Shannon (2012-11-12). ["RIP Stalking Cat"](http://news.bme.com/2012/11/12/rip-stalking-cat/). *ModBlog*. [BMEzine](https://en.wikipedia.org/wiki/BMEzine "BMEzine"). Retrieved 7 November 2013.

[^3]: D'Arminio, Aubry (2008-09-30). ["Take the 'Guinness World Records 2009' pop-culture quiz!"](http://popwatch.ew.com/2008/09/30/guinness-world/). *Popwatch*. [Entertainment Weekly](https://en.wikipedia.org/wiki/Entertainment_Weekly "Entertainment Weekly"). Retrieved 2013-10-16.

[^4]: [Dolan, Mark](https://en.wikipedia.org/wiki/Mark_Dolan "Mark Dolan"). ["The World's Strangest Plastic Surgery and Me (episode guide)"](http://www.channel4.com/programmes/the-worlds-and-me/episode-guide/series-3/episode-1). *The World's... and Me*. [Channel 4](https://en.wikipedia.org/wiki/Channel_4 "Channel 4"). Retrieved 2013-10-16.

[^5]: ["It's a weird world of world records"](http://www.couriermail.com.au/entertainment/weird/its-a-weird-world/story-e6frep26-1111117540062). *The Sunday Mail*. [Courier Mail](https://en.wikipedia.org/wiki/The_Courier-Mail "The Courier-Mail"). 2008-09-21. Retrieved 2013-11-07.

[^6]: ["Dennis Avner"](http://surgerybeforeafter.com/dennis-avner-plastic-surgery-disaster/). *Surgery Before After*. Retrieved 15 November 2017.

[^7]: ["BBC - Science & Nature - Human Body and Mind - Obsessions - Gallery"](https://www.bbc.co.uk/science/humanbody/mind/articles/disorders/gallery/gallery_case2.shtml). *www.bbc.co.uk*. Retrieved 2025-01-12.

[^8]: Casavant, Vanessa Renée (2005-08-16). ["Catman's transformation raises concerns over extreme surgery"](https://web.archive.org/web/20120728070817/http://seattletimes.nwsource.com/html/localnews/2002441727_catman16.html). *[The Seattle Times](https://en.wikipedia.org/wiki/The_Seattle_Times "The Seattle Times")*. Archived from [the original](http://seattletimes.nwsource.com/html/localnews/2002441727_catman16.html) on 2012-07-28. Retrieved 7 November 2013.

[^9]: Stensland, Jessie (2008-07-02). ["Catman pounces on Whidbey"](https://web.archive.org/web/20131029202632/http://www.whidbeynewstimes.com/news/22830289.html). *[Whidbey News-Times](https://en.wikipedia.org/wiki/Whidbey_News-Times "Whidbey News-Times")*. [Sound Publishing, Inc.](https://en.wikipedia.org/wiki/Sound_Publishing,_Inc. "Sound Publishing, Inc.") Archived from [the original](http://www.whidbeynewstimes.com/news/22830289.html) on 29 October 2013. Retrieved 7 November 2013.

[^10]: Calhoun, Tess (2007-07-22). ["Told Stalkingcat he must move"](http://tesstheredpony.livejournal.com/264431.html). *Tess the Red Pony*. [LiveJournal](https://en.wikipedia.org/wiki/LiveJournal "LiveJournal"). Retrieved 7 November 2013.

[^11]: Calhoun, Tess (2007-08-13). ["LiveJournal comment; "If you want the facts...""](http://stalkingcat.livejournal.com/2653.html?thread=68957#t68957). *Stalking Cat*. [LiveJournal](https://en.wikipedia.org/wiki/LiveJournal "LiveJournal"). Retrieved 7 November 2013.

[^12]: Calhoun, Tess (2007-09-28). ["GRRRRRRRRRRRRRRRRRRRRRs"](http://tesstheredpony.livejournal.com/271813.html). *Tess the Red Pony*. LiveJournal. Retrieved 7 November 2013.

[^13]: Hastings, LP (2012-11-12). ["Dennis Avner aka "Stalking Cat" Found Dead; On his Time in OC"](https://web.archive.org/web/20151202094236/http://blogs.ocweekly.com/navelgazing/2012/11/dennis_avner_stalking_cat.php). [OC Weekly](https://en.wikipedia.org/wiki/OC_Weekly "OC Weekly"). Archived from [the original](http://blogs.ocweekly.com/navelgazing/2012/11/dennis_avner_stalking_cat.php) on 2015-12-02. Retrieved 7 November 2013.

[^14]: ["Passages: Dennis Avner, Stalking Cat, dead at 54"](http://eastcountymagazine.org/node/11720). *[East County Magazine](https://en.wikipedia.org/wiki/East_County_Magazine?action=edit&redlink=1 "East County Magazine (page does not exist)")*. 2012-11-14. Retrieved 7 November 2013.

[^15]: [http://westcoastinkmag.com/larry-hanks/](http://westcoastinkmag.com/larry-hanks/)

[^16]: ["The World's Strangest Plastic Surgery and Me"](https://youtube.com/watch?v=wyI0CMwTi7A&t=35m18s). *Youtube*. Retrieved 21 December 2017.