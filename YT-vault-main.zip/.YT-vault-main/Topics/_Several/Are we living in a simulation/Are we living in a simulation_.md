---
title: "Are we living in a simulation?"
source: "https://ed.ted.com/lessons/are-we-living-in-a-simulation-zohreh-davoudi?lesson_collection=questions-no-one-yet-knows-the-answers-to#review"
---
## Want a daily email of lesson plans that span all subjects and age groups?

## Are we living in a simulation? - Zohreh Davoudi

**1,431,713** Views

**4,539** Questions Answered

TEDEd Animation

---

## Let’s Begin…

All life on Earth— living and inanimate, microscopic and cosmic— is governed by mathematical laws with apparently arbitrary constants. And this opens up a question: If the universe is completely governed by these laws, couldn’t a powerful enough computer simulate it exactly? Could our reality actually be a detailed simulation set in place by a more advanced civilization? Zohreh Davoudi investigates.

 
![](https://www.youtube.com/watch?v=yGfTDcHJHSI)

200

Create and share a new lesson based on this one.

## About TED-Ed Animations

TED-Ed Animations feature the words and ideas of educators brought to life by professional animators. Are you an educator or animator interested in creating a TED-Ed Animation? [Nominate yourself here »](https://ed.ted.com/nominate_an_educator)

## Meet The Creators

Director

[Eoin Duffy](https://www.ted.com/profiles/1504437)

Educator

Zohreh Davoudi

Narrator

Christina Greer

Sound Designer

QB Sound

Music

QB Sound