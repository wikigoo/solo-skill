---
title: "Bengal famine of 1943"
source: "https://en.wikipedia.org/wiki/Bengal_famine_of_1943"
---
The **Bengal famine of 1943** was a [famine](https://en.wikipedia.org/wiki/Famine_in_India "Famine in India") during [World War II](https://en.wikipedia.org/wiki/World_War_II "World War II") in the [Bengal Province](https://en.wikipedia.org/wiki/Bengal_Presidency "Bengal Presidency") and [Orissa Province](https://en.wikipedia.org/wiki/Orissa_Province "Orissa Province") of [British India](https://en.wikipedia.org/wiki/British_India "British India"). An estimated 800,000–3.8 million people died,[^1] in the Bengal region (present-day [Bangladesh](https://en.wikipedia.org/wiki/Bangladesh "Bangladesh") and [West Bengal](https://en.wikipedia.org/wiki/West_Bengal "West Bengal")), from [starvation](https://en.wikipedia.org/wiki/Starvation "Starvation"), [malaria](https://en.wikipedia.org/wiki/Malaria "Malaria") and other diseases aggravated by [malnutrition](https://en.wikipedia.org/wiki/Malnutrition "Malnutrition"), [population displacement](https://en.wikipedia.org/wiki/Population_displacement "Population displacement"), unsanitary conditions, poor British wartime policies, and lack of health care.[^29] Millions were impoverished as the crisis overwhelmed large segments of the economy and catastrophically disrupted the social fabric. Eventually, families disintegrated; men sold their small farms and left home to look for work or to join the [British Indian Army](https://en.wikipedia.org/wiki/British_Indian_Army "British Indian Army"), and women and children became homeless migrants, often travelling to [Calcutta](https://en.wikipedia.org/wiki/Kolkata "Kolkata") or other large cities in search of organised relief.

Bengal's economy had been predominantly [agrarian](https://en.wikipedia.org/wiki/Agrarian_society "Agrarian society") at that time, with between half and three-quarters of the rural poor subsisting in a "semi-starved condition". Stagnant agricultural productivity and a stable land base were unable to cope with a rapidly increasing population, resulting in both long-term decline in per capita availability of rice and growing numbers of the land-poor and landless labourers. A high proportion laboured beneath a chronic and spiralling cycle of debt that ended in [debt bondage](https://en.wikipedia.org/wiki/Debt_bondage "Debt bondage") and the loss of their landholdings due to [land grabbing](https://en.wikipedia.org/wiki/Land_grabbing "Land grabbing").

The financing of military escalation led to wartime inflation. Many workers received monetary wages rather than payment in kind with a portion of the harvest. When prices rose sharply, their wages failed to follow suit; this drop in [real wages](https://en.wikipedia.org/wiki/Real_wages "Real wages") left them less able to purchase food. During the [Japanese occupation of Burma](https://en.wikipedia.org/wiki/Japanese_occupation_of_Burma "Japanese occupation of Burma"), many rice imports were lost as the region's market supplies and transport systems were disrupted by British " [denial policies](#March_1942:_Denial_policies) " for rice and boats (by some [critiques](#Historiography) considered a " [scorched earth](https://en.wikipedia.org/wiki/Scorched_earth "Scorched earth") " response to the occupation). The British also implemented inflation policies during the war aimed at making more resources available for Allied troops. These policies, along with other economic measures, created the "forced transferences of purchasing power" to the military from ordinary people, reducing their food consumption.[^30] [^31] [^32] The Bengal Chamber of Commerce (composed mainly of British-owned firms), with the approval of the Government of Bengal, devised a Foodstuffs Scheme to provide preferential distribution of goods and services to workers in high-priority roles such as armed forces, war industries, civil servants and other "priority classes", to prevent them from leaving their positions. These factors were compounded by restricted access to grain: domestic sources were constrained by emergency inter-provincial [trade barriers](https://en.wikipedia.org/wiki/Embargo "Embargo"), while aid from [Churchill's war cabinet](https://en.wikipedia.org/wiki/Churchill_war_ministry "Churchill war ministry") was limited, [ostensibly](#1942–1944:_Refusal_of_imports) due to a wartime shortage of shipping. More proximate causes included [large-scale natural disasters in south-western Bengal](https://en.wikipedia.org/wiki/List_of_Bangladesh_tropical_cyclones "List of Bangladesh tropical cyclones") (a [cyclone](https://en.wikipedia.org/wiki/Cyclone "Cyclone"), [tidal waves](https://en.wikipedia.org/wiki/Storm_surge "Storm surge") and flooding, and [rice crop disease](https://en.wikipedia.org/wiki/Cochliobolus_miyabeanus "Cochliobolus miyabeanus")). The relative impact of each of these factors on the death toll is a [matter of debate](#Historiography).

The provincial government never formally declared a state of famine, and its [humanitarian aid](https://en.wikipedia.org/wiki/Humanitarian_aid "Humanitarian aid") was ineffective through the worst months of the crisis. It attempted to fix the price of rice [paddy](https://en.wikipedia.org/wiki/Paddy_\(unmilled_rice\) "Paddy (unmilled rice)") through price controls which resulted in a [black market](https://en.wikipedia.org/wiki/Black_market "Black market") which encouraged sellers to withhold stocks, leading to [hyperinflation](https://en.wikipedia.org/wiki/Hyperinflation "Hyperinflation") from [speculation](https://en.wikipedia.org/wiki/Speculation "Speculation") and [hoarding](https://en.wikipedia.org/wiki/Hoarding_\(economics\) "Hoarding (economics)") after controls were abandoned. Aid increased significantly when the British Indian Army took control of funding in October 1943, but effective relief arrived after a record rice harvest that December. Deaths from starvation declined, yet over half the famine-related deaths occurred in 1944 after the [food security](https://en.wikipedia.org/wiki/Food_security "Food security") crisis had abated, as a result of disease. British Prime Minister [Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill "Winston Churchill") has been criticised for his role in the famine, with critics arguing that his war priorities and the refusal to divert food supplies to Bengal significantly worsened the situation.[^33] [^29] [^34] [^35]

## Background

From the late 19th century through the [Great Depression](https://en.wikipedia.org/wiki/Great_Depression "Great Depression"), social and economic forces exerted a harmful impact on the structure of Bengal's income distribution and the ability of its agricultural sector to sustain the populace. These processes included increasing household debt,[^36] a rapidly growing population, stagnant agricultural productivity, increased social stratification, and alienation of the peasant class from their landholdings.[^37] The interaction of these left clearly defined social and economic groups mired in poverty and indebtedness, unable to cope with economic shocks or maintain their access to food beyond the near term. In 1942 and 1943, in the immediate and central context of the Second World War, the shocks Bengalis faced were numerous, complex and sometimes sudden.[^38] [^39] Millions were vulnerable to starvation.[^36]

![ Two shirtless men standing partially concealed behind three buffaloes in a very large rice field. All are in ankle-deep water.](https://en.wikipedia.org/wiki/File:Farmers_and_Water_Buffalo_Plowing_a_Rice_Field_by_Frank_Bond.jpg)

Rice farmers ploughing a rice field with water buffaloes near Gushkara, Bengal, 1944

The Government of India's Famine Inquiry Commission report (1945) described Bengal as a "land of rice growers and rice eaters".[^2] Rice dominated the agricultural output of the province, accounting for nearly 88% of its [arable land](https://en.wikipedia.org/wiki/Arable_land "Arable land") use [^40] and 75% of its crops.[^3] Overall, Bengal produced one third of India's rice – more than any other single province.[^40] Rice accounted for 75–85% of daily food consumption,[^41] with fish being the second major food source,[^42] [^43] supplemented by small amounts of wheat.[^4]

There are three [seasonal rice crops](https://en.wikipedia.org/wiki/Rice#Ecotypes_and_cultivars "Rice") in Bengal. By far the most important is the winter crop of *aman* rice. Sown in May and June and harvested in November and December, it produces about 70% of the total annual crop.[^44] Crucially, the [(debated) shortfall](#1942–1943:_Shortfall_and_carryover) in rice production in 1942 occurred during the all-important *aman* harvest.[^45]

Rice yield per acre had been stagnant since the beginning of the twentieth century;[^46] coupled with a rising population, this created pressures that were a leading factor in the famine.[^47] [^48] Bengal had a population of about 60 million [^49] [^50] in an area of 77,442 square miles, according to a 1941 census.[^51] [^5] Declining mortality rates, induced in part by the pre-1943 success of the [British Raj](https://en.wikipedia.org/wiki/British_Raj "British Raj") in famine reduction [^52] [^53] caused its population to increase by 43% between 1901 and 1941 – from 42.1 million to 60.3 million. Over the same period India's population as a whole increased by 37%.[^54] [^6] The economy was almost solely agrarian,[^36] [^55] but agricultural productivity was among the lowest in the world.[^56] Agricultural technology was undeveloped, access to credit was limited and expensive, and any potential for government aid was hampered by political and financial constraints.[^57] Land quality and fertility had been deteriorating in Bengal and other regions of India, but the loss was especially severe here. [Agricultural expansion](https://en.wikipedia.org/wiki/Agricultural_expansion "Agricultural expansion") required deforestation and land reclamation. These activities damaged the natural drainage courses, silting up rivers and the channels that fed them, leaving them and their fertile deltas moribund.[^58] [^59] The combination of these factors caused stubbornly low agricultural productivity.[^60] [^61] [^62]

Prior to about 1920, the food demands of Bengal's growing population could be met in part by cultivating unused scrub lands.[^63] No later than the first quarter of the twentieth century, Bengal began to experience an acute shortage of such land,[^64] [^65] leading to a chronic and growing shortage of rice.[^66] Its inability to keep pace with rapid population growth changed it from a net exporter of foodgrains to a net importer. Imports were a small portion of the total available food crops, however, and did little to alleviate problems of food supply.[^67] Bengali doctor and chemist Chunilal Bose, a professor in Calcutta's medical college, estimated in 1930 that both the ingredients and the small total amount of food in the Bengali diet made it among the least nutritious in India and the world, and greatly harmful to the physical health of the populace.[^68] [Economic historian](https://en.wikipedia.org/wiki/Economic_historian "Economic historian") [Cormac Ó Gráda](https://en.wikipedia.org/wiki/Cormac_%C3%93_Gr%C3%A1da "Cormac Ó Gráda") writes, "Bengal's rice output in normal years was barely enough for bare-bones subsistence... the province's margin over subsistence on the eve of the famine was slender." [^69] These conditions left a large proportion of the population continually on the brink of malnutrition or even starvation.[^55]

### Land-grabbing

Structural changes in the credit market and land transfer rights pushed Bengal into recurring danger of famine and dictated which economic groups would suffer greatest hardship.[^70] [^71] The British Indian system of [land tenure](https://en.wikipedia.org/wiki/Land_tenure "Land tenure"), particularly in Bengal,[^72] was very complex, with rights unequally divided among three diverse economic and social groups: traditional absentee large landowners or *[zamindars](https://en.wikipedia.org/wiki/Zamindar "Zamindar")*; the upper-tier "wealthy peasant" *[jotedars](https://en.wikipedia.org/wiki/Jotedar "Jotedar")*; and, at the lower socioeconomic level, the *[ryot](https://en.wikipedia.org/wiki/Ryot "Ryot")* (peasant) smallholders and dwarfholders, *bargadars* ([sharecroppers](https://en.wikipedia.org/wiki/Sharecropper "Sharecropper")), and agricultural labourers.[^73] *Zamindar* and *jotedar* landowners were protected by law and custom,[^74] but those who cultivated the soil, with small or no landholdings, suffered persistent and increasing losses of land rights and welfare. During the late nineteenth and early twentieth centuries, the power and influence of the landowners fell and that of the *jotedars* rose. Particularly in less developed regions, *jotedars* gained power as grain or jute traders and, more importantly, by making loans to sharecroppers, agricultural labourers and ryots.[^75] [^7] They gained power over their tenants using a combination of [debt bondage](https://en.wikipedia.org/wiki/Debt_bondage "Debt bondage") through the transfer of debts and mortgages, and parcel-by-parcel land-grabbing.[^76]

Land-grabbing usually took place via informal credit markets. Many financial entities had disappeared during the Great Depression; peasants with small landholdings generally had to resort to informal local lenders [^77] to purchase basic necessities during lean months between harvests.[^78] As influential Bengali businessman [M. A. Ispahani](https://en.wikipedia.org/wiki/Mirza_Ahmad_Ispahani "Mirza Ahmad Ispahani") testified, "...the Bengal cultivator, \[even\] before the war, had three months of feasting, five months of subsistence diet and four months of starvation".[^79] Moreover, if a labourer did not possess goods recoverable as cash, such as seed or cattle for ploughing, he would go into debt.[^80] Particularly during poor crops, smallholders fell into cycles of debt, often eventually forfeiting land to creditors.[^81]

Small landholders and sharecroppers acquired debts swollen by usurious rates of interest.[^82] [^8] Any poor harvest exacted a heavy toll; the accumulation of consumer debt, seasonal loans and crisis loans began a cycle of spiralling, perpetual indebtedness. It was then relatively easy for the *jotedars* to use litigation to force debtors to sell all or part of their landholdings at a low price or forfeit them at auction. Debtors then became landless or land-poor sharecroppers and labourers, usually working the same fields they had once owned.[^83] The accumulation of household debt to a single, local, informal creditor bound the debtor almost inescapably to the creditor/landlord; it became nearly impossible to settle the debt after a good harvest and simply walk away. In this way, the *jotedars* effectively dominated and impoverished the lowest tier of economic classes in several districts of Bengal.[^84]

Such exploitation, exacerbated by Muslim inheritance practices that divided land among multiple siblings,[^85] widened inequalities in land ownership.[^86] At the time, millions of Bengali agriculturalists held little or no land.[^9] In absolute terms, the social group which suffered by far the most of every form of impoverishment and death during the Bengal famine of 1943 were the landless agricultural labourers.[^87]

### Transport

![Satellite imagery from 1999 of the Sundarbans forest along the Bay of Bengal, showing its riverine character](https://en.wikipedia.org/wiki/File:Sundarbans.jpg)

Satellite view of the Sundarbans

Water provided the main source of transport during rainy seasons, and throughout the year in areas such as the vast delta of the coastal southeastern [Sundarbans](https://en.wikipedia.org/wiki/Sundarbans "Sundarbans"). River transport was integral to Bengal's economy, an irreplaceable factor in the production and distribution of rice.[^88] Roads were generally scarce and in poor condition,[^89] and Bengal's extensive railway system was employed largely for military purposes until the very late stages of the crisis.[^90]

The development of [railways in Bengal](https://en.wikipedia.org/wiki/Rail_transport_in_India "Rail transport in India") in the 1890s disrupted natural drainage and divided the region into innumerable poorly drained "compartments".[^91] Rail indirectly brought about excessive silting, which increased flooding and created stagnant water areas, damaging crop production and sometimes contributing to a partial shift away from the productive *aman* rice cultivar towards less productive cultivars, and also created a more hospitable environment for water-borne diseases such as [cholera](https://en.wikipedia.org/wiki/Cholera "Cholera") and [malaria](https://en.wikipedia.org/wiki/Malaria "Malaria").[^92]

### Soil and water supply

East Bengal and west Bengal have different soils. The sandy soil of the east, and the lighter sedimentary earth of the Sundarbans, tended to drain more rapidly after the monsoon season than the [laterite](https://en.wikipedia.org/wiki/Laterite "Laterite") or heavy clay regions of western Bengal.[^93] [Soil exhaustion](https://en.wikipedia.org/wiki/Soil_exhaustion "Soil exhaustion") necessitated that large tracts in western and central Bengal be left fallow; eastern Bengal had far fewer uncultivated fields. The annual flooding of these fallow fields created a breeding place for malaria-carrying mosquitoes;[^94] malaria epidemics lasted a month longer in the central and western areas with slower drainage.[^93]

Rural areas lacked access to safe water supplies. Water came primarily from large earthen tanks, rivers and [tube wells](https://en.wikipedia.org/wiki/Tube_well "Tube well"). In the dry season, partially drained tanks became a further breeding area for malaria- [vector](https://en.wikipedia.org/wiki/Vector_\(epidemiology\) "Vector (epidemiology)") mosquitoes.[^95] Tank and river water was susceptible to contamination by cholera; with tube wells being much safer.[^96] However, as many as one-third of the existing wells in wartime Bengal were in disrepair.[^96]

## Pre-famine shocks and distress

Throughout 1942 and early 1943, military and political events combined with natural disasters and plant disease began to place widespread stress on Bengal's economy.[^97] While Bengal's food needs rose from increased military presence and an influx of refugees from Burma,[^98] its ability to obtain rice and other grains was restricted by inter-provincial trade barriers.[^99]

### Japanese invasion of Burma

![ A small, naked, pot-bellied boy runs beside a line of men carrying large bundles on their heads. Some of the men are also running. All are on a road. A military vehicle is partially visible beside them.](https://en.wikipedia.org/wiki/File:Burmese_refugees_flee_along_the_Prome_Road_into_India,_January_1942.jpg)

Indian refugees flee Burma along the Prome Road from Rangoon to Mandalay and eventually on to India, January 1942.

The Japanese campaign for Burma set off an exodus of more than half of the one million Indians from Burma for India.[^100] The flow began after the [bombing of Rangoon (1941–1942)](https://en.wikipedia.org/wiki/Bombing_of_Rangoon_\(1941%E2%80%931942\) "Bombing of Rangoon (1941–1942)"), and for months thereafter desperate people poured across the borders, escaping into India through Bengal and Assam.[^101] On 26 April 1942, all Allied forces were ordered to retreat from Burma into India.[^102] Military transport and other supplies were dedicated to military use, and unavailable for use by the refugees.[^103] By mid May 1942, the monsoon rains became heavy in the Manipur hills, further inhibiting civilian movement.[^104]

The number of refugees who successfully reached India totalled at least 500,000; tens of thousands died along the way. In later months, 70 to 80% of these refugees were afflicted with diseases such as dysentery, smallpox, malaria, or cholera, with 30% "desperately so".[^105] The influx of refugees created several conditions that may have contributed to the famine. Their arrival created an increased demand for food,[^98] clothing and medical aid, further straining the resources of the province.[^106] The poor hygienic conditions of their forced journey sparked official fears of a public health risk due to epidemics caused by social disruption.[^107] Finally, their distraught state after their struggles [^108] bred foreboding, uncertainty, and panic amongst the populace of Bengal; this aggravated panic buying and hoarding that may have contributed to the onset of the famine.[^108]

By April 1942, Japanese warships and aircraft had sunk approximately 100,000 tons of merchant shipping in the Bay of Bengal.[^109] According to [General Archibald Wavell](https://en.wikipedia.org/wiki/Archibald_Wavell,_1st_Earl_Wavell "Archibald Wavell, 1st Earl Wavell"), Commander-in-Chief of the army in India, both the [War Office](https://en.wikipedia.org/wiki/War_Office "War Office") in London and the commander of the British [Eastern Fleet](https://en.wikipedia.org/wiki/Eastern_Fleet "Eastern Fleet") acknowledged that the fleet was powerless to mount serious opposition to Japanese naval attacks on [Ceylon](https://en.wikipedia.org/wiki/Ceylon "Ceylon"), southern or eastern India, or on shipping in the Bay of Bengal.[^109] For decades, rail transport had been integral to successful efforts by the Raj to forestall famine in India.[^53] However, Japanese raids put additional strain on railways, which also endured flooding in the Brahmaputra, a malaria epidemic, and the [Quit India Movement](https://en.wikipedia.org/wiki/Quit_India_Movement "Quit India Movement") targeting road and rail communication.[^110] Throughout this period, transportation of civil supplies was compromised by the railways' increased military obligations, and the dismantling of tracks carried out in areas of eastern Bengal in 1942 to hamper a potential Japanese invasion.[^111]

![ A line-drawing map of India and Burma, with arrows showing the escape routes of civilians during the Japanese invasion.](https://en.wikipedia.org/wiki/File:Indian_exodus_from_Burma_to_Manipur,_Bengal,_and_Assam,_January_to_July_1942.jpg)

Map of Indian civilian exodus from Burma into Manipur, Bengal, and Assam, between January and July 1942.

The [fall of Rangoon](https://en.wikipedia.org/wiki/Japanese_conquest_of_Burma "Japanese conquest of Burma") in March 1942 cut off the import of Burmese rice into India and Ceylon.[^38] Due in part to increases in local populations, prices for rice were already 69% higher in September 1941 than in August 1939.[^112] The loss of Burmese imports led to further increased demand on the rice-producing regions.[^113] This, according to the Famine Commission, was in a market in which the "progress of the war made sellers who could afford to wait reluctant to sell".[^113] The loss of rice imports from Burma, which many districts in Bengal were dependent on,[^114] provoked an aggressive scramble for rice across India, which sparked a dramatic and unprecedented surge in [demand-pull](https://en.wikipedia.org/wiki/Demand-pull_inflation "Demand-pull inflation") price inflation in Bengal and other rice producing regions of India. Across India and particularly in Bengal, this caused a "derangement" of the rice markets.[^115] Particularly in Bengal, the price effect of the loss of Burmese rice was vastly disproportionate to the relatively modest size of the loss in terms of total consumption.[^116] Despite this, Bengal continued to export rice to Ceylon [^10] for months afterwards, even as the beginning of a food crisis began to become apparent.[^11] All this, together with transport problems created by the government's ["boat denial" policy](#March_1942:_Denial_policies), were the direct causes of inter-provincial trade barriers on the movement of food grains,[^117] and contributed to a series of failed government policies that further exacerbated the food crisis.[^118]

### 1942–1945: Military build-up, inflation, and displacement

![ A line of six black American soldiers in service uniform (non-combat) sitting or standing beside the railing at the entrance of a temple. All are taking off their shoes prior to entering the temple.](https://en.wikipedia.org/wiki/File:AmericanSoldiersCalcutta1943.jpg)

American soldiers at the Calcutta Jain Temple, July 1943. Calcutta became a hub for hundreds of thousands of Allied troops.

The fall of Burma brought Bengal close to the war front; its impact fell more strongly on Bengal than elsewhere in India.[^119] Major urban areas, especially Calcutta, drew increasing numbers of workers into military industries and troops from many nations. Unskilled labourers from Bengal and nearby provinces were employed by military contractors, particularly for the construction of American and British airfields.[^120] Hundreds of thousands of American, British, Indian, and Chinese troops arrived in the province,[^121] straining domestic supplies and leading to scarcities across wide ranges of daily necessities.[^122] The general inflationary pressures of a war-time economy caused prices to rise rapidly across the entire spectrum of goods and services.[^123] The rise in prices was "not disturbing" until 1941, when it became more alarming.[^124] Then in early 1943, the rate of inflation for foodgrains in particular took an [unprecedented upward turn](#1942–1943:_Price_chaos).[^125]

Nearly the full output of India's cloth, wool, leather and silk industries were sold to the military.[^126] In the system that the British Government used to procure goods through the Government of India, industries were left in private ownership rather than facing outright requisitioning of their productive capacity. Firms were required to sell goods to the military on credit and at fixed, low prices.[^127] However, firms were left free to charge any price they desired in their domestic market for whatever they had left over. In the case of the textiles industries that supplied cloth for the uniforms of the British military, for example, they charged a very high price in domestic markets.[^127] By the end of 1942, cloth prices had more than tripled from their pre-war levels; they had more than quadrupled by mid-1943.[^128] Much of the goods left over for civilian use were purchased by speculators.[^129] As a result, "civilian consumption of cotton goods fell by more than 23% from the peace time level by 1943/44".[^130] The hardships that were felt by the rural population through a severe " [cloth famine](#Cloth_famine) " were alleviated when military forces began distributing relief supplies between October 1942 and April 1943.[^131]

![Side view of eleven World War II fighter planes parked in a very large field. Soldiers in khaki uniform, wearing shorts, climb atop or sit inside all of them making repairs.](https://en.wikipedia.org/wiki/File:67_Sqn_Hurricanes.jpg)

Hawker Hurricane Mark IIBs and IICs of No. 67 Squadron RAF lined up at Chittagong. Construction of airfields displaced the civilian population and increased inflation.

The method of credit financing was tailored to UK wartime needs. Britain agreed to pay for defence expenditures above the amount that India had paid in peacetime (adjusted for inflation). However, their purchases were made entirely on credit accumulated in the Bank of England and not redeemable until after the war. At the same time, the Bank of India was permitted to treat those credits as assets against which it could print currency up to two and a half times more than the total debt incurred. India's money printing presses then began running overtime, printing the currency that paid for all these massive expenditures. The tremendous rise in nominal money supply coupled with a scarcity of consumption goods spurred [monetary inflation](https://en.wikipedia.org/wiki/Monetary_inflation "Monetary inflation"), reaching its peak in 1944–45.[^132] The accompanying rise in incomes and purchasing power fell disproportionately into the hands of industries in Calcutta (in particular, munitions industries).[^133]

Military build-up caused massive displacement of Bengalis from their homes. Farmland purchased for airstrip and camp construction is "estimated to have driven between 30,000 and 36,000 families (about 150,000 to 180,000 persons) off their land", according to the historian Paul Greenough. They were paid for the land, but they had lost their employment.[^134] The urgent need for housing for the immense influx of workers and soldiers from 1942 onward created further problems. Military barracks were scattered around Calcutta.[^135] The Famine Commission report of 1945 stated that the owners had been paid for these homes, but "there is little doubt that the members of many of these families became famine victims in 1943".[^136]

### March 1942: Denial policies

Anticipating a Japanese invasion of British India via the eastern border of Bengal, the British military launched a pre-emptive, two-pronged [scorched-earth](https://en.wikipedia.org/wiki/Scorched-earth "Scorched-earth") initiative in eastern and coastal Bengal. Its goal was to deny the expected invaders access to food supplies, transport and other resources.[^12]

First, a "denial of rice" policy was carried out in three southern districts along the coast of the Bay of Bengal – [Bakarganj](https://en.wikipedia.org/wiki/Backergunge_District "Backergunge District") (or Barisal), [Midnapore](https://en.wikipedia.org/wiki/Midnapore_district "Midnapore district") and [Khulna](https://en.wikipedia.org/wiki/Khulna_District "Khulna District") – that were expected to have surpluses of rice. [John Herbert](https://en.wikipedia.org/wiki/John_Herbert_\(Conservative_politician\) "John Herbert (Conservative politician)"), the governor of Bengal, issued an urgent [^137] directive in late March 1942 immediately requiring stocks of [paddy](https://en.wikipedia.org/wiki/Paddy_\(unmilled_rice\) "Paddy (unmilled rice)") (unmilled rice) deemed surplus, and other food items, to be removed or destroyed in these districts.[^138] Official figures for the amounts impounded were relatively small and would have contributed only modestly to local scarcities.[^139] However, evidence that fraudulent, corrupt and coercive practices by the purchasing agents removed far more rice than officially recorded, not only from designated districts, but also in unauthorised areas, suggests a greater impact.[^140] In addition to destroying surplus rice, British authorities denied requests from Indian officials to import wheat.[^141] Far more damaging were the policy's disturbing impact on regional market relationships and contribution to a sense of public alarm.[^142] Disruption of deeply intertwined relationships of trust and trade credit created an immediate freeze in informal lending. This credit freeze greatly restricted the flow of rice into trade.[^143]

The second prong, a "boat denial" policy, was designed to deny Bengali transport to any invading Japanese army. It applied to districts readily accessible via the Bay of Bengal and the larger rivers that flow into it. Implemented on 1 May after an initial registration period,[^144] the policy authorised the Army to confiscate, relocate or destroy any boats large enough to carry more than ten people, and allowed them to requisition other means of transport such as bicycles, bullock carts, and elephants.[^145] Under this policy, the Army confiscated approximately 45,000 rural boats,[^146] severely disrupting river-borne movement of labour, supplies and food, and compromising the livelihoods of boatmen and fishermen.[^147] Leonard G. Pinnell, a British civil servant who headed the Bengal government's Department of Civil Supplies, told the Famine Commission that the policy "completely broke the economy of the fishing class".[^148] Transport was generally unavailable to carry seed and equipment to distant fields or rice to the market hubs.[^149] Artisans and other groups who relied on boat transport to carry goods to market were offered no recompense; neither were rice growers nor the network of migratory labourers.[^42] The large-scale removal or destruction of rural boats caused a near-complete breakdown of the existing transport and administration infrastructure and market system for movement of rice paddy.[^150] No steps were taken to provide for the maintenance or repair of the confiscated boats,[^151] and many fishermen were unable to return to their trade.[^42] The Army took no steps to distribute food rations to make up for the interruption of supplies.[^43] According to Human Geographer Senjuti Mallik, data suggests that the British harvested 29 million tons of wheat from 1943 to 1944 and that they chose to save the wheat in case British civilians needed it instead of redirecting the surplus to Bengal.[^141]

These policies were implemented without consulting Bengali officials, which contributed to more corruption and political competition,[^152] and they had important political ramifications. The [Indian National Congress](https://en.wikipedia.org/wiki/Indian_National_Congress "Indian National Congress"), among other groups, staged protests denouncing the denial policies for placing draconian burdens on Bengali peasants; these were part of a nationalist sentiment and outpouring that later peaked in the ["Quit India" movement](https://en.wikipedia.org/wiki/Quit_India_Movement "Quit India Movement").[^153] The policies' wider impact – the extent to which they compounded or even caused the famine to occur one year later – has been the subject of much [discussion](#Historiography).[^154]

### Provincial trade barriers

Many [Indian provinces](https://en.wikipedia.org/wiki/Presidencies_and_provinces_of_British_India#Administration_under_the_Crown_\(1858%E2%80%931947\) "Presidencies and provinces of British India") and [princely states](https://en.wikipedia.org/wiki/Princely_state "Princely state") imposed inter-provincial trade barriers from mid-1942, preventing trade in domestic rice. Anxiety and soaring rice prices, triggered by the fall of Burma,[^155] were one underlying reason for the trade barriers. Trade imbalances brought on by price controls were another.[^117] The power to restrict inter-provincial trade was given to provincial governments in November 1941 under the [Defence of India Act, 1939](https://en.wikipedia.org/wiki/Defence_of_India_Act,_1939 "Defence of India Act, 1939").[^13] Provincial governments began setting up trade barriers that prevented the flow of foodgrains (especially rice) and other goods between provinces. These barriers reflected a desire to see that local populations were well fed, thus forestalling local emergencies.[^156]

In January 1942, [Punjab](https://en.wikipedia.org/wiki/Punjab_Province_\(British_India\) "Punjab Province (British India)") banned exports of wheat;[^157] [^14] this increased the perception of [food insecurity](https://en.wikipedia.org/wiki/Food_insecurity "Food insecurity") and led the enclave of wheat-eaters in Greater Calcutta to increase their demand for rice precisely when an impending rice shortage was feared.[^158] The [Central Provinces](https://en.wikipedia.org/wiki/Central_Provinces "Central Provinces") prohibited the export of foodgrains outside the province two months later.[^159] [Madras](https://en.wikipedia.org/wiki/Madras_Presidency "Madras Presidency") banned rice exports in June,[^160] followed by export bans in Bengal and its neighbouring provinces of [Bihar](https://en.wikipedia.org/wiki/Bihar_Province "Bihar Province") and [Orissa](https://en.wikipedia.org/wiki/Orissa_Province "Orissa Province") that July.[^161]

The [Famine Inquiry Commission](https://en.wikipedia.org/wiki/Famine_Inquiry_Commission "Famine Inquiry Commission") of 1945 characterised this "critical and potentially most dangerous stage" as a key policy failure. As one [deponent](https://en.wikipedia.org/wiki/Deposition_\(law\) "Deposition (law)") to the Commission put it: "Every province, every district, every \[administrative division\] in the east of India had become a food republic unto itself. The trade machinery for the distribution of food \[between provinces\] throughout the east of India was slowly strangled, and by the spring of 1943 was dead." [^162] Bengal was unable to import domestic rice; this policy helped transform [market failures](https://en.wikipedia.org/wiki/Market_failure "Market failure") and food shortage into famine and widespread death.[^163]

### Mid-1942: Prioritised distribution

The loss of Burma reinforced the strategic importance of Calcutta as the hub of [heavy industry](https://en.wikipedia.org/wiki/Heavy_industry "Heavy industry") and the main supplier of armaments and textiles for the entire Asian theatre.[^164] To support its wartime mobilisation, the British Indian Government categorised the population into socioeconomic groups of "priority" and "non-priority" classes, according to their relative importance to the war effort.[^165] Members of the "priority" classes were largely composed of *[bhadraloks](https://en.wikipedia.org/wiki/Bhadralok "Bhadralok")*, who were upper-class or [bourgeois](https://en.wikipedia.org/wiki/Bourgeois "Bourgeois") middle-class, socially mobile, educated, urban, and sympathetic to Western values and modernisation. Protecting their interests was a major concern of both private and public relief efforts.[^166] This placed the rural poor in direct competition for scarce basic supplies with workers in public agencies, war-related industries, and in some cases even politically well-connected middle-class agriculturalists.[^167]

As food prices rose and the signs of famine became apparent from July 1942,[^168] the Bengal Chamber of Commerce (composed mainly of British-owned firms) [^169] devised a Foodstuffs Scheme to provide preferential distribution of goods and services to workers in high-priority war industries, to prevent them from leaving their positions. The scheme was approved by Government of Bengal.[^170] Rice was directed away from the starving rural districts to workers in industries considered vital to the military effort – particularly in the area around Greater Calcutta.[^171] Workers in prioritised sectors – private and government wartime industries, military and civilian construction, paper and textile mills, engineering firms, the [Indian Railways](https://en.wikipedia.org/wiki/Indian_Railways "Indian Railways"), coal mining, and government workers of various levels [^172] – were given significant advantages and benefits. Essential workers received subsidised food,[^173] and were frequently paid in part in weekly allotments of rice sufficient to feed their immediate families, further protecting them from inflation.[^174] Essential workers also benefited from ration cards, a network of "cheap shops" which provided essential supplies at discounted rates, and direct, preferential allocation of supplies such as water, medical care, and antimalarial supplies. They also received subsidised food, free transportation, access to superior housing, regular wages and even "mobile cinema units catering to recreational needs".[^173] By December of that year, the total number of individuals covered (workers and their families) was approximately a million.[^175] Medical care was directed to the priority groups – particularly the military. Public and private medical staff at all levels were transferred to military duty, while medical supplies were monopolised.[^176]

Rural labourers and civilians not members of these groups received severely reduced access to food and medical care, generally available only to those who migrated to selected population centres.[^107] Otherwise, according to [medical historian](https://en.wikipedia.org/wiki/History_of_medicine "History of medicine") [Sanjoy Bhattacharya](https://en.wikipedia.org/wiki/Sanjoy_Bhattacharya "Sanjoy Bhattacharya"), "vast areas of rural eastern India were denied any lasting state-sponsored distributive schemes".[^177] For this reason, the policy of prioritised distribution is sometimes discussed as one [cause of the famine](#Historiography).[^178]

### Civil unrest

![ A single-paged official document on paper that appears old. Text is written with an old-style manual typewriter. The words "Secret Cipher Telegram" are prominently stamped atop the page.](https://en.wikipedia.org/wiki/File:Civil_unrest_India_August_1942_Telegram.jpg)

Secret Cipher Telegram from C. in C. India to the UK War Office, dated 17 August 1942, describing the civil unrest in wake of the Quit India Resolution, 9 August 1942.

The war escalated resentment and fear of the Raj among rural agriculturalists and business and industrial leaders in Greater Calcutta.[^179] The unfavourable military situation of the Allies after the fall of Burma led the US and China to urge the UK to enlist India's full cooperation in the war by negotiating a peaceful transfer of political power to an elected Indian body; this goal was also supported by the [Labour Party](https://en.wikipedia.org/wiki/Labour_Party_\(UK\) "Labour Party (UK)") in Britain. [Winston Churchill](https://en.wikipedia.org/wiki/Winston_Churchill "Winston Churchill"), the [British prime minister](https://en.wikipedia.org/wiki/British_prime_minister "British prime minister"), responded to the new pressure through the [Cripps' mission](https://en.wikipedia.org/wiki/Cripps'_mission "Cripps' mission"), broaching the post-war possibility of an autonomous political status for India in exchange for its full military support, but negotiations collapsed in early April 1942.[^180]

On 8 August 1942, the Indian National Congress launched the Quit India movement as a nationwide display of nonviolent resistance.[^181] The British authorities reacted by imprisoning the Congress leaders.[^182] Without its leadership, the movement changed its character and took to sabotaging factories, bridges, telegraph and railway lines, and other government property,[^182] thereby threatening the British Raj's war enterprise.[^182] The British acted forcefully to suppress the movement, taking around 66,000 in custody (of whom just over 19,000 were still convicted under civil law or detained under the Defence of India Act in early 1944). More than 2,500 Indians were shot when police fired upon protesters, many of whom were killed.[^183] In Bengal, the movement was strongest in the [Tamluk](https://en.wikipedia.org/wiki/Tamluk_subdivision "Tamluk subdivision") and [Contai](https://en.wikipedia.org/wiki/Contai_subdivision "Contai subdivision") subdivisions of Midnapore district,[^184] where rural discontent was well-established and deep.[^185] [^15] In Tamluk, by April 1942 the government had destroyed some 18,000 boats in pursuit of its denial policy, while war-related inflation further alienated the rural population, who became eager volunteers when local Congress recruiters proposed open rebellion.[^186]

The violence during the "Quit India" movement was internationally condemned, and hardened some sectors of British opinion against India;[^187] The historians [Christopher Bayly](https://en.wikipedia.org/wiki/Christopher_Bayly "Christopher Bayly") and Tim Harper believe it reduced the [British War Cabinet's](https://en.wikipedia.org/wiki/Churchill_war_ministry "Churchill war ministry") willingness to provide famine aid at a time when supplies were also needed for the war effort.[^188] In several ways the political and social disorder and distrust that were the effects and after-effects of rebellion and civil unrest placed political, logistical, and infrastructural constraints on the Government of India that contributed to later famine-driven woes.[^189]

### 1942–1943: Price chaos

Throughout April 1942, British and Indian refugees fled Burma, many through Bengal, as the cessation of Burmese imports continued to drive up rice prices. In June, the Bengal government established price controls for rice, and on 1 July fixed prices at a level considerably lower than the prevailing market price. The principal result of the fixed low price was to make sellers reluctant to sell; stocks disappeared, either on to the black market or into storage.[^190] The government then let it be known that the price control law would not be enforced except in the most egregious cases of war profiteering.[^191] This easing of restrictions plus the ban on exports created about four months of relative price stability.[^192] In mid-October, though, south-west Bengal was struck by a series of [natural disasters](#October_1942:_Natural_disasters) that destabilised prices again,[^193] causing another rushed scramble for rice, greatly to the benefit of the Calcutta black market.[^194] Between December 1942 and March 1943 the government made several attempts to "break the Calcutta market" by bringing in rice supplies from various districts around the province; however, these attempts to drive down prices by increasing supply were unsuccessful.[^195]

On 11 March 1943, the provincial government rescinded its price controls,[^196] resulting in dramatic rises in the price of rice, due in part to soaring levels of speculation.[^197] The period of inflation between March and May 1943 was especially intense;[^198] May was the month of the first reports of death by starvation in Bengal.[^199] The government attempted to re-establish public confidence by insisting that the crisis was being caused almost solely by speculation and hoarding,[^200] but their propaganda failed to dispel the widespread belief that there was a shortage of rice.[^201] The provincial government never formally declared a state of famine, even though its [Famine Code](https://en.wikipedia.org/wiki/Indian_Famine_Codes "Indian Famine Codes") would have mandated a sizable increase in aid. In the early stages of the famine, the rationale for this was that the provincial government was expecting aid from the Government of India. It felt then its duty lay in maintaining confidence through propaganda that asserted that there was no shortage. After it became clear that aid from central government was not forthcoming, the provincial government felt they simply did not have the amount of food supplies that a declaration of famine would require them to distribute, while distributing more money might make inflation worse.[^202]

When inter-provincial trade barriers were abolished on 18 May, prices temporarily fell in Calcutta, but soared in the neighbouring provinces of Bihar and Orissa when traders rushed to purchase stocks.[^203] The provincial government's attempts to locate and seize any hoarded stocks failed to find significant hoarding.[^204] In Bengal, prices were soon five to six times higher than they had been before April 1942.[^205] Free trade was abandoned in July 1943,[^206] and price controls were reinstated in August.[^196] Despite this, there were unofficial reports of rice being sold in late 1943 at roughly eight to ten times the prices of late 1942.[^207] Purchasing agents were sent out by the government to obtain rice, but their attempts largely failed. Prices remained high, and the black market was not brought under control.[^208]

### October 1942: Natural disasters

![ Close-up shot of a leaf blade, resembling a blade of grass. Many very obvious dry, discolored spots show the leaf is unhealthy or dying.](https://en.wikipedia.org/wiki/File:Cochliobolus_miyabeanus.jpg)

Brown spot disease: symptoms of Cochliobolus miyabeanus on rice.

Bengal was affected by a series of natural disasters late in 1942. The winter rice crop was afflicted by a severe outbreak of fungal [brown spot disease](https://en.wikipedia.org/wiki/Brown_spot_disease "Brown spot disease"), while, on 16–17 October a [cyclone](https://en.wikipedia.org/wiki/Cyclone "Cyclone") and three [storm surges](https://en.wikipedia.org/wiki/Storm_surge "Storm surge") ravaged croplands, destroyed houses and killing thousands, at the same time dispersing high levels of [fungal spores](https://en.wikipedia.org/wiki/Fungal_spore "Fungal spore") across the region and increasing the spread of the crop disease.[^209] The fungus reduced the crop yield even more than the cyclone.[^210] After describing the horrific conditions he had witnessed, the [mycologist](https://en.wikipedia.org/wiki/Mycology "Mycology") S. Y. Padmanabhan wrote that the outbreak was similar in impact to the [potato blight](https://en.wikipedia.org/wiki/Potato_blight "Potato blight") that caused the Irish [Great Famine](https://en.wikipedia.org/wiki/Great_Famine_\(Ireland\) "Great Famine (Ireland)"): "Though administrative failures were immediately responsible for this human suffering, the principal cause of the short crop production of 1942 was the \[plant\] epidemic... nothing as devastating... has been recorded in plant pathological literature".[^211]

The Bengal cyclone came through the [Bay of Bengal](https://en.wikipedia.org/wiki/Bay_of_Bengal "Bay of Bengal"), landing on the coastal areas of Midnapore and 24 Parganas.[^212] It killed 14,500 people and 190,000 cattle, whilst rice paddy stocks in the hands of cultivators, consumers, and dealers were destroyed.[^213] It also created local atmospheric conditions that contributed to an increased incidence of malaria.[^214] The three storm surges which followed the cyclone destroyed the seawalls of Midnapore and flooded large areas of Contai and [Tamluk](https://en.wikipedia.org/wiki/Tamluk "Tamluk").[^215] Waves swept an area of 450 square miles (1,200 km <sup>2</sup>), floods affected 400 square miles (1,000 km <sup>2</sup>), and wind and torrential rain damaged 3,200 square miles (8,300 km <sup>2</sup>). For nearly 2.5 million Bengalis, the accumulative damage of the cyclone and storm surges to homes, crops and livelihoods was catastrophic:[^216]

> Corpses lay scattered over several thousand square miles of devastated land, 7,400 villages were partly or wholly destroyed, and standing flood waters remained for weeks in at least 1,600 villages. Cholera, dysentery and other water-borne diseases flourished. 527,000 houses and 1,900 schools were lost, over 1,000 square miles of the most fertile paddy land in the province was entirely destroyed, and the standing crop over an additional 3,000 square miles was damaged.[^217]

The cyclone, floods, plant disease, and warm, humid weather reinforced each other and combined to have a substantial impact on the *aman* rice crop of 1942.[^218] Their impact was felt in other aspects as well, as in some districts the cyclone was responsible for an increased incidence of malaria, with deadly effect.[^219]

### October 1942: Unreliable crop forecasts

At about the same time, official forecasts of crop yields predicted a significant shortfall.[^220] However, crop statistics of the time were scant and unreliable.[^221] Administrators and statisticians had known for decades that India's agricultural production statistics were completely inadequate [^222] and "not merely guesses, but frequently demonstrably absurd guesses".[^223] There was little or no internal bureaucracy for creating and maintaining such reports, and the low-ranking police officers or village officials charged with gathering local statistics were often poorly supplied with maps and other necessary information, poorly educated, and poorly motivated to be accurate.[^224] The Bengal Government thus did not act on these predictions,[^225] doubting their accuracy and observing that forecasts had predicted a shortfall several times in previous years, while no significant problems had occurred.[^226]

### Air raids on Calcutta

The Famine Inquiry Commission's 1945 report singled out the first Japanese air raids on Calcutta in December 1942 as a causation.[^227] The attacks, largely unchallenged by Allied defences,[^228] continued throughout the week,[^227] triggering an exodus of thousands from the city.[^229] As evacuees travelled to the countryside, food-grain dealers closed their shops.[^227] To ensure that workers in the prioritised industries in Calcutta would be fed,[^230] the authorities seized rice stocks from wholesale dealers, breaking any trust the rice traders had in the government.[^231] "From that moment", the 1945 report stated, "the ordinary trade machinery could not be relied upon to feed Calcutta. The \[food security\] crisis had begun".[^227]

### 1942–1943: Shortfall and carryover

Whether the famine resulted from crop shortfall or failure of land distribution has been much debated.[^232] According to [Amartya Sen](https://en.wikipedia.org/wiki/Amartya_Sen "Amartya Sen"): "The... \[rice paddy\] supply for 1943 was only about 5% lower than the average of the preceding five years. It was, in fact, 13% higher than in 1941, and there was, of course, no famine in 1941." [^233] The Famine Inquiry Commission report concluded that the overall deficit in rice in Bengal in 1943, taking into account an estimate of the amount of carryover of rice from the previous harvest,[^16] was about three weeks' supply. In any circumstances, this was a significant shortfall requiring a considerable amount of food relief, but not a deficit large enough to create widespread deaths by starvation.[^234] According to this view, the famine "was not a crisis of food availability, but of the \[unequal\] distribution of food and income".[^235] There has been very considerable debate about the amount of carryover available for use at the onset of the famine.[^236]

Several contemporary experts cite evidence of a much larger shortfall.[^237] Commission member Wallace Aykroyd argued in 1974 that there had been a 25% shortfall in the harvest of the winter of 1942,[^238] while L. G. Pinnell, responsible to the Government of Bengal from August 1942 to April 1943 for managing food supplies, estimated the crop loss at 20%, with disease accounting for more of the loss than the cyclone; other government sources privately admitted the shortfall was 2 million tons.[^239] The economist George Blyn argues that with the cyclone and floods of October and the loss of imports from Burma, the 1942 Bengal rice harvest had been reduced by one-third.[^240]

### 1942–1944: Refusal of imports

Beginning as early as December 1942, high-ranking government officials and military officers (including John Herbert, the Governor of Bengal; [Viceroy Linlithgow](https://en.wikipedia.org/wiki/Victor_Hope,_2nd_Marquess_of_Linlithgow "Victor Hope, 2nd Marquess of Linlithgow"); [Leo Amery](https://en.wikipedia.org/wiki/Leo_Amery "Leo Amery") the Secretary of State for India; General [Claude Auchinleck](https://en.wikipedia.org/wiki/Claude_Auchinleck "Claude Auchinleck"), Commander-in-Chief of British forces in India,[^241] and Admiral [Louis Mountbatten](https://en.wikipedia.org/wiki/Louis_Mountbatten,_1st_Earl_Mountbatten_of_Burma "Louis Mountbatten, 1st Earl Mountbatten of Burma"), Supreme Commander of South-East Asia [^242]) began requesting food imports for India through government and military channels, but for months these requests were either rejected or reduced to a fraction of the original amount by Churchill's War Cabinet.[^243] The colony was also not permitted to spend its own sterling reserves, or even use its own ships, to import food.[^244] Although Viceroy Linlithgow appealed for imports from mid-December 1942, he did so on the understanding that the military would be given preference over civilians.[^17] The Secretary of State for India, Leo Amery, was on one side of a cycle of requests for food aid and subsequent refusals from the British War Cabinet that continued through 1943 and into 1944.[^245] Amery did not mention worsening conditions in the countryside, stressing that Calcutta's industries must be fed or its workers would return to the countryside. Rather than meeting this request, the UK promised a relatively small amount of wheat that was specifically intended for western India (that is, not for Bengal) in exchange for an increase in rice exports from Bengal to Ceylon.[^11]

The tone of Linlithgow's warnings to Amery grew increasingly serious over the first half of 1943, as did Amery's requests to the War Cabinet; on 4 August 1943 Amery noted the spread of famine, and specifically stressed the effect upon Calcutta and the potential effect on the morale of European troops. The cabinet again offered only a relatively small amount, explicitly referring to it as a token shipment.[^246] The explanation generally offered for the refusals included insufficient shipping,[^247] particularly in light of Allied plans to [invade Normandy](https://en.wikipedia.org/wiki/Normandy_landings "Normandy landings").[^248] The Cabinet also refused offers of food shipments from several different nations.[^249] When such shipments did begin to increase modestly in late 1943, the transport and storage facilities were understaffed and inadequate.[^250] When Viscount Archibald Wavell replaced Linlithgow as Viceroy in the latter half of 1943, he too began a series of exasperated demands to the War Cabinet for very large quantities of grain.[^251] His requests were again repeatedly denied, causing him to decry the current crisis as "one of the greatest disasters that has befallen any people under British rule, and \[the\] damage to our reputation both among Indians and foreigners in India is incalculable".[^252] Churchill wrote to [Franklin D. Roosevelt](https://en.wikipedia.org/wiki/Franklin_D._Roosevelt "Franklin D. Roosevelt") at the end of April 1944 asking for aid from the United States in shipping wheat in from Australia, but Roosevelt replied apologetically on 1 June that he was "unable on military grounds to consent to the diversion of shipping".[^253]

Experts' disagreement over political issues can be found in differing explanations of the War Cabinet's refusal to allocate funds to import grain. [Lizzie Collingham](https://en.wikipedia.org/wiki/Lizzie_Collingham "Lizzie Collingham") holds the massive global dislocations of supplies caused by World War II virtually guaranteed that hunger would occur somewhere in the world, yet Churchill's animosity and perhaps racism toward Indians decided the exact location where famine would fall.[^254] Similarly, Madhusree Mukerjee makes a stark accusation: "The War Cabinet's shipping assignments made in August 1943, shortly after Amery had pleaded for famine relief, show Australian wheat flour travelling to Ceylon, the Middle East, and Southern Africa – everywhere in the Indian Ocean but to India. Those assignments show a will to punish." [^255] In contrast, Mark Tauger strikes a more supportive stance: "In the Indian Ocean alone from January 1942 to May 1943, the Axis powers sank 230 British and Allied merchant ships totalling 873,000 tons, in other words, a substantial boat every other day. British hesitation to allocate shipping concerned not only potential diversion of shipping from other war-related needs but also the prospect of losing the shipping to attacks without actually \[bringing help to\] India at all." [^256] Peter Bowbrick elaborates further on the British government's delay in shipping food, stating that Linlithgow's request for food shipments in December 1942 was half-hearted and that it was made on the assumption that Bengal already had a food surplus but that it was being hoarded, which is why it was ignored by the British metropolitan government. Further delays after April 1943 stemmed from the refusal to divert ships away from the preparations for [Operation Overlord](https://en.wikipedia.org/wiki/Operation_Overlord "Operation Overlord"), whose failure would have been disastrous for the world and whose success was, as a result, prioritised above sending aid to India.[^257]

## Famine, disease, and the death toll

An estimated 0.8–3.8 million [^1] Bengalis died, out of a population of 60.3 million. According to Irish historian [Cormac Ó Gráda](https://en.wikipedia.org/wiki/Cormac_%C3%93_Gr%C3%A1da "Cormac Ó Gráda") "the scholarly consensus is about 2.1 million".[^1]

Contemporary mortality statistics were to some degree under-recorded, particularly for the rural areas, where data collecting and reporting was rudimentary even in normal times. Thus, many of those who died or migrated were unreported.[^258] The principal causes of death also changed as the famine progressed in two waves.[^259]

Early on, conditions drifted towards famine at different rates in different Bengal districts. The Government of India dated the beginning of the Bengal food crisis from the air raids on Calcutta in December 1942,[^227] blaming the acceleration to full-scale famine by May 1943 on the effects of price decontrol.[^260] However, in some districts the food crisis had begun as early as mid-1942.[^261] The earliest indications were somewhat obscured, since rural poor were able to draw upon various survival strategies for a few months.[^262] After December 1942 reports from various commissioners and district officers began to cite a "sudden and alarming" inflation, nearly doubling the price of rice; this was followed in January by reports of distress caused by serious food supply problems.[^263] In May 1943, six districts – Rangpur, Mymensingh, Bakarganj, Chittagong, Noakhali and Tipperah – were the first to report deaths by starvation. Chittagong and Noakhali, both "boat denial" districts in the [Ganges Delta](https://en.wikipedia.org/wiki/Ganges_Delta "Ganges Delta") (or Sundarbans Delta) area, were the hardest hit.[^199] In this first wave – from May to October 1943 – starvation was the principal cause of excess mortality (that is, those attributable to the famine, over and above the normal death rates), filling the emergency hospitals in Calcutta and accounting for the majority of deaths in some districts.[^264] According to the Famine Inquiry Commission report, many victims on the streets and in the hospitals were so emaciated that they resembled "living skeletons".[^265] While some districts of Bengal were relatively less affected throughout the crisis,[^266] no demographic or geographic group was completely immune to increased mortality rates caused by disease – but deaths from starvation were confined to the rural poor.[^267]

Deaths by starvation had peaked by November 1943.[^268] Disease began its sharp upward turn around October 1943 and overtook starvation as the most common cause of death around December.[^269] Disease-related mortality then continued to take its toll through early-to-mid 1944.[^264] Among diseases, malaria was the biggest killer.[^270] From July 1943 to June 1944, the monthly death toll from malaria averaged 125% above rates from the previous five years, reaching 203% above average in December 1943.[^270] Malaria parasites were found in nearly 52% of blood samples examined at Calcutta hospitals during the peak period, November–December 1944.[^271] Statistics for malaria deaths are almost certainly inaccurate, since the symptoms often resemble those of other fatal fevers, but there is little doubt that it was the main killer.[^272] Other famine-related deaths resulted from dysentery and diarrhoea, typically through consumption of poor-quality food or deterioration of the digestive system caused by malnutrition.[^273] Cholera is a [waterborne disease](https://en.wikipedia.org/wiki/Waterborne_diseases "Waterborne diseases") associated with social disruption, poor sanitation, contaminated water, crowded living conditions (as in refugee camps), and a wandering population – problems brought on after the October cyclone and flooding and then continuing through the crisis.[^274] The epidemic of [smallpox](https://en.wikipedia.org/wiki/Smallpox "Smallpox") largely resulted from a result of lack of vaccinations and the inability to quarantine patients, caused by general social disruption.[^275] According to social demographer Arup Maharatna, statistics for smallpox and cholera are probably more reliable than those for malaria, since their symptoms are more easily recognisable.[^276]

![ Line-drawing map of Bengal in 1943. All of its large political districts are shown and labelled.](https://en.wikipedia.org/wiki/File:Map_of_Bengal_districts_1943.png)

Map of Greater Bengal in 1943

The mortality statistics present a confused picture of the distribution of deaths among age and gender groups. Although very young children and the elderly are usually more susceptible to the effects of starvation and disease, overall in Bengal it was adults and older children who suffered the highest proportional mortality rises.[^277] However, this picture was inverted in some urban areas, perhaps because the cities attracted large numbers of very young and very old migrants.[^278] In general, males suffered generally higher death rates than females,[^279] although the rate of female infant death was higher than for males, perhaps reflecting a discriminatory bias.[^280] A relatively lower death rate for females of child-bearing age may have reflected a reduction in fertility, brought on by malnutrition, which in turn reduced maternal deaths.[^281]

Regional differences in mortality rates were influenced by the effects of migration,[^282] and of natural disasters.[^283] In general, excess mortality was higher in the east (followed by west, centre, and north of Bengal in that order),[^284] even though the relative shortfall in the rice crop was worst in the western districts of Bengal.[^285] Eastern districts were relatively densely populated,[^286] were closest to the Burma war zone, and normally ran grain deficits in pre-famine times.[^287] These districts also were subject to the boat denial policy, and had a relatively high proportion of jute production instead of rice.[^283] Workers in the east were more likely to receive monetary wages than payment in kind with a portion of the harvest, a common practice in the western districts.[^288] [^289] When prices rose sharply, their wages failed to follow suit;[^290] this drop in [real wages](https://en.wikipedia.org/wiki/Real_wages "Real wages") left them less able to purchase food.[^290] The following table, derived from Arup Maharatna (1992), shows trends in excess mortality for 1943–44 as compared to prior non-famine years. Death rate is total number of deaths in a year (mid-year population) from all causes, per 1000.[^291] All death rates are with respect to the population in 1941.[^292] Percentages for 1943–44 are of *excess deaths* (that is, those attributable to the famine, over and above the normal incidence) [^18] as compared to rates from 1937 to 1941.

<table><caption>Cause-specific death rates during pre-famine and famine periods; relative importance of different causes of death during famine: Bengal <sup><a href="#fn:293">293</a></sup></caption><tbody><tr><th rowspan="2">Cause of death</th><th colspan="2">Pre-famine<br>1937–41</th><th colspan="2">1943</th><th colspan="2">1944</th></tr><tr><td colspan="2">Rate</td><td>Rate</td><td>%</td><td>Rate</td><td>%</td></tr><tr><td>Cholera</td><td colspan="2">0.73</td><td>3.60</td><td>23.88</td><td>0.82</td><td>0.99</td></tr><tr><td>Smallpox</td><td colspan="2">0.21</td><td>0.37</td><td>1.30</td><td>2.34</td><td>23.69</td></tr><tr><td>Fever</td><td colspan="2">6.14</td><td>7.56</td><td>11.83</td><td>6.22</td><td>0.91</td></tr><tr><td>Malaria</td><td colspan="2">6.29</td><td>11.46</td><td>43.06</td><td>12.71</td><td>71.41</td></tr><tr><td>Dysentery/diarrhoea</td><td colspan="2">0.88</td><td>1.58</td><td>5.83</td><td>1.08</td><td>2.27</td></tr><tr><td>All other</td><td colspan="2">5.21</td><td>7.2</td><td>14.11</td><td>5.57</td><td>0.74</td></tr><tr><td>All causes</td><td colspan="2">19.46</td><td>31.77</td><td>100.00</td><td>28.75</td><td>100.00</td></tr></tbody></table>

Overall, the table shows the dominance of malaria as the cause of death throughout the famine, accounting for roughly 43% [^19] of the excess deaths in 1943 and 71% in 1944. Cholera was a major source of famine-caused deaths in 1943 (24%) but dropped to a negligible percentage (1%) the next year. Smallpox deaths were almost a mirror image: they made up a small percentage of excess deaths in 1943 (1%) but jumped in 1944 (24%). Finally, the sharp jump in the death rate from "All other" causes in 1943 is almost certainly due to deaths from pure starvation, which were negligible in 1944.[^294]

Though excess mortality due to malarial deaths peaked in December 1943, rates remained high throughout the following year.[^295] Scarce supplies of [quinine](https://en.wikipedia.org/wiki/Quinine "Quinine") (the most common malaria medication) were very frequently diverted to the [black market](https://en.wikipedia.org/wiki/Black_market "Black market").[^296] Advanced anti-malarial drugs such as [mepacrine](https://en.wikipedia.org/wiki/Mepacrine "Mepacrine") (Atabrine) were distributed almost solely to the military and to "priority classes"; [DDT](https://en.wikipedia.org/wiki/DDT "DDT") (then relatively new and considered "miraculous") and [pyrethrum](https://en.wikipedia.org/wiki/Pyrethrum "Pyrethrum") were sprayed only around military installations. [Paris Green](https://en.wikipedia.org/wiki/Paris_Green "Paris Green") was used as an insecticide in some other areas.[^297] This unequal distribution of anti-malarial measures may explain a lower incidence of malarial deaths in population centres, where the greatest cause of death was "all other" (probably migrants dying from starvation).[^294]

Deaths from dysentery and diarrhoea peaked in December 1943, the same month as for malaria.[^295] Cholera deaths peaked in October 1943 but receded dramatically in the following year, brought under control by a vaccination program overseen by military medical workers.[^298] A similar smallpox vaccine campaign started later and was pursued less effectively;[^299] smallpox deaths peaked in April 1944.[^300] "Starvation" was generally not listed as a cause of death at the time; many deaths by starvation may have been listed under the "all other" category.[^301] Here the death rates, rather than per cents, reveal the peak in 1943.

The two waves – starvation and disease – also interacted and amplified one another, increasing the excess mortality.[^302] Widespread starvation and malnutrition first compromised immune systems, and reduced resistance to disease led to death by opportunistic infections.[^303] Second, the social disruption and dismal conditions caused by a cascading breakdown of social systems brought mass migration, overcrowding, poor sanitation, poor water quality and waste disposal, increased vermin, and unburied dead. All of these factors are closely associated with the increased spread of infectious disease.[^269]

## Social disruption

![Old photograph of a woman squatting and tiny, emaciated toddler standing on a sidewalk. The woman is shirtless but squatting to conceal her breasts. The toddler is wearing rags.](https://en.wikipedia.org/wiki/File:Destitute_mother_and_child_Bengal_famine_1943.jpg)

A family on the sidewalk in Calcutta during the Bengal famine of 1943

Despite the organised and sometimes violent civil unrest immediately before the famine,[^15] there was no organised rioting when the famine took hold.[^304] However, the crisis overwhelmed the provision of health care and key supplies: food relief and medical rehabilitation were supplied too late, whilst medical facilities across the province were utterly insufficient for the task at hand.[^305] A long-standing system of rural patronage, in which peasants relied on large landowners to supply subsistence in times of crisis, collapsed as patrons exhausted their own resources and abandoned the peasants.[^306]

Families also disintegrated, with cases of abandonment, [child-selling](https://en.wikipedia.org/wiki/Child-selling "Child-selling"), prostitution, and sexual exploitation.[^307] Lines of small children begging stretched for miles outside cities; at night, children could be heard "crying bitterly and coughing terribly... in the pouring monsoon rain... stark naked, homeless, motherless, fatherless and friendless. Their sole possession was an empty tin".[^308] A schoolteacher in [Mahisadal](https://en.wikipedia.org/wiki/Mahisadal "Mahisadal") witnessed "children picking and eating undigested grains out of a beggar's diarrheal discharge".[^309] Author [Freda Bedi](https://en.wikipedia.org/wiki/Freda_Bedi "Freda Bedi") wrote that it was "not just the problem of rice and the availability of rice. It was the problem of society in fragments".[^310]

### Population displacement

The famine fell hardest on the rural poor. As the distress continued, families adopted increasingly desperate means for survival. First, they reduced their food intake and began to sell jewellery, ornaments, and smaller items of personal property. As expenses for food or burials became more urgent, the items sold became larger and less replaceable. Eventually, families disintegrated; men sold their small farms and left home to look for work or to join the army, and women and children became homeless migrants,[^311] often travelling to Calcutta or another large city in search of organised relief:[^311]

> Husbands deserted wives and wives husbands; elderly dependents were left behind in the villages; babies and young children were sometimes abandoned. According to a survey carried out in Calcutta during the latter half of 1943, some breaking up of the family had occurred in about half the destitute population which reached the city.[^312]

In Calcutta, evidence of the famine was "... mainly in the form of masses of rural destitutes trekking into the city and dying on the streets".[^243] Estimates of the number of the sick who flocked to Calcutta ranged between 100,000 and 150,000.[^313] Once they left their rural villages in search of food, their outlook for survival was grim: "Many died by the roadside – witness the skulls and bones which were to be seen there in the months following the famine." [^314]

### Sanitation and undisposed dead

![Hand-drawn sketch of a half-eaten corpse on the ground, a jackal gnawing on its leg bone, five vultures waiting for the jackal to leave. The corpse's facial expression resembles someone screaming.](https://en.wikipedia.org/wiki/File:Chittaprosad-Hungry-Bengal-sketch1.jpg)

Image of Midnapore famine victim from Chittaprosad Bhattacharya 's Hungry Bengal, five thousand copies of which were destroyed by authorities. The caption read "His name was Kshetramohan Naik."

The disruption of core elements of society brought a catastrophic breakdown of sanitary conditions and hygiene standards.[^269] Large-scale migration resulted in the abandonment of the facilities and sale of the utensils necessary for washing clothes or preparation of food.[^315] Many people drank contaminated rainwater from streets and open spaces where others had urinated or defecated.[^316] Particularly in the early months of the crisis, conditions did not improve for those under medical care:

> Conditions in certain famine hospitals at this time... were indescribably bad... Visitors were horrified by the state of the wards and patients, the ubiquitous filth, and the lack of adequate care and treatment... \[In hospitals all across Bengal, the\] condition of patients was usually appalling, a large proportion suffering from acute emaciation, with 'famine diarrhoea'... Sanitary conditions in nearly all temporary indoor institutions were very bad to start with...[^317]

The desperate condition of the healthcare did not improve appreciably until the army, under Viscount Wavell, took over the provision of relief supplies in October 1943. At that time medical resources [^318] were made far more available.[^319]

Disposal of corpses soon became a problem for the government and the public, as numbers overwhelmed cremation houses, burial grounds, and those collecting and disposing of the dead. Corpses lay scattered throughout the pavements and streets of Calcutta. In only two days of August 1943, at least 120 were removed from public thoroughfares.[^320] In the countryside bodies were often disposed of in rivers and water supplies.[^321] As one survivor explained, "We couldn't bury them or anything. No one had the strength to perform rites. People would tie a rope around the necks and drag them over to a ditch." [^322] Corpses were also left to rot and putrefy in open spaces. The bodies were picked over by vultures and dragged away by jackals. Sometimes this happened while the victim was still living.[^323] The sight of corpses beside canals, ravaged by dogs and jackals, was common; during a seven-mile boat ride in Midnapore in November 1943, a journalist counted at least five hundred such sets of skeletal remains.[^324] The weekly newspaper *Biplabi* commented in November 1943 on the levels of putrefaction, contamination, and vermin infestation:

> Bengal is a vast cremation ground, a meeting place for ghosts and evil spirits, a land so overrun by dogs, jackals and vultures that it makes one wonder whether the Bengalis are really alive or have become ghosts from some distant epoch.[^325]

By the summer of 1943, many districts of Bengal, especially in the countryside, had taken on the look of "a vast [charnel house](https://en.wikipedia.org/wiki/Charnel_house "Charnel house") ".[^323]

### Cloth famine

![ A very shriveled and emaciated woman holding a very emaciated baby in the crook of her arm. Both are wearing only rags, and the mother's right breast is unconcealed. Her hands are holding a bowl and a canister, and she may be begging.](https://en.wikipedia.org/wiki/File:MotherWithShredsOfClothingAndChildCalcutta1943.jpg)

Mother with child on a Calcutta street. Bengal famine 1943

As a further consequence of the crisis, a "cloth famine" left the poorest in Bengal clothed in scraps or naked through the winter.[^326] [^327] The British military consumed nearly all the textiles produced in India by purchasing Indian-made boots, parachutes, uniforms, blankets, and other goods at heavily discounted rates.[^126] India produced 600,000 miles of cotton fabric during the war, from which it made two million parachutes and 415 million items of military clothing.[^126] It exported 177 million yards of cotton in 1938–1939 and 819 million in 1942–1943.[^328] The country's production of silk, wool and leather was also used up by the military.[^126]

The small proportion of material left over was purchased by speculators for sale to civilians, subject to similarly steep inflation;[^126] in May 1943 prices were 425% higher than in August 1939.[^328] With the supply of cloth crowded out by commitments to Britain and price levels affected by profiteering, those not among the " [priority classes](#Mid-1942:_Prioritised_distribution) " faced increasingly dire scarcity. Swami Sambudhanand, president of the [Ramakrishna Mission](https://en.wikipedia.org/wiki/Ramakrishna_Mission "Ramakrishna Mission") in [Bombay](https://en.wikipedia.org/wiki/Bombay "Bombay"), stated in July 1943:

> The robbing of graveyards for clothes, disrobing of men and women in out of way places for clothes... and minor riotings here and there have been reported. Stray news has also come that women have committed suicide for want of cloth... Thousands of men and women... cannot go out to attend their usual work outside for want of a piece of cloth to wrap round their loins.[^128]

Many women "took to staying inside a room all day long, emerging only when it was \[their\] turn to wear the single fragment of cloth shared with female relatives".[^329]

### Exploitation of women and children

One of the classic effects of famine is that it intensifies the exploitation of women; the sale of women and girls, for example, tends to increase.[^330] The sexual exploitation of poor, rural, lower-caste and tribal women by the *jotedars* had been difficult to escape even before the crisis.[^331] In the wake of the cyclone and later famine, many women lost or sold all their possessions, and lost a male guardian due to abandonment or death. Those who migrated to Calcutta frequently had only begging or prostitution available as strategies for survival; often regular meals were the only payment.[^332] Tarakchandra Das suggests that a large proportion of the girls aged 15 and younger who migrated to Calcutta during the famine disappeared into brothels;[^333] in late 1943, entire boatloads of girls for sale were reported in ports of East Bengal.[^334] Girls were also prostituted to soldiers, with boys acting as pimps.[^335] Families sent their young girls to wealthy landowners overnight in exchange for very small amounts of money or rice,[^336] or sold them outright into prostitution; girls were sometimes enticed with sweet treats and kidnapped by pimps. Very often, these girls lived in constant fear of injury or death, but the brothels were their sole means of survival, or they were unable to escape.[^337] Women who had been sexually exploited could not later expect any social acceptance or a return to their home or family.[^338] [Bina Agarwal](https://en.wikipedia.org/wiki/Bina_Agarwal "Bina Agarwal") writes that such women became permanent outcastes in a society that highly values female chastity, rejected by both their birth family and husband's family.[^339]

An unknown number of children, some tens of thousands, were orphaned.[^340] Many others were abandoned, sometimes by the roadside or at orphanages,[^341] or sold for as much as two *[maunds](https://en.wikipedia.org/wiki/Maund_\(unit\) "Maund (unit)")* (one *maund* was roughly equal to 37 kilograms (82 lb)),[^342] or as little as one *seer* (1 kilogram (2.2 lb)) [^343] of unhusked rice, or for trifling amounts of cash. Sometimes they were purchased as household servants, where they would "grow up as little better than domestic slaves".[^344] They were also purchased by sexual predators. Altogether, according to Greenough, the victimisation and exploitation of these women and children was an immense social cost of the famine.[^345]

## Relief efforts

![ A group of 15 boys, 10 standing and five squatting. Most appear naked. All have prominent pot-bellies but ribs obviously showing, a common symptom of malnutrition.](https://en.wikipedia.org/wiki/File:OrphansWhoSurvivedBengalFamine1943.jpg)

Orphans who survived the famine

Aside from the relatively prompt but inadequate provision of [humanitarian aid](https://en.wikipedia.org/wiki/Humanitarian_aid "Humanitarian aid") for the cyclone-stricken areas around Midnapore beginning in October 1942,[^346] the response of both the Bengal Provincial Government and the Government of India was slow.[^347] A "non-trivial" yet "pitifully inadequate" amount of aid began to be distributed from private charitable organisations [^348] in the early months of 1943 and increased through time, mainly in Calcutta but to a limited extent in the countryside.[^349] In April, more government relief began to flow to the outlying areas, but these efforts were restricted in scope and largely misdirected,[^215] with most of the cash and grain supplies flowing to the relatively wealthy landowners and urban middle-class (and typically Hindu) *bhadraloks*.[^350] This initial period of relief included three forms of aid:[^351] agricultural loans (cash for the purchase of paddy seed, plough cattle, and maintenance expenses),[^352] grain given as gratuitous relief, and "test works" that offered food and perhaps a small amount of money in exchange for strenuous work. The "test" aspect arose because there was an assumption that if relatively large numbers of people took the offer, that indicated that famine conditions were prevalent.[^353] Agricultural loans offered no assistance to the large numbers of rural poor who had little or no land.[^354] Grain relief was divided between cheap grain shops and the open market, with far more going to the markets. Supplying grain to the markets was intended to lower grain prices,[^355] but in practice gave little help to the rural poor, instead placing them into direct purchasing competition with wealthier Bengalis at greatly inflated prices.[^356] Thus from the beginning of the crisis until around August 1943, private charity was the principal form of relief available to the very poor.[^357]

According to Paul Greenough, the Provincial Government of Bengal delayed its relief efforts primarily because they had no idea how to deal with a provincial rice market crippled by the interaction of man-made shocks,[^358] as opposed to the far more familiar case of localised shortage due to natural disaster. Moreover, the urban middle-class were their overriding concern, not the rural poor. They were also expecting the Government of India to rescue Bengal by bringing food in from outside the province (350,000 tons had been promised but not delivered). And finally, they had long stood by a public propaganda campaign declaring "sufficiency" in Bengal's rice supply, and were afraid that speaking of scarcity rather than sufficiency would lead to increased [hoarding](https://en.wikipedia.org/wiki/Hoarding_\(economics\) "Hoarding (economics)") and speculation.[^349]

There was also rampant corruption and nepotism in the distribution of government aid; often as much as half of the goods disappeared into the black market or into the hands of friends or relatives.[^359] Despite a long-established and detailed Famine Code that would have triggered a sizable increase in aid, and a statement privately circulated by the government in June 1943 that a state of famine might need to be formally declared,[^360] this declaration never happened.[^202]

Since government relief efforts were initially limited at best, a large and diverse number of private groups and voluntary workers attempted to meet the alarming needs caused by deprivation.[^361] Communists, socialists, wealthy merchants, women's groups, private citizens from distant [Karachi](https://en.wikipedia.org/wiki/Karachi "Karachi") and Indian [expatriates](https://en.wikipedia.org/wiki/Expatriate "Expatriate") from as far away as east Africa aided in relief efforts or sent donations of money, food and cloth.[^362] Markedly diverse political groups, including pro-war allies of the Raj and anti-war nationalists, each set up separate relief funds or aid groups.[^363] Though the efforts of these diverse groups were sometimes marred by Hindu and Muslim [communalism](https://en.wikipedia.org/wiki/Communalism_\(South_Asia\) "Communalism (South Asia)"), with bitter accusations and counter-accusations of unfair treatment and favouritism,[^364] collectively they provided substantial aid.[^362]

Grain began to flow to buyers in Calcutta after the inter-provincial trade barriers were abolished in May 1943,[^365] but on 17 July a flood of the [Damodar River](https://en.wikipedia.org/wiki/Damodar_River "Damodar River") in Midnapore breached major rail lines, severely hampering import by rail.[^366] As the depth and scope of the famine became unmistakable, the Provincial Government began setting up gruel kitchens in August 1943; the gruel, which often provided barely a survival-level caloric intake,[^367] was sometimes unfit for consumption – decayed or contaminated with dirt and filler.[^368] Unfamiliar and indigestible grains were often substituted for rice, causing intestinal distress that frequently resulted in death among the weakest. Nevertheless, food distributed from government gruel kitchens immediately became the main source of aid for the rural poor.[^369]

The rails had been repaired in August and pressure from the Government of India brought substantial supplies into Calcutta during September,[^370] Linlithgow's final month as Viceroy. However, a second problem emerged: the Civil Supplies Department of Bengal was undermanned and under-equipped to distribute the supplies, and the resulting transportation bottleneck left very large piles of grain accumulating in the open air in several locations, including Calcutta's Botanical Garden.[^371] [Field Marshal](https://en.wikipedia.org/wiki/Field_marshal_\(United_Kingdom\) "Field marshal (United Kingdom)") [Archibald Wavell](https://en.wikipedia.org/wiki/Archibald_Wavell,_1st_Earl_Wavell "Archibald Wavell, 1st Earl Wavell") replaced Linlithgow that October, within two weeks he had requested military support for the transport and distribution of crucial supplies. This assistance was delivered promptly, including "a full [division](https://en.wikipedia.org/wiki/Division_\(military\) "Division (military)") of... 15,000 \[British\] soldiers...military [lorries](https://en.wikipedia.org/wiki/Truck "Truck") and the [Royal Air Force](https://en.wikipedia.org/wiki/Royal_Air_Force "Royal Air Force") " and distribution to even the most distant rural areas began on a large scale.[^372] In particular, grain was imported from [the Punjab](https://en.wikipedia.org/wiki/The_Punjab "The Punjab"), and medical resources [^318] were made far more available.[^373] Rank-and-file soldiers, who had sometimes fed the destitute from their rations (defying orders not to do so),[^374] were held in esteem by Bengalis for the efficiency of their work in distributing relief.[^375] That December, the "largest \[rice\] paddy crop ever seen" in Bengal was harvested. According to Greenough, large amounts of land previously used for other crops had been switched to rice production. The price of rice began to fall.[^376] Survivors of the famine and epidemics gathered the harvest themselves,[^377] though in some villages there were no survivors capable of doing the work.[^378] Wavell went on to make several other key policy steps, including promising that aid from other provinces would continue to feed the Bengal countryside, setting up a minimum rations scheme,[^376] and (after considerable effort) prevailing upon Great Britain to increase international imports.[^271] He has been widely praised for his decisive and effective response to the crisis.[^379] All official food relief work ended in December 1943 and January 1944.[^380] [^381] [^249] [^170]

## Economic and political effects

The famine's aftermath greatly accelerated pre-existing [socioeconomic](https://en.wikipedia.org/wiki/Socioeconomics "Socioeconomics") processes leading to poverty and [income inequality](https://en.wikipedia.org/wiki/Income_inequality "Income inequality"),[^382] severely disrupted important elements of Bengal's economy and social fabric, and ruined millions of families.[^383] The crisis overwhelmed and impoverished large segments of the economy. A key source of impoverishment was the widespread coping strategy of selling assets, including land. In 1943 alone in one village in east Bengal, for example, 54 out of a total of 168 families sold all or part of their landholdings; among these, 39 (or very nearly 3 out of 4) did so as a coping strategy in reaction to the scarcity of food.[^384] As the famine wore on across Bengal, nearly 1.6 million families – roughly one-quarter of all landholders – sold or mortgaged their paddy lands in whole or in part. Some did so to profit from skyrocketing prices, but many others were trying to save themselves from crisis-driven distress. A total of 260,000 families sold all their landholdings outright, thus falling from the status of landholders to that of labourers.[^385] The table below illustrates that land transfers increased significantly in each of four successive years. When compared to the base period of 1940–41, the 1941–42 increase was 504%, 1942–43 was 665%, 1943–44 was 1,057% and the increase of 1944–45 compared to 1940–41 was 872%:

<table><caption>Land alienation in Bengal, 1940–41 to 1944–45: number of sales of occupancy holdings <sup><a href="#fn:386">386</a></sup></caption><tbody><tr><th colspan="1">1940–41</th><th colspan="1">1941–42</th><th colspan="1">1942–43</th><th colspan="1">1943–44</th><th colspan="1">1944–45</th></tr><tr><td colspan="1">141,000</td><td colspan="1">711,000</td><td colspan="1">938,000</td><td colspan="1">1,491,000</td><td colspan="1">1,230,000</td></tr></tbody></table>

This fall into lower income groups happened across a number of occupations. In absolute numbers, the hardest hit by post-famine impoverishment were women and landless agricultural labourers. In relative terms, those engaged in rural trade, fishing and transport (boatmen and bullock cart drivers) suffered the most.[^387] In absolute numbers, agricultural labourers faced the highest rates of destitution and mortality.[^388]

The "panicky responses" of the colonial state as it controlled the distribution of medical and food supplies in the wake of the fall of Burma had profound political consequences. "It was soon obvious to the bureaucrats in New Delhi and the provinces, as well as the GHQ (India)," wrote Sanjoy Bhattacharya, "that the disruption caused by these short-term policies – and the political capital being made out of their effects – would necessarily lead to a situation where major constitutional concessions, leading to the dissolution of the Raj, would be unavoidable." [^177] Similarly, nationwide opposition to the boat denial policy, as typified by [Mahatma Gandhi](https://en.wikipedia.org/wiki/Mahatma_Gandhi "Mahatma Gandhi") 's vehement editorials, helped strengthen the [Indian independence movement](https://en.wikipedia.org/wiki/Indian_independence_movement "Indian independence movement"). The denial of boats alarmed the public; the resulting dispute was one point that helped to shape the "Quit India" movement of 1942 and harden the War Cabinet's response. An Indian National Congress (INC) resolution sharply decrying the destruction of boats and seizure of homes was considered treasonous by Churchill's War Cabinet, and was instrumental in the later arrest of the INC's top leadership.[^389] Public thought in India, shaped by impulses such as media coverage and charity efforts, converged into a set of closely related conclusions: the famine had been a national injustice, preventing any recurrence was a national imperative, and the human tragedy left in its wake was as [Jawaharlal Nehru](https://en.wikipedia.org/wiki/Jawaharlal_Nehru "Jawaharlal Nehru") said "...the final judgment on British rule in India".[^390] According to historian Benjamin R. Siegel:

> ...at a national level, famine had transformed India's political landscape, underscoring the need for self-rule to Indian citizens far away from its epicenter. Photographs and journalism and the affective bonds of charity tied Indians inextricably to Bengal and made their suffering its own; a provincial \[famine\] was turned, in the midst of war, into a national case against imperial rule.[^391]

## Media coverage and other depictions

![Top half of the front page of a newspaper. The paper is "People's War". The headline is "Queues of Death". There is a hand-drawn sketch of a distressed mother holding an unconscious or dead male child.](https://en.wikipedia.org/wiki/File:PeoplesWar_Sept1943.jpeg)

The People's War, an organ of the Communist Party of India, published graphic photos of the famine by Sunil Janah.

Calcutta's two leading English-language newspapers were *The Statesman* (at the time British-owned) [^392] and *[Amrita Bazar Patrika](https://en.wikipedia.org/wiki/Amrita_Bazar_Patrika "Amrita Bazar Patrika")* (edited by independence campaigner [Tushar Kanti Ghosh](https://en.wikipedia.org/wiki/Tushar_Kanti_Ghosh "Tushar Kanti Ghosh")).[^393] In the early months of the famine, the government applied pressure on newspapers to "calm public fears about the food supply" [^394] and follow the official stance that there was no rice shortage. This effort had some success; *The Statesman* published editorials asserting that the famine was due solely to speculation and hoarding, while "berating local traders and producers, and praising ministerial efforts".[^394] [^20] News of the famine was also subject to strict war-time censorship – even use of the word "famine" was prohibited [^320] – leading *The Statesman* later to remark that the UK government "seems virtually to have withheld from the British public knowledge that there was famine in Bengal at all".[^395]

Beginning in mid-July 1943 and more so in August, however, these two newspapers began publishing detailed and increasingly critical accounts of the depth and scope of the famine, its impact on society, and the nature of British, Hindu, and Muslim political responses.[^396] A turning point in news coverage came on 22 August 1943, when the editor of *The Statesman*, [Ian Stephens](https://en.wikipedia.org/wiki/Ian_Stephens_\(editor\) "Ian Stephens (editor)"), solicited and published a series of graphic photos of the victims. These made world headlines [^395] and marked the beginning of domestic and international consciousness of the famine.[^397] The next morning, "in Delhi second-hand copies of the paper were selling at several times the news-stand price," [^320] and soon "in [Washington](https://en.wikipedia.org/wiki/Washington,_D.C. "Washington, D.C.") the [State Department](https://en.wikipedia.org/wiki/United_States_Department_of_State "United States Department of State") circulated them among policy makers".[^398] In Britain, *The Guardian* called the situation "horrible beyond description".[^399] The images had a profound effect and marked "for many, the beginning of the end of colonial rule".[^399] Stephens' decision to publish them and to adopt a defiant editorial stance won accolades from many (including the Famine Inquiry Commission),[^400] and has been described as "a singular act of journalistic courage without which many more lives would have surely been lost".[^320] The publication of the images, along with Stephens' editorials, not only helped to bring the famine to an end by driving the British government to supply adequate relief to the victims,[^401] but also inspired Amartya Sen's influential contention that the presence of a free press prevents famines in democratic countries.[^402] The photographs also spurred *Amrita Bazar Patrika* and the Indian Communist Party's organ, *People's War*, to publish similar images; the latter would make photographer [Sunil Janah](https://en.wikipedia.org/wiki/Sunil_Janah "Sunil Janah") famous.[^403] Women journalists who covered the famine included Freda Bedi reporting for Lahore's *The Tribune*,[^404] and [Vasudha Chakravarti](https://en.wikipedia.org/wiki/Vasudha_Chakravarti?action=edit&redlink=1 "Vasudha Chakravarti (page does not exist)") and [Kalyani Bhattacharjee](https://en.wikipedia.org/wiki/Kalyani_Bhattacharjee "Kalyani Bhattacharjee"), who wrote from a nationalist perspective.[^405]

The famine has been portrayed in novels, films and art. The novel *Ashani Sanket* by [Bibhutibhushan Bandyopadhyay](https://en.wikipedia.org/wiki/Bibhutibhushan_Bandyopadhyay "Bibhutibhushan Bandyopadhyay") is a fictional account of a young doctor and his wife in rural Bengal during the famine. It was adapted into a film of the same name (*[Distant Thunder](https://en.wikipedia.org/wiki/Distant_Thunder_\(1973_film\) "Distant Thunder (1973 film)")*) by director [Satyajit Ray](https://en.wikipedia.org/wiki/Satyajit_Ray "Satyajit Ray") in 1973. The film is listed in *The New York Times Guide to the Best 1,000 Movies Ever Made*.[^406] Also well-known are the novel *So Many Hungers!* (1947) by [Bhabani Bhattacharya](https://en.wikipedia.org/wiki/Bhabani_Bhattacharya "Bhabani Bhattacharya") and the 1980 film *[Akaler Shandhaney](https://en.wikipedia.org/wiki/Akaler_Shandhaney "Akaler Shandhaney")* by [Mrinal Sen](https://en.wikipedia.org/wiki/Mrinal_Sen "Mrinal Sen"). [Ella Sen](https://en.wikipedia.org/wiki/Ella_Sen?action=edit&redlink=1 "Ella Sen (page does not exist)") 's collection of stories based on reality, *Darkening Days: Being a Narrative of Famine-Stricken Bengal* recounts horrific events from a woman's point of view.[^407]

A contemporary sketchbook of iconic scenes of famine victims, *Hungry Bengal: a tour through Midnapur District in November, 1943* by [Chittaprosad Bhattacharya](https://en.wikipedia.org/wiki/Chittaprosad_Bhattacharya "Chittaprosad Bhattacharya"), was immediately banned by the British authorities and 5,000 copies were seized and destroyed.[^408] One copy was hidden by Chittaprosad's family and is now in the possession of the Delhi Art Gallery.[^409] Another artist famed for his sketches of the famine was [Zainul Abedin](https://en.wikipedia.org/wiki/Zainul_Abedin "Zainul Abedin").[^410]

## Historiography

Controversy about the causes of the famine has continued in the decades since. Attempting to determine culpability, research and analysis has covered complex issues such as the impacts of natural forces, market failures, failed policies or even malfeasance by governmental institutions, and war profiteering or other unscrupulous acts by private business. The questionable accuracy of much of the available contemporary statistical and anecdotal data is a complicating factor,[^223] as is the fact that the analyses and their conclusions are political and politicised.[^411]

The degree of crop shortfall in late 1942 and its impact in 1943 has dominated the [historiography](https://en.wikipedia.org/wiki/Historiography "Historiography") of the famine.[^69] [^21] The issue reflects a larger debate between two perspectives: one emphasises the importance of food availability decline (FAD) as a cause for famine, and another focuses on the [failure of exchange entitlements](https://en.wikipedia.org/wiki/Theories_of_famines#Failure_of_exchange_entitlements "Theories of famines") (FEE). The FAD explanation blames famine on crop failures brought on principally by crises such as drought, flood, or man-made devastation from war.[^412] The FEE account agrees that such external factors are in some cases important, but holds that famine is primarily the interaction between pre-existing "structural vulnerability" (such as poverty) and a shock event (such as war or political interference in markets) that disrupts the economic market for food. When these interact, some groups within society can become unable to purchase or acquire food even though sufficient supplies are available.[^413]

Both the FAD and the FEE perspectives would agree that Bengal experienced at least some grain shortage in 1943 due to the loss of imports from Burma, damage from the cyclone, and brown-spot infestation. However, the FEE analyses do not consider shortage the main factor,[^414] while FAD-oriented scholars such as Peter Bowbrick hold that a sharp drop in the food supply was the pivotal determining factor.[^415] S.Y. Padmanabhan and later Mark Tauger, in particular, argue that the impact of [brown-spot disease](https://en.wikipedia.org/wiki/Cochliobolus_miyabeanus "Cochliobolus miyabeanus") was vastly underestimated, both during the famine and in later analyses.[^416] The signs of crop infestation by the fungus are subtle; given the social and administrative conditions at the time, local officials would very likely have overlooked them.[^417]

Academic consensus generally follows the FEE account, as formulated by Nobel Prize-winning economist [Amartya Sen](https://en.wikipedia.org/wiki/Amartya_Sen "Amartya Sen"),[^418] in describing the Bengal famine of 1943 as an "entitlements famine". Sen noted that Bengal should have had enough resources to feed its population, but mass deaths occurred due to a combination of wartime inflation, speculative buying, and panic hoarding. These factors together drove food prices beyond the reach of poor Bengalis.[^419] [^420] This in turn caused a fatal decline in the [real wages](https://en.wikipedia.org/wiki/Real_wage "Real wage") of landless agricultural workers,[^421] transforming what should have been a local shortage into a major famine.[^422]

More recent analyses often stress political factors.[^423] Discussions of the government's role split into two broad camps: those which suggest that the government unwittingly caused or was unable to respond to the crisis,[^424] and those which assert that the government wilfully caused or ignored the plight of starving Indians. The former see the problem as a series of avoidable war-time policy failures and "panicky responses" [^177] from a government that was inept,[^425] overwhelmed [^426] and in disarray; the latter being a product of wartime priorities by the "ruling colonial elite",[^427] which left the poor of Bengal unprovided for, due to military considerations.[^428]

![A jowly, well-dressed man, obviously Winston Churchill, standing outside a doorway. He is smiling and making a "V for victory" gesture.](https://en.wikipedia.org/wiki/File:Churchill_V_sign_HU_55521.jpg)

British Prime Minister Winston Churchill in 1943

Sen acknowledges that British misgovernment played a role in the crisis but believes the main issue was a misunderstanding of the famine's cause. According to Sen, the British had put too much focus on measuring food shortages that didn't actually exist, rather than addressing the real problem: that the severe inflation had made food unaffordable for many people. This inflation created significant imbalances in people's ability to obtain food, which was the true driver of the famine.[^429] In stark contrast, although [Cormac Ó Gráda](https://en.wikipedia.org/wiki/Cormac_%C3%93_Gr%C3%A1da "Cormac Ó Gráda") notes that the exchange entitlements view of this famine is generally accepted,[^430] he lends greater weight to the importance of a crop shortfall than does Sen, and goes on to largely reject Sen's emphasis on hoarding and speculation.[^431] He does not stop there but emphasises a "lack of political will" and the pressure of wartime priorities that drove the British government and the provincial government of Bengal to make fateful decisions: the "denial policies", the use of heavy shipping for war supplies rather than food, the refusal to officially declare a state of famine, and the [Balkanisation](https://en.wikipedia.org/wiki/Balkanization "Balkanization") of grain markets through inter-provincial trade barriers.[^432] On this view, these policies were designed to serve British military goals at the expense of Indian interests,[^433] reflecting the War Cabinet's willingness to "supply the Army's needs and let the Indian people starve if necessary".[^434] Far from being accidental, these dislocations were fully recognised beforehand as fatal for identifiable Indian groups whose economic activities did not directly, actively, or adequately advance British military goals.[^435] The policies may have met their intended wartime goals, but only at the cost of large-scale dislocations in the domestic economy. The British government, this argument maintains, thus bears moral responsibility for the rural deaths.[^436] Auriol Law-Smith's discussion of contributing causes of the famine also lays blame on the British government of India, primarily emphasising Viceroy Linlithgow's lack of political will to "infringe provincial autonomy" by using his authority to remove interprovincial barriers, which would have ensured the free movement of life-saving grain.[^437] According to 2018 research by Indian economist [Utsa Patnaik](https://en.wikipedia.org/wiki/Utsa_Patnaik "Utsa Patnaik"), the "profit inflation" policies had caused food prices to soar sixfold while wages had remained stagnant, resulting in the widespread starvation and the deaths of three million people. Patnaik argues that this economic manipulation had deliberately "pushed food out of reach of the poor", and was part of a systematic colonial exploitation, that prioritized British interests over the welfare of the colonized populations.[^438] [^29] [^30]

A related argument, present since the days of the famine [^439] but expressed at length by journalist [Madhusree Mukerjee](https://en.wikipedia.org/wiki/Madhusree_Mukerjee "Madhusree Mukerjee"), accuses key figures in the British government (particularly Prime Minister Winston Churchill) [^440] of genuine antipathy toward Indians and [Indian independence](https://en.wikipedia.org/wiki/Winston_Churchill#Indian_independence "Winston Churchill"), an antipathy arising mainly from a desire to protect [imperialist](https://en.wikipedia.org/wiki/Imperialism "Imperialism") power but sourced from [racist](https://en.wikipedia.org/wiki/Racism "Racism") attitudes towards Indian people.[^441] This is sometimes attributed to British anger over widespread Bengali nationalist sentiment and the perceived treachery of the violent [Quit India](https://en.wikipedia.org/wiki/Quit_India "Quit India") uprising.[^442] Others have critiqued this view [^443] with [Tirthankar Roy](https://en.wikipedia.org/wiki/Tirthankar_Roy "Tirthankar Roy") referring to it as "naive".[^444] Instead, Roy attributes the delayed response to rivalry and misinformation spread about the famine within the local government, particularly by the Minister of Civil Supplies [Huseyn Shaheed Suhrawardy](https://en.wikipedia.org/wiki/Huseyn_Shaheed_Suhrawardy "Huseyn Shaheed Suhrawardy"), who maintained there was no food shortage throughout the famine, while noting that there is little evidence of Churchill's views influencing War Cabinet policy.[^444]

For its part, the report of the Famine Commission (its members appointed in 1944 by the British Government of India [^445] and chaired by Sir John Woodhead, a former Indian Civil Service official in Bengal),[^446] absolved the British government from all major blame.[^447] It acknowledged some failures in its price controls and transportation efforts [^448] and laid additional responsibility at the feet of unavoidable fate, but reserved its broadest and most forceful finger-pointing for local politicians in the (largely Muslim) [^449] [^22] provincial [Government of Bengal](https://en.wikipedia.org/wiki/Prime_Minister_of_Bengal "Prime Minister of Bengal"):[^450] As it stated, "after considering all the circumstances, we cannot avoid the conclusion that it lay in the power of the Government of Bengal, by bold, resolute and well-conceived measures at the right time to have largely prevented the tragedy of the famine as it actually took place".[^451] For example, the position of the Famine Inquiry Commission with respect to charges that prioritised distribution aggravated the famine is that the Government of Bengal's lack of control over supplies was the more serious matter.[^452] Some sources allege that the Famine Commission deliberately declined to blame the UK or was even designed to do so;[^453] however, Bowbrick defends the report's overall accuracy, stating it was undertaken without any preconceptions and twice describing it as excellent. Meanwhile, he repeatedly and rather forcefully favors its analyses over Sen's.[^454] British accusations that Indian officials were responsible began as early as 1943, as an editorial in *The Statesman* on 5 October noted disapprovingly.[^395]

Paul Greenough stands somewhat apart from other analysts by emphasising a pattern of victimization.[^455] In his account, Bengal was at base susceptible to famine because of population pressures and market inefficiencies, and these were exacerbated by a dire combination of war, political strife, and natural causes.[^456] [^457] Above all else, direct blame should be laid on a series of government interventions that disrupted the wholesale rice market.[^458] Once the crisis began, morbidity rates were driven by a series of cultural decisions, as dependents were abandoned by their providers at every level of society: male heads of peasant households abandoned weaker family members; landholders abandoned the various forms of patronage that according to Greenough had traditionally been maintained, and the government abandoned the rural poor. These abandoned groups had been socially and politically selected for death.[^459]

A final line of blaming holds that major industrialists either caused or at least significantly exacerbated the famine through speculation, war profiteering, hoarding, and corruption – "unscrupulous, heartless grain traders forcing up prices based on false rumors".[^460] Working from an assumption that the Bengal famine claimed 1.5 million lives, the Famine Inquiry Commission made a "gruesome calculation" that "nearly a thousand rupees \[£88 in 1944; equivalent to £3,374 [^461] or $1,609 [^462] in 2025\] of profits were accrued per death".[^463] As the Famine Inquiry Commission put it, "a large part of the community lived in plenty while others starved... corruption was widespread throughout the province and in many classes of society".[^464]

A 2019 study on "Drought and Famine in India, 1870–2016", by Vimal Mishra, the lead researcher (along with other researchers in India and the US) published in the journal [Geophysical Research Letters](https://en.wikipedia.org/wiki/Geophysical_Research_Letters "Geophysical Research Letters"), was the first to use weather data to argue that wartime policies had exacerbated the Bengal famine. It concluded that British policies under Winston Churchill significantly contributed to the 1943 Bengal famine and the famine was "unique" as it did not primarily result from serious drought, unlike previous famines in India. Data showed rain levels in late 1943 had been "above average". Instead, they concluded that factors such as wartime inflation, speculative buying, and panic hoarding had severely exacerbated food shortages while Churchill's government had continued exporting rice from India despite warnings of impending famine and denied emergency wheat supplies. In contrast, previous local government responses to famines, such as the 1873–74 Bihar famine, were more effective, highlighting the detrimental impact of colonial British policies to the Bengal famine.[^33]

According to Indian historian Zareer Masani, directly blaming Churchill for the famine relies on historical oversimplifications that overlook the complex situation on the ground. Masani highlights that the Prime Minister was largely misled by official reports from the colonial administration. These documents assured him that there distorted his initial perception of the crisis. Furthermore, the management of food supplies and agriculture wasn't the direct responsibility of London, but fell under the jurisdiction of the autonomous provincial government of Bengal, which was run by a local coalition at the time. This regional authority struggled against massive speculation and the hoarding of rice stocks by local merchants, who withdrew food from the market to drive up prices. Ultimately, the crisis was rooted in the context of the War. The Japanese invasion of Burma abruptly cut off the primary rice import route to Bengal, a disaster compounded by a devastating cyclone in late 1942. Masani points out that as soon as the full scale of the tragedy was confirmed, Churchill ordered the shipment of hundreds of thousands of tons of grain to Bengal, a decision made despite a severe shortage of merchant shipping and the urgent military demands of the War [^465].

[^1]: The estimates do not include Orissa. There has been a wide range of estimates since the famine. See [Maharatna (1996](#CITEREFMaharatna1996), pp. 214–231), especially table 5.1 on page 215, for a review of the data. [Devereux (2000](#CITEREFDevereux2000), p. 6) suggested a range of 2.1–3 million, deriving the lower figure from [Dyson & Maharatna (1991)](#CITEREFDysonMaharatna1991) and the upper from [Amartya Sen](https://en.wikipedia.org/wiki/Amartya_Sen "Amartya Sen") 's "widely quoted figure of 3 million".[^23] Sen estimated between 2.7 and 3 million deaths for the period 1943–1946.[^24] [Cormac Ó Gráda](https://en.wikipedia.org/wiki/Cormac_%C3%93_Gr%C3%A1da "Cormac Ó Gráda") (2007): "\[E\]stimates of mortality in Bengal range from 0.8 million to 3.8 million; today the scholarly consensus is about 2.1 million (Hall-Matthews 2005; Sen 1981; Maharatna 1996)." [^25] Paul R. Greenough (1982) suggested a total of 3.5 to 3.8 million famine-related deaths.[^26] Contemporaneous estimates included, in 1945, that of the Famine Inquiry Commission – appointed in 1944 by the Government of India and chaired by Sir John Woodhead – of around 1.5 million famine-related deaths out of Bengal's population of 60.3 million.[^27] That figure covered January 1943 to June 1944.[^28] K. P. Chattopadhyay, a [University of Calcutta](https://en.wikipedia.org/wiki/University_of_Calcutta "University of Calcutta") anthropologist, estimated in 1944 that 3.5 million famine-related deaths had occurred in 1943; this was widely believed at the time, but subsequently rejected by many scholars as too high ([Greenough 1982](#CITEREFGreenough1982), pp. 300–301; [Dyson & Maharatna 1991](#CITEREFDysonMaharatna1991), p. 281).

[^2]: [Famine Inquiry Commission (1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 5): "The total extent of the cultivated land in Bengal is nearly 29 million acres. Some of this is cropped more than once, and the total area sown under various crops is normally 35 million acres. The principal crop is rice which accounts for a little less than 26 million acres. In fact, Bengal may be described as a land of rice growers and rice eaters. The area under other staple foodgrains is small; that under wheat, for instance, is less than 200,000 acres, and the total area under food crops of all kinds other than rice is somewhat over 4 million acres. This includes land devoted to the cultivation of fruits and vegetables. The most important non-food crop is jute, which accounts normally for between 2 million and 2.5 million acres."

[^3]: Some land [produced more than one crop a year](https://en.wikipedia.org/wiki/Multiple_cropping "Multiple cropping"), sometimes rice in one season and other crops in another, reducing rice's yearly proportion of its total crops sown ([Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 10).

[^4]: Wheat was considered a staple by many in Calcutta, but nowhere else in Bengal.([Knight 1954](#CITEREFKnight1954), p. 78) The wheat-eating enclave in Calcutta were industrial workers who had come there from other provinces ([Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 31).

[^5]: [Famine Inquiry Commission (1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 4) describes the ratio of population to land in European terms: "The area of the province is 77,442 square miles, rather more than the area of England, Wales, and one-half of Scotland. The population is a little over 60 millions, which is well in excess of that of the \[entire\] United Kingdom, and not much less than the aggregate population of France, Belgium, Holland, and Denmark." In terms of US states, Bengal was roughly the size of Idaho ([Bulletin of the U.S. Army 1943](#CITEREFBulletin_of_the_U.S._Army1943), p. 28).

[^6]: Census statistics were considerably more accurate than those for foodgrain production. ([Knight 1954](#CITEREFKnight1954), p. 22)

[^7]: "... a peasant \[i.e., ryot\] differs from a landless labourer in terms of ownership (since he owns land, which the labourer does not), the landless share-cropper differs from the landless labourer not in their respective ownerships, but in the way they can use the only resource they own, viz. labour power. The landless labourer will be employed in exchange for a wage, while the share-cropper will do the cultivation and own a part of the *product* \[including especially rice\]" ([A. Sen 1981a](#CITEREFA._Sen1981a), p. 5).

[^8]: For example, "\[over\] and above the half share of the product that was the customary rent, the jotedars commonly recovered grain loans with 50% interest and seed loans with 100% interest at the time of harvest... they \[also\] arbitrarily levied a wide variety of \[extra charges\]." ([Bose 1986](#CITEREFBose1986), pp. 256–257)

[^9]: Two contemporary reports – the 1940 Report of the Land Revenue Commission of Bengal ([Government of Bengal 1940b](#CITEREFGovernment_of_Bengal1940b)) and the field survey published in [Mahalanobis, Mukherjea & Ghosh (1946)](#CITEREFMahalanobisMukherjeaGhosh1946) – agree that even before the famine of 1943, at least half of the nearly 46 million in Bengal who depended on agriculture for their livelihood were landless or land-poor labourers under consistent threat of food insecurity. Approximately two acres of farmland would provide subsistence-level food for an average family ([Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), pp. 372, 374). According to the 1940 Land Revenue Board report, 46% of rural families owned two acres or less or were landless tenants. The 1946 survey by the [Indian Statistical Institute](https://en.wikipedia.org/wiki/Indian_Statistical_Institute "Indian Statistical Institute"), found that 77% did not own sufficient land to provide subsistence for themselves.

[^10]: Ceylon (now [Sri Lanka](https://en.wikipedia.org/wiki/Sri_Lanka "Sri Lanka")) was a vital asset in the Allied war effort. It was "one of the very few sources of natural rubber still controlled by the Allies".([Axelrod & Kingston 2007](#CITEREFAxelrodKingston2007), p. 220) Further, it was a vital link in "British supply lines around the southern tip of Africa to the Middle East, India and Australia".([Lyons 2016](#CITEREFLyons2016), p. 150) Churchill noted Ceylon's importance in maintaining the flow of oil from the Middle East, and considered its port of [Colombo](https://en.wikipedia.org/wiki/Colombo "Colombo") "the only really good base" for the [Eastern Fleet](https://en.wikipedia.org/wiki/Eastern_Fleet "Eastern Fleet") and the defence of India.([Churchill 1986](#CITEREFChurchill1986), pp. 152, 155, 162)

[^11]: In late January 1943, for example, the [Viceroy Linlithgow](https://en.wikipedia.org/wiki/Victor_Hope,_2nd_Marquess_of_Linlithgow "Victor Hope, 2nd Marquess of Linlithgow") wrote to the Secretary of State for India, [Leo Amery](https://en.wikipedia.org/wiki/Leo_Amery "Leo Amery"): "Mindful of our difficulties about food I told \[the Premier of Bengal, [A. K. Fazlul Huq](https://en.wikipedia.org/wiki/A._K._Fazlul_Huq "A. K. Fazlul Huq")\] that he simply *must* produce some more rice out of Bengal for Ceylon even if Bengal itself went short! He was by no means unsympathetic, and it is possible that I may in the result screw a little out of them. The Chief \[Churchill\] continues to press me most strongly about both rice and labour for Ceylon".([Mansergh 1971](#CITEREFMansergh1971), p. 544, Document no. 362) Quoted in many sources, for example [A. Sen (1977](#CITEREFA._Sen1977), p. 54), [Ó Gráda (2008](#CITEREFÓ_Gráda2008), pp. 30–31), [Mukerjee (2010](#CITEREFMukerjee2010), p. 129), and [J. Mukherjee (2015](#CITEREFJ._Mukherjee2015), p. 93).

[^12]: Sources agree that the impetus came from the military; see for example [Ó Gráda (2009](#CITEREFÓ_Gráda2009), p. 154). Some, such as [J. Mukherjee (2015](#CITEREFJ._Mukherjee2015), p. 58), add that Herbert was "instructed through central government channels". At least two sources have suggested that the avowed objective of denying supplies to an invading Japanese army was less important than a covert goal of controlling available rice stocks and means of transport so the rice supplies could be directed toward the armed forces; see [Iqbal (2010](#CITEREFIqbal2010), p. 282) and [De (2006](#CITEREFDe2006), p. 12).

[^13]: "On 29 November 1941 the central government conferred, by notification, concurrent powers on the provincial governments under the Defence of India Rules (DIR) to restrict/prohibit the movement of food grains and to requisition both food grains and any other commodity they considered necessary. With regard to food grains, the provincial governments had the power to restrict/stop, seize them and regulate their price, divert them from their usual channels of transportation and, as stated, their movement".([De 2006](#CITEREFDe2006), p. 8)

[^14]: Note that this was *not* due to any shortage of wheat; on the contrary, the Punjab ran a huge surplus. A shortage of rice throughout India in 1941 caused foodgrain prices in general to rise. Agriculturalists in the Punjab wished to hold onto stocks to a small extent to cover their own rice deficit, but more importantly to profit from the price increases. To aid food purchases in the rest of India, the Indian government placed price controls on Punjabi wheat. The response was swift: the majority of wheat farmers held onto their stocks, so wheat disappeared and the Punjab government began to assert that it now faced famine conditions ([Yong 2005](#CITEREFYong2005), pp. 291–294).

[^15]: Bengal as a whole in 1943 was subject to acts of sabotage against institutions or offices of colonial rule, including 151 bomb explosions, 153 cases of severe damage to police stations or other public buildings, 4 police stations destroyed, and 57 cases of sabotage to roads ([Chakrabarty 1992a](#CITEREFChakrabarty1992a), p. 813)

[^16]: In this context, "carryover" is not the same as [excess supply](https://en.wikipedia.org/wiki/Excess_supply "Excess supply") or "surplus". Rice stocks were typically aged for at least two or three months after harvest, since the grain became much more palatable after this period. This ongoing process of deferred consumption had been interrupted by a rice shortfall two years before the famine, and some speculate that supplies had not yet fully recovered.

[^17]: [Mukerjee (2010](#CITEREFMukerjee2010), p. 139) states: "At no recorded instance did either the \[Bengal\] governor or the viceroy express concern for their subjects: their every request for grain would be phrased in terms of the war effort. Contemporaries attested that Herbert cared about the starvation in Bengal; so prioritising the war effort may reflect his and Linlithgow's estimation of which concerns might possibly have moved their superiors."

[^18]: In the table, the rate of total excess deaths from "All causes" for 1943 would be the figure over and above the 1937–41 baseline; specifically, it would be 31.77 – 19.46

[^19]: (11.46 -6.29) / (31.77 – 19.46), then multiplied by 100 = 41.998% or approximately 42%. Discrepancy presumably due to rounding or truncation of tabular data presented in [Maharatna (1992](#CITEREFMaharatna1992), p. 243, Table 5.5).

[^20]: *The Statesman* was the only major newspaper that had acquiesced to (or been persuaded by) government pressure to present the Quit India movement in a negative light ([Greenough 1983](#CITEREFGreenough1983), p. 355 *note 7*; [Greenough 1999](#CITEREFGreenough1999), p. 43 *note 7*).

[^21]: See for example [A. Sen (1977)](#CITEREFA._Sen1977), [A. Sen (1981a)](#CITEREFA._Sen1981a), [A. Sen (1981b)](#CITEREFA._Sen1981b), [Bowbrick (1986)](#CITEREFBowbrick1986), [Tauger (2003)](#CITEREFTauger2003), [Islam (2007a)](#CITEREFIslam2007a) and [Devereux (2001)](#CITEREFDevereux2001).

[^22]: For example, in the 1937 Bengal Congress elections, Hindus won only 60 out of a total of 250 seats ([Prayer 2001](#CITEREFPrayer2001), p. 141 *n 122*). The provincial government of Bengal was essentially under Muslim control from 1937 until 1947, ([Fraser 2006](#CITEREFFraser2006), p. 13) including the office of [Prime Minister of Bengal](https://en.wikipedia.org/wiki/Prime_Minister_of_Bengal "Prime Minister of Bengal").

[^23]: [Devereux 2000](#CITEREFDevereux2000), p. 5.

[^24]: [A. Sen 1980](#CITEREFA._Sen1980), p. 202; [A. Sen 1981a](#CITEREFA._Sen1981a), p. 201.

[^25]: [Ó Gráda 2007](#CITEREFÓ_Gráda2007), p. 19.

[^26]: [Greenough 1982](#CITEREFGreenough1982), pp. 299–309.

[^27]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 109–110.

[^28]: [Greenough 1982](#CITEREFGreenough1982), p. 300.

[^29]: Limaye, Yogita (20 July 2020). ["Churchill's legacy leaves Indians questioning his hero status"](https://www.bbc.com/news/world-asia-india-53405121). *BBC News*. Retrieved 4 March 2026.

[^30]: Monbiot, George (30 March 2022). ["Putin exploits the lie machine but didn't invent it. British history is also full of untruths"](https://www.theguardian.com/commentisfree/2022/mar/30/putin-lie-machine-history-untruths). *The Guardian*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0261-3077](https://search.worldcat.org/issn/0261-3077). Retrieved 1 July 2024.

[^31]: ["Profit Inflation, Keynes and the Holocaust in Bengal, 1943–44 | Economic and Political Weekly"](https://www.epw.in/journal/2018/42/special-articles/profit-inflation-keynes-and-holocaust.html). *www.epw.in*. 17 October 2018. Retrieved 1 July 2024.

[^32]: Patnaik, Utsa (December 2017). ["Mr Keynes and the forgotten holocaust in Bengal, 1943–44: Or, the macroeconomics of extreme demand compression"](http://journals.sagepub.com/doi/10.1177/2348448917725856). *Studies in People's History*. **4** (2): 197–210. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1177/2348448917725856](https://doi.org/10.1177%2F2348448917725856). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [2348-4489](https://search.worldcat.org/issn/2348-4489).

[^33]: Safi, Michael (29 March 2019). ["Churchill's policies contributed to 1943 Bengal famine – study"](https://www.theguardian.com/world/2019/mar/29/winston-churchill-policies-contributed-to-1943-bengal-famine-study). *The Guardian*. [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [0261-3077](https://search.worldcat.org/issn/0261-3077). Retrieved 19 June 2024.

[^34]: ["Remembering WW2's forgotten famine"](https://www.bbc.com/news/av/magazine-32058977). *BBC News*. Retrieved 19 June 2024.

[^35]: Osborne, Samuel (14 August 2017). ["5 of the worst atrocities carried out by British Empire, after 'historical amnesia' claims | The Independent"](https://www.independent.co.uk/news/uk/home-news/worst-atrocities-british-empire-amritsar-boer-war-concentration-camp-mau-mau-a7612176.html). *The Independent*. Retrieved 19 June 2024.

[^36]: [Arnold 1991](#CITEREFArnold1991), p. 68.

[^37]: [Bose 1986](#CITEREFBose1986), pp. 33–37.

[^38]: [Ó Gráda 2008](#CITEREFÓ_Gráda2008), p. 20.

[^39]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 6–7.

[^40]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), p. 338.

[^41]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 10.

[^42]: [De 2006](#CITEREFDe2006), p. 13.

[^43]: [Bayly & Harper 2005](#CITEREFBaylyHarper2005), pp. 284–285.

[^44]: [A. Sen 1977](#CITEREFA._Sen1977), p. 36; [Tauger 2009](#CITEREFTauger2009), pp. 167–168.

[^45]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 32–33.

[^46]: [Islam 2007a](#CITEREFIslam2007a), p. 433.

[^47]: [Das 2008](#CITEREFDas2008), p. 61.

[^48]: [Islam 2007a](#CITEREFIslam2007a), pp. 433–434.

[^49]: [Dyson 1991](#CITEREFDyson1991), p. 279.

[^50]: [Weigold 1999](#CITEREFWeigold1999), p. 73.

[^51]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 4.

[^52]: [Dyson 2018](#CITEREFDyson2018), p. 158.

[^53]: [Roy 2019](#CITEREFRoy2019), p. 113.

[^54]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 4, 203.

[^55]: [Greenough 1982](#CITEREFGreenough1982), p. 84.

[^56]: [Islam 2007b](#CITEREFIslam2007b), p. 185.

[^57]: [Islam 2007b](#CITEREFIslam2007b), pp. 200–204.

[^58]: [Roy 2006](#CITEREFRoy2006), pp. 5393–5394.

[^59]: [Roy 2007](#CITEREFRoy2007), p. 244.

[^60]: [Islam 2007b](#CITEREFIslam2007b), pp. 203–204.

[^61]: [Greenough 1982](#CITEREFGreenough1982), pp. 61–84.

[^62]: [Das 1949](#CITEREFDas1949), pp. Chapter XI, pp. 96–111.

[^63]: [Washbrook 1981](#CITEREFWashbrook1981), p. 670.

[^64]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), p. 382.

[^65]: [S. Bose 1982b](#CITEREFS._Bose1982b), p. 469.

[^66]: [Mahalanobis 1944](#CITEREFMahalanobis1944), p. 70.

[^67]: [Islam 2007b](#CITEREFIslam2007b), pp. 55–56.

[^68]: [C. Bose 1930](#CITEREFC._Bose1930), pp. 2–3, 92, 96.

[^69]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 12.

[^70]: [Mukherji 1986](#CITEREFMukherji1986), p. PE-21; [Iqbal 2009](#CITEREFIqbal2009), pp. 1346–1351.

[^71]: [Chaudhuri 1975](#CITEREFChaudhuri1975); [Chatterjee 1986](#CITEREFChatterjee1986), pp. 170–172; [Arnold 1991](#CITEREFArnold1991), p. 68 "In Bengal... More serious and intractable \[than population growth\] was the continuing subdivision of landholdings and the chronic burden of indebtedness on the peasants, which left them by the late 1930s in a permanently 'semi-starved condition', without the resources to endure a major crop failure or survive the drying up of credit that invariably accompanied the prospect of famine in rural India. With no fresh land to bring under cultivation, peasants holdings shrank as the output of rice *per capita* dwindled".

[^72]: [Bekker 1951](#CITEREFBekker1951), pp. 319, 326.

[^73]: [Das 2008](#CITEREFDas2008), p. 60.

[^74]: [Cooper 1983](#CITEREFCooper1983), p. 230.

[^75]: [Ray & Ray 1975](#CITEREFRayRay1975), p. 84; [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 9.

[^76]: [Mukherji 1986](#CITEREFMukherji1986); [S. Bose 1982b](#CITEREFS._Bose1982b), pp. 472–473.

[^77]: [Ali 2012](#CITEREFAli2012), pp. 135–140.

[^78]: [Ali 2012](#CITEREFAli2012), p. 29; [Chatterjee 1986](#CITEREFChatterjee1986), pp. 176–177.

[^79]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 60.

[^80]: [Greenough 1982](#CITEREFGreenough1982), p. 66.

[^81]: [Mukherji 1986](#CITEREFMukherji1986), p. PE-18; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 39.

[^82]: [S. Bose 1982b](#CITEREFS._Bose1982b), pp. 471–472; [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 75.

[^83]: [Chatterjee 1986](#CITEREFChatterjee1986), p. 179.

[^84]: [S. Bose 1982b](#CITEREFS._Bose1982b), pp. 472–473; [Das 2008](#CITEREFDas2008), p. 60.

[^85]: [Ali 2012](#CITEREFAli2012), p. 128; [S. Bose 1982b](#CITEREFS._Bose1982b), p. 469.

[^86]: [Hunt 1987](#CITEREFHunt1987), p. 42; [Iqbal 2010](#CITEREFIqbal2010) chapter 5, particularly p. 107

[^87]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), p. 341; [A. Sen 1981a](#CITEREFA._Sen1981a), p. 73.

[^88]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 63–64; [Iqbal 2011](#CITEREFIqbal2011), pp. 272–273.

[^89]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 8–9; [Natarajan 1946](#CITEREFNatarajan1946), pp. 542, 548 *note 12*; [Brennan 1988](#CITEREFBrennan1988), pp. 10–11.

[^90]: [Mukerjee 2014](#CITEREFMukerjee2014), p. 73; [Iqbal 2011](#CITEREFIqbal2011), pp. 273–274.

[^91]: [Iqbal 2010](#CITEREFIqbal2010), pp. 14–15.

[^92]: [Kazi 2004](#CITEREFKazi2004), pp. 154–157; [Iqbal 2010](#CITEREFIqbal2010), chapter 6, see for example the map on page 187.

[^93]: [McClelland 1859](#CITEREFMcClelland1859), pp. 32, 38, as cited in [Iqbal 2010](#CITEREFIqbal2010), p. 58

[^94]: [Hunt 1987](#CITEREFHunt1987), p. 127; [Learmonth 1957](#CITEREFLearmonth1957), p. 56.

[^95]: [Roy 2006](#CITEREFRoy2006), p. 5394.

[^96]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 128.

[^97]: [Tauger 2009](#CITEREFTauger2009), pp. 194–195.

[^98]: [Maharatna 1992](#CITEREFMaharatna1992), p. 206.

[^99]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 98.

[^100]: [Tinker 1975](#CITEREFTinker1975), p. 2.

[^101]: [Rodger 1942](#CITEREFRodger1942), p. 67.

[^102]: [Tinker 1975](#CITEREFTinker1975), p. 8.

[^103]: [Tinker 1975](#CITEREFTinker1975), pp. 8–10.

[^104]: [Tinker 1975](#CITEREFTinker1975), p. 11.

[^105]: [Tinker 1975](#CITEREFTinker1975), pp. 2–4, 11–12.

[^106]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 23–24, 28–29, 103.

[^107]: [Bhattacharya 2002b](#CITEREFBhattacharya2002b), p. 101.

[^108]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 25.

[^109]: [Wavell 2015](#CITEREFWavell2015), pp. 96–97.

[^110]: [Wavell 2015](#CITEREFWavell2015), pp. 99–100.

[^111]: [Iqbal 2011](#CITEREFIqbal2011), pp. 273–274.

[^112]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 23.

[^113]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 28.

[^114]: Islam, Muhammad Saiful (1 January 2023). ["Impact of British fall in Burma on Bengal famine of 1943: experience of Faridpur district of Bangladesh"](https://doi.org/10.1108%2FSEAMJ-02-2023-0015). *Southeast Asia*. **24** (1): 27–39. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1108/SEAMJ-02-2023-0015](https://doi.org/10.1108%2FSEAMJ-02-2023-0015). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [2948-0426](https://search.worldcat.org/issn/2948-0426).

[^115]: [Greenough 1982](#CITEREFGreenough1982), p. 103 "When Burma fell in April 1942 the hidden mechanism which had for years kept supply and demand in Bengal was rudely jarred... The transport network was already stretched thin by military demands... no \[other provinces\] were willing to accept loss of supply... The result was a derangement of the entire rice market of India..."

[^116]: [S. Bose 1990](#CITEREFS._Bose1990), pp. 703, 715; [Ó Gráda 2008](#CITEREFÓ_Gráda2008), p. 20.

[^117]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 24.

[^118]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 29.

[^119]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 103.

[^120]: [Iqbal 2011](#CITEREFIqbal2011), p. 278.

[^121]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 131–132.

[^122]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 170–171; [Greenough 1980](#CITEREFGreenough1980), p. 222; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 40–41, 110, 191; [De 2006](#CITEREFDe2006), p. 2.

[^123]: [A. Sen 1981a](#CITEREFA._Sen1981a), pp. 50, 67–70.

[^124]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 19–20.

[^125]: [S. Bose 1990](#CITEREFS._Bose1990), p. 715.

[^126]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 221–222.

[^127]: [Rothermund 2002](#CITEREFRothermund2002), pp. 115–122.

[^128]: [Natarajan 1946](#CITEREFNatarajan1946), p. 49.

[^129]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 222.

[^130]: [Mukherji 1986](#CITEREFMukherji1986), p. PE-25.

[^131]: [Knight 1954](#CITEREFKnight1954), p. 101.

[^132]: [S. Bose 1990](#CITEREFS._Bose1990), p. 715; [Rothermund 2002](#CITEREFRothermund2002), pp. 115–122; [A. Sen 1977](#CITEREFA._Sen1977), p. 50; [Mukherji 1986](#CITEREFMukherji1986), p. PE-25.

[^133]: [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 12.

[^134]: [Greenough 1982](#CITEREFGreenough1982), p. 90.

[^135]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 150.

[^136]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 27, as cited in [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 66

[^137]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 66; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 217 *note 23*; note refers to page 59.

[^138]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 25–26; [Iqbal 2011](#CITEREFIqbal2011), p. 282; [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 154.

[^139]: [A. Sen 1977](#CITEREFA._Sen1977), p. 45; [S. Bose 1990](#CITEREFS._Bose1990), p. 717.

[^140]: [Weigold 1999](#CITEREFWeigold1999), p. 67; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 62, 272; [Greenough 1982](#CITEREFGreenough1982), pp. 94–95.

[^141]: Mallik, Senjuti (1 June 2023). ["Colonial Biopolitics and the Great Bengal Famine of 1943"](https://doi.org/10.1007/s10708-022-10803-4). *GeoJournal*. **88** (3): 3205–3221. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1007/s10708-022-10803-4](https://doi.org/10.1007%2Fs10708-022-10803-4). [ISSN](https://en.wikipedia.org/wiki/ISSN_\(identifier\) "ISSN (identifier)") [1572-9893](https://search.worldcat.org/issn/1572-9893). [PMC](https://en.wikipedia.org/wiki/PMC_\(identifier\) "PMC (identifier)") [9735018](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC9735018). [PMID](https://en.wikipedia.org/wiki/PMID_\(identifier\) "PMID (identifier)") [36531534](https://pubmed.ncbi.nlm.nih.gov/36531534).

[^142]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 61–63; [Ghosh 1944](#CITEREFGhosh1944), p. 52.

[^143]: [Greenough 1982](#CITEREFGreenough1982), pp. 120–121.

[^144]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 63–65; [De 2006](#CITEREFDe2006), p. 13.

[^145]: [A. Sen 1977](#CITEREFA._Sen1977), p. 45; [Bayly & Harper 2005](#CITEREFBaylyHarper2005), pp. 284–285; [Iqbal 2011](#CITEREFIqbal2011), p. 274; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 67 Instructions were given in May for the confiscation, destruction or removal of all mechanical transport – private cars, bicycles, carriages and bullock carts "not required for Military of Civil Defense purposes" –– the Victoria Memorial was "camouflaged" in cow dung, andplans were hatched to blow up as many as seventeen bridges in and around Calcutta.

[^146]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 9.

[^147]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 154; [Brennan 1988](#CITEREFBrennan1988), pp. 542–543, *note 3*.

[^148]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 98, 139.

[^149]: [Iqbal 2011](#CITEREFIqbal2011), p. 272; [S. Bose 1990](#CITEREFS._Bose1990), p. 717.

[^150]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 9; [Pinnell 1944](#CITEREFPinnell1944), p. 5, "Army Proposal of 23 April submitted to Chief Civil Defence Commissioner, Bengal", as cited in [Greenough 1982](#CITEREFGreenough1982), p. 89

[^151]: [Iqbal 2011](#CITEREFIqbal2011), p. 276.

[^152]: Mukherjee, Janam (2016). *Hungry Bengal: war, famine and the end of empire*. Oxford: Oxford University Press. [ISBN](https://en.wikipedia.org/wiki/ISBN_\(identifier\) "ISBN (identifier)") [978-0-19-020988-9](https://en.wikipedia.org/wiki/Special:BookSources/978-0-19-020988-9 "Special:BookSources/978-0-19-020988-9").

[^153]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 67–74; [Bhattacharya 2013](#CITEREFBhattacharya2013), pp. 21–23.

[^154]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 58–67; [Iqbal 2011](#CITEREFIqbal2011).

[^155]: [Knight 1954](#CITEREFKnight1954), p. 270.

[^156]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 17, 192.

[^157]: [Knight 1954](#CITEREFKnight1954), p. 279; [Yong 2005](#CITEREFYong2005), pp. 291–294.

[^158]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 32.

[^159]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 23, 193.

[^160]: [Knight 1954](#CITEREFKnight1954), p. 280.

[^161]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 24; [Knight 1954](#CITEREFKnight1954), pp. 48, 280.

[^162]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 16–17.

[^163]: [A. Sen 1977](#CITEREFA._Sen1977), p. 51; [Brennan 1988](#CITEREFBrennan1988), p. 563.

[^164]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 47, 131.

[^165]: [Bhattacharya & Zachariah 1999](#CITEREFBhattacharyaZachariah1999), p. 77.

[^166]: [Greenough 1982](#CITEREFGreenough1982); [Brennan 1988](#CITEREFBrennan1988), pp. 559–560.

[^167]: [Bhattacharya 2002a](#CITEREFBhattacharya2002a), p. 103.

[^168]: [A. Sen 1977](#CITEREFA._Sen1977), pp. 36–38; [Dyson & Maharatna 1991](#CITEREFDysonMaharatna1991), p. 287.

[^169]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 95.

[^170]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 30, as cited in [A. Sen 1981a](#CITEREFA._Sen1981a), p. 56

[^171]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 101.

[^172]: [Bhattacharya 2002a](#CITEREFBhattacharya2002a), p. 39; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 42.

[^173]: [Bhattacharya 2002a](#CITEREFBhattacharya2002a), p. 39.

[^174]: [Greenough 1980](#CITEREFGreenough1980), pp. 211–212; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 89.

[^175]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 30; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 40.

[^176]: [Bhattacharya 2002b](#CITEREFBhattacharya2002b), pp. 101–102.

[^177]: [Bhattacharya 2002b](#CITEREFBhattacharya2002b), p. 102.

[^178]: [S. Bose 1990](#CITEREFS._Bose1990), pp. 716–717.

[^179]: [Bhattacharya & Zachariah 1999](#CITEREFBhattacharyaZachariah1999), p. 99.

[^180]: [Datta 2002](#CITEREFDatta2002), pp. 644–646.

[^181]: [Bayly & Harper 2005](#CITEREFBaylyHarper2005), p. 247.

[^182]: [Bayly & Harper 2005](#CITEREFBaylyHarper2005), p. 248.

[^183]: [Brown 1991](#CITEREFBrown1991), p. 340.

[^184]: [Bandyopadhyay 2004](#CITEREFBandyopadhyay2004), p. 418.

[^185]: [Chakrabarty 1992a](#CITEREFChakrabarty1992a), p. 791; [Chatterjee 1986](#CITEREFChatterjee1986), pp. 180–181.

[^186]: [Bandyopadhyay 2004](#CITEREFBandyopadhyay2004), pp. 418–419.

[^187]: [Panigrahi 2004](#CITEREFPanigrahi2004), pp. 239–240.

[^188]: [Bayly & Harper 2005](#CITEREFBaylyHarper2005), p. 286.

[^189]: [De 2006](#CITEREFDe2006), pp. 2, 5; [Law-Smith 1989](#CITEREFLaw-Smith1989), p. 49.

[^190]: [Greenough 1982](#CITEREFGreenough1982), pp. 105, quoting *Navanati Papers*, "Memo of Rice Mills Association", pp. 181–82 "Once the black market was introduced it was easily found out that the government had neither any reserve of stock for dumping on the market to preserve their \[controlled price rate\] nor an effective organisation to punish breaches of the control."

[^191]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 1, 144–145; [Greenough 1982](#CITEREFGreenough1982), pp. 104–105.

[^192]: [Greenough 1982](#CITEREFGreenough1982), p. 106; [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 33.

[^193]: [Greenough 1982](#CITEREFGreenough1982), pp. 106–107.

[^194]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 34.

[^195]: [A. Sen 1977](#CITEREFA._Sen1977), pp. 36, 38.

[^196]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 58, as cited in [Weigold 1999](#CITEREFWeigold1999), p. 71

[^197]: [A. Sen 1977](#CITEREFA._Sen1977), pp. 38, 50.

[^198]: [A. Sen 1976](#CITEREFA._Sen1976), p. 1280.

[^199]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 112; [Aykroyd 1975](#CITEREFAykroyd1975), p. 74; [Iqbal 2011](#CITEREFIqbal2011), p. 282.

[^200]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 55, 98.

[^201]: [A. Sen 1977](#CITEREFA._Sen1977), p. 50; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), pp. 55, 57.

[^202]: [Brennan 1988](#CITEREFBrennan1988), p. 543 *note 5*; [A. Sen 1977](#CITEREFA._Sen1977), p. 32.

[^203]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 111.

[^204]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 55–58.

[^205]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 40, 104.

[^206]: [A. Sen 1977](#CITEREFA._Sen1977), p. 51.

[^207]: [A. Sen 1977](#CITEREFA._Sen1977), p. 36; [S. Bose 1990](#CITEREFS._Bose1990), pp. 716–717.

[^208]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 58–59.

[^209]: [Ó Gráda 2007](#CITEREFÓ_Gráda2007), p. 10.

[^210]: [Braund 1944](#CITEREFBraund1944); [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 32.

[^211]: [Padmanabhan 1973](#CITEREFPadmanabhan1973), pp. 11, 23, as cited in [Dyson 2018](#CITEREFDyson2018), p. 185. Also cited in [Tauger 2003](#CITEREFTauger2003), [Tauger 2009](#CITEREFTauger2009), pp. 176–179, and [Iqbal 2010](#CITEREFIqbal2010) among others.

[^212]: [Brennan 1988](#CITEREFBrennan1988), p. 543.

[^213]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 32, 65, 66, 236.

[^214]: [Brennan 1988](#CITEREFBrennan1988), p. 552, *note 14*.

[^215]: [Brennan 1988](#CITEREFBrennan1988), p. 548.

[^216]: [Greenough 1982](#CITEREFGreenough1982), pp. 93–96.

[^217]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 78–79.

[^218]: [Tauger 2003](#CITEREFTauger2003), p. 66.

[^219]: [Brennan 1988](#CITEREFBrennan1988), p. 552, *note 12*.

[^220]: [Mahalanobis 1944](#CITEREFMahalanobis1944), p. 71; [Mansergh 1971](#CITEREFMansergh1971), p. 357.

[^221]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), p. 338; [Dewey 1978](#CITEREFDewey1978); [Mahalanobis 1944](#CITEREFMahalanobis1944).

[^222]: [Mahalanobis 1944](#CITEREFMahalanobis1944), pp. 69–71.

[^223]: [Tauger 2009](#CITEREFTauger2009), pp. 173–174.

[^224]: [Dewey 1978](#CITEREFDewey1978), pp. 282, 312–313.

[^225]: [Mahalanobis 1944](#CITEREFMahalanobis1944), p. 71.

[^226]: [Mahalanobis 1944](#CITEREFMahalanobis1944), p. 72.

[^227]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 34, 37.

[^228]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 10.

[^229]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 40; [Greenough 1982](#CITEREFGreenough1982), p. 109.

[^230]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 40.

[^231]: [Greenough 1982](#CITEREFGreenough1982), p. 109, *note 60*.

[^232]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 12; [Mahalanobis 1944](#CITEREFMahalanobis1944), p. 71.

[^233]: [A. Sen 1977](#CITEREFA._Sen1977), p. 39; [A. Sen 1981a](#CITEREFA._Sen1981a), p. 58.

[^234]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 15.

[^235]: [Rothermund 2002](#CITEREFRothermund2002), p. 119.

[^236]: [A. Sen 1977](#CITEREFA._Sen1977), pp. 47, 52; [De 2006](#CITEREFDe2006), p. 30; [Mukerjee 2014](#CITEREFMukerjee2014), p. 73.

[^237]: [De 2006](#CITEREFDe2006), p. 34.

[^238]: [Aykroyd 1975](#CITEREFAykroyd1975), p. 73.

[^239]: [Braund 1944](#CITEREFBraund1944), as cited in [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 50

[^240]: [Blyn 1966](#CITEREFBlyn1966), pp. 253–254, as cited in [Islam 2007a](#CITEREFIslam2007a), pp. 423–424; [Tauger 2009](#CITEREFTauger2009), p. 174

[^241]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), pp. 174–179.

[^242]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 186–187.

[^243]: [A. Sen 1981b](#CITEREFA._Sen1981b), p. 441.

[^244]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 205.

[^245]: [Mansergh & Lumby 1973](#CITEREFManserghLumby1973), Documents 59, 71, 72, 74, 98, 139, 157, 207, 219, as cited in [A. Sen 1977](#CITEREFA._Sen1977), p. 53

[^246]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 122–123; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 53.

[^247]: [Mansergh & Lumby 1973](#CITEREFManserghLumby1973), pp. 133–141, 155–158; [A. Sen 1977](#CITEREFA._Sen1977), p. 52; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 128, 142, 185–188.

[^248]: [Collingham 2012](#CITEREFCollingham2012), p. 152.

[^249]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 141–142; [Mukerjee 2010](#CITEREFMukerjee2010), pp. 191–218.

[^250]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 223–225 *Annexures I and II to Appendix V*, as cited in [Greenough 1980](#CITEREFGreenough1980), p. 214

[^251]: [Tauger 2009](#CITEREFTauger2009), p. 194.

[^252]: [Ó Gráda 2008](#CITEREFÓ_Gráda2008), p. 32.

[^253]: ["Did Churchill Cause the Bengal Famine?"](https://winstonchurchill.hillsdale.edu/did-churchill-cause-the-bengal-famine/#_ftn20). *The Churchill Project*. [Hillsdale College](https://en.wikipedia.org/wiki/Hillsdale_College "Hillsdale College"). 8 April 2015.

[^254]: [Collingham 2012](#CITEREFCollingham2012), p. 153.

[^255]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 112–114, 273.

[^256]: [Tauger 2009](#CITEREFTauger2009), p. 193.

[^257]: Bowbrick, Peter (2 March 2022). ["Falsehoods and myths in famine research: The Bengal famine and Daoud"](https://doi.org/10.1002%2Fjid.3635). *Journal of International Development*. **36** (6): 2513–2536. [doi](https://en.wikipedia.org/wiki/Doi_\(identifier\) "Doi (identifier)"):[10.1002/jid.3635](https://doi.org/10.1002%2Fjid.3635). [S2CID](https://en.wikipedia.org/wiki/S2CID_\(identifier\) "S2CID (identifier)") [247336051](https://api.semanticscholar.org/CorpusID:247336051).

[^258]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 108–109.

[^259]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 116.

[^260]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 40–41.

[^261]: [Brennan 1988](#CITEREFBrennan1988), p. 555.

[^262]: [Greenough 1980](#CITEREFGreenough1980), pp. 205–207 "\[W\]hen crops begin to fail the cultivator \[sells or barters\]... his wife's jewelry, grain, cattle...\[or reduces\] his current food intake... Starving Indian peasants, once they fail in the market, forage in fields, ponds and jungles; they beg on a large scale; they migrate, often over long distances by travelling ticketless on the railways;... \[and they\] take shelter in the protection of a rural patron."

[^263]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. Appendix VI, Extracts of Reports from Commissioners and District Officers, pp. 225–27.

[^264]: [Maharatna 1992](#CITEREFMaharatna1992), p. 210.

[^265]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 41, 116.

[^266]: [Maharatna 1993](#CITEREFMaharatna1993), p. 4.

[^267]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 2.

[^268]: [S. Bose 1990](#CITEREFS._Bose1990), p. 701.

[^269]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 118.

[^270]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 1.

[^271]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 194.

[^272]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 41–42, 211.

[^273]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 120.

[^274]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 78; [Maharatna 1992](#CITEREFMaharatna1992), pp. 268, 383–384.

[^275]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 121, 137.

[^276]: [Maharatna 1992](#CITEREFMaharatna1992), p. 41.

[^277]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 263–264.

[^278]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 262–263.

[^279]: [Dyson 1991](#CITEREFDyson1991), p. 284.

[^280]: [Maharatna 1992](#CITEREFMaharatna1992), p. 270.

[^281]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 260, 263.

[^282]: [Maharatna 1992](#CITEREFMaharatna1992), p. 279.

[^283]: [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 13.

[^284]: [Maharatna 1992](#CITEREFMaharatna1992), p. 282.

[^285]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 87.

[^286]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 92 ”Eastern districts were relatively densely populated, were closest to the Burma war zone, and normally ran grain deficits in pre-famine times”

[^287]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 146; [S. Bose 1990](#CITEREFS._Bose1990), p. 711.

[^288]: [Ali 2012](#CITEREFAli2012), pp. 31, 136.

[^289]: [Greenough 1980](#CITEREFGreenough1980), p. 212.

[^290]: [A. Sen 1981a](#CITEREFA._Sen1981a), p. 75; [Brennan 1988](#CITEREFBrennan1988), p. 542; [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 12.

[^291]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 257, 227.

[^292]: [Maharatna 1992](#CITEREFMaharatna1992), p. 243.

[^293]: Derived from [Maharatna (1992](#CITEREFMaharatna1992), p. 243, Table 5.5)

[^294]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 249, 251.

[^295]: [Maharatna 1992](#CITEREFMaharatna1992), p. 268.

[^296]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 142, 174.

[^297]: [Bhattacharya 2002a](#CITEREFBhattacharya2002a), p. 102.

[^298]: [Maharatna 1992](#CITEREFMaharatna1992), p. 268; [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 136.

[^299]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 136–137.

[^300]: [Maharatna 1992](#CITEREFMaharatna1992), p. 240.

[^301]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 41, 251.

[^302]: [Greenough 1982](#CITEREFGreenough1982), p. 141; [Maharatna 1992](#CITEREFMaharatna1992), p. 378.

[^303]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 128–129.

[^304]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 68.

[^305]: [Maharatna 1992](#CITEREFMaharatna1992), pp. 243–244.

[^306]: [Greenough 1980](#CITEREFGreenough1980), pp. 207–208, 218–225.

[^307]: [Greenough 1980](#CITEREFGreenough1980), pp. 225–233; [Ó Gráda 2009](#CITEREFÓ_Gráda2009).

[^308]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 170, 186–187.

[^309]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 248.

[^310]: [Bedi 1944](#CITEREFBedi1944), p. 13.

[^311]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 67; [Greenough 1980](#CITEREFGreenough1980), pp. 227–228.

[^312]: [Maharatna 1992](#CITEREFMaharatna1992), p. 265, note 92; [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 68.

[^313]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 2; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 135.

[^314]: [A. Sen 1981a](#CITEREFA._Sen1981a), p. 196.

[^315]: [Greenough 1980](#CITEREFGreenough1980), p. 342; [Bowbrick 1986](#CITEREFBowbrick1986), p. 27.

[^316]: [Das 1949](#CITEREFDas1949), pp. 5–6.

[^317]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 138.

[^318]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 141.

[^319]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 139–140.

[^320]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 125.

[^321]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 239–240; [Greenough 1982](#CITEREFGreenough1982), pp. 166–167.

[^322]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 229–230.

[^323]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 239–240.

[^324]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 236.

[^325]: [S. Bose 1990](#CITEREFS._Bose1990), p. 699.

[^326]: [Natarajan 1946](#CITEREFNatarajan1946), pp. 48–50.

[^327]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 133, 221.

[^328]: [Natarajan 1946](#CITEREFNatarajan1946), p. 48.

[^329]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 220–221.

[^330]: [Ray 2005](#CITEREFRay2005), p. 397; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 45.

[^331]: [Cooper 1983](#CITEREFCooper1983), p. 248.

[^332]: [Greenough 1980](#CITEREFGreenough1980), p. 229.

[^333]: [Das 1949](#CITEREFDas1949), p. 44.

[^334]: [Bedi 1944](#CITEREFBedi1944), p. 87, as cited in [Greenough 1980](#CITEREFGreenough1980), p. 229

[^335]: [B. Sen 1945](#CITEREFB._Sen1945), p. 29, as cited in [Greenough 1980](#CITEREFGreenough1980), pp. 229–230 "A section of the contractors has made a profession of selling girls to \[soldiers\]. There are places in Chittagong, Comilla and Noakhali where women sell themselves literally in hordes, and young boys act as pimps...".

[^336]: [Collingham 2012](#CITEREFCollingham2012), pp. 147–148.

[^337]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 158, 183–86; [Greenough 1982](#CITEREFGreenough1982), pp. 221–223, 177–178, 155–157.

[^338]: [Greenough 1980](#CITEREFGreenough1980), p. 233.

[^339]: [Agarwal 2008](#CITEREFAgarwal2008), p. 162.

[^340]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 166.

[^341]: [Greenough 1980](#CITEREFGreenough1980), pp. 230–233.

[^342]: [Greenough 1980](#CITEREFGreenough1980), p. 210.

[^343]: [Greenough 1980](#CITEREFGreenough1980), p. 231.

[^344]: [Greenough 1980](#CITEREFGreenough1980), p. 232.

[^345]: [Greenough 1980](#CITEREFGreenough1980), p. 232; [Greenough 1982](#CITEREFGreenough1982), p. 235.

[^346]: [Brennan 1988](#CITEREFBrennan1988), pp. 548–551.

[^347]: [Greenough 1982](#CITEREFGreenough1982), p. 127; [Brennan 1988](#CITEREFBrennan1988), pp. 547–548, 562–563; [Greenough 1982](#CITEREFGreenough1982), pp. 127–137; [Maharatna 1992](#CITEREFMaharatna1992), pp. 236–238.

[^348]: [A. Sen 1990](#CITEREFA._Sen1990), p. 185.

[^349]: [Greenough 1982](#CITEREFGreenough1982), p. 127.

[^350]: [Greenough 1982](#CITEREFGreenough1982), pp. 133–136; [Brennan 1988](#CITEREFBrennan1988), pp. 559–560.

[^351]: [Maharatna 1992](#CITEREFMaharatna1992), p. 236.

[^352]: [Brennan 1988](#CITEREFBrennan1988), pp. 557–558.

[^353]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 29.

[^354]: [Brennan 1988](#CITEREFBrennan1988), p. 553.

[^355]: [Brennan 1988](#CITEREFBrennan1988), p. 545.

[^356]: [Brennan 1988](#CITEREFBrennan1988), p. 559.

[^357]: [A. Sen 1977](#CITEREFA._Sen1977), p. 38.

[^358]: [Greenough 1982](#CITEREFGreenough1982), pp. 127–128 "Finally, and perhaps most compellingly, responsible officials in the Revenue and Civil Supplies ministries simply did not know how to proceed with relief under the bizarre conditions that had developed by mid–1943".

[^359]: [Brennan 1988](#CITEREFBrennan1988), pp. 555, 557; [Greenough 1982](#CITEREFGreenough1982), p. 169; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 174; [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 75.

[^360]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 69.

[^361]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 176.

[^362]: [Siegel 2018](#CITEREFSiegel2018), pp. 34–35.

[^363]: [Siegel 2018](#CITEREFSiegel2018), p. 41; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 77.

[^364]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 14, 175–176.

[^365]: [Greenough 1980](#CITEREFGreenough1980), p. 213.

[^366]: [Greenough 1982](#CITEREFGreenough1982), p. 129.

[^367]: [Brennan 1988](#CITEREFBrennan1988), p. 552.

[^368]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 180; [De 2006](#CITEREFDe2006), p. 40.

[^369]: [Greenough 1982](#CITEREFGreenough1982), pp. 131–132.

[^370]: [Greenough 1982](#CITEREFGreenough1982), p. 136.

[^371]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 61–62; [Greenough 1980](#CITEREFGreenough1980), p. 214, as cited in [Schneer 1947](#CITEREFSchneer1947), p. 176

[^372]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 62–63; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 140–142.

[^373]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 62–63, 75, 139–40; [Brennan 1988](#CITEREFBrennan1988), p. 558.

[^374]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 194.

[^375]: [Khan 2015](#CITEREFKhan2015), p. 215.

[^376]: [Greenough 1982](#CITEREFGreenough1982), p. 140.

[^377]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 213.

[^378]: [Callahan 2011](#CITEREFCallahan2011), p. 323.

[^379]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 2, 106; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 140–142.

[^380]: [Greenough 1982](#CITEREFGreenough1982), pp. 136–137.

[^381]: [A. Sen 1977](#CITEREFA._Sen1977), p. 36; [A. Sen 1981a](#CITEREFA._Sen1981a), pp. 55, 215.

[^382]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), p. 342.

[^383]: [Greenough 1980](#CITEREFGreenough1980), pp. 218–233; [Greenough 1982](#CITEREFGreenough1982), pp. 184 *ff*.

[^384]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 172.

[^385]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), pp. 339–340.

[^386]: [S. Bose 1993](#CITEREFS._Bose1993), p. 134, Table 8.

[^387]: [Mahalanobis, Mukherjea & Ghosh 1946](#CITEREFMahalanobisMukherjeaGhosh1946), pp. 361, 393.

[^388]: [Maharatna 1992](#CITEREFMaharatna1992), p. 212.

[^389]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 67–71.

[^390]: [Siegel 2018](#CITEREFSiegel2018), pp. 23, 24, 48.

[^391]: [Siegel 2018](#CITEREFSiegel2018), p. 48.

[^392]: [A. Sen 1977](#CITEREFA._Sen1977), p. 52, *fourth footnote*; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 42.

[^393]: [Newspaper baron 2014](#CITEREFNewspaper_baron2014).

[^394]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 4.

[^395]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 57.

[^396]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 43.

[^397]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 125; [Mukerjee 2010](#CITEREFMukerjee2010), p. 261.

[^398]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 261.

[^399]: [Vernon 2009](#CITEREFVernon2009), p. 148.

[^400]: [A. Sen 1977](#CITEREFA._Sen1977); [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 42.

[^401]: [A. Sen 2011](#CITEREFA._Sen2011), p. 341; [Schiffrin 2014](#CITEREFSchiffrin2014), pp. 177–179.

[^402]: [Schiffrin 2014](#CITEREFSchiffrin2014), p. 177.

[^403]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 42, *note 13*; p. 77, *note 132*

[^404]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 173.

[^405]: [Siegel 2018](#CITEREFSiegel2018), p. 36.

[^406]: [Best movies 2003](#CITEREFBest_movies2003).

[^407]: [Siegel 2018](#CITEREFSiegel2018), p. 37.

[^408]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 139.

[^409]: [Chittaprosad's Bengal Famine](#CITEREFChittaprosad's_Bengal_Famine).

[^410]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 42.

[^411]: [Tauger 2009](#CITEREFTauger2009), p. 175; [Siegel 2018](#CITEREFSiegel2018), p. 43; [Devereux 2000](#CITEREFDevereux2000), p. 23; [Devereux 2001](#CITEREFDevereux2001), p. 256.

[^412]: [A. Sen 1976](#CITEREFA._Sen1976); [A. Sen 1981a](#CITEREFA._Sen1981a); [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 90.

[^413]: [Devereux 2000](#CITEREFDevereux2000), pp. 19–21.

[^414]: [Islam 2007a](#CITEREFIslam2007a), p. 424.

[^415]: [Bowbrick 1986](#CITEREFBowbrick1986), pp. 111–114.

[^416]: [Padmanabhan 1973](#CITEREFPadmanabhan1973), pp. 11, 23; [Tauger 2003](#CITEREFTauger2003), pp. 65–67.

[^417]: [Tauger 2009](#CITEREFTauger2009), pp. 178–179.

[^418]: [A. Sen 1977](#CITEREFA._Sen1977); [A. Sen 1981a](#CITEREFA._Sen1981a).

[^419]: [Greenough 1982](#CITEREFGreenough1982), pp. 127–138; [A. Sen 1977](#CITEREFA._Sen1977).

[^420]: [A. Sen 1976](#CITEREFA._Sen1976), p. 1280; [A. Sen 1977](#CITEREFA._Sen1977), p. 50; [A. Sen 1981a](#CITEREFA._Sen1981a), p. 76.

[^421]: [Aykroyd 1975](#CITEREFAykroyd1975), p. 74.

[^422]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), pp. 39–40.

[^423]: [Devereux 2000](#CITEREFDevereux2000), pp. 21–23 "The conclusion is inescapable: famines are *always* political."

[^424]: [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 18.

[^425]: [A. Sen 1977](#CITEREFA._Sen1977), p. 50; [S. Bose 1990](#CITEREFS._Bose1990), p. 717.

[^426]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 195.

[^427]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 91.

[^428]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 10.

[^429]: [A. Sen 1977](#CITEREFA._Sen1977), pp. 52–53.

[^430]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 90: "The 1943–44 famine has become paradigmatic as an 'entitlements famine,' whereby speculation born of greed and panic produced an 'artificial' shortage of rice, the staple food."

[^431]: [Ó Gráda 2008](#CITEREFÓ_Gráda2008), pp. 25–28; [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 90.

[^432]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 90 "...the lack of political will to divert foodstuffs from the war effort rather than \[market\] speculation... was mainly responsible for the famine"; [Ó Gráda 2008](#CITEREFÓ_Gráda2008), pp. 20, 33.

[^433]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), pp. 190–191.

[^434]: [Wavell 1973](#CITEREFWavell1973), pp. 68, 122; [S. Bose 1990](#CITEREFS._Bose1990), pp. 716–717.

[^435]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 251–252.

[^436]: [Ó Gráda 2010](#CITEREFÓ_Gráda2010), p. 39.

[^437]: [Law-Smith 1989](#CITEREFLaw-Smith1989), p. 64.

[^438]: [Patnaik 2018](#CITEREFPatnaik2018), p. 33-34,38–39.

[^439]: [Greenough 1983](#CITEREFGreenough1983), p. 375.

[^440]: [Hickman 2008](#CITEREFHickman2008), pp. 238–240.

[^441]: [Mukerjee 2010](#CITEREFMukerjee2010), pp. 274–275.

[^442]: [Mukerjee 2010](#CITEREFMukerjee2010), p. 273; [Bayly & Harper 2005](#CITEREFBaylyHarper2005), p. 286; [Collingham 2012](#CITEREFCollingham2012), pp. 144–145.

[^443]: [Herman 2010](#CITEREFHerman2010); [Roy 2019](#CITEREFRoy2019), pp. 129–130.

[^444]: [Roy 2019](#CITEREFRoy2019), pp. 129–130.

[^445]: [Islam 2007a](#CITEREFIslam2007a), p. 423.

[^446]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 161.

[^447]: [Siegel 2018](#CITEREFSiegel2018), p. 43; [Ó Gráda 2008](#CITEREFÓ_Gráda2008), p. 24 *note 78*.

[^448]: [Siegel 2018](#CITEREFSiegel2018), p. 43.

[^449]: [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), p. 185.

[^450]: [Ó Gráda 2015](#CITEREFÓ_Gráda2015), p. 39.

[^451]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 105.

[^452]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), pp. 100–102.

[^453]: [Ó Gráda 2009](#CITEREFÓ_Gráda2009), p. 179; [Rangasami 1985](#CITEREFRangasami1985). Cited approvingly in [Osmani 1993](#CITEREFOsmani1993) and [Mukerjee 2014](#CITEREFMukerjee2014), p. 71.

[^454]: [Bowbrick 1985](#CITEREFBowbrick1985), pp. 18, 53, 57: "In my opinion the Famine Commission wrote an excellent report. They sought the truth rather than evidence in favour of their \[own\] hypotheses. They entered into their study with no preconceived ideas as to whether it was a FAD or a distribution famine and they reached a conclusion that was not in accordance with the official view (p. 18)."

[^455]: [A. Sen 1977](#CITEREFA._Sen1977), p. 50.

[^456]: [Greenough 1982](#CITEREFGreenough1982), p. 138.

[^457]: [Bowbrick 1986](#CITEREFBowbrick1986); [Tauger 2003](#CITEREFTauger2003).

[^458]: [Greenough 1982](#CITEREFGreenough1982), p. 262.

[^459]: [Greenough 1982](#CITEREFGreenough1982), pp. 261–275; [S. Bose 1990](#CITEREFS._Bose1990), pp. 721–724.

[^460]: [Tauger 2009](#CITEREFTauger2009), p. 185; [J. Mukherjee 2015](#CITEREFJ._Mukherjee2015), pp. 2–6.

[^461]: UK [Consumer Price Index](https://en.wikipedia.org/wiki/Consumer_Price_Index "Consumer Price Index") inflation figures from 1209–2024 based on data from ["Inflation calculator"](https://www.bankofengland.co.uk/monetary-policy/inflation/inflation-calculator). *[Bank of England](https://en.wikipedia.org/wiki/Bank_of_England "Bank of England")*. London. 18 February 2026. Retrieved 1 April 2026.

[^462]: 1634–1699: [McCusker, J. J.](https://en.wikipedia.org/wiki/John_J._McCusker "John J. McCusker") (1997). [*How Much Is That in Real Money? A Historical Price Index for Use as a Deflator of Money Values in the Economy of the United States: Addenda et Corrigenda*](https://www.americanantiquarian.org/proceedings/44525121.pdf) (PDF). [American Antiquarian Society](https://en.wikipedia.org/wiki/American_Antiquarian_Society "American Antiquarian Society"). 1700–1799: [McCusker, J. J.](https://en.wikipedia.org/wiki/John_J._McCusker "John J. McCusker") (1992). [*How Much Is That in Real Money? A Historical Price Index for Use as a Deflator of Money Values in the Economy of the United States*](https://www.americanantiquarian.org/proceedings/44517778.pdf) (PDF). [American Antiquarian Society](https://en.wikipedia.org/wiki/American_Antiquarian_Society "American Antiquarian Society"). 1800–present: Federal Reserve Bank of Minneapolis. ["Consumer Price Index (estimate) 1800–"](https://www.minneapolisfed.org/about-us/monetary-policy/inflation-calculator/consumer-price-index-1800-). Retrieved 29 February 2024.

[^463]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 83; details in *note 1*; [Aykroyd 1975](#CITEREFAykroyd1975), p. 79.

[^464]: [Famine Inquiry Commission 1945a](#CITEREFFamine_Inquiry_Commission1945a), p. 107, as cited in [Brennan, Heathcote & Lucas 1984](#CITEREFBrennanHeathcoteLucas1984), p. 13

[^465]: Masani, Zareer (December 2020). ["Churchill and the genocide myth"](https://thecritic.co.uk/issues/december-2020/churchill-and-the-genocide-myth/). *The Critic*.