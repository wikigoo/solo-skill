---
title: "Nihilism"
source: "https://en.wikipedia.org/wiki/Nihilism"
---
![Diagram with the texts "nihilism", "meaning", "morality", and "knowledge", together with arrows](https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c0/Forms_of_nihilism_%28contrast_adjusted%29.svg/250px-Forms_of_nihilism_%28contrast_adjusted%29.svg.png?utm_source=en.wikipedia.org&utm_campaign=parser&utm_content=thumbnail)

Different forms of nihilism reject distinct aspects of existence, such as a higher meaning, morality, and knowledge. 14

**Nihilism** [^1] is a family of [philosophical](https://en.wikipedia.org/wiki/Philosophical "Philosophical") views that reject the existence of any objectively meaningful [purpose](https://en.wikipedia.org/wiki/Meaning_of_life "Meaning of life"), [moral value](https://en.wikipedia.org/wiki/Morality "Morality"), [truth](https://en.wikipedia.org/wiki/Truth "Truth"), [knowledge](https://en.wikipedia.org/wiki/Knowledge "Knowledge"), or related concepts. Nihilistic views span several branches of philosophy, including [ethics](https://en.wikipedia.org/wiki/Ethics "Ethics"), [value theory](https://en.wikipedia.org/wiki/Value_theory "Value theory"), [epistemology](https://en.wikipedia.org/wiki/Epistemology "Epistemology"), and [metaphysics](https://en.wikipedia.org/wiki/Metaphysics "Metaphysics"). Nihilism is also described as a broad cultural phenomenon or historical movement that pervades [modernity](https://en.wikipedia.org/wiki/Modernity "Modernity") in the [Western world](https://en.wikipedia.org/wiki/Western_world "Western world").

[Existential nihilism](https://en.wikipedia.org/wiki/Existential_nihilism "Existential nihilism") asserts that [life](https://en.wikipedia.org/wiki/Life "Life") has no objective [meaning](https://en.wikipedia.org/wiki/Meaning_\(existential\) "Meaning (existential)") or purpose. The idea that all individual and societal values are ultimately pointless has been associated with various responses. They range from general [indifference](https://en.wikipedia.org/wiki/Apathy "Apathy") and [existential crises](https://en.wikipedia.org/wiki/Existential_crises "Existential crises") to transformative reinterpretations of established ideals and a creative embrace of personal meaning-making. [Moral nihilism](https://en.wikipedia.org/wiki/Moral_nihilism "Moral nihilism"), a related view, denies the [objective](https://en.wikipedia.org/wiki/Subjectivity_and_objectivity_\(philosophy\) "Subjectivity and objectivity (philosophy)") existence of morality, arguing that moral evaluations and practices rest on misguided assumptions without any foundation in external [reality](https://en.wikipedia.org/wiki/Reality "Reality").

In epistemology or the theory of knowledge, nihilism challenges knowledge and truth. According to [relativism](https://en.wikipedia.org/wiki/Relativism "Relativism"), knowledge, truth, or [meaning](https://en.wikipedia.org/wiki/Meaning_\(philosophy\) "Meaning (philosophy)") are relative to the [perspectives](https://en.wikipedia.org/wiki/Perspectivism "Perspectivism") of specific individuals or cultural contexts. This implies there is no independent framework to assess which opinion is ultimately correct. [Skeptical](https://en.wikipedia.org/wiki/Philosophical_skepticism "Philosophical skepticism") interpretations go further by denying the existence of knowledge or truth altogether. In metaphysics, [one form of nihilism](https://en.wikipedia.org/wiki/Metaphysical_nihilism "Metaphysical nihilism") states that the universe could have been empty without any [objects](https://en.wikipedia.org/wiki/Physical_object "Physical object"). This view holds that there is no fundamental reason for [why something exists rather than nothing](https://en.wikipedia.org/wiki/Why_is_there_anything_at_all%3F "Why is there anything at all?"). [Mereological nihilism](https://en.wikipedia.org/wiki/Mereological_nihilism "Mereological nihilism") asserts there are only simple objects, like [elementary particles](https://en.wikipedia.org/wiki/Elementary_particle "Elementary particle"), but no composite objects, like tables. Cosmological nihilism is the view that reality is [unintelligible](https://en.wikipedia.org/wiki/Intelligible_form "Intelligible form") and indifferent to human understanding. Other nihilist positions include political, semantic, logical, and [therapeutic nihilism](https://en.wikipedia.org/wiki/Therapeutic_nihilism "Therapeutic nihilism").

Some aspects of nihilism have their roots in [ancient philosophy](https://en.wikipedia.org/wiki/Ancient_philosophy "Ancient philosophy") in the form of challenges to established beliefs, values, and practices. However, nihilism is primarily associated with modernity, emerging in the 18th and 19th centuries, particularly in [Germany](https://en.wikipedia.org/wiki/German_philosophy "German philosophy") and [Russia](https://en.wikipedia.org/wiki/Russian_philosophy "Russian philosophy") through the works of [Friedrich Heinrich Jacobi](https://en.wikipedia.org/wiki/Friedrich_Heinrich_Jacobi "Friedrich Heinrich Jacobi") and [Ivan Turgenev](https://en.wikipedia.org/wiki/Ivan_Turgenev "Ivan Turgenev"). It took center stage in the thought of [Friedrich Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche "Friedrich Nietzsche"), who understood nihilism as a pervasive cultural trend in which people lose the traditional values and ideals guiding their lives as a result of [secularization](https://en.wikipedia.org/wiki/Secularization "Secularization"). In the 20th century, nihilist themes were explored by [Dadaism](https://en.wikipedia.org/wiki/Dadaism "Dadaism"), [existentialism](https://en.wikipedia.org/wiki/Existentialism "Existentialism"), and [postmodern philosophy](https://en.wikipedia.org/wiki/Postmodern_philosophy "Postmodern philosophy").

## Definition, related terms, and etymology

Nihilism is a family of views that reject or deny certain ideas about [existence](https://en.wikipedia.org/wiki/Existence "Existence").[^18] Different forms of nihilism deny different claims about reality. For example, [existential nihilism](https://en.wikipedia.org/wiki/Existential_nihilism "Existential nihilism") denies that life has [a higher meaning](https://en.wikipedia.org/wiki/Meaning_of_life "Meaning of life"), and [moral nihilism](https://en.wikipedia.org/wiki/Moral_nihilism "Moral nihilism") rejects the existence of [moral phenomena](https://en.wikipedia.org/wiki/Morality "Morality"). Similarly, epistemological nihilism questions the possibility of objective [knowledge](https://en.wikipedia.org/wiki/Knowledge "Knowledge"), while political nihilism advocates the destruction of established [political institutions](https://en.wikipedia.org/wiki/Political_institution "Political institution").[^14] The precise definition of nihilism is disputed, and many other definitions and types of nihilism have been proposed, covering a wide range of topics studied by different branches of philosophy, such as [ethics](https://en.wikipedia.org/wiki/Ethics "Ethics"), [value theory](https://en.wikipedia.org/wiki/Value_theory "Value theory"), [epistemology](https://en.wikipedia.org/wiki/Epistemology "Epistemology"), and [metaphysics](https://en.wikipedia.org/wiki/Metaphysics "Metaphysics").[^21]

In addition to philosophical theories, nihilism can also refer to a broader cultural phenomenon or historical movement. In this context, it is primarily associated with [modernity](https://en.wikipedia.org/wiki/Modernity "Modernity") in the [Western world](https://en.wikipedia.org/wiki/Western_world "Western world"), characterized by deep skepticism toward established norms and values alongside indifference, [despair](https://en.wikipedia.org/wiki/Despair "Despair"), and a lack of purpose.[^27] Outside the academic discourse, the term *nihilism* is used more loosely in everyday language to describe negative, destructive, or [antisocial](https://en.wikipedia.org/wiki/Anti-social_behaviour "Anti-social behaviour") attitudes, expressing that someone fails to care about a particular issue. For instance, [conservatives](https://en.wikipedia.org/wiki/Conservatives "Conservatives") may be labeled as nihilistic for not valuing progress, while [progressives](https://en.wikipedia.org/wiki/Progressives "Progressives") may be described as such for disregarding established norms.[^33]

![Oil painting of a man in a dark coat with golden embroidery and his arms crossed](https://en.wikipedia.org/wiki/File:Friedrich_Heinrich_Jacobi_portrait.jpg)

Friedrich Heinrich Jacobi coined the term nihilism as a philosophical concept. 36

Nihilism has often been associated with certain disillusioned attitudes toward the world, like [pessimism](https://en.wikipedia.org/wiki/Philosophical_pessimism "Philosophical pessimism"), [absurdism](https://en.wikipedia.org/wiki/Absurdism "Absurdism"), [existentialism](https://en.wikipedia.org/wiki/Existentialism "Existentialism"), [cynicism](https://en.wikipedia.org/wiki/Cynicism_\(contemporary\) "Cynicism (contemporary)"), and [apathy](https://en.wikipedia.org/wiki/Apathy "Apathy"). Although there is some overlap between these concepts, they have distinct meanings and do not necessarily imply nihilism or vice versa.[^40] Pessimism contrasts with [optimism](https://en.wikipedia.org/wiki/Optimism "Optimism") as a negative outlook focused on bad outcomes and characterized by [hopelessness](https://en.wikipedia.org/wiki/Hopelessness "Hopelessness"). A key difference to nihilism, according to one interpretation, is that pessimists see the world as inherently bad, whereas nihilists deny it has any positive or negative meaning.[^43] Absurdism argues that the world is not just meaningless, as existential nihilism asserts, but also absurd. It examines the absurdity arising from paradoxical attempts to find meaning in an inherently meaningless universe.[^46] Existentialism is a philosophical tradition that addresses absurdist and nihilist views while exploring the [human condition](https://en.wikipedia.org/wiki/Human_condition "Human condition") through themes like [anxiety](https://en.wikipedia.org/wiki/Anxiety "Anxiety"), death, freedom, and [authenticity](https://en.wikipedia.org/wiki/Authenticity_\(philosophy\) "Authenticity (philosophy)").[^50] Cynicism is a distrustful attitude toward the motives of other people or society in general.[^53] Apathy is a [state of mind](https://en.wikipedia.org/wiki/Mental_state "Mental state") in which a person does not care about things, characterized by indifference and a lack of desires and emotions.[^57]

The word *nihilism* is a combination of the [Latin](https://en.wikipedia.org/wiki/Latin "Latin") term *nihil*, meaning ' [nothing](https://en.wikipedia.org/wiki/Nothing "Nothing") ', and the [suffix](https://en.wikipedia.org/wiki/Suffix "Suffix") *\-ism*, indicating an [ideology](https://en.wikipedia.org/wiki/Ideology "Ideology"). Its literal meaning is 'ideology of nothing' or 'ideology of negation', reflected in terms like *annihilate* and *nihility*.[^60] The word emerged in 18th-century Germany, first as a literary term and later as a philosophical notion, which [Friedrich Heinrich Jacobi](https://en.wikipedia.org/wiki/Friedrich_Heinrich_Jacobi "Friedrich Heinrich Jacobi") conceptualized to criticize philosophical thought that rejects meaning or existence.[^66] Its first recorded use in English dates to the 1810s.[^15] The term became popular in 19th-century Russia through [Ivan Turgenev](https://en.wikipedia.org/wiki/Ivan_Turgenev "Ivan Turgenev") 's novel *[Fathers and Sons](https://en.wikipedia.org/wiki/Fathers_and_Sons_\(novel\) "Fathers and Sons (novel)")* and the [Russian nihilist movement](https://en.wikipedia.org/wiki/Russian_nihilist_movement "Russian nihilist movement"). Interest in it increased more broadly in the 20th century in response to [Friedrich Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche "Friedrich Nietzsche") 's works, while its meaning expanded to cover a wider range of philosophical and cultural phenomena.[^16]

## Ethics and value theory

![Black-and-white photo showing a man with a thick mustache from the side, wearing a dark suit and resting his head on his hand](https://en.wikipedia.org/wiki/File:Nietzsche1882.jpg)

Friedrich Nietzsche described nihilism as the process in which "the highest values devaluate themselves". 17

Forms of nihilism belonging to the fields of [ethics](https://en.wikipedia.org/wiki/Ethics "Ethics") and [value theory](https://en.wikipedia.org/wiki/Value_theory "Value theory") question the existence of values, [morality](https://en.wikipedia.org/wiki/Morality "Morality"), and the [meaning of life](https://en.wikipedia.org/wiki/Meaning_of_life "Meaning of life").[^77]

### Existential nihilism

Existential nihilism asserts that life has no objective meaning or purpose. It is not limited to the idea that some people fail to find meaning in their lives but makes the broader claim that human existence in general, or the world as a whole, lacks a higher purpose. This view suggests that living a genuinely meaningful life is impossible, that there is no higher reason to continue living, and that all efforts, achievements, [happiness](https://en.wikipedia.org/wiki/Happiness "Happiness"), and [suffering](https://en.wikipedia.org/wiki/Suffering "Suffering") are ultimately pointless.[^19]

Existential nihilism has diverse practical implications since people usually act with a purpose in mind, sometimes with the explicit goal of making their lives meaningful. As a result, the belief that there is no higher meaning or purpose can bring about [indifference](https://en.wikipedia.org/wiki/Apathy "Apathy"), a [lack of motivation](https://en.wikipedia.org/wiki/Motivation#Amotivation_and_akrasia "Motivation"), and [anxiety](https://en.wikipedia.org/wiki/Anxiety "Anxiety"). In extreme cases, this can result in [depression](https://en.wikipedia.org/wiki/Depression_\(mood\) "Depression (mood)") and despair or trigger an [existential crisis](https://en.wikipedia.org/wiki/Existential_crisis "Existential crisis").[^20] [^2] Some philosophers, such as [Martin Heidegger](https://en.wikipedia.org/wiki/Martin_Heidegger "Martin Heidegger"), highlight the connection to [boredom](https://en.wikipedia.org/wiki/Boredom "Boredom"), arguing the lack of engagement and goals experienced in this [mood](https://en.wikipedia.org/wiki/Mood_\(psychology\) "Mood (psychology)") makes life appear pointless.[^22]

![Black-and-white photo of a man with glasses wearing a dark suit with a tie](https://en.wikipedia.org/wiki/File:Sartre_1967_crop.jpg)

Considering the problem of existential nihilism, Jean-Paul Sartre proposed that people can make their lives meaningful by inventing themselves and their values. 23

Diverse possible reactions to existential nihilism have been proposed.[^24] Inspired by [Indian philosophy](https://en.wikipedia.org/wiki/Indian_philosophy "Indian philosophy"), [Arthur Schopenhauer](https://en.wikipedia.org/wiki/Arthur_Schopenhauer "Arthur Schopenhauer") suggested a [pessimistic](https://en.wikipedia.org/wiki/Philosophical_pessimism "Philosophical pessimism") and [ascetic](https://en.wikipedia.org/wiki/Ascetic "Ascetic") response, advocating detachment from the world by [renouncing](https://en.wikipedia.org/wiki/Renunciation "Renunciation") desires and ceasing to affirm life.[^25] [Friedrich Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche "Friedrich Nietzsche") proposed that accepting the lack of an otherworldly source of meaning can liberate individuals from inherited dogmas to affirm life without illusions. He sought to use the disruptive force of nihilism to [re-interpret or re-evaluate all established ideals and values](https://en.wikipedia.org/wiki/Transvaluation_of_values "Transvaluation of values") in an attempt to overcome nihilism and replace it with an [affirmative attitude toward life](https://en.wikipedia.org/wiki/Nietzschean_affirmation "Nietzschean affirmation").[^26] [^3] [Jean-Paul Sartre](https://en.wikipedia.org/wiki/Jean-Paul_Sartre "Jean-Paul Sartre") suggested people can create their own values through the [free choices](https://en.wikipedia.org/wiki/Free_will "Free will") they make, despite the cosmic lack of meaning. Considering different responses to nihilism, [Albert Camus](https://en.wikipedia.org/wiki/Albert_Camus "Albert Camus") rejected [suicide](https://en.wikipedia.org/wiki/Suicide "Suicide") as an evasion of the human condition, arguing instead for a defiant attitude which rebels against meaninglessness and affirms [freedom](https://en.wikipedia.org/wiki/Freedom "Freedom").[^28] Other responses include a destructive attitude aiming to violently tear down political authorities and social institutions, attempts to undermine nihilism by identifying genuine sources of meaning, and a passive [resignation](https://en.wikipedia.org/wiki/Resignation "Resignation") or quiet acceptance.[^29]

Arguments for and against existential nihilism are discussed in the academic discourse. Arguments from a [cosmological](https://en.wikipedia.org/wiki/Cosmological "Cosmological") perspective assert that human existence is a minor and [insignificant](https://en.wikipedia.org/wiki/Insignificant "Insignificant") aspect of the [universe](https://en.wikipedia.org/wiki/Universe "Universe") as a whole, which is indifferent to human concerns and aspirations. A different line of argument asserts that there is no [God](https://en.wikipedia.org/wiki/God "God") and that there can be no objective foundation for values without a God. From this perspective, [religion](https://en.wikipedia.org/wiki/Religion "Religion") may be interpreted as a response to the [fear of death](https://en.wikipedia.org/wiki/Fear_of_death "Fear of death"), functioning as a futile attempt to find meaning in a meaningless universe.[^4] Another viewpoint highlights the pervasiveness of senseless suffering and violence while emphasizing the fleeting nature of happiness. Some theorists link this view to human mortality, suggesting that the inevitability of [death](https://en.wikipedia.org/wiki/Death "Death") renders all human accomplishments transient and ultimately futile.[^31] A different perspective from biology argues that life is driven by blind [natural selection](https://en.wikipedia.org/wiki/Natural_selection "Natural selection") on a large scale and the satisfaction of innate [needs](https://en.wikipedia.org/wiki/Need "Need") on an individual scale, neither of which aims at a higher purpose.[^32] Subjectivists, by contrast, focus on the [subjective](https://en.wikipedia.org/wiki/Subjectivity_and_objectivity_\(philosophy\) "Subjectivity and objectivity (philosophy)") nature of all value experiences, asserting that they lack any objective ground.[^133]

Opponents of existential nihilism have responded with counterarguments to these statements. For example, some reject the pessimistic outlook that life is primarily characterized by suffering, violence, and death, claiming instead that these negative phenomena are counterbalanced by positive experiences such as happiness and [love](https://en.wikipedia.org/wiki/Love "Love").[^34] Many non-nihilistic theories of the meaning of life are examined in the academic discourse. Some [supernaturalistic](https://en.wikipedia.org/wiki/Supernaturalistic "Supernaturalistic") views focus on a god or the soul as sources of meaning. [Naturalistic](https://en.wikipedia.org/wiki/Ethical_naturalism "Ethical naturalism") views, by contrast, assert that subjective or objective values are inherent in the physical world. They include the discussion of fields where humans actively find meaning, such as exercising freedom, committing oneself to a cause, pursuing [altruism](https://en.wikipedia.org/wiki/Altruism "Altruism"), and engaging in positive [social relationships](https://en.wikipedia.org/wiki/Social_relationships "Social relationships").[^35]

### Moral nihilism

Unlike existential nihilism, moral nihilism focuses specifically on moral phenomena rather than a higher meaning or purpose. In its broadest form, it is the [metaethical](https://en.wikipedia.org/wiki/Metaethical "Metaethical") view that there are no moral facts. Also called *amoralism* and *error theory*, it denies the objective existence of morality, arguing that the theories and practices categorized under this label rest on misguided assumptions without any substantial link to reality.[^142] On a practical level, some moral nihilists, such as [Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche "Friedrich Nietzsche"), assert that without [moral obligations](https://en.wikipedia.org/wiki/Obligation#Obligation_and_morality "Obligation"), anything is permitted, suggesting that people are allowed to act however they want. Other moral nihilists reject this conclusion and argue that the denial of morality affects not only moral obligations, or what people are required to do, but also moral [permissions](https://en.wikipedia.org/wiki/Permission_\(philosophy\) "Permission (philosophy)"), or what people are allowed to do.[^37] [Axiological](https://en.wikipedia.org/wiki/Axiological "Axiological") nihilism, a related view, disputes the objective existence of values in general. This rejection is not limited to moral values and also concerns other types, like aesthetic and religious values.[^38]

One argument for moral nihilism suggests that moral properties do not exist because of their odd nature, prescribing what to do rather than describing facts, such as shape and size. Science-based versions of this view hold that scientific inquiry does not reveal objective moral facts or that humans lack a [source](https://en.wikipedia.org/wiki/Epistemology#Sources "Epistemology") of moral knowledge. A related argument for moral nihilism focuses on the conventional aspects of moral evaluations and the difficulties in resolving moral disagreements.[^39] Another line of thought emphasizes the [evolutionary](https://en.wikipedia.org/wiki/Evolution "Evolution") origin of morality, viewing it as a mere product of natural selection without a deeper metaphysical foundation.[^159]

[Moral realists](https://en.wikipedia.org/wiki/Moral_realism "Moral realism") have raised objections to moral nihilism. Naturalists argue that moral facts belong to the natural world and can be [empirically observed](https://en.wikipedia.org/wiki/Empirical_evidence "Empirical evidence"). [Non-naturalists](https://en.wikipedia.org/wiki/Ethical_non-naturalism "Ethical non-naturalism") propose that moral phenomena are different from natural phenomena, but are real nonetheless.[^41] [Common-sense](https://en.wikipedia.org/wiki/Common-sense "Common-sense") philosophers assert that moral beliefs are deeply ingrained in practical experience and everyday reasoning, making the wholesale denial of moral facts implausible. A similar objection asserts that moral nihilism is incoherent and rests on a misunderstanding of moral language. Some critics focus on negative practical consequences rather than truth, suggesting that moral nihilism erodes [social trust](https://en.wikipedia.org/wiki/Social_responsibility "Social responsibility") and leads to antisocial conduct.[^42]

Some philosophers use the term *moral nihilism* in a more restricted sense that does not imply a rejection of all forms of morality. In one alternative sense, moral nihilism is the same as [moral subjectivism](https://en.wikipedia.org/wiki/Moral_subjectivism "Moral subjectivism"), arguing that moral evaluations are purely subjective and lack rational objective justification. As a result, moral judgments are seen as [expressions of arbitrary personal preferences](https://en.wikipedia.org/wiki/Expressivism "Expressivism"), making moral disagreements rationally unresolvable.[^167] In another sense, moral nihilism refers to [ethical egoism](https://en.wikipedia.org/wiki/Ethical_egoism "Ethical egoism"), the theory that morality is determined by self-interest. This view denies that the [well-being](https://en.wikipedia.org/wiki/Well-being "Well-being") of others has moral implications unless it has external consequences for one's own well-being.[^44]

## Epistemology

### Relativism

Epistemological or epistemic nihilism is a family of views that challenge the existence or universal nature of knowledge. Some versions embrace relativism, denying that [objectivity](https://en.wikipedia.org/wiki/Subjectivity_and_objectivity_\(philosophy\) "Subjectivity and objectivity (philosophy)") is possible. For example, [truth-relativism](https://en.wikipedia.org/wiki/Factual_relativism "Factual relativism") asserts that [truth](https://en.wikipedia.org/wiki/Truth "Truth") is relative to the [perspectives](https://en.wikipedia.org/wiki/Perspectivism "Perspectivism") of specific individuals, groups, historical epochs, or cultural contexts.[^5] According to this view, statements like "the sun rises in the east" and "killing is wrong" are true in some perspectives and false in others. This theory not only claims that different people have different opinions but additionally asserts that no independent framework exists to assess which opinion is ultimately correct. As a result, there is no absolute truth on which observers from different perspectives can agree.[^176]

A related form of relativistic nihilism focuses on [meaning](https://en.wikipedia.org/wiki/Meaning_\(philosophy\) "Meaning (philosophy)") rather than truth. It argues that different people rely on incompatible [conceptual schemes](https://en.wikipedia.org/wiki/Conceptual_scheme "Conceptual scheme") [^6] to make sense of the world. In the absence of a universal framework, genuine communication and [shared understanding](https://en.wikipedia.org/wiki/Intersubjectivity "Intersubjectivity") are deemed impossible since each viewpoint has its own interpretation of reality. Without a common ground, these [incommensurable](https://en.wikipedia.org/wiki/Commensurability_\(philosophy_of_science\) "Commensurability (philosophy of science)") belief systems are arbitrary constructions, limiting reason to operations within a specific system without the ability to reconcile them.[^48]

![Black-and-white photo of man wearing a white shirt with his gaze directed slightly upward](https://en.wikipedia.org/wiki/File:Jean-Francois_Lyotard_cropped.jpg)

Exploring antifoundationalism, Jean-François Lyotard challenged metanarratives that aim to provide universal frameworks of rational understanding. 49

Proponents of relativism emphasize the diversity of human viewpoints and the frequent inability to resolve [disagreements](https://en.wikipedia.org/wiki/Disagreement_\(epistemology\) "Disagreement (epistemology)") and reach a shared understanding.[^190] Another argument asserts that theories are usually [underdetermined](https://en.wikipedia.org/wiki/Underdetermination "Underdetermination") by the data supporting them. As a result, there are different equally valid interpretations without an objective standard to resolve their differences.[^51] An influential criticism argues that relativism [undermines itself](https://en.wikipedia.org/wiki/Self-refuting_idea "Self-refuting idea"): if all truths are relative to a viewpoint, then relativism itself is only true for some viewpoints and false for others.[^52] Another objection is that the absence of absolute epistemic standards may have odd consequences, for example, that people should not argue if they disagree or that they should generally suspend their judgments.[^198]

Nietzsche was an influential proponent of relativistic nihilism. He saw belief systems as an expression of the [will to power](https://en.wikipedia.org/wiki/Will_to_power "Will to power"), arguing that their goal is to assert dominance rather than represent reality.[^54] In [postmodern philosophy](https://en.wikipedia.org/wiki/Postmodern_philosophy "Postmodern philosophy"), epistemological nihilism is associated with [antifoundationalism](https://en.wikipedia.org/wiki/Antifoundationalism "Antifoundationalism"), arguing that there is no ultimate rational ground of knowledge or action. It challenges universal frameworks, termed *[grand metanarratives](https://en.wikipedia.org/wiki/Metanarrative "Metanarrative")*, that claim to provide such a ground.[^55]

### Skepticism

While relativist versions of epistemological nihilism allow that knowledge exists relative to a perspective, skeptic versions deny the existence of knowledge in general.[^7] Also called *radical skepticism*, this view argues that there is no foundation or justification of knowledge claims. Unlike more moderate forms of skepticism, it questions even the most reasonable knowledge claims grounded in basic common sense.[^206] A closely related form of epistemological nihilism, sometimes called *alethiological nihilism*, centers on truth rather than knowledge, stating that truth does not exist.[^58]

One argument in favor of radical skepticism asserts that absolute certainty is required for knowledge. It attempts to show that [doubt](https://en.wikipedia.org/wiki/Doubt "Doubt") can never be fully expelled.[^59] For example, the [dream argument](https://en.wikipedia.org/wiki/Dream_argument "Dream argument"), suggested by philosophers such as [René Descartes](https://en.wikipedia.org/wiki/Ren%C3%A9_Descartes "René Descartes"), points out that, while [dreaming](https://en.wikipedia.org/wiki/Dream "Dream"), people usually cannot distinguish between dream and reality. Based on this observation, it argues that there is no knowledge since an individual can never be certain that they are not currently dreaming.[^219] A related approach, inspired by [Roderick Chisholm](https://en.wikipedia.org/wiki/Roderick_Chisholm "Roderick Chisholm"), asserts that [a criterion](https://en.wikipedia.org/wiki/Problem_of_the_criterion "Problem of the criterion") or a standard of evaluation is required to judge what counts as knowledge. It holds that knowledge is impossible because people cannot have this criterion without prior knowledge, meaning that knowledge and its criterion cannot be established independently, as each relies on the other, similar to the [chicken-or-the-egg problem](https://en.wikipedia.org/wiki/Chicken_or_the_egg "Chicken or the egg").[^61] [^8] Despite these arguments, radical skepticism is a rare position, accepted only by a few philosophers and challenged by many criticisms. Its main influence stems from attempts by non-skeptical philosophers to prove that their theories overcome the challenge of skepticism.[^63] Some objections state that radical skepticism is incoherent or self-refuting. For example, if there is no knowledge then skeptics cannot know that there is no knowledge, making it questionable why anyone should believe their theories.[^64] Another counterargument is that common sense gives stronger support for the existence of knowledge than the abstract arguments used to defend skepticism.[^65]

Epistemological nihilism can lead to other forms of nihilism. For instance, the inability to discern the meaning of life can lead to the conclusion that there is no such meaning, resulting in existential nihilism.[^237] [Moral skepticism](https://en.wikipedia.org/wiki/Moral_skepticism "Moral skepticism"), the view that there is no moral knowledge, can have a similar effect: the incapacity to distinguish right from wrong behavior can lead to the rejection of moral facts. Some theorists associate epistemological nihilism primarily with moral skepticism.[^67]

## Metaphysics

### Metaphysical nihilism

Metaphysical or ontological nihilism encompasses views about the fundamental nature of [reality](https://en.wikipedia.org/wiki/Reality "Reality"). One version addresses the question of [why there is anything at all](https://en.wikipedia.org/wiki/Why_there_is_anything_at_all "Why there is anything at all"). It suggests that, at least in principle, an empty world is possible. While this view recognises that the world contains [concrete objects](https://en.wikipedia.org/wiki/Concrete_objects "Concrete objects"), it argues that their existence is not inevitable, because there could have been nothing. In such a scenario, the universe would be entirely empty, without any people, animals, planets, and no other forms of matter or energy.[^68]

The subtraction argument proposes a procedure to support this view. It states that the world does not depend on any particular concrete object. For example, the world could still exist if a specific rock was removed. The argument concludes that an empty world is possible since it is the result of continuously reapplying this idea, subtracting objects at each step until an empty universe remains.[^69] [^9] Opponents of metaphysical nihilism assert that an empty world is impossible, meaning that something must exist. A theologically inspired version asserts that God is a necessary object that must be present even if nothing else is. Another version accepts that any individual concrete object can be removed, but not all at once. It asserts that abstract objects, such as [natural numbers](https://en.wikipedia.org/wiki/Natural_number "Natural number"), have necessary existence and that they require the existence of at least some concrete objects without depending on any specific object in particular.[^250]

A more radical and controversial form of metaphysical nihilism denies the actual existence of objects. It states that there is no world, arguing that the experience of the universe is a mere illusion without an underlying reality. As a result, nothing at all is real. This view is sometimes interpreted as [a form of solipsism](https://en.wikipedia.org/wiki/Metaphysical_solipsism "Metaphysical solipsism"), proposing that only [the self](https://en.wikipedia.org/wiki/The_self "The self") exists and that the external world is merely an idea held by the self without a substantial reality.[^72]

### Mereological nihilism

Mereological or compositional nihilism is the view that complex or composite objects do not exist. Composite objects are objects made up of [proper parts](https://en.wikipedia.org/wiki/Proper_part "Proper part"). For example, a house is a composite object made up of parts like walls, windows, and doors. Each of these parts is itself a composite object made up of smaller parts, such as [molecules](https://en.wikipedia.org/wiki/Molecule "Molecule") and [atoms](https://en.wikipedia.org/wiki/Atom "Atom"). Mereological nihilists argue that only noncomposite or simple objects exist, such as [elementary particles](https://en.wikipedia.org/wiki/Elementary_particle "Elementary particle"). As a result, composite objects are understood as mere collections of simple objects. According to this view, there are no houses or tables; there are only elementary particles arranged house-wise or table-wise.[^73]

Proponents of mereological nihilism highlight the parsimony and [simplicity](https://en.wikipedia.org/wiki/Simplicity "Simplicity") of a minimal [ontology](https://en.wikipedia.org/wiki/Ontology "Ontology") that excludes everything except simple objects, citing metaphysical principles like [Ockham's Razor](https://en.wikipedia.org/wiki/Ockham's_Razor "Ockham's Razor") in its favor.[^74] Another supporting argument suggests that mereological nihilism avoids certain metaphysical paradoxes associated with the relation between parts and wholes, like the [Ship of Theseus](https://en.wikipedia.org/wiki/Ship_of_Theseus "Ship of Theseus").[^75] [^10] Opponents of mereological nihilism highlight the counterintuitive consequences of denying the existence of ordinary objects, contradicting [common sense](https://en.wikipedia.org/wiki/Common_sense "Common sense").[^265] Other criticisms assert that mereological nihilism is unable to provide a coherent framework for how to understand collections of elementary particles or fails to explain phenomena like [emergent properties](https://en.wikipedia.org/wiki/Emergent_properties "Emergent properties").[^78]

### Cosmic nihilism

Cosmic or cosmological nihilism is the view that reality is [unintelligible](https://en.wikipedia.org/wiki/Intelligibility_\(philosophy\) "Intelligibility (philosophy)") and lacks inherent meaning. Closely related to epistemological and existential nihilism, it asserts that the world is blank, featureless, or chaotic, making it indifferent to human attempts to understand it. Cosmic nihilists often emphasize the vastness of the universe, arguing that it shows the insignificance of humans and their endeavors.[^79]

A broad form of cosmic nihilism states that reality as a whole is unintelligible. According to this view, the chaotic nature of the world makes it impossible to comprehend the universe at any level or find meaningful patterns in it, leading to alienation as human understanding fails to grasp reality.[^80] For example, [Max Stirner](https://en.wikipedia.org/wiki/Max_Stirner "Max Stirner") characterized the world as a "metaphysical chaos" without "a comprehensive structure of objective meanings".[^81] In response to arguments stating that it is possible in certain cases to discern patterns and predict outcomes, some cosmic nihilists have proposed more narrow versions. One version acknowledges that humans can understand some aspects of reality, for example, through rigorous scientific study. Nonetheless, this view maintains that the universe remains impenetrable to comprehension and indifferent to human aspirations on other levels, lacking intelligible structures that correspond to objective values, moral principles, and a higher purpose.[^275]

## Other forms

![Black-and-white photo of a porcelain urinal signed "R. Mutt"](https://en.wikipedia.org/wiki/File:Marcel_Duchamp,_1917,_Fountain,_photograph_by_Alfred_Stieglitz.jpg)

Dadaism expresses nihilistic themes in art by challenging artistic standards, for example, by presenting Fountain, a readymade urinal, at a 1917 art exhibition. 82

![Oil painting of a person screaming against the backdrop of an orange sky](https://en.wikipedia.org/wiki/File:Edvard_Munch_-_The_Scream_-_Google_Art_Project.jpg)

Edvard Munch 's 1893 painting The Scream is sometimes associated with nihilism due to its theme of existential terror. 284

In addition to the main nihilistic theories discussed in ethics, value theory, epistemology, and metaphysics, nihilism is also examined in other areas. Discussions include fields such as [literature](https://en.wikipedia.org/wiki/Literature "Literature"), [art](https://en.wikipedia.org/wiki/Art "Art"), culture, and politics.[^84] Various literary works portray characters or attitudes that reject established norms, exhibit disillusionment with life, or struggle with existential despair. Bazarov, the protagonist of [Ivan Turgenev](https://en.wikipedia.org/wiki/Ivan_Turgenev "Ivan Turgenev") 's novel *[Fathers and Sons](https://en.wikipedia.org/wiki/Fathers_and_Sons_\(novel\) "Fathers and Sons (novel)")*, is an early and influential example. Driven by a deep distrust of established authorities, Bazarov follows a cold scientific rationalism. He openly expresses his hate toward conventional beliefs, societal norms, and [sentimentality](https://en.wikipedia.org/wiki/Sentimentality "Sentimentality"), aiming to dismantle them without a vision of what should replace them.[^85] In response to Turgenev's novel, [Nikolay Chernyshevsky](https://en.wikipedia.org/wiki/Nikolay_Chernyshevsky "Nikolay Chernyshevsky") 's *[What Is to Be Done?](https://en.wikipedia.org/wiki/What_Is_to_Be_Done%3F_\(novel\) "What Is to Be Done? (novel)")* explored nihilism from the perspective of [rational egoism](https://en.wikipedia.org/wiki/Rational_egoism "Rational egoism").[^86] Many of [Fyodor Dostoevsky](https://en.wikipedia.org/wiki/Fyodor_Dostoevsky "Fyodor Dostoevsky") 's works explore the problem of nihilism, particularly the idea that without God, there is no moral basis for right or wrong.[^297] For example, his novel *[The Brothers Karamazov](https://en.wikipedia.org/wiki/The_Brothers_Karamazov "The Brothers Karamazov")* examines the tensions between faith, free will, and nihilism through the perspectives of the protagonists.[^88] Nothingness is a central concern for many characters in the works of [Samuel Beckett](https://en.wikipedia.org/wiki/Samuel_Beckett "Samuel Beckett"), either as the object of desire or fear.[^89] Nihilist themes are also present in the literary works of [Franz Kafka](https://en.wikipedia.org/wiki/Franz_Kafka "Franz Kafka"), [Jean-Paul Sartre](https://en.wikipedia.org/wiki/Jean-Paul_Sartre "Jean-Paul Sartre"), and [Albert Camus](https://en.wikipedia.org/wiki/Albert_Camus "Albert Camus").[^90]

In the field of art, [Dadaism](https://en.wikipedia.org/wiki/Dadaism "Dadaism") emerged during the [First World War](https://en.wikipedia.org/wiki/First_World_War "First World War") as a nihilistic rejection of established moral, societal, and [artistic standards](https://en.wikipedia.org/wiki/Beauty "Beauty"). Dadaists embraced chaos, spontaneity, and irrationality, infusing their art with irreverence, nonsense, and [humor](https://en.wikipedia.org/wiki/Humor "Humor") to provoke and challenge traditional [conceptions of art](https://en.wikipedia.org/wiki/Philosophy_of_art "Philosophy of art"). For example, [Marcel Duchamp](https://en.wikipedia.org/wiki/Marcel_Duchamp "Marcel Duchamp") presented *[Fountain](https://en.wikipedia.org/wiki/Fountain_\(Duchamp\) "Fountain (Duchamp)")*, a readymade urinal, at an [art exhibition](https://en.wikipedia.org/wiki/Art_exhibition "Art exhibition"), which became one of the most iconic pieces of the movement.[^280] In cinema, the movie *[Citizen Kane](https://en.wikipedia.org/wiki/Citizen_Kane "Citizen Kane")* suggests a form of epistemic nihilism, showcasing moral ambiguity and the impossibility of arriving at an objective assessment of the protagonist's character.[^91] Elements of nihilism are also found in movies such as *[Taxi Driver](https://en.wikipedia.org/wiki/Taxi_Driver "Taxi Driver")*,[^305] *[A Clockwork Orange](https://en.wikipedia.org/wiki/A_Clockwork_Orange_\(film\) "A Clockwork Orange (film)")*,[^93] *[Fight Club](https://en.wikipedia.org/wiki/Fight_Club "Fight Club")*,[^94] *[The Big Lebowski](https://en.wikipedia.org/wiki/The_Big_Lebowski "The Big Lebowski")*,[^95] and *[American Psycho](https://en.wikipedia.org/wiki/American_Psycho_\(film\) "American Psycho (film)")*.[^96]

In the field of [law](https://en.wikipedia.org/wiki/Law "Law"), [legal nihilists](https://en.wikipedia.org/wiki/Legal_nihilism "Legal nihilism") assert that laws lack an inherent meaning or a moral foundation, viewing them as unjust or arbitrary constructs used to maintain control and exercise [power](https://en.wikipedia.org/wiki/Power_\(social_and_political\) "Power (social and political)").[^311] Religious or theological nihilism is associated with [atheism](https://en.wikipedia.org/wiki/Atheism "Atheism") and denies the [existence of God](https://en.wikipedia.org/wiki/Existence_of_God "Existence of God"). Some theorists identify this view as the root of other nihilist outlooks, such as existential and moral nihilism.[^98]

In the [philosophy of language](https://en.wikipedia.org/wiki/Philosophy_of_language "Philosophy of language"), [semantic](https://en.wikipedia.org/wiki/Semantic "Semantic") nihilism denies that linguistic meaning is possible, arguing that there is no genuine communication since language fails to describe reality.[^99] Logical nihilism is a theory about the relation between [formal logic](https://en.wikipedia.org/wiki/Formal_logic "Formal logic") and [natural language](https://en.wikipedia.org/wiki/Natural_language "Natural language") inference. It asserts that the [logical consequence](https://en.wikipedia.org/wiki/Logical_consequence "Logical consequence") relation studied by logicians is unable to accurately reflect [inferential](https://en.wikipedia.org/wiki/Inference "Inference") practices in natural language.[^320] In [Africana philosophy](https://en.wikipedia.org/wiki/Africana_philosophy "Africana philosophy"), black nihilism is a negative outlook on [discrimination](https://en.wikipedia.org/wiki/Discrimination "Discrimination") and the possibility of reforming political and social systems to avoid [antiblack racism](https://en.wikipedia.org/wiki/Anti-Black_racism "Anti-Black racism").[^101]

[Therapeutic](https://en.wikipedia.org/wiki/Therapeutic_nihilism "Therapeutic nihilism") or medical nihilism is the position that [medical interventions](https://en.wikipedia.org/wiki/Medical_intervention "Medical intervention") are largely ineffective. Against the advances of [modern medicine](https://en.wikipedia.org/wiki/Modern_medicine "Modern medicine"), it argues that the [methodology](https://en.wikipedia.org/wiki/Methodology "Methodology") of [medical research](https://en.wikipedia.org/wiki/Medical_research "Medical research") is fundamentally flawed and further distorted by financial incentives, resulting in a systematic overestimation of the benefits of treatments.[^102]

### Political nihilism

Political nihilism is a negative outlook on existing political and social structures, similar to [anarchism](https://en.wikipedia.org/wiki/Anarchism "Anarchism"). It seeks to uphold individual freedom against oppressive governmental controls and societal norms. Its radical and nihilistic tendencies are expressed in the revolutionary aim to dismantle these established forms of order. It targets [political institutions](https://en.wikipedia.org/wiki/Political_institution "Political institution"), and the traditional beliefs and social practices supporting them, without offering new systems to take their place.[^329] [^11]

Political nihilism is mainly linked to the [Russian nihilist movement](https://en.wikipedia.org/wiki/Russian_nihilist_movement "Russian nihilist movement") of the late 19th century. It emerged as a reaction to the rigid social structures and [authoritarian](https://en.wikipedia.org/wiki/Authoritarian "Authoritarian") rule in [Tsarist Russia](https://en.wikipedia.org/wiki/Russian_Empire "Russian Empire"). In their rejection of established institutions and norms, Russian nihilists resorted to extreme means to promote a radical social [revolution](https://en.wikipedia.org/wiki/Revolution "Revolution"), leading to forms of violence and [terrorism](https://en.wikipedia.org/wiki/Terrorism "Terrorism"), including [assassinations](https://en.wikipedia.org/wiki/Assassination "Assassination") and [arson](https://en.wikipedia.org/wiki/Arson "Arson"). Some of the revolutionaries saw Turgenev's character Bazarov as their inspiration and role model.[^339]

## History

Although nihilism is primarily associated with [modernity](https://en.wikipedia.org/wiki/Modernity "Modernity"), some of its origins trace back to [ancient philosophy](https://en.wikipedia.org/wiki/Ancient_philosophy "Ancient philosophy").[^107] Some [Sophists](https://en.wikipedia.org/wiki/Sophists "Sophists"), like [Protagoras](https://en.wikipedia.org/wiki/Protagoras "Protagoras") (c. 490–420 BCE), disputed the existence of an objective truth, arguing for a relativistic nihilism according to which "man is the measure of all things".[^108] [Socrates](https://en.wikipedia.org/wiki/Socrates "Socrates") 's (c. 470–399 BCE) method of [radical questioning](https://en.wikipedia.org/wiki/Socratic_method#Questioning_methods "Socratic method") served as a precursor of nihilism by challenging established beliefs, values, and practices, often with the goal of exposing their lack of a solid [foundation](https://en.wikipedia.org/wiki/Foundationalism "Foundationalism").[^348] [^12] [Pyrrho](https://en.wikipedia.org/wiki/Pyrrho "Pyrrho") (c. 360–270 BCE) formulated a broad version of epistemological nihilism in his attempt to show that knowledge is impossible.[^111]

Negative attitudes toward objective knowledge and the world are also found in [ancient Indian philosophy](https://en.wikipedia.org/wiki/Ancient_Indian_philosophy "Ancient Indian philosophy"). However, it is controversial to what extent they constitute forms of nihilism in a strict sense, and some interpreters limit nihilism to the Western tradition.[^112] In the 6th century BCE, the school of [Ajñana](https://en.wikipedia.org/wiki/Aj%C3%B1ana "Ajñana") developed a radical skepticism, questioning the possibility and usefulness of knowledge.[^357] [Buddhist](https://en.wikipedia.org/wiki/Buddhist "Buddhist") thought, starting in the 6th and 5th centuries BCE, focuses on the pervasiveness of [suffering](https://en.wikipedia.org/wiki/Dukkha "Dukkha"), identifying it as a fundamental [aspect of existence](https://en.wikipedia.org/wiki/Three_marks_of_existence "Three marks of existence"). It teaches [renunciation](https://en.wikipedia.org/wiki/Renunciation "Renunciation") of worldly desires to achieve liberation from suffering in the state of [nirvana](https://en.wikipedia.org/wiki/Nirvana "Nirvana").[^114] According to a common interpretation, the school of [Mādhyamaka](https://en.wikipedia.org/wiki/M%C4%81dhyamaka "Mādhyamaka"), which emerged in the 2nd century CE, defends metaphysical nihilism, rejecting the existence of an ultimate foundation or absolute reality underlying the multiplicity of experienced phenomena.[^115]

In the [early modern period](https://en.wikipedia.org/wiki/Early_modern_period "Early modern period"), [secularization](https://en.wikipedia.org/wiki/Secularization "Secularization") and the [Scientific Revolution](https://en.wikipedia.org/wiki/Scientific_Revolution "Scientific Revolution") undermined established religious beliefs and values prevalent in the Western world during the [medieval period](https://en.wikipedia.org/wiki/Medieval_period "Medieval period"), preparing the emergence of nihilism.[^369] [René Descartes](https://en.wikipedia.org/wiki/Ren%C3%A9_Descartes "René Descartes") (1596–1650) considered an extreme form of epistemological nihilism in his quest for absolute certainty. He suggested that humans cannot trust even their most fundamental beliefs unless they can rule out that a malevolent God-like being is constantly [deceiving them](https://en.wikipedia.org/wiki/Trickster "Trickster").[^117] [Immanuel Kant](https://en.wikipedia.org/wiki/Immanuel_Kant "Immanuel Kant") (1724–1804) drew a sharp distinction between [appearances](https://en.wikipedia.org/wiki/Phenomenon "Phenomenon") and [things underlying those appearances](https://en.wikipedia.org/wiki/Thing-in-itself "Thing-in-itself"). By limiting knowledge to the sphere of appearances, he prepared a type of existential nihilism, making the deeper meaning of things in themselves inaccessible.[^118] In criticizing the [rationalism](https://en.wikipedia.org/wiki/Rationalism "Rationalism") of the [Kantian](https://en.wikipedia.org/wiki/Kantian "Kantian") philosopher [Johann Gottlieb Fichte](https://en.wikipedia.org/wiki/Johann_Gottlieb_Fichte "Johann Gottlieb Fichte") (1762–1814), [Friedrich Jacobi](https://en.wikipedia.org/wiki/Friedrich_Jacobi "Friedrich Jacobi") (1743–1819) coined the philosophical concept of nihilism to describe philosophical thought that leads to the denial of existence and meaning.[^119]

![Oil painting of a bearded man with white hair, seated in an armchair and dressed in a dark coat](https://en.wikipedia.org/wiki/File:Turgenev_by_Repin.jpg)

In 19th-century Russia, Ivan Turgenev was responsible for popularizing the term nihilism. 384

In Russia, the term *nihilism* gained popularity through [Ivan Turgenev](https://en.wikipedia.org/wiki/Ivan_Turgenev "Ivan Turgenev") 's (1818–1883) portrayal of the nihilist character Bazarov in his novel *[Fathers and Sons](https://en.wikipedia.org/wiki/Fathers_and_Sons_\(novel\) "Fathers and Sons (novel)")*.[^384] Starting in the second half of the 19th century, the [Russian nihilist movement](https://en.wikipedia.org/wiki/Russian_nihilist_movement "Russian nihilist movement") was a form of political nihilism, characterized by a radical rejection of traditional social, political, and aesthetic norms.[^121] Meanwhile in Western Europe, the nihilistic [egoism](https://en.wikipedia.org/wiki/Egoism "Egoism") of [Max Stirner](https://en.wikipedia.org/wiki/Max_Stirner "Max Stirner") (1806–1856) reduced other people to their usefulness without respect for their [personhood](https://en.wikipedia.org/wiki/Personhood "Personhood"). Stirner also formulated a cosmic nihilism that sees the universe as an unintelligible, metaphysical chaos.[^122] [Søren Kierkegaard](https://en.wikipedia.org/wiki/S%C3%B8ren_Kierkegaard "Søren Kierkegaard") (1813–1855) explored different lifestyles or "spheres of existence" through which people seek meaning in their lives. He warned against an aesthetic lifestyle of pursuing sensory pleasures without ulterior goals, arguing that it leads to a nihilistic outlook marked by meaninglessness. Instead, he recommended a [leap of faith](https://en.wikipedia.org/wiki/Leap_of_faith "Leap of faith") that trusts in God as a higher source of meaning.[^396]

[Arthur Schopenhauer](https://en.wikipedia.org/wiki/Arthur_Schopenhauer "Arthur Schopenhauer") (1788–1860) developed a [pessimistic philosophy](https://en.wikipedia.org/wiki/Philosophical_pessimism "Philosophical pessimism"), characterizing the world as a place of suffering, brought into being by a blind, irrational [will](https://en.wikipedia.org/wiki/Will_\(philosophy\)#Schopenhauer "Will (philosophy)").[^400] Influenced by Schopenhauer, the problem of nihilism took center stage in the thought of [Friedrich Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche "Friedrich Nietzsche") (1844–1900). He understood it as a broad cultural phenomenon in which people lose the values and ideals guiding their lives. He explored the causes and consequences of this shift in evaluative outlook, examining reactions to it and ways of overcoming it.[^125] According to Nietzsche, nihilism often manifests in a distorted form as passive nihilism, masking its life-denying nature behind religious dogmas, conventional morality, and societal norms. Against this tendency, Nietzsche recommended active nihilism, which openly acknowledges the lack of meaning and uses its negative force to dismantle established values.[^13] He saw this as a transitional phase to overcome nihilism in general, leading to a vital [affirmation of life](https://en.wikipedia.org/wiki/Affirmation_of_life "Affirmation of life") through a [revaluation of all values](https://en.wikipedia.org/wiki/Revaluation_of_all_values "Revaluation of all values").[^127]

![Black-and-white photo of a seated man in a dark suit with white hair](https://en.wikipedia.org/wiki/File:Heidegger_2_(1960).jpg)

Martin Heidegger conceived of nihilism as a fundamental historical movement in Western thought. 128

Many subsequent developments in the 20th-century history of nihilism were responses to Nietzsche's philosophy.[^129] [Martin Heidegger](https://en.wikipedia.org/wiki/Martin_Heidegger "Martin Heidegger") (1889–1976) agreed with Nietzsche's description of the pervasive and corrosive nature of nihilism, seeing it as a fundamental historical movement in Western thought reaching back to the ancient period. Interpreting Nietzsche's concept of the [will to power](https://en.wikipedia.org/wiki/Will_to_power "Will to power") and [modern technological developments](https://en.wikipedia.org/wiki/The_Question_Concerning_Technology "The Question Concerning Technology"), Heidegger came to the conclusion that Nietzsche's attempt to overcome nihilism fails and leads to an even more complete nihilism. As an alternative, Heidegger turned to early [Presocratic philosophy](https://en.wikipedia.org/wiki/Presocratic_philosophy "Presocratic philosophy") to recover a non-nihilistic understanding of being.[^420]

[Bertrand Russell](https://en.wikipedia.org/wiki/Bertrand_Russell "Bertrand Russell") (1872–1970) proposed a view aligned with cosmic nihilism, characterizing humanity as an accidental and insignificant byproduct of cosmic forces that are alien and indifferent to human concerns.[^431] Against the backdrop of [World War I](https://en.wikipedia.org/wiki/World_War_I "World War I"), [Dadaists](https://en.wikipedia.org/wiki/Dadaists "Dadaists") expressed aspects of nihilism through art, seeking to undermine established norms and values while embracing [nonsense](https://en.wikipedia.org/wiki/Nonsense "Nonsense") and absurdity.[^131] The question of nihilism and its denial of the meaning of life played a central role for [existentialist philosophers](https://en.wikipedia.org/wiki/Existentialism "Existentialism").[^132] [Jean-Paul Sartre](https://en.wikipedia.org/wiki/Jean-Paul_Sartre "Jean-Paul Sartre") (1905–1980) asserted that humans have [no inborn essence](https://en.wikipedia.org/wiki/Existence_precedes_essence "Existence precedes essence") defining who they are or what their purpose is. He argued that they can overcome this lack of predefined meaning through [freedom](https://en.wikipedia.org/wiki/Freedom "Freedom"), proposing that people make their lives meaningful by inventing themselves and their values.[^100] In his [absurdist philosophy](https://en.wikipedia.org/wiki/Absurdism "Absurdism"), [Albert Camus](https://en.wikipedia.org/wiki/Albert_Camus "Albert Camus") (1913–1960) explored the psychological paradox that arises from the inherent drive to seek meaning in an objectively meaningless world. He termed this condition "the absurd" and advocated for a defiant stance or rebellion against the lack of meaning.[^439]

In the second half of the 20th century, certain aspects of nihilism emerged in [postmodern philosophy](https://en.wikipedia.org/wiki/Postmodern_philosophy "Postmodern philosophy"), often in response to Nietzsche and Heidegger.[^134] [Jacques Derrida](https://en.wikipedia.org/wiki/Jacques_Derrida "Jacques Derrida") 's (1930–2004) philosophy of [deconstruction](https://en.wikipedia.org/wiki/Deconstruction "Deconstruction") challenged the existence of absolute truth and stable meaning. Derrida aimed to expose the hidden assumptions and biases on which this viewpoint rests.[^135] [Jean-François Lyotard](https://en.wikipedia.org/wiki/Jean-Fran%C3%A7ois_Lyotard "Jean-François Lyotard") (1924–1998) explored [antifoundationalism](https://en.wikipedia.org/wiki/Antifoundationalism "Antifoundationalism"), rejecting the existence of universal frameworks of understanding, termed [metanarratives](https://en.wikipedia.org/wiki/Metanarratives "Metanarratives"). He aimed to undermine their validity as standards of truth claims, proposing instead that they are merely different [language games](https://en.wikipedia.org/wiki/Language_game "Language game") people play without any clear hierarchy prioritizing one language game over the others.[^451] Similarly, [Richard Rorty](https://en.wikipedia.org/wiki/Richard_Rorty "Richard Rorty") (1931–2007) dismissed the notion of objective truths, suggesting that people rely on their own judgment and creativity instead of privileging established perspectives, like the scientific worldview.[^457] Against Nietzsche's and Heidegger's attempts to overcome nihilism, [Gianni Vattimo](https://en.wikipedia.org/wiki/Gianni_Vattimo "Gianni Vattimo") (1936–2023) embraced it, viewing nihilism as the only viable alternative in the [postmodern era](https://en.wikipedia.org/wiki/Postmodern_era "Postmodern era").[^138]

[^1]: Pronunciation: [/ ˈ n aɪ (h) ɪ l ɪ z əm, ˈ n iː -/](https://en.wikipedia.org/wiki/Help:IPA/English "Help:IPA/English")

[^2]: Existential crises are inner conflicts in which individuals struggle to find meaning in their lives. Some authors suggest that nihilistic beliefs can trigger existential crises. Others propose nihilism as one way to resolve them by learning to accept meaninglessness rather than finding a source of meaning.[^92]

[^3]: In this context, Nietzsche contrasted passive with active nihilism. Passive nihilism is a form of resignation characterized by pessimism, hopelessness, and disengagement while refusing to acknowledge the absence of meaning. Active nihilism openly accepts meaninglessness and uses its negativity as a force to destroy established values and ideologies.[^113]

[^4]: The logic underlying this idea is sometimes reversed as an argument for [theism](https://en.wikipedia.org/wiki/Theism "Theism"), advocating faith in God's existence based on the idea that the loss of belief in God entails the denial of a purpose of life and leads to despair.[^30]

[^5]: Related forms of epistemological relativism target the standards of knowledge, justification, or rationality.[^45]

[^6]: A conceptual scheme is a system of categories, concepts, or beliefs through which people organize their ideas, understand their experiences, and interpret reality.[^47]

[^7]: Some philosophers, such as [Karen L. Carr](https://en.wikipedia.org/wiki/Karen_L._Carr "Karen L. Carr"), distinguish epistemological nihilism from skepticism and relativism. According to this interpretation, skepticism and relativism imply uncertainty about the existence of knowledge and objectivity, recommending the suspension of judgment. Epistemological nihilism, by contrast, firmly asserts that knowledge or objectivity do not exist.[^56]

[^8]: [Agrippa's trilemma](https://en.wikipedia.org/wiki/Agrippa's_trilemma "Agrippa's trilemma") presents a similar conundrum for the existence of knowledge.[^62]

[^9]: Some forms of the subtraction argument include the assumption that the world is finite to ensure that this endpoint is reached.[^249]

[^10]: The Ship of Theseus is a thought experiment in which the parts of a ship are gradually replaced until no original part remains. The metaphysical paradox is tied to the question of whether the resulting ship is the same as the original ship. This problem does not arise for mereological nihilism, since it denies the existence of composite objects.[^264]

[^11]: [National nihilism](https://en.wikipedia.org/wiki/National_nihilism "National nihilism"), a related outlook, is a negative attitude toward one's own country.[^104] In China, the term *[historical nihilism](https://en.wikipedia.org/wiki/Historical_nihilism "Historical nihilism")* is used by the [Chinese Communist Party](https://en.wikipedia.org/wiki/Chinese_Communist_Party "Chinese Communist Party") to describe historical views that challenge the party's official account of the past.[^105]

[^12]: For example, his character in Plato's Republic suggested in the [Allegory of the cave](https://en.wikipedia.org/wiki/Allegory_of_the_cave "Allegory of the cave") that commonly held beliefs about reality are just a shadow of a higher unperceived reality.[^110]

[^13]: This includes his pronouncement that " [God is dead](https://en.wikipedia.org/wiki/God_is_dead "God is dead") ".[^126]

[^14]: 

[^15]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^16]: [Joyce 2013](#CITEREFJoyce2013)

[^17]: [Crosby 1988](#CITEREFCrosby1988), p. [35](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA35)

[^18]: 

[^19]: [Gertz 2019](#CITEREFGertz2019), pp. [1–4, 73–76](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA1)

[^20]: [Crosby 1988](#CITEREFCrosby1988), p. [35](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA35)

[^21]: 

[^22]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^23]: [Joyce 2013](#CITEREFJoyce2013)

[^24]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 671

[^25]: [Stewart 2023](#CITEREFStewart2023), pp. [2, 18](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PA2)

[^26]: [Crosby 1988](#CITEREFCrosby1988), pp. [8, 35](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA8)

[^27]: 

[^28]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 671

[^29]: [Pratt](#CITEREFPratt), Lead section

[^30]: [Diken 2008](#CITEREFDiken2008), p. 3

[^31]: [Slocombe 2006](#CITEREFSlocombe2006), p. 1

[^32]: [ter Borg 1988](#CITEREFter_Borg1988), pp. 1–2

[^33]: 

[^34]: [Gertz 2019](#CITEREFGertz2019), pp. [3–5](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA3)

[^35]: [HarperCollins 2022](#CITEREFHarperCollins2022)

[^36]: 

[^37]: [Gertz 2019](#CITEREFGertz2019), p. [32](https://books.google.com/books?id=vwZ9wgEACAAJ&pg=PA32)

[^38]: [Livieri & di Giovanni 2023](#CITEREFLivieridi_Giovanni2023), Lead section, § 1. Life and Intellectual Career, § 3.5 The Open Letter to Fichte (1799)

[^39]: [Bensussan 2025](#CITEREFBensussan2025), pp. [12](https://books.google.com/books?id=hb9wEQAAQBAJ&pg=PA12)

[^40]: 

[^41]: [Gertz 2019](#CITEREFGertz2019), p. [59](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA59)

[^42]: [Cutler 2014](#CITEREFCutler2014), p. [33](https://books.google.com/books?id=LdAdBgAAQBAJ&pg=PA33)

[^43]: 

[^44]: [Gertz 2019](#CITEREFGertz2019), pp. [60–64](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA60)

[^45]: [Tartaglia & Llanera 2020](#CITEREFTartagliaLlanera2020), pp. 27–28

[^46]: 

[^47]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [44–45](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA44)

[^48]: [Crosby 1998](#CITEREFCrosby1998), § 3. Existential nihilism

[^49]: [Gordon 1984](#CITEREFGordon1984), pp. 15–18

[^50]: 

[^51]: [Aho 2025](#CITEREFAho2025), Lead section

[^52]: [Burnham & Papandreopoulos](#CITEREFBurnhamPapandreopoulos), Lead section

[^53]: 

[^54]: [Gertz 2019](#CITEREFGertz2019), pp. [64–65](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA64)

[^55]: [Bewes 1997](#CITEREFBewes1997), pp. [1–2](https://books.google.com/books?id=iR3C_y0kYCgC&pg=PA1)

[^56]: [Diken 2008](#CITEREFDiken2008), pp. 55–56, 59

[^57]: 

[^58]: [Gertz 2019](#CITEREFGertz2019), pp. [68–71](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA68)

[^59]: [American Psychological Association 2018](#CITEREFAmerican_Psychological_Association2018)

[^60]: 

[^61]: [Gertz 2019](#CITEREFGertz2019), p. [4](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA4)

[^62]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^63]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 671

[^64]: [Pratt](#CITEREFPratt), § 1. Origins

[^65]: [Hoad 1996](#CITEREFHoad1996), p. 313

[^66]: 

[^67]: [Gloy 2013](#CITEREFGloy2013), p. [146](https://brill.com/display/title/51616)

[^68]: [Gertz 2019](#CITEREFGertz2019), p. [32](https://books.google.com/books?id=vwZ9wgEACAAJ&pg=PA32)

[^69]: [Livieri & di Giovanni 2023](#CITEREFLivieridi_Giovanni2023), Lead section, § 1. Life and Intellectual Career, § 3.5 The Open Letter to Fichte (1799)

[^70]: [OED staff 2025](#CITEREFOED_staff2025)

[^71]: 

[^72]: [Gillespie 1996](#CITEREFGillespie1996), pp. xi, xix–xx, 110

[^73]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671–673

[^74]: [Crosby 1998](#CITEREFCrosby1998), § 1. Historical Background

[^75]: [Pratt](#CITEREFPratt), § 1. Origins

[^76]: [Slocombe 2006](#CITEREFSlocombe2006), p. 1

[^77]: 

[^78]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 671

[^79]: [Pratt](#CITEREFPratt), Lead section

[^80]: [Cowan 2020](#CITEREFCowan2020), p. [25](https://books.google.com/books?id=_2jDDwAAQBAJ&pg=PA25)

[^81]: [Oddie 2013](#CITEREFOddie2013), § Are Value Claims Truth Evaluable?, § Quasi-Realism and Creeping Minimalism

[^82]: [Groothuis 2020](#CITEREFGroothuis2020), pp. [165–169](https://books.google.com/books?id=_2jDDwAAQBAJ&pg=PA165)

[^83]: 

[^84]: [Pratt](#CITEREFPratt), § 3. Existential Nihilism

[^85]: [Crosby 1998](#CITEREFCrosby1998), § Existential Nihilism

[^86]: [Groothuis 2020](#CITEREFGroothuis2020), pp. [165–169](https://books.google.com/books?id=_2jDDwAAQBAJ&pg=PA165)

[^87]: 

[^88]: [Joyce 2013](#CITEREFJoyce2013)

[^89]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [25–27](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA25)

[^90]: [Yalom 2020](#CITEREFYalom2020), pp. 423–428

[^91]: [Sommers-Flanagan & Sommers-Flanagan 2012](#CITEREFSommers-FlanaganSommers-Flanagan2012), p. [131](https://books.google.com/books?id=RMclh6zR3LEC&pg=PA131)

[^92]: 

[^93]: [Carr 1992](#CITEREFCarr1992), pp. 125–126

[^94]: [Yalom 2020](#CITEREFYalom2020), pp. 423–428

[^95]: [Davis & Hicks 2013](#CITEREFDavisHicks2013), pp. [166, 171–172](https://books.google.com/books?id=HcxEAAAAQBAJ&pg=PA166)

[^96]: [American Psychological Association 2023](#CITEREFAmerican_Psychological_Association2023)

[^97]: 

[^98]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [25–27](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA25)

[^99]: [George 2015](#CITEREFGeorge2015), p. [74](https://books.google.com/books?id=Ym7vCAAAQBAJ&pg=PA74)

[^100]: 

[^101]: [Crosby 1998](#CITEREFCrosby1998), § 3. Existential nihilism

[^102]: [Gertz 2019](#CITEREFGertz2019), pp. 82–85

[^103]: 

[^104]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [41–42](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA41)

[^105]: [Crosby 1998](#CITEREFCrosby1998), § Existential Nihilism

[^106]: 

[^107]: [Crosby 1998](#CITEREFCrosby1998), § Existential Nihilism

[^108]: [Stewart 2023](#CITEREFStewart2023), p. [147](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PA147)

[^109]: 

[^110]: [Pratt](#CITEREFPratt), Lead section, § 2. Friedrich Nietzsche and Nihilism

[^111]: [Diken 2008](#CITEREFDiken2008), pp. 5, 31

[^112]: [Kirwin](#CITEREFKirwin), § 1b. Rejection of an Otherworldly Basis for Value

[^113]: 

[^114]: [Vattimo 1989](#CITEREFVattimo1989), pp. [15–17](https://books.google.com/books?id=G-1YV3x6yakC&pg=PA15)

[^115]: [Gillespie 1996](#CITEREFGillespie1996), pp. [179–180](https://books.google.com/books?id=r4Itb0Zc2hUC&pg=PA179)

[^116]: 

[^117]: [Crosby 1998](#CITEREFCrosby1998), § Existential Nihilism

[^118]: [Pratt](#CITEREFPratt), § 3. Existential Nihilism

[^119]: [Joyce 2013](#CITEREFJoyce2013)

[^120]: 

[^121]: [Diken 2008](#CITEREFDiken2008), pp. 3–4, 15–16, 28

[^122]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [48–49](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA48)

[^123]: [Crosby 1988](#CITEREFCrosby1988), pp. [38–40](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA38)

[^124]: - [Crosby 1998](#CITEREFCrosby1998), § Critical comment

[^125]: [Crosby 1988](#CITEREFCrosby1988), pp. [38–40, 46–47, 53, 55–58](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA38)

[^126]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [21–25](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA21)

[^127]: [Stewart 2023](#CITEREFStewart2023), pp. [2–4](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PA2)

[^128]: [Gertz 2019](#CITEREFGertz2019), pp. [81, 87](https://books.google.com/books?id=aU6qDwAAQBAJ&pg=PA81)

[^129]: [Storey 2011](#CITEREFStorey2011), p. 18

[^130]: 

[^131]: [Crosby 1998](#CITEREFCrosby1998), § Critical comment

[^132]: [Tartaglia 2015](#CITEREFTartaglia2015), pp. [21–22](https://books.google.com/books?id=acazCgAAQBAJ&pg=PA21)

[^133]: 

[^134]: [Crosby 1998](#CITEREFCrosby1998), § Critical comment

[^135]: [Crosby 1988](#CITEREFCrosby1988), pp. [41–42](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA41)

[^136]: [Crosby 1988](#CITEREFCrosby1988), pp. [352–357](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA352)

[^137]: 

[^138]: [Crosby 1988](#CITEREFCrosby1988), pp. [364–367, 369–370](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA364)

[^139]: [Metz 2023](#CITEREFMetz2023), § 2. Supernaturalism, § 3. Naturalism

[^140]: [Seachris](#CITEREFSeachris), § 3. Theories of Meaning *in* Life

[^141]: [Yalom 2020](#CITEREFYalom2020), pp. 431–435

[^142]: 

[^143]: [Crosby 1988](#CITEREFCrosby1988), pp. [11–12](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA11)

[^144]: [Joyce 2013](#CITEREFJoyce2013)

[^145]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^146]: [Dreier 2007](#CITEREFDreier2007), pp. 240–242

[^147]: [Pradhan 2024](#CITEREFPradhan2024), pp. [183–184](https://books.google.com/books?id=m4wWEQAAQBAJ&pg=183)

[^148]: 

[^149]: [Dreier 2007](#CITEREFDreier2007), pp. 240–242

[^150]: [Krellenstein 2017](#CITEREFKrellenstein2017), pp. [75–90](https://www.jstor.org/stable/44631529)

[^151]: [Joyce 2013](#CITEREFJoyce2013)

[^152]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^153]: 

[^154]: [Mulligan 2009](#CITEREFMulligan2009), pp. [401–402](https://books.google.com/books?id=Bt99AgAAQBAJ&pg=PA401)

[^155]: [Oddie 2013](#CITEREFOddie2013), Lead section, § Do Value Claims Have Truth Makers?

[^156]: - [Krellenstein 2017](#CITEREFKrellenstein2017), pp. 76–80

[^157]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^158]: [Dreier 2007](#CITEREFDreier2007), pp. 242–249

[^159]: [Krellenstein 2017](#CITEREFKrellenstein2017), pp. 76–80

[^160]: - [Lutz 2023](#CITEREFLutz2023), Lead section, § 1. What Is Moral Naturalism?
- [DeLapp](#CITEREFDeLapp), § 4a. Moral Realisms

[^161]: [Sayre-McCord 2023](#CITEREFSayre-McCord2023), § 2. Metaphysics

[^162]: [FitzPatrick 2011](#CITEREFFitzPatrick2011), pp. [7–8](https://link.springer.com/chapter/10.1057/9780230294899_2)

[^163]: [Ridge 2019](#CITEREFRidge2019), Lead section

[^164]: 

[^165]: [Sinnott-Armstrong 2007](#CITEREFSinnott-Armstrong2007), pp. [53–59](https://books.google.com/books?id=5pzCOHmcDocC&pg=PA59)

[^166]: [Krellenstein 2017](#CITEREFKrellenstein2017), pp. 80–82

[^167]: 

[^168]: [Crosby 1988](#CITEREFCrosby1988), pp. [11–14](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA11)

[^169]: [Weller 2010](#CITEREFWeller2010), p. [10](https://books.google.com/books?id=TEZ9DAAAQBAJ&pg=PA10)

[^170]: 

[^171]: [Crosby 1988](#CITEREFCrosby1988), pp. [11, 14–15](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA11)

[^172]: [Weller 2010](#CITEREFWeller2010), p. [10](https://books.google.com/books?id=TEZ9DAAAQBAJ&pg=PA10)

[^173]: 

[^174]: [Davis 2014](#CITEREFDavis2014)

[^175]: [Baghramian & Carter 2025](#CITEREFBaghramianCarter2025), Lead section

[^176]: 

[^177]: [Crosby 1988](#CITEREFCrosby1988), pp. 18–19, 35

[^178]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^179]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^180]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^181]: [Hautamäki 2022](#CITEREFHautamäki2022), p. 534

[^182]: [Blackburn 2008](#CITEREFBlackburn2008)

[^183]: 

[^184]: [Crosby 1988](#CITEREFCrosby1988), pp. 18–19, 23–26, 35

[^185]: [Coady 2005](#CITEREFCoady2005), p. 800

[^186]: 

[^187]: [Gratton 2018](#CITEREFGratton2018), Lead section, § 3.2 Justice in light of the Postmodern Condition

[^188]: [Woodward](#CITEREFWoodward), § 4b. The Postmodern Condition

[^189]: [Gertz 2019](#CITEREFGertz2019), pp. 88–90, 92–93

[^190]: [Baghramian & Carter 2025](#CITEREFBaghramianCarter2025), § 2. Why Relativism?

[^191]: 

[^192]: [Baghramian & Carter 2025](#CITEREFBaghramianCarter2025), § 2.4 Underdetermination of theory by data

[^193]: [Davis 2014](#CITEREFDavis2014)

[^194]: 

[^195]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^196]: [Coady 2005](#CITEREFCoady2005), p. 800

[^197]: [Moruzzi 2008](#CITEREFMoruzzi2008), pp. 207–208

[^198]: [Moruzzi 2008](#CITEREFMoruzzi2008), pp. 211–212, 221–222

[^199]: 

[^200]: [Crosby 1988](#CITEREFCrosby1988), pp. 18–21

[^201]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^202]: [Pratt](#CITEREFPratt), § 2. Friedrich Nietzsche and Nihilism, § 4. Antifoundationalism and Nihilism

[^203]: 

[^204]: [Carr 1992](#CITEREFCarr1992), pp. [20–21](https://books.google.com/books?id=_i2VZYYYp-gC&pg=PA20)

[^205]: [Dowdall 2024](#CITEREFDowdall2024), p. [29](https://books.google.com/books?id=bXL6EAAAQBAJ&pg=PA29)

[^206]: 

[^207]: [Joyce 2013](#CITEREFJoyce2013)

[^208]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^209]: [Gertz 2019](#CITEREFGertz2019), p. [33](https://books.google.com/books?id=vwZ9wgEACAAJ&pg=PA33)

[^210]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671, 673

[^211]: [Bunnin & Yu 2009](#CITEREFBunninYu2009), p. 472

[^212]: [Kyriacou & Wallbridge 2021](#CITEREFKyriacouWallbridge2021), pp. 1–2

[^213]: 

[^214]: [Cuneo 2007](#CITEREFCuneo2007), pp. 115–116

[^215]: [Slocombe 2006](#CITEREFSlocombe2006), p. 5

[^216]: 

[^217]: [Hetherington, " *Fallibilism* "](#Hetherington,_"Fallibilism), § 8. Implications of Fallibilism: No Knowledge?

[^218]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^219]: 

[^220]: [Windt 2021](#CITEREFWindt2021), § 1.1 Cartesian Dream Skepticism

[^221]: [Klein 1998](#CITEREFKlein1998), § 8. The Epistemic Principles and Scepticism

[^222]: [Hetherington, " *Knowledge* "](#Hetherington,_"Knowledge), § 4. Sceptical Doubts About Knowing

[^223]: 

[^224]: [McCain](#CITEREFMcCain), § 1. The Problem, § 2. Chisholm on the Problem of the Criterion

[^225]: [Pitts 2017](#CITEREFPitts2017), p. [263](https://books.google.com/books?id=T_SkDgAAQBAJ&pg=PA263)

[^226]: [Klein 2011](#CITEREFKlein2011), pp. [484–485](https://books.google.com/books?id=1ETRCwAAQBAJ&pg=PA484)

[^227]: 

[^228]: [Hookway 2005](#CITEREFHookway2005), p. 838

[^229]: [Comesaña & Klein 2024](#CITEREFComesañaKlein2024), Lead section

[^230]: [Kyriacou & Wallbridge 2021](#CITEREFKyriacouWallbridge2021), pp. 1–2

[^231]: 

[^232]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671, 673

[^233]: [Huemer 2001](#CITEREFHuemer2001), p. [27](https://books.google.com/books?id=ccmNDGIiJ3IC&pg=PA27)

[^234]: 

[^235]: [Steup & Neta 2024](#CITEREFSteupNeta2024), § 6.2 Responses to the Closure Argument

[^236]: [Reed 2015](#CITEREFReed2015), p. [75](https://books.google.com/books?id=geSrCQAAQBAJ&pg=PA75)

[^237]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^238]: 

[^239]: [Olson 2006](#CITEREFOlson2006), pp. 618–619

[^240]: [Cuneo 2007](#CITEREFCuneo2007), pp. 115–116

[^241]: 

[^242]: [Coggins 2005](#CITEREFCoggins2005), Lead section

[^243]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 673–674

[^244]: [Coggins 2010](#CITEREFCoggins2010), pp. [1–2](https://books.google.com/books?id=tBh_DAAAQBAJ&pg=PA1)

[^245]: 

[^246]: [Coggins 2005](#CITEREFCoggins2005), Lead section

[^247]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 673–674

[^248]: [Coggins 2010](#CITEREFCoggins2010), pp. [11–12](https://books.google.com/books?id=tBh_DAAAQBAJ&pg=PA11)

[^249]: [Coggins 2010](#CITEREFCoggins2010), pp. [11–12](https://books.google.com/books?id=tBh_DAAAQBAJ&pg=PA11)

[^250]: 

[^251]: [Coggins 2010](#CITEREFCoggins2010), pp. [1–4, 141](https://books.google.com/books?id=tBh_DAAAQBAJ&pg=PA1)

[^252]: [Rodriguez-Pereyra 2000](#CITEREFRodriguez-Pereyra2000), pp. 335–336

[^253]: 

[^254]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 4, 6

[^255]: [Turner 2011](#CITEREFTurner2011), pp. 3–4

[^256]: [Carr 1992](#CITEREFCarr1992), pp. [17–18, 149](https://books.google.com/books?id=_i2VZYYYp-gC&pg=PA17)

[^257]: 

[^258]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^259]: [Rettler 2018](#CITEREFRettler2018), pp. 842–843

[^260]: [Brenner 2015](#CITEREFBrenner2015), pp. 318–319

[^261]: [Turner 2011](#CITEREFTurner2011), pp. 3–4

[^262]: [Brenner 2015](#CITEREFBrenner2015), pp. 318–319

[^263]: [Rettler 2018](#CITEREFRettler2018), pp. 842–843

[^264]: [Rettler 2018](#CITEREFRettler2018), pp. 842–843, 854–855

[^265]: 

[^266]: [Rettler 2018](#CITEREFRettler2018), pp. 842–843

[^267]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 673

[^268]: 

[^269]: [Tallant 2014](#CITEREFTallant2014), pp. 1511–1512, 1526

[^270]: [Cornell 2017](#CITEREFCornell2017), pp. 77–78

[^271]: 

[^272]: [Crosby 1998](#CITEREFCrosby1998), § Cosmic nihilism

[^273]: [Crosby 1988](#CITEREFCrosby1988), pp. 26–27, 30

[^274]: [Gertz 2019](#CITEREFGertz2019), p. [74](https://books.google.com/books?id=vwZ9wgEACAAJ&pg=PA74)

[^275]: 

[^276]: [Crosby 1988](#CITEREFCrosby1988), pp. 26–27

[^277]: [Crosby 1998](#CITEREFCrosby1998), § Cosmic nihilism

[^278]: [Weller 2010](#CITEREFWeller2010), p. [11](https://books.google.com/books?id=TEZ9DAAAQBAJ&pg=PA11)

[^279]: [Crosby 1988](#CITEREFCrosby1988), p. 27

[^280]: 

[^281]: [Stewart 2023](#CITEREFStewart2023), pp. i, 18

[^282]: [Manschreck 1976](#CITEREFManschreck1976), pp. 89–90

[^283]: [Hopkins 2004](#CITEREFHopkins2004), pp. 14, 110, 154

[^284]: 

[^285]: [Carroll 2024](#CITEREFCarroll2024), [§ 15. Thinking without Foundations](https://books.google.com/books?id=FG4iEQAAQBAJ&pg=PT144)

[^286]: [Dowdall 2024](#CITEREFDowdall2024), p. 83

[^287]: 

[^288]: [Crosby 1988](#CITEREFCrosby1988), pp. [9–11](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA9)

[^289]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671–672

[^290]: [Stewart 2023](#CITEREFStewart2023), pp. i, 18

[^291]: [Walicki 2002](#CITEREFWalicki2002)

[^292]: 

[^293]: [Gillespie 1996](#CITEREFGillespie1996), pp. xix, 145–148

[^294]: [Manschreck 1976](#CITEREFManschreck1976), pp. 85–86

[^295]: [Pratt](#CITEREFPratt), § 1. Origins

[^296]: [Dowdall 2024](#CITEREFDowdall2024), p. [141](https://books.google.com/books?id=bXL6EAAAQBAJ&pg=PA141)

[^297]: [Stewart 2023](#CITEREFStewart2023), pp. [ix, 195](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PR9)

[^298]: [Stepenberg 2019](#CITEREFStepenberg2019), pp. xi–xv, 115–116

[^299]: [Weller 2008](#CITEREFWeller2008), pp. 321–322

[^300]: 

[^301]: [Gillespie 1996](#CITEREFGillespie1996), pp. 164, 178

[^302]: [Manschreck 1976](#CITEREFManschreck1976), pp. 86–88, 90–93

[^303]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671–672

[^304]: [Stoehr 2015](#CITEREFStoehr2015), pp. [1, 67–68](https://books.google.com/books?id=0OYyBwAAQBAJ&pg=PA1)

[^305]: [Smith 2002](#CITEREFSmith2002), p. [350](https://books.google.com/books?id=-1mUcGRpt0EC&pg=PA350)

[^306]: [Abrams 2007](#CITEREFAbrams2007), p. [6](https://books.google.com/books?id=QbJo2oiFFoUC&pg=PA6)

[^307]: - [Kavadlo 2015](#CITEREFKavadlo2015), p. [14](https://books.google.com/books?id=lXwvBgAAQBAJ&pg=PA14)

[^308]: [Yeo 2017](#CITEREFYeo2017), p. [53](https://books.google.com/books?id=R6k7DwAAQBAJ&pg=PA53)

[^309]: [Gaughran 2009](#CITEREFGaughran2009), p. [231](https://books.google.com/books?id=-OV50oVxKyoC&pg=PA231)

[^310]: [Yeo 2017](#CITEREFYeo2017), p. [53](https://books.google.com/books?id=R6k7DwAAQBAJ&pg=PA53)

[^311]: 

[^312]: [Walicki 2002](#CITEREFWalicki2002)

[^313]: [Buchanan 2003](#CITEREFBuchanan2003), pp. 20, 45–46

[^314]: [Sapio 2010](#CITEREFSapio2010), pp. [33–34](https://books.google.com/books?id=-955DwAAQBAJ&pg=PA33)

[^315]: - [Joyce 2013](#CITEREFJoyce2013)

[^316]: [Slocombe 2006](#CITEREFSlocombe2006), p. 7

[^317]: [Olson 2006](#CITEREFOlson2006), p. 618

[^318]: - [Alvarez 1994](#CITEREFAlvarez1994), pp. 354–357

[^319]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 7, 100

[^320]: 

[^321]: [Cotnoir 2018](#CITEREFCotnoir2018), pp. 301–303

[^322]: [Dowdall 2024](#CITEREFDowdall2024), p. [29](https://books.google.com/books?id=bXL6EAAAQBAJ&pg=PA29)

[^323]: 

[^324]: [Warren 2015](#CITEREFWarren2015), pp. 215–218, 233

[^325]: [Johnson 2024](#CITEREFJohnson2024), p. 290

[^326]: 

[^327]: [Stegenga 2018](#CITEREFStegenga2018), pp. [1–2](https://books.google.com/books?id=tT5MDwAAQBAJ&pg=PA1)

[^328]: [Devanesan 2020](#CITEREFDevanesan2020), pp. 1–2

[^329]: 

[^330]: [Crosby 1988](#CITEREFCrosby1988), pp. [9–11, 35](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA9)

[^331]: [Pratt](#CITEREFPratt), § 1. Origins

[^332]: [Crosby 1998](#CITEREFCrosby1998), Lead section

[^333]: [Joyce 2013](#CITEREFJoyce2013)

[^334]: 

[^335]: [Nairn 2011](#CITEREFNairn2011), p. [380](https://books.google.com/books?id=vQDfDwAAQBAJ&pg=PA380)

[^336]: [Marples 1996](#CITEREFMarples1996), p. [25](https://books.google.com/books?id=evVZCwAAQBAJ&pg=PA25)

[^337]: - [Peng 2023](#CITEREFPeng2023), p. [1597](https://books.google.com/books?id=gRLREAAAQBAJ&pg=PA1597)

[^338]: [Cadell 2021](#CITEREFCadell2021)

[^339]: 

[^340]: [Crosby 1988](#CITEREFCrosby1988), pp. [9–11](https://books.google.com/books?id=9VnPgFiW0CIC&pg=PA9)

[^341]: [Pratt](#CITEREFPratt), § 1. Origins

[^342]: 

[^343]: [Pratt](#CITEREFPratt), § 1. Origins

[^344]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 1, 5

[^345]: [Gertz 2019](#CITEREFGertz2019), p. 13

[^346]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 671–672

[^347]: [Iannone 2013](#CITEREFIannone2013), p. 235

[^348]: [Gertz 2019](#CITEREFGertz2019), pp. 13–17

[^349]: [Gertz 2019](#CITEREFGertz2019), pp. 14–15

[^350]: 

[^351]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 1, 5

[^352]: [Iannone 2013](#CITEREFIannone2013), p. 496

[^353]: - [Diken 2008](#CITEREFDiken2008), p. 3
- [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 672

[^354]: [Toribio Vazquez 2021](#CITEREFToribio_Vazquez2021), pp. 1199–1200

[^355]: [Morrison 2002](#CITEREFMorrison2002), pp. 3–6, 34, 50

[^356]: [Westerhoff 2016](#CITEREFWesterhoff2016), pp. 337–338

[^357]: - [Warder 1998](#CITEREFWarder1998), pp. 43–44

[^358]: [Fountoulakis 2021](#CITEREFFountoulakis2021), p. [23](https://books.google.com/books?id=xGtREAAAQBAJ&pg=PA23)

[^359]: [Fletcher et al. 2020](#CITEREFFletcherRomeroTalbotWarburton2020), p. [46](https://books.google.com/books?id=drX4DwAAQBAJ&pg=PA46)

[^360]: 

[^361]: [Morrison 2002](#CITEREFMorrison2002), pp. 24–25, 31–34

[^362]: [Gómez 2007](#CITEREFGómez2007), p. [110](https://books.google.com/books?id=sQULdfIlBIYC&pg=PA110)

[^363]: [Gillespie 1996](#CITEREFGillespie1996), pp. 192, 208, 226, 289

[^364]: [Braak 2011](#CITEREFBraak2011), pp. [38–39](https://books.google.com/books?id=oVFuqMvr7D4C&pg=PA38)

[^365]: [Gertz 2019](#CITEREFGertz2019), p. 72

[^366]: - [Frazier 2024](#CITEREFFrazier2024), § 3. The Critique of 'Things': Madhyamaka Metaphysical Nihilism

[^367]: [Westerhoff 2016](#CITEREFWesterhoff2016), pp. 337–338

[^368]: [Arnold](#CITEREFArnold), § 1. Nāgārjuna and the Paradoxical “Perfection of Wisdom” Literature, § 2c. Ethics and the Charge of Nihilism

[^369]: 

[^370]: [Crosby 1988](#CITEREFCrosby1988), pp. 38–39, 200–203

[^371]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 671

[^372]: [Gillespie 1996](#CITEREFGillespie1996), p. xxii

[^373]: 

[^374]: [Gertz 2019](#CITEREFGertz2019), pp. 18–22

[^375]: [Crosby 1988](#CITEREFCrosby1988), pp. 206–207, 209–210, 217

[^376]: - [Crosby 1988](#CITEREFCrosby1988), pp. 248–249

[^377]: [Gertz 2019](#CITEREFGertz2019), pp. 28–34

[^378]: [Crosby 1998](#CITEREFCrosby1998), § 1. Historical Background

[^379]: 

[^380]: [Gertz 2019](#CITEREFGertz2019), p. 32

[^381]: [Livieri & di Giovanni 2023](#CITEREFLivieridi_Giovanni2023), Lead section, § 1. Life and Intellectual Career, § 3.5 The Open Letter to Fichte (1799)

[^382]: [Crowe 2021](#CITEREFCrowe2021), pp. 157–158, 167–168

[^383]: [Toribio Vazquez 2021](#CITEREFToribio_Vazquez2021), pp. 1200–1201

[^384]: 

[^385]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 672

[^386]: [Gillespie 1996](#CITEREFGillespie1996), p. xix

[^387]: [Crosby 1998](#CITEREFCrosby1998), § 1. Historical Background

[^388]: [Lovell 1998](#CITEREFLovell1998), Lead section

[^389]: - [Pratt](#CITEREFPratt), § 1. Origins

[^390]: [Gillespie 1996](#CITEREFGillespie1996), p. xix

[^391]: [Lovell 1998](#CITEREFLovell1998), Lead section

[^392]: 

[^393]: [Pratt](#CITEREFPratt), § 1. Origins

[^394]: [Crosby 1988](#CITEREFCrosby1988), pp. 15, 27

[^395]: [Holbrook 1977](#CITEREFHolbrook1977), pp. 382–383

[^396]: 

[^397]: [Lippitt & Evans 2024](#CITEREFLippittEvans2024), § 3. The 'Spheres of Existence' or 'Stages on Life's Way'

[^398]: [Carlisle 2006](#CITEREFCarlisle2006), pp. [21–22](https://books.google.com/books?id=lxQLlAM_vrkC&pg=PA21)

[^399]: [Schulz 2014](#CITEREFSchulz2014), pp. 135–138

[^400]: 

[^401]: [Stewart 2023](#CITEREFStewart2023), pp. [9, 129–132](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PA9)

[^402]: [Crosby 1998](#CITEREFCrosby1998), § Existential Nihilism

[^403]: [Gillespie 1996](#CITEREFGillespie1996), p. xx

[^404]: 

[^405]: [Slocombe 2006](#CITEREFSlocombe2006), p. 1

[^406]: [Gertz 2019](#CITEREFGertz2019), pp. 37–40

[^407]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 672

[^408]: [Gillespie 1996](#CITEREFGillespie1996), pp. xi–xii

[^409]: [Crosby 1998](#CITEREFCrosby1998), § 1. Historical Background

[^410]: 

[^411]: [Gertz 2019](#CITEREFGertz2019), pp. 51–52

[^412]: [Gillespie 1996](#CITEREFGillespie1996), pp. xi–xii

[^413]: [Van Tongeren 2013](#CITEREFVan_Tongeren2013), pp. 589–590

[^414]: [Almeida 2022](#CITEREFAlmeida2022), [§ Nihilism, an Old Ghost that Haunts Us](https://www.scielo.br/j/edreal/a/vvF5KGJ98sK97mXpVmzQkBg/?lang=en)

[^415]: 

[^416]: [Gertz 2019](#CITEREFGertz2019), pp. 37–57

[^417]: [Pratt](#CITEREFPratt), Lead section, § 2. Friedrich Nietzsche and Nihilism

[^418]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), pp. 672–673

[^419]: [Crosby 1998](#CITEREFCrosby1998), § 1. Historical Background

[^420]: 

[^421]: [Pratt](#CITEREFPratt), § 2. Friedrich Nietzsche and Nihilism

[^422]: [Gertz 2019](#CITEREFGertz2019), pp. 170–174

[^423]: [Diken 2008](#CITEREFDiken2008), p. 3

[^424]: [Wrathall 2025](#CITEREFWrathall2025), § 5. The History of Being

[^425]: [Becker-Lorca 2024](#CITEREFBecker-Lorca2024), [§ 2. Being as Nothing: The Uncanny Gift of Nihilism](https://www.scielo.org.mx/scielo.php?script=sci_arttext&pid=S0188-66492024000300221&lng=en&nrm=iso&tlng=en)

[^426]: 

[^427]: [Gertz 2019](#CITEREFGertz2019), p. 57

[^428]: [Pratt](#CITEREFPratt), Lead section, § 2. Friedrich Nietzsche and Nihilism, § 5. Conclusion

[^429]: [Gemes & Sykes 2013](#CITEREFGemesSykes2013), p. 672

[^430]: [Toribio Vazquez 2021](#CITEREFToribio_Vazquez2021), pp. 1199–1200, 1206–1207

[^431]: 

[^432]: [Crosby 1988](#CITEREFCrosby1988), p. 27

[^433]: [Manschreck 1976](#CITEREFManschreck1976), p. 88

[^434]: 

[^435]: [Manschreck 1976](#CITEREFManschreck1976), pp. 89–90

[^436]: [Stewart 2023](#CITEREFStewart2023), p. [18](https://books.google.com/books?id=oImzEAAAQBAJ&pg=PA18)

[^437]: [Toribio Vazquez 2021](#CITEREFToribio_Vazquez2021), pp. 1199–1200, 1206–1207

[^438]: [Gertz 2019](#CITEREFGertz2019), pp. 81–85

[^439]: 

[^440]: [Crosby 1998](#CITEREFCrosby1998), § 3. Existential nihilism

[^441]: [Crosby 1988](#CITEREFCrosby1988), pp. 32–33

[^442]: [Joyce 2013](#CITEREFJoyce2013)

[^443]: 

[^444]: [Slocombe 2006](#CITEREFSlocombe2006), pp. xi–xiii, 77, 79, 86

[^445]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^446]: [Gratton 2018](#CITEREFGratton2018), Lead section

[^447]: [Gertz 2019](#CITEREFGertz2019), pp. 88–89

[^448]: 

[^449]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 78–79

[^450]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^451]: 

[^452]: [Slocombe 2006](#CITEREFSlocombe2006), pp. 90–93

[^453]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^454]: [Gratton 2018](#CITEREFGratton2018), Lead section, § 3.2 Justice in light of the Postmodern Condition

[^455]: [Woodward](#CITEREFWoodward), § 4b. The Postmodern Condition

[^456]: [Gertz 2019](#CITEREFGertz2019), pp. 88–90, 92–93

[^457]: 

[^458]: [Tartaglia 2020](#CITEREFTartaglia2020), p. 87

[^459]: [Pratt](#CITEREFPratt), § 4. Antifoundationalism and Nihilism

[^460]: 

[^461]: [Olson 2000](#CITEREFOlson2000), p. 184

[^462]: [Harris](#CITEREFHarris), Lead section, § 3. Hermeneutical Nihilism

[^463]: [Slocombe 2006](#CITEREFSlocombe2006), pp. xi, 91

[^464]: [Hryschko 2010](#CITEREFHryschko2010), pp. 49–51