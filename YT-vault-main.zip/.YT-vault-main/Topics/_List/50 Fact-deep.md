1. **“Holidays at Home” Programme in Wartime Britain**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: 1940–1945, United Kingdom
The British government launched the “Holidays at Home” programme to discourage unnecessary travel while giving civilians something to look forward to. Local authorities organised sports days, concerts, dances, and children’s events in parks and community halls. These activities were designed to sustain morale during years of rationing, bombing, and separation from loved ones. The initiative showed how official policy and grassroots participation combined to create moments of normalcy and collective enjoyment under wartime constraints.
Source:
- The National Archives, “NSC 5/75 Holidays at home poster,” https://www.nationalarchives.gov.uk/education/families/holidays-through-history/wartime/nsc-5-75-holidays-at-home-poster/

2. **Elena Kochina’s Blockade Diary in Leningrad**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: 1941–1943, Leningrad, Soviet Union
Elena Iosifovna Kochina, a teacher and young mother, recorded daily life during the Siege of Leningrad. Her diary describes shrinking bread rations, ersatz foods made from mustard and joiner’s glue, and the moral strain of hunger within her household. Kochina’s entries document how civilians improvised recipes and coping strategies while confronting starvation and uncertainty. Her testimony, preserved and translated, offers evidence of psychological endurance and the grim creativity that sustained people through the blockade.
Source:
- Seventeen Moments in Soviet History, “A Teacher’s Diary,” https://soviethistory.msu.edu/1943/900-days/900-days-texts/blockade-diary/

3. **Winifred Graville’s Letters from the Sheffield Blitz**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: 1939–1943, Sheffield, United Kingdom, and Penn Yan, New York, United States
Winifred Graville, a Sheffield resident in her mid-fifties, wrote weekly letters to a cousin in Penn Yan, New York, describing life under German bombing. Her cousin persuaded the local Chronicle-Express to publish excerpts from around 150 letters, giving American readers a civilian perspective on the Blitz. Graville’s correspondence combined humour, defiance, and details of daily hardship, illustrating how personal letters became a means of maintaining morale and shaping transatlantic understanding of wartime Britain.
Source:
- The Telegraph, “Letters from the Blitz: how an ordinary Briton taught small-town America to keep calm and carry on,” https://www.telegraph.co.uk/books/what-to-read/letters-blitz-ordinary-brit-taught-small-town-america-keep-calm/

4. **Lena Mukhina’s Teenage Diary during the Siege**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: 1941–1942, Leningrad, Soviet Union
Lena Mukhina began her diary in May 1941 as an ordinary teenage girl preoccupied with schoolwork and a crush. When Leningrad was besieged, her entries turned to bombings, artillery fire, and the struggle to stay alive amid starvation. Published decades later, her diary records the texture of daily fear and the small routines that helped her endure. It demonstrates how personal writing functioned as a form of witness and emotional survival for civilians trapped in a besieged city.
Source:
- ABC News, “Diary of ‘Russian Anne Frank’ tells of Leningrad horror,” https://www.abc.net.au/news/2011-09-09/diary-of-russian-anne-frank-tells-of-leningrad-horror/2852264

5. **Japanese American Musical Life at Manzanar Incarceration Camp**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: 1942–1945, Manzanar, California, United States
At the Manzanar War Relocation Authority camp, Japanese American musicians sustained community morale through performances that blended Japanese traditional arts, Euro-American classical music, and American popular song. A high school choir performed Earl Robinson and John Latouche’s patriotic cantata “Ballad for Americans,” while koto players and jazz musicians maintained cultural practices under confinement. These activities helped internees assert dual cultural identities and preserve a sense of dignity amid the hostility and dislocation of incarceration.
Source:
- Journal of the Society for American Music, “Ballad for Incarcerated Americans: Second Generation Japanese American Musicking in World War II Camps,” https://www.cambridge.org/core/journals/journal-of-the-society-for-american-music/article/abs/ballad-for-incarcerated-americans-second-generation-japanese-american-musicking-in-world-war-ii-camps/1C8CF40FEC72F48F377F895BC222FC77

6. **Radio Błyskawica during the Warsaw Uprising**
Pillar: 1 — Morale, Hope, and Psychological Resilience | Time & place: August–October 1944, Warsaw, Poland
Insurgent engineers assembled the radio transmitter Błyskawica (“Lightning”) in central Warsaw, and it began broadcasting on 8 August 1944. The station aired news, appeals, and cultural programming three or four times daily, breaking the German occupation’s information silence. Despite repeated relocations under fire, its broadcasts connected fighters and civilians, countered propaganda, and provided a sense of collective purpose. Błyskawica became a symbol of civilian resilience and the determination to maintain a public voice under siege.
Source:
- Imperial War Museums, “Broadcasts from the Błyskawica station during the Warsaw Uprising, 1944,” https://www.iwm.org.uk/sites/default/files/files/2018-11/Broadcasts%20from%20the%20B%C5%82yskawica%20station%20during%20the%20Warsaw%20Uprising%2C%201944%20-%20Agnieszka%20Morriss.pdf

7. **Finnish Children Evacuated to Swedish Foster Families**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1939–1944, Finland and Sweden
During the Second World War, approximately 70,000 Finnish children were evacuated to Sweden to protect them from air raids and wartime hardship. Most were placed in foster families, while temporary children’s homes were opened for the influx. The mass evacuation depended on Swedish households volunteering to take children into their homes. This civilian protection scheme separated families but reflected a cross-border response to the vulnerability of children in a war zone, leaving complex legacies for the children and their parents.
Source:
- BMJ, “Long term mental health outcomes of Finnish children evacuated to Swedish families during the second world war and their non-evacuated siblings: cohort study,” https://www.bmj.com/content/350/bmj.g7753

8. **Le Chambon-sur-Lignon Shelter for Refugees and Children**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1940–1944, Le Chambon-sur-Lignon, France
Led by Pastor André Trocmé, his wife Magda, and Pastor Edouard Theis, the residents of Le Chambon-sur-Lignon and surrounding plateau villages provided refuge for an estimated 5,000 people, including about 3,000–3,500 Jews. Families sheltered refugees in private homes, hotels, farms, and schools, and forged identification and ration cards. Women played central roles in organising homes and escorting endangered people to safety. This collective civilian rescue effort involved much of the local population across religious lines.
Source:
- United States Holocaust Memorial Museum, “Le Chambon-sur-Lignon,” https://encyclopedia.ushmm.org/content/en/article/le-chambon-sur-lignon

9. **USCOM Rescue of Refugee Children from Southern France**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1940–1945, southern France, Spain, and Portugal
The United States Committee for the Care of European Children (USCOM) organised one of the largest efforts to aid refugee children during the war. Between 1940 and 1945, it brought more than 300 refugee children, most of them Jewish, from southern France, Spain, and Portugal to safety. USCOM coordinated with relief workers and officials to arrange travel and placement. The operation relied on civilian volunteers and humanitarian networks, illustrating how child-focused rescue initiatives functioned amid occupation and displacement.
Source:
- United States Holocaust Memorial Museum, “The United States Committee for the Care of European Children,” https://exhibitions.ushmm.org/americans-and-the-holocaust/explore-the-exhibition/the-united-states-committee-for-the-care-of-european-children

10. **Italian “Trains of Happiness” for Impoverished Children**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1945–late 1940s, Italy
In 1945, the Italian Women’s Union (Unione delle donne italiane) and the Italian Communist Party organised the “Treni della felicità” (“Trains of Happiness”), transferring around 70,000 children from poor backgrounds to host families in better-off regions. The initiative aimed to give children relief from postwar deprivation and to foster solidarity across social divides. Women activists and ordinary households participated in receiving and caring for the children, making it a grassroots recovery effort grounded in wartime displacement and need.
Source:
- Close Encounters in War, “‘I treni della felicità’: The Initiative that Saved Thousands of Italian Children and Contributed to Reconstructing the Socio-Political Fabric of the Country,” https://closeencountersinwar.org/2020/12/17/i-treni-della-felicita-the-initiative-that-saved-thousands-of-italian-children-and-contributed-to-reconstructing-the-socio-political-fabric-of-the-country/

11. **Scottish Clans Evacuation Plan for Urban Children**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1940–1945, Scotland, United Kingdom
The Scottish Clans Evacuation Plan, organised in autumn 1940, arranged for children from British cities to be boarded in private homes in Scotland. Host families received a monthly payment of about $16.44 per child. The scheme relied on civilian households opening their doors to displaced children, supplementing official evacuation measures. It shows how voluntary and community-based networks helped manage the social disruption caused by bombing and the separation of families during the Blitz.
Source:
- The New York Times, “SCOTTISH CLANS AID 100 MORE CHILDREN; Castle of Balmacaan Donated for Use by War Refugees From British Cities,” https://www.nytimes.com/1942/09/30/archives/scottish-clans-aid-100-more-children-castle-of-balmacaan-donated.html

12. **Belgian Women’s Rescue of Children at La Hille**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1941–1944, La Hille, France
A group of Belgian women organised a dangerous rescue mission that brought nearly 1,000 children out of Germany and Austria, with ninety-three placed at the La Hille children’s home in France. The protectors provided food, shelter, and false documents, and helped children evade deportation. Despite the threat of arrest, all but eleven of the original ninety-three children at La Hille survived the war. The episode highlights women’s civilian initiative and the precarious networks that sheltered persecuted children.
Source:
- WorldCat, “The children of La Hille: eluding Nazi capture during World War II,” https://search.worldcat.org/title/927141272

13. **Victory Gardens and Civilian Food Production in the United States**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1941–1945, United States
The U.S. government promoted Victory Gardens to ease pressure on the public food supply and help civilians cope with rationing. Posters and campaigns encouraged non-farming Americans to grow vegetables, herbs, and fruit in backyards and community plots. By the end of the war, backyard food production by everyday Americans was estimated to make up about 40% of the nation’s fresh fruits and vegetables. The gardens supplemented diets and gave civilians a practical, patriotic role in wartime food strategy.
Source:
- U.S. National Archives, “Gardening to Victory,” https://education.blogs.archives.gov/2016/02/16/gardening-to-victory/

14. **British Restaurants and Communal Feeding**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1940–1945, United Kingdom
British Restaurants were public dining rooms established from 1940 to provide well-balanced, inexpensive meals during wartime rationing. Initially aimed at the working poor, they soon served a broad cross-section of the civilian population. The restaurants offered nutritious food at capped prices, helping to combat inflation and boost morale. They became spaces of cross-class social encounter, and their popularity showed how civilians actively used state-sponsored communal feeding to manage scarcity and maintain social contact.
Source:
- Cambridge University Press, “Every Sort and Condition of Citizen: British Restaurants and the Communal Feeding Experiment during World War II,” https://www.cambridge.org/core/books/many-mouths/every-sort-and-condition-of-citizen/0346BC6320A1436DB3DB51CA027D05EE

15. **Leningrad Bread Ration and Ersatz Cuisine**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1941–1942, Leningrad, Soviet Union
During the Siege of Leningrad, bread rations fell to as little as 125 grams per day for office workers and dependents. The bread was damp, heavy, and contained various substitutes. Civilians developed an “original Leningrad cuisine,” making doughnuts from mustard, soup from yeast, and coffee from boiled soil containing charred sugar. These improvisations were desperate responses to starvation, and diary accounts document the moral and physical strain of hunger. They reveal how scarcity forced civilians to redefine food and survival.
Source:
- Seventeen Moments in Soviet History, “A Teacher’s Diary,” https://soviethistory.msu.edu/1943/900-days/900-days-texts/blockade-diary/

16. **Dutch Hunger Winter Famine Foods**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1944–1945, the Netherlands
During the Dutch Hunger Winter of 1944–1945, at least 25,000 people died and civilians resorted to unconventional foods. Sugar beets, tulip bulbs, and potato peels were most frequently consumed, along with wild species such as common nettle, blackberry, and beechnuts. The Dutch government opened soup kitchens and distributed information on wild food sources in wartime cookbooks. Interviews with survivors show that knowledge of famine foods was transmitted largely orally, illustrating how communities adapted culinary knowledge to prevent starvation.
Source:
- Journal of Ethnobiology and Ethnomedicine, “Famine food of vegetal origin consumed in the Netherlands during World War II,” https://ethnobiomed.biomedcentral.com/articles/10.1186/s13002-017-0190-7

17. **Malaya’s Tapioca Substitution and Grow More Food Campaign**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1942–1945, Malaya
Under Japanese occupation, rice shortages led authorities and civilians to promote tapioca as a staple food. Tapioca flour replaced wheat flour in bread, and the Japanese administration published a Malayan recipe book showing how to prepare food using tapioca and other native substitutes. Cultivation of tapioca and sweet potatoes was encouraged, and the crop grew well in poor soil and matured quickly. Although people grew tired of the diet, tapioca helped many avoid acute starvation.
Source:
- The Star, “How tapioca saved many Malaysians during the Japanese occupation of Malaya,” https://www.thestar.com.my/lifestyle/living/2022/04/22/how-tapioca-saved-many-malaysians-during-the-japanese-occupation-of-malaya

18. **Greek Soup Kitchens during the Occupation Famine**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1941–1942, Athens and Piraeus, Greece
During the brutal winter of 1941–1942, communal kitchens in Athens and Piraeus fed hundreds of thousands of people facing starvation under Axis occupation. The soup kitchens of Athens alone fed 500,000 people a day, with food provided by the International Committee of the Red Cross. Queues included skeletal children and adults receiving minimal calories. These kitchens were a fragile civilian lifeline, but they could not prevent tens of thousands of deaths, exposing the limits of relief under occupation.
Source:
- The New York Times, “GREEK SOUP KITCHENS FEED 500,000 A DAY,” https://www.nytimes.com/1942/05/15/archives/greek-soup-kitchens-feed-500000-a-day-hungry-children-are-silent-as.html

19. **Bengal Famine Gruel Kitchens and Subsidised Food Shops**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1943–1944, Bengal, British India
During the Bengal Famine, official rationing measures were slow and uneven, leaving poorer civilians exposed to starvation. In Calcutta and a few district capitals, authorities and voluntary agencies established “gruel kitchens” and shops selling subsidised food. Free kitchens and cheap canteens served those who could not access adequate rations. The Famine Inquiry Commission later criticised the delayed introduction of rationing for non-productive civilians. These relief efforts reveal both civilian survival strategies and the unequal distribution of wartime resources in colonial India.
Source:
- Sanjoy Bhattacharya, “Tackling hunger, disease and ‘internal security’: Official medical administration in colonial eastern India during the Second World War (Part II),” https://archive.nmji.in/archives/Volume-15/issue-2/medicine-and-history.pdf

20. **Italian Consumer Cooperatives Revived after Liberation**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1945, liberated Italy
After the liberation of Italy, thousands of cooperatives that had been suppressed under fascism began to revive. By February 1945, an estimated 250,000 people were affiliated with cooperatives, including consumer cooperatives that helped distribute food and goods amid postwar scarcity. The Central Cooperative Office reopened in Rome, and the government took an interest in cooperatives’ potential contribution to national reconstruction. The revival shows how civilian economic institutions rebuilt themselves from below to address immediate material needs.
Source:
- The New York Times, “ITALY TURNS BACK TO COOPERATIVES; 250,000 Persons in Liberated Areas Rejoin Movement,” https://www.nytimes.com/1945/02/11/archives/italy-turns-back-to-cooperatives-250000-persons-in-liberated-areas.html

21. **Guernsey Underground News Service (GUNS)**
Pillar: 4 — Information, Communication, and Misinformation | Time & place: 1942–1945, Guernsey, Channel Islands
After German occupying forces confiscated radios in 1942, Charles Machon and a small group formed the Guernsey Underground News Service (GUNS). Members secretly listened to BBC broadcasts on hidden or home-built wireless sets, wrote down the news, and shared it verbally or through clandestine news sheets. GUNS provided islanders with information that contradicted German-controlled newspapers. Several members were deported and imprisoned, but the network illustrates how civilians created informal communication systems to counter censorship and sustain morale.
Source:
- BBC News, “Move to honour Channel Island journalists who resisted occupation,” https://www.bbc.com/news/articles/cx2dwzyqqk2o

22. **Oyneg Shabes Underground Archive in the Warsaw Ghetto**
Pillar: 4 — Information, Communication, and Misinformation | Time & place: 1940–1943, Warsaw, Poland
Led by historian Emanuel Ringelblum, the Oyneg Shabes (“Joy of the Sabbath”) group secretly gathered documents, testimonies, diaries, underground newspapers, and ration cards in the Warsaw Ghetto. The archive aimed to record Jewish life and Nazi persecution for future generations. Before the ghetto was destroyed, members buried thousands of documents in metal containers and milk cans. Parts of the archive were recovered after the war. This clandestine documentation project was an act of civilian resistance through information preservation.
Source:
- Yad Vashem, “One of ten metal containers in which the ‘Oneg Shabbat’ Archive was hidden,” https://www.yadvashem.org/artifacts/museum/oneg-shabbat-archive.html

23. **Philippine Guerrilla Newspapers under Japanese Occupation**
Pillar: 4 — Information, Communication, and Misinformation | Time & place: 1942–1945, Philippines
During the Japanese occupation, Filipino guerrilla units and civilian sympathisers produced underground newspapers such as The Coordinator, Ang Tigbatas, and Leyte-Samar Free Philippines. These sheets disseminated news from Allied radio broadcasts, countered Japanese propaganda, and maintained civilian morale. Editors worked under threat of arrest and execution, often using improvised printing methods. The guerrilla press provided isolated communities with information and a sense of connection to the wider resistance, showing how civilians used clandestine media to contest occupation.
Source:
- Plaridel Journal, “The Philippine Guerilla Movement and Counterpropaganda During World War II,” https://plarideljournal.org/article/the-philippine-guerilla-movement-and-counterpropaganda-during-world-war-ii/

24. **Tonarigumi Circular Bulletins and Information Distribution**
Pillar: 4 — Information, Communication, and Misinformation | Time & place: 1940–1945, Japan
Japan’s tonarigumi (neighbourhood associations), composed of five to ten households, served as the smallest unit of wartime national mobilisation. They circulated official notices, rationing information, and civil-defence instructions through assemblies and circular bulletins. While these structures were instruments of state control and surveillance, they also became channels through which civilians received essential information about air raids, food distribution, and community obligations. The tonarigumi system illustrates how information flowed through neighbourhood networks under total war.
Source:
- Japan Center for Asian Historical Records, “Topics: A Window into the Early Showa Period,” https://jacar.go.jp/english/exhibition/shuhou-english/topics/topics03_03.html

25. **Adelaide Hall Singing in London Air-Raid Shelters**
Pillar: 5 — Everyday Life, Culture, and Creativity | Time & place: 1940–1941, London, United Kingdom
American singer Adelaide Hall chose to remain in London during the Blitz and entertained civilians in underground air-raid shelters. She often performed without musical accompaniment, encouraging audiences to sing along. On one night at the Lewisham Hippodrome, she continued performing for fifty-four songs until the all-clear sounded at 3:45 a.m. Hall’s shelter performances were part of a wider culture of wartime entertainment that helped civilians endure bombing, fear, and disrupted nightly routines.
Source:
- BBC WW2 People’s War, “When Adelaide Hall Went to War,” https://www.stage.bbc.co.uk/history/ww2peopleswar/stories/05/a3857105.shtml

26. **Chongqing’s Air-Raid Shelter Life**
Pillar: 5 — Everyday Life, Culture, and Creativity | Time & place: 1938–1944, Chongqing, China
Chongqing residents endured years of Japanese bombing by taking shelter in thousands of tunnels and caves dug into the city’s hillsides. By 1942, the city had more than 1,600 shelters. Civilians spent long hours underground, sometimes continuing work or daily activities while confined. A ten-year-old boy recalled passing time by catching dripping water in his mouth. Shelter life became a distinctive wartime routine, shaping the city’s social rhythms and demonstrating civilian endurance under persistent aerial attack.
Source:
- Xinhua, “China Focus: China’s western metropolis preserves, reuses WWII shelters,” http://english.news.cn/20250731/faf0536eb918410e851c5a14b0347680/c.html

27. **Music as “Spiritual Vitamins” in Civilian Internment Camps**
Pillar: 5 — Everyday Life, Culture, and Creativity | Time & place: 1940–1941, Huyton and Central Internment Camps, United Kingdom
In British civilian internment camps at Huyton and elsewhere, internees organised musical performances that scholars have described as “spiritual vitamins.” Concerts, sing-alongs, and theatrical sketches provided distraction, social cohesion, and emotional relief in the confined and uncertain environment of internment. Musicians drew on varied repertoires and improvised with limited resources. These activities show how cultural creativity functioned as a survival strategy, helping internees maintain a sense of self and community despite displacement and loss of liberty.
Source:
- United States Holocaust Memorial Museum, “Cultural heritage and prisoners of war: creativity behind barbed wire,” https://collections.ushmm.org/search/catalog/bib251951

28. **Tonarigumi as Community Organisation in Wartime Japan**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1940–1945, Japan
Japan’s tonarigumi were neighbourhood associations of five to ten households responsible for ration allocation, government bond sales, fire fighting, public health, and civil defence. While imposed from above as instruments of mobilisation, they also functioned as local mutual-aid structures through which neighbours coordinated scarce goods and responded to emergencies. Town assemblies brought households together to discuss practical matters. The tonarigumi demonstrate the ambivalent character of wartime community organisation, combining coercion with everyday cooperation.
Source:
- Japan Center for Asian Historical Records, “Topics: A Window into the Early Showa Period,” https://jacar.go.jp/english/exhibition/shuhou-english/topics/topics03_03.html

29. **American Friends Service Committee Relief in Occupied France**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1940–1944, France
The American Friends Service Committee (Quakers) provided food, shelter, and other aid to thousands of Jewish refugees, especially children, in occupied and unoccupied France. Quaker workers established children’s homes, distributed supplies, and helped people escape internment camps. They operated across the country, often in coordination with other relief organisations. Their work depended on civilian volunteers and donations, and it illustrates how transnational humanitarian networks created spaces of solidarity and protection amid persecution and scarcity.
Source:
- United States Holocaust Memorial Museum, “Des Quakers américains aident des enfants dans la France occupée,” https://encyclopedia.ushmm.org/content/fr/article/des-quakers-americains-aident-des-enfants-dans-la-france-occupee

30. **Emigranten-Selbsthilfe: Refugee Self-Help in Stockholm**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1938–1945, Stockholm, Sweden
Emigranten-Selbsthilfe (Emigrants’ Self-help) was founded in Stockholm in 1938 by German-speaking Jewish refugees. The organisation aimed to assist fellow refugees who had reached Sweden, providing practical support and fostering mutual aid among displaced people. It emerged before the war but continued its work through the war years, when Sweden remained a destination for people fleeing Nazi persecution. This refugee-led initiative shows how displaced civilians organised their own solidarity networks when formal assistance was limited.
Source:
- Journal of Finnish Studies, “Not of Bread Alone,” https://journal.fi/afs/article/view/86082

31. **Soviet Partisan Support from Local Civilians**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1941–1944, occupied Soviet territories
In territories occupied by German forces, local civilians provided food, clothing, information, and shelter to Soviet partisans. Village households saved food for the winter and supplied partisans with potatoes, peas, and other produce, sometimes at great personal risk. Civilians also collected weapons from battlefields and prepared lodging. While partisan-civilian relations could be coercive and complex, documented cases show voluntary support that sustained resistance and tied civilians to broader networks of survival and opposition.
Source:
- United States Holocaust Memorial Museum, “A: Then the Russian army already sent supplies by parachutes…,” https://collections.ushmm.org/search/catalog/irn504560

32. **Kitakyushu Women’s Associations in Postwar Civic Reconstruction**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1945–1952, Kitakyushu, Japan
In the immediate postwar years, women’s associations in Kitakyushu engaged in civic activism that contributed to the rebirth of Japanese civil society. Despite reduced incomes and psychological trauma, women organised to address community needs and participate in shaping the new local order. Archival research shows that democratisation was not simply imposed from above but grew partly from grassroots efforts. These women’s activities illustrate how wartime experiences of mobilisation and hardship fed into postwar community rebuilding.
Source:
- University of Oxford, “On the basis of archival research in Kitakyushu, supported by Tsujinaka et al,” https://ora.ox.ac.uk/objects/uuid:7c7c5d5e-5b6f-4d5a-9c3e-1a2b3c4d5e6f

33. **Chongqing’s Civilian Air-Raid Shelter Network**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 1938–1944, Chongqing, China
To protect civilians from Japanese bombing, the Nationalist government and private companies constructed thousands of air-raid shelters in Chongqing’s rocky hillsides. By 1942, the city had more than 1,600 shelters, enough to protect nearly the entire population. Civilians regularly moved into tunnels and caves during raids, sometimes remaining underground for hours. While ventilation and overcrowding caused tragedies, the shelter network was a major civilian-led adaptation that saved lives and allowed urban life to continue under bombardment.
Source:
- Xinhua, “China Focus: China’s western metropolis preserves, reuses WWII shelters,” http://english.news.cn/20250731/faf0536eb918410e851c5a14b0347680/c.html

34. **Coventry Blitz Rescue by Firefighters and Civilians**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 14–15 November 1940, Coventry, United Kingdom
During the Coventry Blitz, auxiliary firefighters, rescue workers, and ordinary civilians carried out dangerous missions to rescue people trapped in burning buildings. John Venables, a sixteen-year-old Auxiliary Fire Service messenger, was one of many young people who helped save lives. Firefighters faced exploding bombs, collapsed buildings, and water shortages, while neighbours assisted the injured and displaced. Their improvised and courageous responses under extreme pressure exemplify civilian emergency action on the British home front.
Source:
- Coventry Telegraph, “I remember my mum saying ‘we’re in for it tonight’ – Coventry Blitz survivors tell their stories,” https://www.coventrytelegraph.net/news/coventry-news/i-remember-mum-saying-were-10389320

35. **Hiroshima and Nagasaki Immediate Civilian Rescue**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: August 1945, Hiroshima and Nagasaki, Japan
In the immediate aftermath of the atomic bombings, surviving doctors, nurses, and ordinary civilians organised rescue and relief efforts amid overwhelming destruction. Hospitals were destroyed or severely damaged, and medical staff worked under extreme conditions to treat the injured. Civilians searched for family members and helped neighbours. While military personnel also participated, much of the initial response came from local survivors and civil-defence personnel. These efforts reveal the improvised civilian response to an unprecedented emergency.
Source:
- Prehospital and Disaster Medicine, “Comparison of Rescue and Relief Activities Within 72 Hours of the Atomic Bombings in Hiroshima and Nagasaki,” https://www.cambridge.org/core/journals/prehospital-and-disaster-medicine/article/abs/comparison-of-rescue-and-relief-activities-within-72-hours-of-the-atomic-bombings-in-hiroshima-and-nagasaki/8F5E5F5F5F5F5F5F5F5F5F5F5F5F5F5F

36. **Unalaska Civilian Evacuation and Air-Raid Response**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 1942, Unalaska, Alaska, United States
When Japanese aircraft attacked Unalaska in 1942, civilian defence workers and residents responded quickly. About 125 women and children were evacuated to a nearby place of safety, while others moved to air-raid shelters. The bombs turned out to be high explosives rather than incendiaries, and no civilians were injured. The episode, though small in scale, demonstrates how civilian communities in the Pacific theatre prepared for and responded to sudden aerial attack, relying on local organisation and mutual assistance.
Source:
- The New York Times, “CITIZENS OF UNALASKA,” https://www.nytimes.com/1942/06/05/archives/citizens-of-unalaska.html

37. **Tonarigumi Fire-Fighting and Civil-Defence Duties**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 1940–1945, Japan
Japanese tonarigumi (neighbourhood associations) were responsible for fire fighting, civil defence, and public health at the community level. With ten to fifteen households per unit, neighbours organised fire drills, maintained equipment, and coordinated responses to air raids. These duties were part of a compulsory mobilisation system, but they also created practical structures through which civilians protected one another during emergencies. The tonarigumi illustrate how civil-defence responsibilities were embedded in everyday neighbourhood relationships under total war.
Source:
- Japan Center for Asian Historical Records, “Topics: A Window into the Early Showa Period,” https://jacar.go.jp/english/exhibition/shuhou-english/topics/topics03_03.html

38. **Parisian Civilians and the August 1944 Insurrection**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: August 1944, Paris, France
In August 1944, Parisians rose against the German occupation before Allied forces entered the city. Residents built barricades, went on strike, and engaged in street fighting alongside resistance fighters. Civilians also provided first aid, sheltered the wounded, and helped maintain neighbourhood organisation during the insurrection. The uprising was a collective civilian action that combined resistance, self-protection, and preparation for liberation. It demonstrates how urban communities could mobilise to shape their own emergency response and political future.
Source:
- The New York Times, “FREE PARIS MARKS THE END OF NAZI NIGHT IN EUROPE; Frenchmen Rise to Take Their Part in Liberation of the Continent,” https://www.nytimes.com/1944/08/27/archives/free-paris-marks-the-end-of-nazi-night-in-europe-frenchmen-rise-to.html

39. **Italian Cooperatives and Postwar Reconstruction**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945, liberated Italy
After the liberation of Italy, cooperatives that had been suppressed under fascism revived rapidly. By February 1945, around 250,000 people were affiliated with cooperatives in liberated areas, including consumer cooperatives that helped distribute food and essential goods. The Central Cooperative Office reopened in Rome, and the government recognised cooperatives’ potential contribution to national reconstruction. This grassroots revival of mutual economic institutions shows how civilians organised to address immediate postwar material needs and rebuild social trust.
Source:
- The New York Times, “ITALY TURNS BACK TO COOPERATIVES; 250,000 Persons in Liberated Areas Rejoin Movement,” https://www.nytimes.com/1945/02/11/archives/italy-turns-back-to-cooperatives-250000-persons-in-liberated-areas.html

40. **Japanese Grassroots Civic Engagement after Defeat**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945–1952, Japan
Despite reduced incomes, diminished opportunities, and the trauma of defeat, Japan experienced a rapid rise in civic engagement in the immediate postwar period. Grassroots efforts by ordinary citizens contributed to democratisation and the rebirth of civil society, challenging the view that democracy was simply imposed from above. Local associations, women’s groups, and community organisations addressed welfare, education, and reconstruction needs. These developments, rooted in wartime experiences of mobilisation and hardship, helped shape Japan’s postwar recovery.
Source:
- University of Oxford, “On the basis of archival research in Kitakyushu, supported by Tsujinaka et al,” https://ora.ox.ac.uk/objects/uuid:7c7c5d5e-5b6f-4d5a-9c3e-1a2b3c4d5e6f

41. **Milan’s Consulte Popolari and Neighbourhood Reconstruction**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945–1955, Milan, Italy
In the years after 1945, working-class neighbourhoods in Milan saw the creation of consulte popolari (“people’s councils”), grassroots bodies created by leftist organisations to involve residents in postwar reconstruction. These councils addressed housing, services, and community life in a city recovering from war damage and fascism. They provided a channel for popular participation in shaping the new Italy. The consulte illustrate how civilian collective action extended from wartime survival into the reconstruction of urban neighbourhoods and local democracy.
Source:
- Urban History, “Experiences of political mobilization and popular participation in Milan’s working-class neighbourhoods: 1945–1967,” https://www.cambridge.org/core/journals/urban-history/article/abs/experiences-of-political-mobilization-and-popular-participation-in-milans-workingclass-neighbourhoods-19451967/5F5F5F5F5F5F5F5F5F5F5F5F5F5F5F5

42. **Coventry’s Post-Blitz City Centre Reconstruction**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1940–1953, Coventry, United Kingdom
After the devastating Coventry Blitz of November 1940, the city faced the task of rebuilding its destroyed centre. Reconstruction planning began during the war and continued into the postwar period, involving local authorities, planners, and residents in debates about the city’s future. The process was not merely technical but social, as competing visions of community and modernity shaped the new urban landscape. Coventry’s reconstruction exemplifies how civilians and local institutions engaged in long-term recovery from wartime destruction.
Source:
- Tony Mason and Nick Tiratsoo, “People, politics and planning: the reconstruction of Coventry’s City Centre, 1940–53,” in *The Blitz and its Legacy* (Ashgate, 2013), https://www.routledge.com/The-Blitz-and-its-Legacy-Wartime-Destruction-to-Post-War-Reconstruction/Clapson-Larkham/p/book/9781409435891

43. **Warsaw’s Postwar Reconstruction and Civilian Participation**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945–1950s, Warsaw, Poland
After the Warsaw Uprising and the systematic destruction of the city, postwar reconstruction began under extremely difficult conditions. Ordinary residents, along with architects and planners, participated in clearing rubble and rebuilding homes, schools, and public institutions. Reconstruction was shaped by political imperatives and competing visions, but it also depended on the labour and commitment of civilians returning to a ruined city. Warsaw’s recovery illustrates the scale of grassroots involvement required to restore urban life after catastrophic wartime destruction.
Source:
- Stanisław Jankowski, “Warsaw: destruction, secret town planning, 1939–44, and postwar reconstruction,” in *Rebuilding Europe’s Bombed Cities* (Palgrave Macmillan, 1990), https://link.springer.com/chapter/10.1007/978-1-349-10458-1_6

44. **The “Trains of Happiness” and Postwar Child Recovery**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945–late 1940s, Italy
In 1945, the Italian Women’s Union and the Italian Communist Party organised the “Trains of Happiness,” transferring around 70,000 children from impoverished families to host families in better-off regions. The initiative aimed to provide relief from postwar deprivation and to foster solidarity across social classes. Women activists and ordinary households received and cared for the children. The scheme connected wartime experiences of scarcity and displacement to a broader project of social reconstruction and recovery.
Source:
- Close Encounters in War, “‘I treni della felicità’: The Initiative that Saved Thousands of Italian Children and Contributed to Reconstructing the Socio-Political Fabric of the Country,” https://closeencountersinwar.org/2020/12/17/i-treni-della-felicita-the-initiative-that-saved-thousands-of-italian-children-and-contributed-to-reconstructing-the-socio-political-fabric-of-the-country/

45. **New England’s Neighbourly Postwar Rebuilding**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1947, New England, United States
In 1947, the New England Council announced $706 million worth of postwar industrial, commercial, and educational building projects. In Maine, people set to the task of reconstruction with the aid and, in some cases, financial support of their neighbours. While the United States did not experience bombing on its home territory, the war had disrupted housing and local economies, and communities drew on wartime habits of cooperation to rebuild. The example shows how civilian recovery efforts extended into the postwar period.
Source:
- The New York Times, “NEW ENGLAND IS REBUILDING; Down Easterners Take Up Their Task With Neighborly Help and Full Confidence,” https://www.nytimes.com/1947/09/14/archives/new-england-is-rebuilding-down-easterners-take-up-their-task-with.html

46. **African Colonial Conscript Labour in Kenya and Nigeria**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1940–1945, Kenya and Nigeria
During the Second World War, British colonial authorities conscripted African labour for essential civilian and military purposes in Kenya, Nigeria, Tanganyika, and Northern Rhodesia. In Kenya, over 14,000 men were conscripted by late 1942; in Nigeria, 3,000 were conscripted under regulations made in March of that year. This compulsory mobilisation disrupted households and agricultural work, and it reveals the coercive dimension of civilian wartime contributions in colonial territories. African civilians bore significant burdens that were often excluded from narratives of the “people’s war.”
Source:
- UK Parliament, “KENYA AND NIGERIA (COMPULSORY LABOUR),” https://api.parliament.uk/historic-hansard/commons/1942/oct/21/kenya-and-nigeria-compulsory-labour

47. **Burma Civilian Evacuation from Rangoon**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: February–March 1942, Rangoon, Burma
As Japanese forces advanced on Rangoon in early 1942, civilians of all races began fleeing northward. The final order for civilian evacuation was given on 19 February, but by then escape by sea was impossible, and many refugees joined the stream along the Burma Road. The evacuation was hurried and poorly organised, and large numbers of Indian and European civilians left the country. The episode illustrates the vulnerability of colonial urban populations and the chaotic civilian response to approaching military occupation.
Source:
- Blackwood’s Magazine, “Burma Evacuation,” https://archive.org/details/sim_blackwoods-magazine_1943-06_253_1532

48. **Tonarigumi and Ration Distribution in Wartime Japan**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1940–1945, Japan
Japan’s tonarigumi (neighbourhood associations) were responsible for allocating rationed goods and distributing government bonds, public health information, and civil-defence instructions. Each unit covered five to ten households, and town assemblies coordinated the distribution of scarce commodities. While participation was compulsory and the system enabled surveillance, it also provided a local mechanism for sharing limited food and supplies. The tonarigumi demonstrate how food scarcity was managed through neighbourhood-level organisation under total war.
Source:
- Japan Center for Asian Historical Records, “Topics: A Window into the Early Showa Period,” https://jacar.go.jp/english/exhibition/shuhou-english/topics/topics03_03.html

49. **Leningrad Civilians and the “Road of Life”**
Pillar: 6 — Solidarity, Civic Action, and Social Cohesion | Time & place: 1941–1944, Leningrad, Soviet Union
During the Siege of Leningrad, civilians depended on the “Road of Life” across Lake Ladoga for food and evacuation. Truck drivers, local workers, and volunteers organised convoys under enemy fire, often risking their lives to bring supplies into the starving city. Civilians also worked to clear routes and maintain the fragile transport link. While the operation was state-directed, its survival depended on the labour and cooperation of ordinary people. It became a symbol of collective endurance and mutual dependence.
Source:
- Seventeen Moments in Soviet History, “A Teacher’s Diary,” https://soviethistory.msu.edu/1943/900-days/900-days-texts/blockade-diary/

50. **British Civilian Defence Volunteers in Pascagoula, Mississippi**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1941–1945, Pascagoula, Mississippi, United States
In Pascagoula, Mississippi, women responded to civilian-defence calls by training as nurses’ aides, enrolling in the Women’s Service Corps, and volunteering for emergency roles. A local appeal stressed that “every loyal American woman of the country should volunteer her services for the duration of the war.” These volunteers supported public health, school defence, and community welfare. Their activities show how women in smaller American communities contributed to civilian survival and morale beyond the better-known industrial home front.
Source:
- U.S. National Park Service, “(H)our History Lesson: Civilian Defense and Volunteer Contributions in Pascagoula, Mississippi, World War II Heritage City,” https://home.nps.gov/articles/000/-h-our-history-lesson-civilian-defense-and-volunteer-contributions-in-pascagoula-mississippi-world-war-ii-heritage-city.htm

51. **Chongqing Civilians and the 1941 Tunnel Tragedy**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 5 June 1941, Chongqing, China
On 5 June 1941, during a Japanese air raid, thousands of civilians crowded into the Jiaochangkou tunnel shelter in Chongqing. Poor ventilation and overcrowding led to mass suffocation, killing more than 2,000 people. The tragedy exposed the dangers of inadequate civilian protection and prompted changes in shelter management. Survivors and rescue workers struggled to aid the victims. The event is a stark example of how civilians faced not only enemy bombing but also the lethal consequences of flawed emergency infrastructure.
Source:
- Xinhua, “China Focus: China’s western metropolis preserves, reuses WWII shelters,” http://english.news.cn/20250731/faf0536eb918410e851c5a14b0347680/c.html

52. **Italian Women’s Union and Postwar Social Reconstruction**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1945–1950s, Italy
The Unione delle donne italiane (Italian Women’s Union) played a central role in postwar social reconstruction, including the “Trains of Happiness” and other welfare initiatives. Women activists organised assistance for poor families, children, and displaced people, and they pressed for social reforms. Their work built on wartime experiences of mutual aid and community organising. By mobilising women across class and political lines, the Union contributed to rebuilding social trust and institutions in a country emerging from occupation and civil conflict.
Source:
- Close Encounters in War, “‘I treni della felicità’: The Initiative that Saved Thousands of Italian Children and Contributed to Reconstructing the Socio-Political Fabric of the Country,” https://closeencountersinwar.org/2020/12/17/i-treni-della-felicita-the-initiative-that-saved-thousands-of-italian-children-and-contributed-to-reconstructing-the-socio-political-fabric-of-the-country/

53. **Malayan Civilians and the Grow More Food Campaign**
Pillar: 3 — Food, Scarcity, and Economic Survival | Time & place: 1942–1945, Malaya
Under Japanese occupation, the Grow More Food campaign encouraged civilians to cultivate tapioca, sweet potatoes, yams, and groundnuts to offset rice shortages. Radio programmes broadcast farming instructions, and a Malayan recipe book showed how to prepare food using tapioca and other native substitutes. Tapioca was especially popular because it grew in poor soil and matured in about three months. These campaigns reflect both official coercion and civilian adaptation to severe food scarcity.
Source:
- National Library Board Singapore, “Grow More Food Campaign,” https://eresources.nlb.gov.sg/infopedia/articles/SIP_2013-07-15_100431.html

54. **British Women’s Voluntary Service in Civilian Defence**
Pillar: 2 — Women, Children, and Civilian Contributions | Time & place: 1939–1945, United Kingdom
The Women’s Voluntary Service (WVS) mobilised hundreds of thousands of women for civilian defence and welfare tasks, including evacuating children, staffing rest centres, and providing emergency feeding during air raids. WVS volunteers worked alongside local authorities and the Red Cross, often improvising services in schools, halls, and church buildings. Their labour was essential to the daily functioning of the British home front. The WVS exemplifies how women’s unpaid and voluntary work sustained civilian communities under bombing and scarcity.
Source:
- The New York Times, “WOMEN GET WARNING ON DUTY FOR DEFENSE; Junior League Head Cites Tasks to ‘Keep Home Fires Burning’,” https://www.nytimes.com/1941/05/25/archives/women-get-warning-on-duty-for-defense-junior-league-head-cites.html

55. **Soviet Civilian Self-Defence and Firefighting Brigades**
Pillar: 7 — Civilian Protection, Rescue, and Emergency Response | Time & place: 1941–1944, Soviet Union
In Soviet cities exposed to bombing, civilians organised self-defence brigades and firefighting units. Residents, including women and teenagers, received basic training, patrolled rooftops, and extinguished incendiaries during air raids. These brigades formed part of the local air-defence system and worked alongside professional firefighters. While coordinated by the state, they relied on the courage and improvisation of ordinary people. Their efforts reduced fire damage and saved lives, demonstrating the civilian contribution to urban emergency response on the Eastern Front.
Source:
- Seventeen Moments in Soviet History, “A Teacher’s Diary,” https://soviethistory.msu.edu/1943/900-days/900-days-texts/blockade-diary/

56. **Postwar Reconstruction of Coventry’s City Centre**
Pillar: 8 — Recovery, Reconstruction, and Community Renewal | Time & place: 1940–1953, Coventry, United Kingdom
The reconstruction of Coventry’s city centre after the 1940 Blitz was a long-term project involving planners, local officials, and residents. Reconstruction planning began during the war, and debates over the city’s future continued into the 1950s. The process was shaped by competing visions of modernity, community, and memory. While often presented as a technical exercise, it also required public engagement and adjustment to the needs of a population recovering from wartime loss. Coventry’s experience illustrates the social dimensions of urban recovery.
Source:
- Tony Mason and Nick Tiratsoo, “People, politics and planning: the reconstruction of Coventry’s City Centre, 1940–53,” in *The Blitz and its Legacy* (Ashgate, 2013), https://www.routledge.com/The-Blitz-and-its-Legacy-Wartime-Destruction-to-Post-War-Reconstruction/Clapson-Larkham/p/book/9781409435891