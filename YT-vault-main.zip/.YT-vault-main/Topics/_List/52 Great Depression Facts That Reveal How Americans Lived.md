---
source: https://www.factretriever.com/great-depression-facts
---

# 52 Great Depression Facts That Reveal How Americans Lived


The Great Depression wasn't simply a stock market crash or a chapter in a history textbook. It was more than a decade of hardship that transformed nearly every aspect of American life. Millions of people lost their jobs, savings, homes, and farms almost overnight. Families stretched every dollar, children grew up without enough food, and entire communities struggled just to survive. Yet the Great Depression also reshaped the United States in lasting ways. It inspired sweeping government programs, changed how banks operate, influenced fashion and entertainment, and left behind unforgettable photographs and stories of resilience that still define the era today. These Great Depression facts explore the causes of the crisis, what everyday life was like, and how Americans endured one of the most difficult periods in modern history.

---

- ## Quick Great Depression Facts
    
    ### If you're looking for the highlights, here are some of the most important Great Depression facts:
    
    • The Great Depression began after the Wall Street Crash of October 1929.
    
    • Thousands of U.S. banks failed between 1930 and 1933.
    
    • The nation's economy shrank by nearly half during the worst years.
    
    • Millions of families lost their homes or farms.
    
    • Homeless communities became known as Hoovervilles.
    
    • The Dust Bowl forced hundreds of thousands of Americans to leave their farms.
    
    • Franklin D. Roosevelt introduced the New Deal to combat the crisis.
    
    • Social Security was created during the Great Depression.
    
    • About one in four American workers was unemployed at its peak.
    
    • Most historians agree that [World War II](https://www.factretriever.com/world-war-ii) finally brought the Depression to an end.[2]
- ## What Caused the Great Depression?
    
    Although the stock market crash is often blamed for the Great Depression, it was only one piece of a much larger economic collapse. Weak banks, easy credit, declining consumer spending, overproduction, falling farm prices, and disastrous public panic all combined to create a crisis unlike anything the United States had experienced before.
    
    The following facts explain how the Depression began, and why it lasted for more than a decade.[11]
- ### "Black Tuesday" Was Only Part of the Crash
    
    Many people remember Black Tuesday, but the stock market actually collapsed over several days. Panic selling began on Black Thursday (October 24, 1929), intensified on Black Monday, and reached its devastating climax on Black Tuesday, when billions of dollars in market value disappeared.[11]
- ### Herbert Hoover Thought the Worst Was Already Over
    
    Herbert Hoover (1874-1964), a [Republican](https://www.factretriever.com/republican-facts), was president when the Great Depression began. He infamously declared in March 1930 that the U.S. had “passed the worst” and argued that the economy would sort itself out. The worst, however, had just begun and would last until the outbreak of WWII (1939).[7]


Most of the Great Depression's economic damage was caused directly by bank runs

- ### Fear Spread Faster Than the Crash Itself
    
    As news of the stock market crash spread, customers rushed to their banks to withdraw their money, sparking disastrous “bank runs.” Nobel prize-winning economist Milton Friedman argues that the 1930s market crash itself did not cause the depression, but rather it was the collapse of the banking system during waves of public panic during 1930-1933.[1]
- ### Daily Life During the Great Depression
    
    Economic statistics only tell part of the story. For ordinary Americans, the Great Depression meant empty cupboards, unpaid bills, and constant uncertainty. Families developed remarkable ways to survive, often relying on neighbors, charities, or simple ingenuity.[7]
- ### One Out of Every Four Workers Lost Their Jobs
    
    During the worst years of the Great Depression, roughly 25 percent of Americans were unemployed. Millions more kept their jobs only by accepting shorter hours or lower wages, while the nation's economy contracted by nearly 50 percent before beginning a slow recovery.[5]
- ### Nearly Half of American Children Lacked Basic Necessities
    
    Historians estimate that almost 50 percent of children during the Great Depression did not have adequate food, housing, or medical care. Poor nutrition contributed to illnesses such as rickets, while many children grew up without proper shoes, warm clothing, or regular healthcare.[8]
- ### Hoovervilles Became Symbols of the Depression
    
    People who lost their homes often lived in what were called “Hoovervilles,” or shanty towns, that were named after President Herbert Hoover. There was also “Hoover Stew” (food dished out in soup kitchens), “Hoover Blankets” (newspapers that served as blankets), “Hoover Hogs” (jack rabbits used as food), and “Hoover Wagons” (broken cars that were pulled by mules).[4]
- ### Soup Kitchens Became Lifelines
    
    Long lines outside soup kitchens became one of the defining images of the Great Depression. Churches, charities, and local governments struggled to feed growing numbers of hungry families. Even Chicago gangster Al Capone opened a soup kitchen that served thousands of free meals each day, though many believed it was also an attempt to improve his public image.[4]
- ### People Ate Foods That Sound Strange Today
    
    Popular foods during the Great Depression include macaroni and cheese, chili, creamed chicken on a biscuit, and corned beef. Some of the stranger foods include prune pudding, peanut butter stuffed baked onions, spaghetti with boiled carrots and white sauce, and Mulligan stew flavored with tobacco.[8]
- ## Finding Joy During Hard Times
    
    ### Monopoly Became Popular During the Depression
    
    During the Great Depression, children played games such as Scrabble and Monopoly, which were first sold during the 1930s. Other popular games were pinochle, canasta, bridge, and whist.[4]
- The “Three Little Pigs“—released May 27, 1933, and produced by Walt Disney—was seen as symbolic of the Great Depression, with the wolf representing the Depression and the three little pigs representing average citizens who eventually succeeded by working together.[7]
- ### Miniature Golf Became a National Craze
    
    During the Great Depression, miniature golf was wildly popular for children and families because of low operating costs,[4]
- ### Families Gathered Around the Radio
    
    For entertainment, children and families often listened to the radio during the Great Depression. Nearly 40% of families owned a radio. Popular radio shows were Amos 'n' Andy, Burns and Allen, The Lone Ranger, Sherlock Holmes, Buck Rogers, and The Shadow.[4]
- ### Even Fashion Reflected the Economy
    
    A new look in women’s fashion emerged in the 1930s. In response to the economic crisis, designers created more affordable fashions with longer hemlines, slim waistlines, lower heels, and less makeup. Accessories became more important as they created the impression of a “new” look without having to buy a new dress.[7]
- Nearly 50% of children during the Great Depression did not have enough to eat, proper housing, or adequate health care.[4]
- ## The Human Cost of the Great Depression
    
    ### Nearly 750,000 Farms Were Lost
    
    Between 1930 and 1935, roughly 750,000 American farms were lost through bankruptcy or foreclosure. Falling crop prices left many farmers unable to pay their debts, forcing families off land they had worked for generations.[6]

The Dust Bowl affected over 100 million acres of land

- ### The Dust Bowl Forced Families to Flee
    
    Severe drought and dust storms exacerbated the Great Depression because it dried out farmlands and forced families to leave their farms. On May 9, 1934, a dust storm carried an estimated 350 million tons of dirt 2,000 miles east ward and dumped four million tons of prairie dirt in Chicago. The drought and dust killed tens of thousands of animals.[6]
- ### Some Farmers Held "Penny Auctions"
    
    During the Depression, distressed farms were sometimes sold at “Penny Auction” (forced auctions) in which farmers would assure that a distressed neighbor would be able to buy back his own farm by holding bids down to pennies, nickels, and quarters. They would dissuade those who wanted to make higher bids, sometimes symbolically with dangling nooses at the auction scene.[6]
- ### California Tried to Keep Migrants Out
    
    Californians tried to stop migrants from moving into their state by creating checkpoints on main highways called “bum blockades.” [California](https://www.factretriever.com/california-facts) even instated an “anti-Okie” law which punished anyone bringing in “indigents” with jail time.[6]
- ### Route 66 Became the Road to Hope
    
    During the Great Depression, hundreds of thousands of families traveled west on Route 66 to California, following what John Steinbeck in his famous novel The Grapes of Wrath called “The Mother Road.”d[6]


Over 210,000 people drove Route 66 to California seeking reprieve from the Dust Bowl, but only 8% of them remained in the Golden State

- ### Millions of Children Left School
    
    By the 1930s, thousands of schools were operating on reduced hours or were closed down entirely. Some three million children had left school, and at least 200,000 took to riding the rails.[8]
- ### Pack Horse Librarians Delivered Books on Horseback
    
    During the Great Depression, pack horse librarians were librarians who would ride horses to deliver library books to children.[9]
- ## Desperate Times Led to Creative Solutions
    
    ### Thousands Tried Selling Apples
    
    During the Great Depression, many people tried apple selling to avoid the shame of panhandling. In New York City alone, there were as many as 6,000 apple sellers.[7]
- ### Chain Letters Promised Instant Wealth
    
    Chain letters seemed to have first begun in 1935 as a get-rich-quick scheme. The source of the letters is unknown, but the letters became so popular that post offices around the nation had to hire extra help.[7]
- ### Some Families Survived on Wild Plants
    
    In the mountain communities of Appalachia, whole families were reduced to dandelions and blackberries for their basic diet. Some children were so hungry, they chewed on their own hands.[8]
- ### One Rancher Destroyed His Own Sheep
    
    One American sheep farmer found that he would not make money off of his sheep during the depression. Rather than watch his 3,000 sheep starve to death, he cut their throats and threw them in a canyon.[6]
- ### Mexican Americans Faced Forced Repatriation
    
    When the Depression struck, Mexican-Americans were accused of taking jobs away from “real” Americans and of unfairly burdening local relief efforts. Some were “encouraged” to return to Mexico.[11]

By 1932, approximately half of African-Americans were out of work

- ### African Americans Were Hit Especially Hard
    
    The Great Depression affected nearly every American, but African Americans often suffered disproportionately. By 1932, roughly half of Black workers were unemployed, and many were the first to lose their jobs when businesses cut staff.[4]
- ### Women Also Faced Workplace Discrimination
    
    During the Depression, many people believed jobs should be reserved for men who were considered the primary breadwinners. As a result, women frequently faced discrimination in hiring and were criticized simply for remaining employed while so many men were out of work.[7]
- ### Families Changed Forever
    
    Economic hardship reshaped American families. Marriage and birth rates declined as couples delayed starting families, while divorce rates fell because many people could not afford to separate. Some fathers left home in search of work and never returned. A 1940 survey estimated that 1.5 million married women had been abandoned by their husbands.[8]


Franklin Delano Roosevelt led the nation through the Great Depression

- ## The New Deal and America's Recovery
    
    ### Franklin D. Roosevelt Promised Americans a "New Deal"
    
    Democrat Franklin Delano Roosevelt (1882-1945) became president in March 1933 and promised a “New Deal for the American people.” During his first hundred days, he attempted to create jobs by establishing federal organizations that were nicknamed “Alphabet Agencies,” such as the TVA, NRA, CCC, and WPA. Economists and historians continue to debate whether Roosevelt’s actions actually deepened and lengthened the Depression.[11]
- ### Social Security Was Born During the Great Depression
    
    One of the New Deal's most lasting achievements was the Social Security Act, signed into law on August 14, 1935. The program created a financial safety net for older Americans and has since expanded to provide benefits for millions of retirees, people with disabilities, and surviving family members.[7]
- ### The Bonus Army's Protest Ended in Violence
    
    In 1932, thousands of World War I veterans traveled to Washington, D.C., demanding early payment of bonuses they had been promised for their military service. When negotiations failed, federal troops were ordered to remove the protesters. The violent eviction shocked many Americans and further damaged President Herbert Hoover's public image.[4]
- ### John Maynard Keynes Changed Economic Thinking
    
    British economist John Maynard Keynes argued that governments should spend money during economic downturns to stimulate demand and create jobs. His ideas gained widespread attention during the Great Depression and continue to influence economic policy around the world.[11]
- ## The Great Depression Changed America Forever
    
    ### One Photograph Became the Face of the Great Depression
    
    In 1936, photographer Dorothea Lange captured her now-famous image Migrant Mother, showing Florence Owens Thompson surrounded by her children in a California labor camp. The photograph became one of the most recognizable images in American history and helped draw national attention to the struggles of migrant families during the Depression.[4]

Lange captured this now iconic image of a mother of seven children during the Great Depression

- ### The Great Depression Changed the American Family
    
    Economic hardship led many couples to postpone marriage and delay having children. Birth rates declined, divorce rates fell, and countless families moved in with relatives to survive. Financial pressures also caused some parents to leave home in search of work, sometimes never returning.[7]
- ### Native Americans Continued to Struggle
    
    In spite of the New Deal and the “Indian New Deal” of 1934, most Native Americans remained bitterly poor during the Great Depression. The “Indian New Deal” (which was also called the Indian Reorganization Act) was a complex and multi-faceted legislation which reversed the Dawes Severalty Act of 1887 and granted tribes more autonomy.[4]
- ### The Hawley-Smoot Tariff Made the Crisis Worse
    
    The Hawley-Smoot Tariff Act of 1930 sharply increased tariffs on imported goods. Other countries responded with tariffs of their own, reducing international trade and worsening the global economic downturn. Many historians consider the law one of the Depression's most damaging policy mistakes.[1][7]
- ### Nearly Every Major Nation Abandoned the Gold Standard
    
    During the Depression, countries around the world stopped tying their currencies directly to [gold](https://www.factretriever.com/gold-facts). Nations that abandoned the gold standard earlier generally recovered more quickly, while those that remained on it often experienced longer economic downturns.[2]
- ### Some Americans Actually Avoided the Worst Hardships
    
    Although the Depression devastated millions of families, historians estimate that up to 40 percent of Americans never experienced severe financial hardship. Stable employment, savings, or living in less-affected regions helped some households weather the crisis better than others.[7]
- ### The Stock Market Needed 25 Years to Recover
    
    Between 1929 and 1933, the U.S. stock market lost about 90 percent of its value. It would take approximately 25 years before the market finally returned to its pre-crash levels.[3]
- ### The average family income dropped about 40% during the Great Depression.
    
    As businesses closed and unemployment rose, the average American family's income dropped by roughly 40 percent, forcing millions to make difficult choices about food, housing, healthcare, and education.[3]
- ## Lasting Legacy
    
    ### The Empire State Building Opened During the Depression
    
    Despite the economic collapse, several iconic construction projects moved forward. The Empire State Building, completed in 1931, and the Golden Gate Bridge, completed in 1937, provided thousands of jobs while becoming enduring symbols of American ambition.[7]
- ### Crime Increased During the Depression
    
    Economic desperation contributed to a rise in crime during the 1930s. Notorious criminals such as John Dillinger, Bonnie and Clyde, Pretty Boy Floyd, and Machine Gun Kelly became national celebrities through sensational newspaper coverage, even though many law-abiding Americans viewed them as dangerous rather than heroic.[4]
- ### World War II Finally Ended the Great Depression
    
    While New Deal programs eased suffering and reduced unemployment, most historians agree that the massive industrial production required during World War II finally restored full employment and brought the Great Depression to an end.[7]
- ## Other Interesting Great Depression Facts
    
    The board game Monopoly, which first became available in 1935, became immensely popular perhaps because players could become rich, at least in their imagination.[7]
- Some people who became homeless would ride on railroad cars because they didn’t have money to travel. Some famous men who rode the rails were William O. Douglas (1898-1980), U.S. Supreme Court Justice from 1939-1975; novelist Louis L’Amour (1908-1988); and folk singer Woody Guthrie (1912-1967). Some scholars claim that more than 50,000 people were injured or killed while jumping trains.[7]
![Facts about the Great Depression and infographic](https://d3jkudlc7u70kh.cloudfront.net/interesting-great-depression-infographic.png)

Everything you wanted to know about the Great Depression in one infographic, including important dates, lasting legacies, and more.

- During the Great Depression, a record 60-80 million Americans went to the movies every week. One of the biggest blockbusters was Merian C. Cooper’s 1933 King Kong. Other popular movies included The Wizard of Oz (1939) and Gone with the Wind (1939).[4]
- As the Great Depression continued year after year, it was not uncommon to see children with severe teeth decay.[9]
- Curious to learn more? Browse our [Interesting Facts](https://www.factretriever.com/interesting-facts) hub.[10]

|   |   |
|---|---|
|Great Depression Timeline<br><br>![](https://d3jkudlc7u70kh.cloudfront.net/resources/images/blank.png)|   |
|Year|Event|
|1929|Stock market crashes|
|1930–1933|Thousands of banks fail|
|1932|Bonus Army protests in Washington|
|1933|Franklin D. Roosevelt takes office; New Deal begins|
|1935|Social Security Act signed|
|1939|World War II begins in Europe|
|1941|U.S. enters World War II; unemployment rapidly declines|
