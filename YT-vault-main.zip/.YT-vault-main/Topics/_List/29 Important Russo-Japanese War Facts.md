---
source: https://www.factretriever.com/russo-japanese-war-facts
---
# 29 Important Russo-Japanese War Facts


- Some historians refer to the Russo-Japanese War as World War Zero, as it was a large-scale conflict just a decade prior to World War I.[2]
- The Russo-Japanese War began on February 8, 1904, when [Japan](https://www.factretriever.com/japan-facts) staged a surprise attack on the Russian navy at Port Arthur in [China](https://www.factretriever.com/china-facts).[1]
- The Russo-Japanese War was the result of an attempt by [Russia](https://www.factretriever.com/russia-facts) to obtain two Asian ports for use in Pacific trade and of Japan’s opposition to greater Russian control in the area.[2]
- Much of the actual fighting in the war occurred in what is now Northeastern China.[2]
- United States President Teddy Roosevelt was awarded the Nobel Peace Prize for mediating the treaty between Russia and Japan that ended the war.[2]
- In 1904, when the Russo-Japanese War began, Russia was one of the largest territorial powers in the world.[2]
![Russian Imperalism](https://d3jkudlc7u70kh.cloudfront.net/russo-japanese-war-causes.jpg)

The clash of Russian and Japanese ambitions caused the war

- It is estimated that 20,000 Chinese civilians were killed during the course of the war—largely at the hands of Russian troops, who looted several villages as they passed through Manchuria.[2]
- The many humiliating defeats suffered by Russia during the war, under the leadership of Tzar Nicholas II, were one cause of the political dissent and anti-tzarist sentiments that ultimately led to the communist revolution in Russia.[2]
- Although Japan won the Russo-Japanese War, mediator Teddy Roosevelt sided with Russia in a refusal to pay any reparations to Japan, resulting in several days of anti-American rioting in Tokyo.[2]
- Originally intimidated by Russia’s military aggressiveness, Japan attempted to negotiate with Russia before declaring war, but Tzar Nicholas’ advisers didn’t believe Japan would actually attack and counseled him not to enter into negotiations.[2]
- The war was ended by the Treaty of Portsmouth, named for Portsmouth, New Hampshire, where the treaty was signed.[2]
- The Russo-Japanese War was the first time in modern history that a European nation was defeated in combat by an Asian nation.[2]
![Tsar Nicholas War](https://d3jkudlc7u70kh.cloudfront.net/russian-japanese-war-tsar.jpg)

This satirical Japanese woodcut depicts Tzar Nicholas awakening from a nightmare to see his troops retreating

- The Russo-Japanese War was fought under Tzar Nichols II, the last tzar ever to rule Russia.[2]
- Although most of the Russo-Japanese War was fought in China, this was done without China’s consent.[4]
- At the end of the war, Japan annexed Korea, and Manchuria was divided up between Japan and Russia, leading to a great deal of anti-Japanese sentiment in Korea and China, who viewed Japan as being just as imperialistic as European powers.[4]
- The Russo-Japanese War was the first war in which machine guns and trench warfare were used.[3]
- The Russo-Japanese War—fought between two naval powers—was the first time torpedoes were used in battle.[3]
- It is believed that Emperor Meiji of Japan experienced so much stress during the Russo-Japanese War that it was one of the causes of the poor health that overtook him afterwards.[3]
- Japan made good use of secret agents during the Russo-Japanese War. One captain in the Imperial Japanese Army successfully pretended to be a hairdresser in China to gather information.[3]
- The Russo-Japanese War was unusual in that both sides treated all of the over 80,000 men who were taken as prisoners of war fairly and humanely.[3]
![Japanese Russian War](https://d3jkudlc7u70kh.cloudfront.net/japanese-army-russian-war.jpg)

The war was a nationalistic victory for Japan and a huge blow to Russian pride

- The victory of Japan over Russia in the Russo-Japanese War resulted in a birth of nationalistic feeling among nations like India, who were subject to other European imperialist powers.[3]
- During the war, Russia attempted to dissuade the Japanese from approaching their forces by the Yalu River by spreading the false rumor that they had the technology to set the river entirely on fire.[3]
- The Russo-Japanese War was the inspiration for a new convention requiring a declaration of war before an attack. Japan started the Russo-Japanese War by simply attacking a Russian port (something the Japanese would do again in their attack on Pearl Harbor in WWII).[3]
- The Hague Peace Conference of 1907 was largely focused on questions of naval warfare that had arisen due to the practices of Japan and Russia during the Russo-Japanese War.[3]
- Due to their dismal performance in gaining military intelligence during the War, the Russian government entirely reorganized their intelligence-gathering branch immediately after the war.[3]
- Russia and other world powers thought that victory was assured, but Japan defeated them in less than 18 months.[3]
![Russo-Japanese War](https://d3jkudlc7u70kh.cloudfront.net/battles-russia-japan.jpg)

The war was swift and decisive

- During the war, Russia laid a total of 4,275 naval mines. Russia’s mines sank more Japanese warships than any other weapon used by the Russian navy.[3]
- Although the war lasted for less than 18 months, Japan captured over 79,000 Russian prisoners of war; Russia, on the other hand, only took 2,000 Japanese POWs. Some scholars suggest the difference in numbers might be due to the Japanese Bushido code of honor, which mandated suicide rather than surrender.[3]
- The final land battle of the Russo-Japanese War was the battle of Mukden, fought in February and March of 1905. There were roughly 89,000 Russian casualities and 71,000 Japanese casualties.[1]