---
title: "73 Interesting Facts about World War II"
source: "https://www.factretriever.com/world-war-ii"
---
# 73 Interesting Facts about World War II

## Human Cost & Atrocities

### The Soviet Union Lost More Than 21 Million People

No nation suffered more during WWII than the Soviet Union. Entire cities were destroyed, millions starved, and countless civilians died in some of the war’s most brutal battles. 2.

### More People Died During The Siege Of Leningrad Than America And Britain Lost In The Entire War

For nearly 900 days, civilians survived starvation, freezing temperatures, and constant bombardment. 3.

### Anne Frank Died Just Weeks Before Liberation

After surviving years in hiding, Anne Frank died of typhus at Bergen-Belsen only weeks before Allied forces arrived. 4.

### Nazi Doctors Performed Horrific Human Experiments

Prisoners were frozen, infected with diseases, sterilized, and mutilated in concentration camp experiments. 5.

### The Nazis Kidnapped Children To “Germanize” Them

They thought that some Polish babies and children looked German and kidnapped about 50,000 of them. 6.

### Einsatzgruppen Death Squads Murdered Entire Communities

These mobile killing units followed German armies across Eastern Europe, carrying out mass shootings. 7.

### Josef Mengele Performed Horrific Experiments On Children

At Auschwitz, Nazi doctor Josef Mengele used thousands of twins, many of them Jewish and Romani children, in cruel medical experiments. Victims were subjected to painful procedures, injections, and genetic testing in attempts to study heredity and human manipulation. Only a small fraction survived. 8.

### The Auschwitz Concentration Camp Complex was the Only Camp To Tattoo Prisoners

The practice began in 1941 when Russian POWs were stamped on the upper-left breast. Jews started receiving tattoos (on their forearms) in 1942. 9.

### The Holocaust Murdered Around Six Million Jews

The Nazis murdered approximately 12 million people, nearly 6 million of those being Jews killed in the Holocaust (“whole burnt”). 10.

### Sonderkommando Prisoners Were Forced To Dispose Of Victims’ Bodies

Special prisoner units known as the Sonderkommando were forced by the Nazis to remove bodies from gas chambers and cremate them. Most were later killed to eliminate witnesses, and only a small number survived the war. Some secretly buried written testimonies that were discovered after liberation. 11.

### The “Beast of Belsen” Claimed He Felt No Remorse

Joseph Kramer, commandant of Bergen-Belsen, was known for overseeing the camp during its horrific conditions. After the war, he was asked about his actions and reportedly said he felt no remorse, claiming he was simply following orders. He was later executed for crimes against humanity. 12.

### Allied Soldiers Could Barely Believe What They Saw In Liberated Camps

Even after the Allies arrived, many concentration camp prisoners were beyond help. In Bergen-Belsen, for example, 13,000 prisoners died after liberation. Nearly 2,500 of the 33,000 survivors of Dachau died within six weeks of liberation. 13.

### The T-4 Program Was A Nazi “Euthanasia” Killing Operation

From 1939, Nazi Germany’s T-4 program, based in Berlin at Tiergartenstraße 4, systematically murdered tens of thousands of disabled and mentally ill people and helped lay the groundwork for later mass killings. 14. It is estimated that 1.5 million children died during the Holocaust. Approximately 1.2 million of them were Jewish and tens of thousands were Gypsies. 15.

## Strange & Unbelievable WWII Facts

### A Japanese Soldier Kept Fighting Until 1974

In 1974, a Japanese soldier named Hiroo Onoda (1922- ) came out of the jungle of the Pacific island of Lubang. He had been hiding there for 29 years, unaware that his country had surrendered. 16.

### Japan Sent Balloon Bombs Across The Pacific

During WWII, the Japanese launched 9,000 “wind ship weapons” of paper and rubberized-silk balloons that carried incendiary and anti-personnel bombs to the U.S. More than 1,000 balloons hit their targets and they reached as far east as Michigan. The only deaths resulting from a balloon bomb were six Americans (including five children and a pregnant woman) on a picnic in Oregon. 17.

### The Swastika Existed Thousands Of Years Before Hitler

Long before the Nazis adopted it, the swastika was an ancient religious symbol associated with good fortune, spirituality, and prosperity. Versions of the symbol have appeared in cultures across India, China, Greece, and other ancient civilizations for thousands of years. 18.

### “Nazi” Originally Began As An Insult

The Nazi Party’s original abbreviation was “Nasos” for National Socialists. The term “Nazi” was initially used mockingly and came from a Bavarian slang word associated with someone seen as simple-minded or foolish. 19.

### Roosevelt Rode In Al Capone’s Armored Car

After the sneak attack at Pearl Harbor, President Roosevelt searched for a bulletproof car. However, because government regulation prohibited spending more than $750 to buy a car, the only one they could find was Al Capone’s limo, which had been seized by the Treasury Department after he was arrested for tax evasion. FDR said, “I hope Mr. Capone won’t mind.” 20.

### Hitler’s Nephew Served In The U.S. Navy

William Hitler, a nephew of Adolf Hitler, was in the U.S. Navy during WWII. He changed his name after the war. 21.

### A 12-Year-Old Boy Fought In The U.S. Navy

Calvin Graham lied about his age and earned military honors before officials discovered the truth. 22.

### The Nazis Operated A Wiretapped Spy Brothel

The salon was wiretapped, and 20 prostitutes underwent several weeks of intense indoctrination and training. They were specifically trained to glean information from diplomats and foreign visitors through seemingly innocuous conversations. 23.

### Americans Renamed Hamburgers “Liberty Steaks”

Anti-German sentiment affected everyday language and culture during the war. 24.

### Hitler Rose From Fringe Politician To Dictator In About A Decade

In the 1928 elections, less than 3% of Germans voted for the Nazi party. In 1938, Hitler was Time magazine’s man of the year. 25.

### The Real James Bond Was Inspired By A WWII Spy

Dusko Popov’s glamorous espionage career reportedly helped inspire Ian Fleming’s famous character. 26.

## Battles & Military History

### The Battle Of Stalingrad Became One Of History’s Bloodiest Battles

Many historians believe that the Battle at Stalingrad (1942-1943) is not only arguably the bloodiest battle in history with up two million casualties, but also the turning point of WWII in Europe. 27.

### The Longest Battle Of WWII Lasted Nearly Six Years

The Battle of the Atlantic stretched from 1939 until Germany’s defeat in 1945. 28.

### The Largest Tank Battle In History Happened At Kursk

The greatest tank battle in history occurred between the Germans and Russians at the Kursk salient in Russia from July 4-22, 1943. 29.

### The Japanese Kamikaze (“divine wind”) Deliberately Crashed Into Ships

The tactic was suggested on October 19, 1944, by Vice-Admiral Onishi in an attempt to balance the technological advantage of invading American forces. Though the numbers are disputed, approximately 2,800 kamikaze pilots died. They sunk 34 U.S. ships, damaged 368, killed 4,900 sailors, and wounded 4,800. 30.

### German U-Boats Nearly Starved Britain

Submarines hunted Allied shipping relentlessly across the Atlantic. 31.

### Most German Submarine Sailors Never Returned Home

Out of the 40,000 men who served on U-boats during WWII, only 10,000 returned. 32.

### WWII Officially Ended Aboard The USS Missouri

Japan formally surrendered in Tokyo Bay on September 2, 1945. 33.

## Technology, Weapons & Science

### The Navajo Code Talkers Created An Unbreakable Code

From 1942, U.S. Marines in the Pacific used the Navajo language as their secret code. The language didn’t have the vocabulary for existing WWII technology, so existing words had to be given new meanings. For example, the word for “hummingbird” (da-he-ti-hi) became code for fighter plane. Around 400 Navajo Indians (Code Talkers) were trained to use the code, and the Japanese never cracked it. 34.

### The Katyusha Rocket Launcher Terrified German Troops

First used in 1941, the Soviet Katyusha could fire massive rocket salvos in seconds, saturating entire battlefields and creating a powerful psychological effect on enemy forces. 35.

### Radar Began As A Failed “Death Ray”

In 1935, British engineer Robert Watson-Watt was working on a “death ray” that would destroy enemy aircraft using radio waves. His “death ray” instead evolved into radar, or “radio detection and ranging.” 36.

### Germany Introduced Jet Fighters Too Late To Change The War

The Messerschmitt Me-262 was years ahead of its time. 37.

### Chemical Weapons Were Rarely Used In Combat During WWII

Poison gas was first used on a large scale in World War I, breaking the stalemate of trench warfare. Although many nations stockpiled chemical weapons during WWII, their battlefield use was rare. Italy used gas in Ethiopia, and Japan used chemical weapons in China. 38.

### The Soviets Were Early Leaders In Paratrooper Warfare

The Soviet Union began experimenting with large-scale paratrooper forces in the early 1930s, years before Britain and other Allied powers developed their own airborne units. 39.

### Britain Defended Cities With Giant Steel-Cabled Balloons

Barrage balloons floated over British cities during WWII, forcing enemy bombers to fly higher and making their attacks less accurate. 40.

### Stuka Dive Bombers Used Sirens To Terrorize Civilians

As part of Germany’s Blitzkrieg tactics, Junkers Ju 87 Stuka dive bombers were fitted with sirens that produced a screaming sound during attacks, designed to spread panic as well as destruction. 41.

### Germany Built The World’s First Ballistic Missiles

V-2 rockets traveled faster than sound and struck targets without warning. 42.

### The Enigma Machine Was Critical To Germany’s War Effort

Allied codebreakers eventually cracked its encrypted communications. 43.

### The Manhattan Project Was One Of History’s Most Secret Programs

Thousands worked on the atomic bomb without fully understanding the project. 44.

## Atomic Bombs & Nuclear Horror

### Survivors Of Both Atomic Bombings Have A Special Name

They are called niju hibakusha, which literally means “explosion-affected people.” 45.

### Flowers Bloomed Again In Hiroshima After The Bombing

The oleander is the official flower of the city of Hiroshima because it was the first to bloom again after the explosion of the atomic bomb in 1945. 46.

### Tokyo Might Have Been The Third Atomic Bomb Target

Japan surrendered before another bomb could be used. 47.

### The Enola Gay became well known for dropping the first atomic bomb on Hiroshima

However, few people know the name of the B-29 that bombed Nagasaki. It was Bock’s Car, named after the plane’s usual commander, Frederick Bock. 48.

## Resistance, Courage & Survival

### Denmark Helped Save Nearly Its Entire Jewish Population

Thousands escaped to neutral Sweden with help from ordinary citizens. 49.

### WWII Accelerated Medical Innovation

Advances in blood transfusions, antibiotics, and trauma care saved countless lives. The most important medical advance that saved soldiers’ lives during WWII was the blood transfusion. 50.

### The Japanese-American 442nd Became Legendary

The most decorated unit ever in U.S. history is the 442nd regimental Combat Team, whose motto was “Go for Broke.” It consisted of Japanese-American volunteers. Together they won 4,667 major medals, awards, and citations, including 560 Silver Stars (28 of which had oak-leaf clusters), 4,000 Bronze Stars, 52 Distinguished Service Crosses, and one Medal of Honor, plus 54 other decorations. It also held the distinction of never having a case of desertion. 51.

### Millions Of Women Entered Wartime Industries

Factories, shipyards, and military support systems depended heavily on women workers. . 52.

### WWII Changed Women’s Roles Forever

The war permanently transformed expectations around women and work. 54.

## Political & Global Consequences

### WWII Destroyed Europe’s Position As Global Superpower

The United States and Soviet Union emerged dominant after Europe’s devastation. 55.

### Germany’s Defeat In WWI Helped Fuel WWII

Economic collapse and resentment after the Treaty of Versailles contributed to Hitler’s rise. 56.

### WWII Created One Of The Largest Refugee Crises In History

Millions fled advancing armies, destroyed cities, and collapsing governments. 57.

### Most WWII Casualties Were Civilians

Women and children made up enormous portions of the dead. 58.

### WWII Was The Deadliest Conflict In Human History

World War II was the most destructive conflict in history. It cost more money, damaged more property, killed more people, and caused more far-reaching changes than any other war in history. An estimated 50-70 million people died. 59.

### The War Reshaped The Entire Modern World

The Cold War, United Nations, nuclear age, and modern intelligence systems all emerged from WWII. 60.

### Erich Hartmann Became The Most Successful Fighter Ace In History

Nicknamed the “Blond Knight,” German pilot Erich Hartmann is credited with 352 aerial victories, the highest number achieved by any fighter pilot in recorded history. 61.

### Several Famous Actors Served In Combat During WWII

Before their film careers, several actors served in WWII combat roles. Henry Fonda served in the Pacific, David Niven fought in the British Army, and Christopher Lee served in RAF operations during the war. 62.

### Hollywood’s Biggest WWII Star Never Went To War

John Wayne became famous for WWII and military films, but he never served in the war due to a football injury that disqualified him from military service. 63.

### Hitler Admired Henry Ford

Adolf Hitler kept a framed photo of Henry Ford on his desk and praised him in Mein Kampf. Ford’s anti-Semitic writings were widely circulated in Germany and are believed to have influenced Nazi ideology. 64.

### Eddie Slovik Was The Only American Soldier Executed For Desertion In WWII

On January 31, 1945, Private Eddie Slovik was executed by firing squad for desertion, the only U.S. soldier to be executed for this crime during World War II and the first since the Civil War. 65.

### A Gardening Expert Helped Design WWII Camouflage

A Better Homes and Gardens editor played a role in developing camouflage patterns for the U.S. military during WWII, using his expertise in natural color and concealment. 66.

### Some Soviet POW Camps Had Mortality Rates As High As 85%

Many prisoners held in Soviet camps during WWII died from starvation, disease, and harsh conditions, with some camps experiencing extremely high death rates. 67.

### The Nazis Once Planned To Deport Europe’s Jews To Madagascar

Before turning to mass extermination, Nazi officials considered a plan to forcibly relocate Europe’s Jewish population to the island of Madagascar. The proposal was never implemented. 68.

### The Worst Naval Disaster In U.S. History Ended In A Controversial Court-Martial

After the USS Indianapolis was sunk by a Japanese submarine in 1945, hundreds of sailors died at sea. Captain Charles McVay was later court-martialed, the only U.S. Navy officer ever punished for losing a ship in wartime. 69.

### Rudolf Hess Was One Of The Last Prisoners Held In The Tower Of London

In 1941, Adolf Hitler’s deputy Rudolf Hess was briefly held and interrogated in the Tower of London after flying to Scotland on a secret mission. He was among the last high-profile detainees ever held there. 70.

### Nazi Germany Promoted The Idea Of The “People’s Car”

The Volkswagen began as a Nazi-era initiative to produce an affordable car for ordinary Germans, with the name literally meaning “people’s car.” 71.

### Germany Declared War On The United States Days After Pearl Harbor

After Japan attacked Pearl Harbor on December 7, 1941, the United States declared war on Japan on December 8. On December 11, Nazi Germany unexpectedly declared war on the United States, a move that brought America fully into the European war. 72.

### Nazi Book Burnings Targeted Famous Authors In 1933

Nazi-led book burnings destroyed works by writers including Einstein, Freud, and H.G. Wells, as part of a campaign against “un-German” ideas. More than a century earlier, poet Heinrich Heine warned: “Where one burns books, one will, in the end, burn people.” 73.

### Rudolf Hess Parachuted Into Scotland On A Self-Declared Peace Mission

On May 10, 1941, Adolf Hitler’s deputy Rudolf Hess flew alone to Scotland and parachuted into the countryside in an attempt to negotiate peace with Britain. British authorities deemed him mentally unstable. After the war, he was tried at Nuremberg and sentenced to life imprisonment. 75.

### A Nazi Collaborator’s Name Became A Word For “Traitor”

Vidkun Quisling’s collaboration with Nazi Germany was so notorious that his name became a synonym for “traitor” in the Norwegian language.