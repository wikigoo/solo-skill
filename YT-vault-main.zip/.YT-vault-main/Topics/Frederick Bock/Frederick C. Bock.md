---
title: "Frederick C. Bock"
source: "https://en.wikipedia.org/wiki/Frederick_C._Bock"
---
![](https://en.wikipedia.org/wiki/File:Atomic_cloud_over_Nagasaki_from_Koyagi-jima.jpeg)

Cloud over Nagasaki following the atomic blast

**Frederick Carl Bock Jr** (18 January 1918 – 25 August 2000) was an American bomber pilot during [World War II](https://en.wikipedia.org/wiki/World_War_II "World War II") who took part in the atomic bombing of [Nagasaki](https://en.wikipedia.org/wiki/Nagasaki,_Nagasaki "Nagasaki, Nagasaki") in 1945.

Bock attended the [University of Chicago](https://en.wikipedia.org/wiki/University_of_Chicago "University of Chicago") and went on to enroll in a graduate course in [philosophy](https://en.wikipedia.org/wiki/Philosophy "Philosophy").[^1]

## Early life and education

## World War II

Upon the entry of the United States into World War II, Bock enlisted in the [Army Air Forces](https://en.wikipedia.org/wiki/United_States_Army_Air_Forces "United States Army Air Forces"), becoming a pilot.[^1] Bock flew missions from [India](https://en.wikipedia.org/wiki/India "India") to [China](https://en.wikipedia.org/wiki/China "China") over the [Himalayas](https://en.wikipedia.org/wiki/Himalayas "Himalayas"), a route known as [the Hump](https://en.wikipedia.org/wiki/The_Hump "The Hump"). He also participated in air raids on [Japan](https://en.wikipedia.org/wiki/Japan "Japan") flown from China.[^1]

### Nagasaki atomic bomb raid

On the Nagasaki Raid, Bock flew the [B-29](https://en.wikipedia.org/wiki/B-29_Superfortress "B-29 Superfortress") bomber *[The Great Artiste](https://en.wikipedia.org/wiki/The_Great_Artiste "The Great Artiste")*, which was used for scientific measurements and [photography](https://en.wikipedia.org/wiki/Photography "Photography") of the effects caused by the nuclear weapon.[^1]

The bomber that actually dropped [Fat Man](https://en.wikipedia.org/wiki/Fat_Man "Fat Man") was called *[Bockscar](https://en.wikipedia.org/wiki/Bockscar "Bockscar"),*[^2] an aircraft named for and usually flown by Bock. The staff was swapped just before the raid, and Major [Charles Sweeney](https://en.wikipedia.org/wiki/Charles_Sweeney "Charles Sweeney") piloted *Bockscar*, which flew with *The Great Artiste* and another aircraft.

[William L. Laurence](https://en.wikipedia.org/wiki/William_L._Laurence "William L. Laurence"), a science writer with the *[New York Times](https://en.wikipedia.org/wiki/The_New_York_Times "The New York Times"),* was a civilian observer aboard *The Great Artiste.* His account of the mission was awarded the 1946 [Pulitzer Prize](https://en.wikipedia.org/wiki/Pulitzer_Prize "Pulitzer Prize").[^1] In his book, *Dawn Over Zero* (Knopf 1946), Laurence describes the scene aboard the B-29:[^1]

> I watched Capt. Frederick C. Bock, the pilot of our ship, went through the intricate motions of lifting a B-29 off the ground and marveled at the quiet efficiency of this Michigan boy who had majored in philosophy at Chicago University... I talked to him on the ground, and I was amazed at the transformation that had taken place. Man and machine had become one, a modern centaur.

— William L. Laurence, Dawn Over Zero (1946)

Bock rose to the rank of major and received the [Distinguished Flying Cross](https://en.wikipedia.org/wiki/Distinguished_Flying_Cross_\(United_States\) "Distinguished Flying Cross (United States)") and the [Air Medal](https://en.wikipedia.org/wiki/Air_Medal "Air Medal").[^1]

## Post-war career

After the war, Bock returned to [Chicago](https://en.wikipedia.org/wiki/Chicago "Chicago"), where he earned his [PhD](https://en.wikipedia.org/wiki/Doctor_of_Philosophy "Doctor of Philosophy") in [zoology](https://en.wikipedia.org/wiki/Zoology "Zoology"), with a specialisation in mathematical statistics and [genetics](https://en.wikipedia.org/wiki/Genetics "Genetics").[^1] Working in Chicago-based research laboratories, Dr. Bock created [algorithms](https://en.wikipedia.org/wiki/Algorithm "Algorithm") for solving complex problems.[^1] At [Baxter Travenol](https://en.wikipedia.org/wiki/Baxter_International "Baxter International") Laboratories, he devised a mathematical model for [peritoneal dialysis](https://en.wikipedia.org/wiki/Peritoneal_dialysis "Peritoneal dialysis").[^1] Dr. Bock retired from Baxter Travenol in 1986.

A native of [Greenville, Michigan](https://en.wikipedia.org/wiki/Greenville,_Michigan "Greenville, Michigan"), Bock died at his [Arizona](https://en.wikipedia.org/wiki/Arizona "Arizona") home in 2000 of cancer.[^1]

## References

[^1]: Saxon, Wolfgang (29 August 2000). ["F. C. Bock, 82, Monitor of Nagasaki Bombing"](https://www.nytimes.com/2000/08/29/us/f-c-bock-82-monitor-of-nagasaki-bombing.html). *The New York Times*. Retrieved 28 April 2018.

[^2]: [USAF Museum – Bockscar Story](http://www.nationalmuseum.af.mil/factsheets/factsheet.asp?id=2546) [Archived](https://web.archive.org/web/20071117185238/http://www.nationalmuseum.af.mil/factsheets/factsheet.asp?id=2546) 2007-11-17 at the [Wayback Machine](https://en.wikipedia.org/wiki/Wayback_Machine "Wayback Machine") Fact Sheet