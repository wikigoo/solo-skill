---
title: "Frederick C. Bock Facts for Kids"
source: "https://kids.kiddle.co/Frederick_C._Bock"
---
[Kids Encyclopedia Facts](https://kids.kiddle.co/)Frederick Carl Bock Jr. (born January 18, 1918 – died August 25, 2000) was an American pilot during [World War II](https://kids.kiddle.co/World_War_II "World War II"). He flew a bomber plane and was part of the mission that dropped an atomic bomb on [Nagasaki](https://kids.kiddle.co/Nagasaki "Nagasaki"), Japan, in 1945.

Before the war, Bock studied at the [University of Chicago](https://kids.kiddle.co/University_of_Chicago "University of Chicago"). He also took advanced classes in [philosophy](https://kids.kiddle.co/Philosophy "Philosophy").

## Frederick Bock's Role in World War II

When the United States joined [World War II](https://kids.kiddle.co/World_War_II "World War II"), Frederick Bock joined the [Army Air Force](https://kids.kiddle.co/United_States_Air_Force "United States Air Force"). He became a pilot.

Bock flew many missions from [India](https://kids.kiddle.co/India "India") to [China](https://kids.kiddle.co/China "China"). This route went over the [Himalayas](https://kids.kiddle.co/Himalayas "Himalayas") mountains. It was known as " [the Hump](https://kids.kiddle.co/The_Hump "The Hump") " because it was so difficult to fly over. He also took part in air attacks on [Japan](https://kids.kiddle.co/Japan "Japan") that started from China.

### The Nagasaki Atomic Bomb Mission

During the Nagasaki mission, Bock piloted a [B-29](https://kids.kiddle.co/Boeing_B-29_Superfortress "Boeing B-29 Superfortress") bomber called *The Great Artiste*. This plane was used to measure scientific data. It also took [pictures](https://kids.kiddle.co/Photography "Photography") of the effects of the atomic bomb.

The B-29 bomber that actually dropped the [Fat Man](https://kids.kiddle.co/Fat_Man "Fat Man") atomic bomb was named *Bockscar*. This plane was usually flown by Bock himself. However, just before the mission, the pilots were switched. Major Charles Sweeney flew *Bockscar* instead. *Bockscar* flew with *The Great Artiste* and another aircraft.

William L. Laurence, a science writer for *[New York Times](https://kids.kiddle.co/The_New_York_Times "The New York Times")*, was on board *The Great Artiste*. He wrote about the mission. His story won the 1946 [Pulitzer Prize](https://kids.kiddle.co/Pulitzer_Prize "Pulitzer Prize"). In his book, *Dawn Over Zero*, Laurence described what it was like on the B-29:

> I watched Capt. Frederick C. Bock, the pilot of our ship, go through the intricate motions of lifting a B-29 off the ground and marveled at the quiet efficiency of this Michigan boy who had majored in philosophy at Chicago University... I talked to him on the ground and I was amazed at the transformation that had taken place. Man and machine had become one, a modern centaur.
> 
> —William L. Laurence, Dawn Over Zero (1946)

Bock became a major in the Army Air Force. He received two important awards: the [Distinguished Flying Cross](https://kids.kiddle.co/Distinguished_Flying_Cross_\(United_States\) "Distinguished Flying Cross (United States)") and the Air Medal.

## Life After the War

After World War II, Bock went back to [Chicago](https://kids.kiddle.co/Chicago "Chicago"). There, he earned his [PhD](https://kids.kiddle.co/Doctor_of_Philosophy "Doctor of Philosophy") in [zoology](https://kids.kiddle.co/Zoology "Zoology"). He focused on using math to study living things and [genetics](https://kids.kiddle.co/Genetics "Genetics") (how traits are passed down).

Dr. Bock worked in research labs in Chicago. He created special [algorithms](https://kids.kiddle.co/Algorithm "Algorithm"), which are like step-by-step instructions, to solve difficult problems. At Baxter Travenol Laboratories, he developed a math model for a medical treatment called peritoneal dialysis. This treatment helps clean a person's blood. Dr. Bock retired from Baxter Travenol in 1986.

Frederick Bock was born in [Greenville, Michigan](https://kids.kiddle.co/Greenville,_Michigan "Greenville, Michigan"). He passed away from cancer at his home in [Arizona](https://kids.kiddle.co/Arizona "Arizona") in 2000.

[![kids search engine](https://kids.kiddle.co/images/wk/kids_search_engine.svg)](https://www.kiddle.co/)  

All content from [Kiddle encyclopedia](https://kids.kiddle.co/) articles (including the article images and facts) can be freely used under [Attribution-ShareAlike](https://creativecommons.org/licenses/by-sa/3.0/) license, unless stated otherwise. Cite this article:

[Frederick C. Bock Facts for Kids](https://kids.kiddle.co/Frederick_C._Bock). *Kiddle Encyclopedia.*