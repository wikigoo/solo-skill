---
title: "Letters from the Blitz: how an ordinary Briton taught small-town America to keep calm and carry on"
source: "https://www.telegraph.co.uk/books/what-to-read/letters-blitz-ordinary-brit-taught-small-town-america-keep-calm/"
---
On October 2, 1940, Ms Winifred Graville, a Sheffield resident in her mid-fifties, wrote to a distant cousin in the small New York village of Penn Yan. “I am off fish at present,” Ms Graville told her cousin. “There are so many dead Germans being caught in the fishing nets and washed up on our shores, that I don’t fancy it very much.”

Between 1939 and 1943, Ms Graville wrote letters almost to her cousin, Mrs Jane L. Beaumont, almost weekly, detailing life in wartime England and the German bombing campaign.

The above letter is an example of the Britishness that underpins her correspondence: a spirited defiance; an always-present humour in the face of unimaginable tragedy; and an insight into the strange realities of civilian life.

Over in Penn Yan, Mrs Beaumont persuaded the editor of the local newspaper, the Chronicle-Express, to publish excerpts from around 150 of her cousin's letters.

Richard MacAlpine, a writer and historian with the Yates County History Center in Penn Yann, discovered the letters while researching the paper’s archives, looking for details on the local community in the build-up and aftermath of the attack on [Pearl Harbor](https://www.telegraph.co.uk/pearl-harbor/). He has now collected them in a new book, Letters from [the Blitz](https://www.telegraph.co.uk/news/2020/09/07/blitz-80-year-anniversary-survivors-real-life-stories/).

![Botanist and writer Winifred Graville](https://www.telegraph.co.uk/content/dam/books/2020/09/07/Ms-Graville-Jane-Beaumont-photo-Yates-County-History-Center-NY_trans_NvBQzQNjv4BqihVibxPbOwKDCDIL8LViR5BFmUvF9iD16AHiiPspD-g.png?imwidth=960)

Botanist and writer Winifred Graville Credit: Jane Beaumont photo:Yates County History Center, NY

“I kept coming across this headline about a cousin in England writing to a lady in our little village of Penn Yan,” MacAlpine tells me. “Eventually I read one and it was just a great letter. It was about the lady’s reaction to the miracle of Dunkirk. I started reading more and more of these letters. Finally, I decided there was a better story in the letters than what I was researching originally.”

While the United States helped the Allies in the Battle of the Atlantic, and transferred 50 destroyers to the Royal Navy in September 1940, the country – and public mood – remained isolationist until Japan launched its attack on Pearl Harbor in December 1941.

The question, as MacAlpine ponders in the book, is why Mrs Beaumont and the Chronicle-Express editor published the letters.

“The lady in Penn Yan was the president of the county historical society,” MacAlpine says. “But I wondered why the editor went along with it. I figured that they were publishing those letters to inform people about what was going on in England. Maybe this small newspaper in a small village could change some attitudes. The cousin may have thought they were making a small but positive contribution to getting America into the war. Of course, it took Pearl Harbor to do it!”

Back in Sheffield, Ms Graville was a botanist and writer, who lived with her maid, Doris. In her first published letter, dated October 5, 1939, she talks about wanting to do a lecturing tour of the US – a tour she continues to plan for the next three years.

The letters include her response to major events – a Dutch-Belgian peace offer in November 1939 (“Sounds alright on paper”); the Nazi invasion of France and the Low Countries in May 1940 (“I have been wandering the garden… trying to cheer myself up”); and Mussolini joining [Hitler](https://www.telegraph.co.uk/adolf-hitler/) the following month (“So Italy is against us after all”) – but it's the stories of ordinary folk at ground level which are most insightful.

!['You folks have no idea what it is like here': St Paul's Cathedral in December 1940](https://www.telegraph.co.uk/content/dam/books/2020/09/07/TELEMMGLPICT000000959900_trans_NvBQzQNjv4BqFuJiaShAU7GsCXIVLpuFGQ2DeGRWs5bp-BaRwj5Xfmc.jpeg?imwidth=960)

'You folks have no idea what it is like here': St Paul's Cathedral in December 1940 Credit: Daily Mail

“You folks, safe on the other side of the world, have no idea what it is like here,” writes Ms Graville in that first letter, which could easily be addressed to readers in the 21 <sup>st</sup> Century. “Not a streetlamp in Britain anywhere, not a light may show, even shops as well as private houses must present an absolutely black appearance from outside from sunset to sunrise. No chinks or faint glows, just utter blackness. Then too, every single person, children included, must by law carry their gas masks if more than five minutes away from home.”

The details of everyday life are relayed as matter-of-fact annoyances or comical observations: the realities of rationing (only two ounces of tea per head, and enough butter for just one generously slathered piece of toast); listening the birdsongs on BBC radio; practicing drills for finding incendiary bombs and what to do in an air raid.

Details of living through air raids are fascinating. In one letter Ms Graville describes how they must fill the kettle before bed, because if there's a raid they're not allowed to draw water. In another letter, Ms Graville distracts her maid from the abject terror by playing rummy, as the bombs drop around them.

She also remarks on the horrifying sounds of whistling bombs and having an ear for the war machinery. (“I said once that I couldn’t tell the difference between an English and a German plane. I no longer am so ignorant.”). Ms Graville describes the sheer exhaustion of being kept up night after night by raids – sometimes for six or even nine hours at a time – and is grateful for the rain. “We cannot have an air raid in a storm like this and that is a great cause for gratitude,” she writes.

Though she's based in Sheffield, she has a good insight into the London [blitz](https://www.telegraph.co.uk/the-blitz/), particularly the public response to the senseless destruction to civilian life and even Buckingham Palace. “The king and queen are ‘one of us’,” she writes. “They are our personal friends.”

!['The king and queen are ‘one of us’: the royal family celebrating VE Day in 1945](https://www.telegraph.co.uk/content/dam/books/2020/09/07/TELEMMGLPICT000229865687_trans_NvBQzQNjv4Bqp9c5WVj0Jr0gvyuux5WeKI-QD44-voN49g7o0Fjx2T4.jpeg?imwidth=960)

'The king and queen are ‘one of us’: the Royal family celebrating VE Day in 1945 Credit: Mirrorpix

Especially gripping are details that seem incredible in 2020: crafting a makeshift gas mask for her canary; receiving pamphlets on “What To Do In An Invasion”, while the Germans planes drop copies of Hitler’s speeches; and the BBC broadcasting commentary on Battle of Britain dogfights as they happen.

“I am literally bouncing up and down in my chair with excitement,” writes Ms Graville. “We could hear guns and bombs quite plainly and the commentator sounded as worked up as if he were describing a national football match! We could hear the anti-aircraft men shouting: ‘Got it! It’s coming down! It’s down, it’s down!’ It was thrilling.”

Some readers may be surprised by the reach of the Nazi propaganda machine. Ms Graville details a radio station being broadcast in perfect English that spreads what we’d now call fake news (“We all put it on as to have a good laugh”); [Lord Haw Haw](https://www.telegraph.co.uk/books/authors/lord-haw-haw-the-traitor-executed-for-helping-the-nazis/), a British fascist who took German citizenship and broadcast Nazi propaganda, who was later hanged for high treason; and the Nazi-run “New British Broadcasting Station”. (MacAlpine notes that the BBC was giving its own spin to Brits, to keep those upper lips well and truly stiffed.)

The letters – as clearly recognised by the cousin in Penn Yan and newspaper editor – didn't just cut through the propaganda that was reaching American shores (“I wish you good people in America would not talk and think of us as a ‘beleaguered island.’ We are NOT beleaguered!”). The letters were also a stark warning to America.

“Being a woman of no importance in the world, I cannot expect America to take any notice of me,” she writes on June 19, 1940, “but my strong advice to that great country is PREPARE. Hitler is after America too, so make no mistake about that.”

Then, on September 4, 1940, a full 15 months before the Pearl Harbor attack, she writes: “I think your isolationists must be folk of a very low level of intelligence.”

The warnings are contrasted with British humour. There’s plenty of talk, as often found in romanticised memories of wartime Britain, of Hitler as a bit of a rotter who could be sorted out with a bop on the nose. Ms Graville calls the Nazis “Hitler’s mob” and “Messrs Hitler, Goering & Co”, and describes how a man from a nearby village has named his cockerels Stalin and Hitler (“None of the hens will have Hitler anywhere near them!”) Though Hitler does get credit for helping her finish her knitting faster than expected, thanks to her needing something to do during the air raids.

“She had a sense of humour – it comes across in the letters,” says MacAlpine. “And she was a tough lady. What really comes out is that 'keep calm and carry on' attitude.”

![The blitz rocked Graville's spirit: children outside an air raid shelter](https://www.telegraph.co.uk/content/dam/books/2020/09/07/TELEMMGLPICT000075570825_trans_NvBQzQNjv4BqqVzuuqpFlyLIwiB6NTmJwQ5dwyI40Jh1IrFVJYVyBWg.jpeg?imwidth=960)

The blitz rocked Graville's spirit: children outside an air raid shelter Credit: Reg Speller

Indeed, as MacAlpine tells me, the near-mythic British spirit is integral to the story. Ms Graville describes the mood during the bombing campaign as being more annoyed than fearful. In one letter she writes: “The spirit here is universal… Mr. Churchill always gets what he sets out to get and the country is solidly behind him.” In another: “If every building in London is laid flat, the war will still go on.”

There are stories of young boys helping the fire brigade. Ms Graville mucked in herself by enrolling into the Women’s Voluntary Service corps.

“Everything that the country is asked to do, it does promptly and if it is something inconvenient, then it is made a joke and there is one more score against Hitler when the day of reckoning comes," she writes. "For the first time in our island history, we are subjected to all kinds of restrictions, rules and regulations, but nobody minds a tinker’s cuss and the comedians bring down the music halls with roars of laughter over them.”

For MacAlpine, Ms Graville’s steely spirit and confidence were only rocked during the Sheffield Blitz, which devastated the city – targeting its steel and arms factories – over two nights of bombing between December 12 and 15. More than 600 civilians were killed

On the first night of bombing, which lasted nine hours, Ms Graville describes how her house rocked and tilted before righting itself (“It almost seemed as if the house paused to think”). By 5am, she says the city was a “raging inferno”. In the aftermath, she walked through the ruins, finding ambulances turned upside-down in bomb craters and a “horrid mess” on the pavement. “That is all that is left of two soldiers,” an ambulance worker told her.

“What good to the war effort has any of that done?" she writes afterwards. "I saw people pathetically searching among the safer ruins for their possessions, others with tragically small bundles, representing their all, and people with bandages, weary faces and tired bodies, but not one ever suggested we should sue for peace. I spoke to several unfortunates and there was never a word of complaint, only sympathy for others. One man said, ‘Eh, but our chaps will give them hell for this.'”

!['We are NOT beleaguered!': dancers at the Windmill Theatre in London](https://www.telegraph.co.uk/content/dam/books/2020/09/07/TELEMMGLPICT000219937763_trans_NvBQzQNjv4BqG6uvMzRsA2gL76S9bNdwvhmlF41RiA7tG3prCrw2yf8.jpeg?imwidth=960)

'We are NOT beleaguered!': dancers at the Windmill Theatre in London Credit: Hulton Archive

The letters were published much less frequently after the US joined the war in December 1941. MacAlpine suggests that by now there was less of a need to inform Americans about the realities of the war; and newspaper inches were likely given to reporting on the US military. In the last letter, dated November 23, 1942, she continues to explain how much harder Brits have it: shops closed by 4pm and no buses after 9pm – along with cinemas and theatres closed so everyone can get the last bus. "How would you like that in the USA?"

There are some lingering mysteries to the story. There were surely letters sent back from Penn Yan to Sheffield, the contents of which are likely lost to time. MacApline suspect that Ms Graville never made it to the United States for her tour. Other than the fact she passed away in 1974, aged 89, he knows little else about her life post-1943.

Perhaps the best piece of advice from Ms Graville to America was this: have a nice cup of tea. “In case USA is ever at war with a nation that can reach them quickly by air, I would strongly recommend Americans to cultivate the tea habit and learn to make it successfully," she writes. "For it has a wonderfully soothing effect and most people here make a cup of tea as soon as they get down.”

**Letters from the Blitz is published by The History Press and is available now**

##### Do you have wartime letters sent from family to loved ones? Share your experience in the comments section below

Every morning

[From the Editor](https://secure.telegraph.co.uk/customer/secure/newsletter/from-the-editor/)

Wake up to free-thinking comment and the biggest news stories, in your inbox every morning

![From the Editor](https://www.telegraph.co.uk/content/dam/newsletters-2-0/thumbnails/may-2026-/Newsletter=FTE.jpg)