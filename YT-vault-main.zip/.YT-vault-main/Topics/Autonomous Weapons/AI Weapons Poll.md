---
title: "AI Weapons Poll"
source: "https://autonomousweapons.org/ai-weapons-poll/"
description: "We must act now to prohibit and regulate these weapons."
---
## Nearly 9 in 10 people in the UK, France and Germany want their governments to lead on global AI weapons rules as leaders urged to act

In November countries could start negotiations on a treaty for autonomous weapons. Ahead of this critical meeting, new polls have revealed that between 86% and 93% of people in the UK, France and Germany think their country should lead calls for a global agreement setting legally binding rules on military AI.

The survey of 6,000 adults in the UK, France and Germany, commissioned by the Future of Life Institute, found:

- **86–93%** of people in each country believe it is at least somewhat important that their government leads on efforts to regulate AI weapons, and doing so is “very important” to between a quarter and two in five (25.6–39.7%)
- **87–94%** support an international treaty to control the use of AI weapons.
- **86–90%** are concerned about the rising use of AI weapons in war.

![](https://autonomousweapons.org/wp-content/uploads/2026/10/CHARTS_E01_1080x1350_V04a.png "CHARTS_E01_1080x1350_V04a")

The results follow significant escalation of military AI usage in Ukraine, Gaza, and Iran. This includes the [AI-targeted](https://www.bloomberg.com/graphics/2026-iran-school-attack/) missile strike that destroyed a school in Iran, killing 123 schoolgirls. A UN report has linked [military AI use](https://childrenandarmedconflict.un.org/en/news/year-unthinkable-suffering-record-number-children-conflict-victims-grave-violations-2025) to last year’s surge in children’s deaths in conflict.

The survey also found widespread concern with the power of Big Tech, and a desire for the government to play a clear role in mitigating the risks of new technologies. This follows [rising concern](https://www.ft.com/content/9a6e17fe-55e4-4a6d-8761-8346ec765ba9?syn-25a6b1a6=1) about US military AI firms such as Palantir and Anduril, and their increasing level of control over UK infrastructure.

In September, [128 states](https://www.reuters.com/world/states-reach-agreement-autonomous-weapons-talks-geneva-2026-09-05/) at the UN Convention on Certain Conventional Weapons (CCW) agreed on a text that could form the basis of negotiations. The text stipulates meaningful human control of autonomous weapons systems, and limits on the range and length of time they are permitted to operate.

Civil society organisations are pressuring all three governments to publicly commit to backing the launch of treaty negotiations. France and Germany already support a treaty in principle.

In November countries could start negotiations on a treaty for autonomous weapons. Ahead of this critical meeting, new polls have revealed that between 86% and 93% of people in the UK, France and Germany think their country should lead calls for a global agreement setting legally binding rules on military AI.

The survey of 6,000 adults in the UK, France and Germany, commissioned by the Future of Life Institute, found:

- **86–93%** of people in each country believe it is at least somewhat important that their government leads on efforts to regulate AI weapons, and doing so is “very important” to between a quarter and two in five (25.6–39.7%)
- **87–94%** support an international treaty to control the use of AI weapons.
- **86–90%** are concerned about the rising use of AI weapons in war.

The results follow significant escalation of military AI usage in Ukraine, Gaza, and Iran. This includes the [AI-targeted](https://www.bloomberg.com/graphics/2026-iran-school-attack/) missile strike that destroyed a school in Iran, killing 123 schoolgirls. A UN report has linked [military AI use](https://childrenandarmedconflict.un.org/en/news/year-unthinkable-suffering-record-number-children-conflict-victims-grave-violations-2025) to last year’s surge in children’s deaths in conflict.

The survey also found widespread concern with the power of Big Tech, and a desire for the government to play a clear role in mitigating the risks of new technologies. This follows [rising concern](https://www.ft.com/content/9a6e17fe-55e4-4a6d-8761-8346ec765ba9?syn-25a6b1a6=1) about US military AI firms such as Palantir and Anduril, and their increasing level of control over UK infrastructure.

In September, [128 states](https://www.reuters.com/world/states-reach-agreement-autonomous-weapons-talks-geneva-2026-09-05/) at the UN Convention on Certain Conventional Weapons (CCW) agreed on a text that could form the basis of negotiations. The text stipulates meaningful human control of autonomous weapons systems, and limits on the range and length of time they are permitted to operate.

Civil society organisations are pressuring all three governments to publicly commit to backing the launch of treaty negotiations. France and Germany already support a treaty in principle.

> *“Machines should never be able to make a decision to take a human life. It’s urgent that governments step up and lead now before humans lose control, and accountability is sidestepped.”  
> *
> 
> *“The evidence is clear. Overwhelming majorities internationally oppose AI weapons proliferating, and in the UK, France, and Germany, overwhelming majorities want their governments to lead on ensuring a legally-binding instrument exists. There’s no time to lose.”*

– Anna Hehir, Head of Military AI Governance at the Future of Life Institute

This poll was also published separately for the [UK (English)](https://autonomousweapons.org/ai-weapons-poll-uk/), [France (Français)](https://autonomousweapons.org/sondage-armes-autonomes-france/) and [Germany (Deutsch)](https://autonomousweapons.org/umfrage-ki-waffen-deutschland/), with country-specific findings.

![](https://autonomousweapons.org/wp-content/uploads/2026/10/CHARTS_E02_1080x1350_V04a.png "CHARTS_E02_1080x1350_V04a") ![](https://autonomousweapons.org/wp-content/uploads/2026/10/governments-to-lead-v2-scaled.png "governments-to-lead-v2")