---
title: "U.S. Strikes in Middle East Use Anthropic, Hours After Trump Ban"
source: "https://www.wsj.com/livecoverage/iran-strikes-2026/card/u-s-strikes-in-middle-east-use-anthropic-hours-after-trump-ban-ozNO0iClZpfpL7K7ElJ2"
---
<iframe frameborder="0" src="https://bb08cf237f9a1251fc0e2ca95c2ee067.safeframe.googlesyndication.com/safeframe/1-0-45/html/container.html" title="محتوای آگهی طرف سوم" width="970" height="250" sandbox="allow-forms allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation" allow="private-state-token-redemption" aria-label="آگهی"></iframe>

[Iran Attacks, March 1: Trump Warns More U.S. Deaths Possible as Blasts Rock Mideast](https://www.wsj.com/livecoverage/iran-strikes-2026?mod=lc_navigation)

Last Updated: March. 2, 2026 at 12:05am ET

![U.S. Strikes in Middle East Use Anthropic, Hours After Trump Ban](https://images.wsj.net/im-28725351?width=620&height=413)

Patrick Sison/Associated Press

Within hours of declaring that the federal government will end its use of artificial-intelligence tools made by tech company Anthropic, President Trump launched a major air attack in Iran with the help of those very same tools.

Commands around the world, including U.S. Central Command in the Middle East, use Anthropic’s Claude AI tool, people familiar with the matter confirmed. Centcom declined to comment about specific systems being used in its ongoing operation against Iran.

The command uses the tool for intelligence assessments, target identification and simulating battle scenarios even as tension between the company and Pentagon ratcheted up, the people said, highlighting how embedded the AI tools are in military operations.

The administration and Anthropic have been feuding for months over how its AI models can be used by the Pentagon. Trump on Friday ordered agencies to [stop working with the company](https://www.wsj.com/tech/ai/trump-will-end-government-use-of-anthropics-ai-models-ff3550d9) and the Defense Department designated it a security threat and risk to its supply chain.

That came after Anthropic refused to let the Pentagon use its tools in all lawful scenarios during their contract negotiation. Anthropic’s lobbying against the administration’s AI policies and ties to organizations that are big Democratic donors have also upset administration officials.

Claude’s use in high-profile missions, such as [the U.S. military operation](https://www.wsj.com/politics/national-security/pentagon-used-anthropics-claude-in-maduro-venezuela-raid-583aff17?mod=Searchresults&pos=1&page=1) that captured Venezuelan President Nicolás Maduro, shows why the administration said it would take six months to phase out the technology—a complicated process given how it is used by partners including data-mining firm Palantir.

As Anthropic’s relationship with the Pentagon soured, the Defense Department reached deals to use competitors ChatGPT maker OpenAI and Elon Musk’s xAI in classified settings. It will take months to replace Claude with the other models, AI experts said.

[Back to Live Updates](https://www.wsj.com/livecoverage/iran-strikes-2026?mod=lc_navigation)