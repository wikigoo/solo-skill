---
title: "Palantir Q2 2026: Revenue $1.935B (+93%), U.S. Commercial Surge 149%, Rule of 40 Reaches 155%, Stock Extends Breakout"
source: "https://www.tradingkey.com/analysis/stocks/us-stocks/262127537-palantir-pltr-q2-2026-1-935b-revenue-93-pct-us-commercial-764m-149-pct-eps-0-41-rule-of-40-155-tradingkey"
---


Palantir reported exceptional Q2 2026 results, with revenue surging 93% year-over-year to $1.935 billion, beating estimates by 7.6%. Adjusted EPS reached $0.41, outperforming expectations. Growth was driven by surging U.S. commercial demand and AI sovereignty adoption, resulting in a record Rule of 40 score of 155% and an adjusted operating margin of 62%. Consequently, management raised full-year 2026 guidance. Despite strong fundamentals, key risks include a high valuation trading at approximately 107x and slower international growth. Technically, the stock is consolidating near $180 after breaking key support at $159.58, with resistance clustered at $205.15.

TradingKey - On August 3rd, Palantir ([PLTR](https://www.tradingkey.com/markets/stocks/pltr)) reported $1.935 billion in Q2 2026 revenue, which was 93% higher than the same period last year. That beat analysts' expectations by 7.6%. The company's U.S. commercial revenue shot up to $764 million, a 149% increase year-over-year. The U.S. government revenue also increased by 90%, coming in at $809 million. That brought total U.S. revenue to $1.573 billion, a 115% year-over-year increase. Net income was $1.062 billion, compared to $320 million last year. Adjusted EPS was $0.41, and that was better than the $0.35 estimate by 18.5%. Total contract value was $3.37 billion, a 49% increase. U.S. commercial TCV was a record $2.13 billion, a 153% increase. Net dollar retention was 157% (up 700 bps from Q1).

The Rule of 40 score was 155%, a combination of 93% growth and 62% adjusted operating margin. Management was optimistic about the FY2026 revenue and U.S. commercial guidance, and raised both estimates. Palantir stock peaked by 30%, after the earnings were released (August 4th), and closed at $162.66. CEO Alex Karp mentioned that close to half of the revenue Palantir is generating comes from the enterprise, and that the demand for AI sovereign solutions should last at least another 18 months.

## U.S. Commercial: $764M (+149% YoY), 220 Deals $1M+, 653 Customers

Record U.S. Commercial revenue at $764M (+28% sequential, +149% YoY). 220 U.S. Commercial deals valued at $1M+, of which 98 exceeded $5M and 70 exceeded $10M. U.S. Commercial customers were 653 (+42% YoY). U.S. Commercial TCV hit a record $2.13B (+153% YoY). Remaining deal value was $6.24B, triple the previous year. Segment is the fastest growing software segment at scale; CEO Karp stated, "no business at our scale has even grown half this much."

## Government Strong; AIP Platform Winning Head-to-Head

U.S. government revenue hit $809M (+90% YoY). International government revenue hit $181M (+42% YoY). Total government revenue hit $990M (+79% YoY). U.S. government defense and civil agencies are adopting AI technologies with new levels of interest. Palantir's AIP platform is winning competitive deployments against “frontier labs” (OpenAI, Anthropic, etc.); a major Silicon Valley tech company selected Palantir over the competition and signed a $10M ACV contract. AIP is winning these deals because customers can maintain control of data and models onsite (AI sovereignty), rather than losing control of them to a third party via “token-maxing.”

## Net Dollar Retention 157%, Operating Margin 62%

NDR of 157% represents a 700 bps improvement from the previous quarter's value of 150%. This indicates high customer satisfaction, increasing customer retention, and successfully meeting customer expectations. Adjusted operating margin was 62% ($1.19B adjusted operating income). GAAP operating income was $912M at a record 47% margin. This achieved a Rule of 40 at a value of 155% (rare for hypergrowth software). Q3 targets revenue at $2.16B and adjusted operating income at $1.29-1.30B.

## AI Sovereignty" Narrative Resonating; FY2026 Guidance Raised Again

Management directive indicates an emphasis on client enterprise’s ability to control their own deployments of AI rather than using frontier models and potentially losing their trade secrets. Karp: “Companies are paying to give away their most important secrets, the very basis for their competitive advantage.” There was overwhelming interest from CEOs and operators in the “sovereign boot camp.” Current Foundry-only customers are shifting to the sovereign AI stack. FY2026 guidance has been increased (Q1), and continues to be increased (now Q2), indicating a strong and confident outlook for the full-year. Adjusted operating margin is estimated to be ~60%. Adjusted free cash flow is expected to be in the range of $4.5-4.7B.

## PLTR Technical Analysis: Support $159.58, Resistance $205.15, Consolidating Near $180

PLTR trading at $179.94 (according to technical analysis). Confirmed a new structure after an extended breakout above $159.58. RSI ~69 (near 70 overbought, but aligned with signal line).

![Palantir Price Chart - Source: Tradingview](https://resource.tradingkey.com/uploads/20260824/PLTR-a8e0a802645640bea78f3b7bb29b2e2c.jpg)

Palantir Price Chart - Source: Tradingview

Moving averages ~$148, $145 supportive. There may be consolidation after a rapid advance from the $120 region. Resistance cluster $205.15 (previous major peak). Break above $205 targets $232.23. Support $159.58 (breakout level). Below that, $148-$145 moving average cluster.

### Key Levels

- ****Support:**** $159.58 (breakout level), $148.06, $144.82 (moving averages)
- ****Resistance:**** $205.15 (next major target), $232.23 (extended target)
- ****Current momentum:**** RSI 69 (near overbought), approaching consolidation risk

## Bottom Line: Hypergrowth + Profitability = Rule of 40 at 155%, FY Guidance Raised

Revenue $1.935B (+93%), U.S. comm $764M (+149%), U.S. govt $809M (+90%), EPS $0.41 (+18%), TCV $3.37B, NDR 157%, operating margin 62%, Rule of 40 155%. FY guidance $8.15B (+82%), U.S. comm $3.424B+ (+134%). Palantir’s combination of 93% growth in revenue and 62% in operating margin is extremely rare. It’s hyper growth Rule of 40 of 155% puts it among the best ever in enterprise software history. Valuation at earnings guidance is still considered high (~107x), but there is a large backlog (NDR 157%, $6.24B) plus rapid growth of customers (653 U.S. commercial customers, +42% growth YoY), plus the expansion AI sovereignty narrative which could mean a number of years of strong growth if execution continues.

Risk factors: valuation is high (at ~107x), slow growth internationally (26% growth YoY), and pressure on margins from gov cloud hosting. A breakout to the upside at $159 is justified, whereas consolidation at $180 is expected before a test of $205. Remember, this is a purely technical analysis, and not an investment suggestion.



TradingKey Stock Score

Palantir Technologies Inc Key Insights:Palantir Technologies Inc's fundamentals are relatively very healthy, and its growth potential is high.Its valuation is considered fairly valued, ranking 84 out of 472 in the Software & IT Services industry.Institutional ownership is very high.Over the past month, multiple analysts have rated it as Buy, with the highest price target at 209.58.In the medium term, the stock price is expected to trend up.Despite a good stock market performance and outperforming fundamentals over the past month, the technicals don't support the current trend.The stock price is trading sideways between the support and resistance levels, making it suitable for range-bound swing trading.[View Details >>](https://www.tradingkey.com/markets/stocks/pltr/stock-analysis)

6.73

Score

Disclaimer: The content of this article solely represents the author's personal opinions and does not reflect the official stance of Tradingkey. It should not be considered as investment advice. The article is intended for reference purposes only, and readers should not base any investment decisions solely on its content. Tradingkey bears no responsibility for any trading outcomes resulting from reliance on this article. Furthermore, Tradingkey cannot guarantee the accuracy of the article's content. Before making any investment decisions, it is advisable to consult an independent financial advisor to fully understand the associated risks.

** Like

## Recommended Articles



Elevate your investing experience

[Open App](https://tradingkey.onelink.me/KHZX/click_banner)