---
title: "Deputy Secretary of Defense Hicks Announces First Tranche of Replicator Capabilities Focus"
source: "https://www.war.gov/News/Releases/Release/Article/3765644/deputy-secretary-of-defense-hicks-announces-first-tranche-of-replicator-capabil/"
---
> [!warning] Warning
> You have accessed part of a historical collection on war.gov. Some of the information contained within may be outdated and links may not function. Please contact the [DOW Webmaster](https://www.war.gov/Contact/) with any questions.

*Exemplifying the Department's focus on harnessing the value of commercial technology to solve critical operational challenges, the first iteration of the Replicator initiative has reached an execution milestone.*

Deputy Secretary Hicks announced today some of the capabilities and one of the systems selected for accelerated fielding as part of the first tranche of the Replicator initiative, which is focused on fielding all-domain attritable autonomous (ADA2) systems.

The Department has secured its needed funding of about $500 million for FY24, to include approximately $300 million from the Fiscal Year (FY) 2024 defense appropriations bill supporting the Department's reprogramming request and additional funding identified using existing authorities and Defense-wide sources. In PB25, the Department has requested a roughly equal amount to the FY24 total and will work with Congress to support this request.

These investments bring together the capabilities of a broad range of traditional and nontraditional technology companies, including systems vendors, component manufacturers, and software developers.

"I am pleased to announce that the Department will begin investing in scalable production for these critical capabilities," said Hicks. "We are taking an important step toward strengthening our defense and technology industrial base. And, we are demonstrating the Department's ability to break down barriers to scaling innovation at speed not just for ADA2 systems, but in our ability to develop new capabilities and processes for the Department and key stakeholders, including Congress."

The first tranche of Replicator capabilities include uncrewed surface vehicles (USV), uncrewed aerial systems (UAS) and counter-uncrewed aerial systems (c-UAS) of various sizes and payloads from several traditional and non-traditional vendors.

In the air domain, the Department will accelerate fielding of the Switchblade-600 loitering munition, produced by Simi Valley, CA-based AeroVironment Inc. U.S.-supplied Switchblade drones have already demonstrated their utility in Ukraine, and this system will provide additional capability to U.S. forces.  
  
"This is a critical step in delivering the capabilities we need, at the scale and speed we need, to continue securing a free and open Indo-Pacific" said Admiral Samuel Paparo, commander of U.S. Indo-Pacific Command. "The entire Department has come together to help make this a reality."

In the maritime domain, the Department is diversifying the vendor base for USVs through the recently announced Production-Ready, Inexpensive, Maritime Expeditionary (PRIME) Commercial Solutions Opening (CSO). The CSO process allows U.S. and international companies to pitch technologies to the Department in a fast-track process for a prototype contract. Launched on January 30, 2024, the PRIME CSO received over one hundred applications from commercial technology companies. With FY24 funding secured, the Department is on track to award several contracts this summer.

The first tranche of Replicator also includes certain capabilities that remain classified, including others in the maritime domain and some in the counter-UAS portfolio.

"Meeting the strategic imperatives facing the nation requires that we harness the very best of America's commercial technology in non-traditional partners, alongside our traditional sources of defense capabilities," said Doug Beck, Director of the Defense Innovation Unit (DIU). "Replicator is doing just that, and that is why we at DIU are proud to work with our partners from across the Department of Defense to make it a reality."

Since Deputy Secretary Hicks' announcement of the Replicator initiative and its initial focus on ADA2 systems just over seven months ago, the Department-wide effort has systematically aligned senior leaders around a common vision to identify and validate key joint operational gaps and rapidly field solutions in 18-24 months. The Department is also preparing the next tranche of capabilities to add to the ADA2 portfolio.

"This is just the beginning," said Admiral Christopher Grady, Vice Chairman of the Joint Chiefs of Staff. "Replicator is helping us jumpstart the delivery of critical capabilities at scale. We will build on that momentum with industry partners to deliver what the warfighter needs, and remove barriers to doing so again and again."