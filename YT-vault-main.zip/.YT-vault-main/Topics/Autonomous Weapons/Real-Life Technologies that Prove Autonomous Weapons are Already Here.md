---
title: "Real-Life Technologies that Prove Autonomous Weapons are Already Here"
source: "https://futureoflife.org/aws/real-life-technologies-that-prove-autonomous-weapons-are-already-here/"
---
For years, we have seen the signs that lethal autonomous weapons were coming. Unfortunately, these weapons are no longer just 'in development' - they are starting to be used in real military applications. Slaugherbots are officially here.

Lethal autonomous weapons have been in development for years. In fact, we warned the world about this [back in 2017](https://youtube.com/watch?v=HipTO_7mUOw).

Unfortunately, Slaughterbots are now here.

In this article, we have collected 4 examples of real-life autonomous weapons which exist today, and have either already been deployed in military operations or will be deployed in the near future.

## 1 – STM Kargu-2

![](https://futureoflife.org/wp-content/uploads/2021/11/laws-spectrum-980x653-1.jpeg)

In spring of 2020, it was reported that an autonomous drone strike had taken place in Libya. As far as we know, this was the first documented case of an autonomous weapon being used in a real military operation.

> According to a recent [UN report](https://undocs.org/Home/Mobile?FinalSymbol=S%2F2021%2F229&Language=E&DeviceType=Desktop), a drone airstrike in Libya from the spring of 2020—made against Libyan National Army forces by Turkish-made [STM Kargu-2](https://en.wikipedia.org/wiki/STM_Kargu) drones on behalf of Libya’s Government of National Accord—was conducted by weapons systems with no known humans “in the loop.”

One of the Kargu-2 drones used in the attack was downed and recovered for inspection, which allowed us to learn the following details about its functionality:

> The STM Kargu-2 is a flying quadcopter that weighs a mere 7 kg, is being mass-produced, is capable of [fully autonomous targeting, can form swarms](https://www.thedrive.com/the-war-zone/34204/turkey-now-has-a-swarming-quadcopter-suicide-drone-that-it-could-export), remains fully operational when GPS and radio links are jammed, and is equipped with [facial recognition software](https://www.forbes.com/sites/davidhambling/2020/06/17/turkish-military-to-receive-500-swarming-kamikaze-drones/?sh=2f7d77e0251a) to target humans. In other words, it’s a Slaughterbot.

Link: [Source](https://spectrum.ieee.org/lethal-autonomous-weapons-exist-they-must-be-banned)

## 2 – Jaeger-C

![](https://futureoflife.org/wp-content/uploads/2021/11/https___specials-images.forbesimg.com_imageserve_6183e6b8f4ebaa891e6729dc_C-Jaeger1_960x0.jpg)

In November 2021, a new form of autonomous weapon got its first military contract:

> Australian robot vehicle maker GaardTech [announced a contract](https://twitter.com/GaardTech/status/1456065348034170880) Thursday to supply its Jaeger-C uncrewed combat vehicle to the Australian Army for demonstrations in 2022.
> 
> The wheeled Jaeger-C is a small machine with a low profile designed to attack from ambush. In some ways, it might be seen as a mobile robotic mine. This is especially true because the makers note it can be remote-controlled or operate “autonomously with image analysis and trained models linked to robotic actions,” according to a report in [Overt Defense](https://www.overtdefense.com/2020/09/18/new-australian-jaeger-c-armed-ugv/).

The weapon has two modes of operation: Chariot mode, for engaging human targets, and Goliath mode, for engaging vehicles. Here is how the two modes work:

> In Chariot mode, the robot engages targets with an undisclosed weapon, which is likely to be a 7.62 mm medium machine gun. It might also be something like the 6.5mm sniper rifle in a [Special Purpose Unmanned Rifle](https://sworddefense.com/spur/) pod recently seen mounted on a [quadruped robot](https://www.newscientist.com/article/2293908-us-military-may-get-a-dog-like-robot-armed-with-a-sniper-rifle/). In Goliath mode, the robot carries out a kamikaze attack on a vehicle. This is named after the [Goliath Tracked Mine](https://www.historynet.com/goliath-tracked-mine-the-beetle-that-started-the-rov-craze.htm) deployed by German forces in WWII. Known as the ‘beetle tank,’ these little tracked vehicles were less than five feet long but carried a hundred-pound explosive charge and were used against tanks and fortifications.

When it identifies an armoured vehicle target, such as a tank, the Jaeger-C will enter ‘Goliath mode’ and roll at up to 50 mph towards the vehicle. When it is close enough, the on-board explosive will automatically detonate, causing critical damage to the target.

It may be possible for a tank to react in time and destroy a fast-approaching Jaeger-C, but this would become very difficult if multiple attack robots were swarming the target vehicle at once.

> The Jaeger-C carries an armor-piercing shaped charge; the size is unspecified, but it’s likely to be at least comparable to the 20-pound warhead on the [FGM-148 Javelin](https://www.army-technology.com/projects/javelin-portable-anti-tank-missile/) and has the huge advantage of attacking the belly of the tank where the armor this thinnest.

No human operator needs to be present – the Jaeger-C is able to perform all of these functions, including recognising a target and deciding whether or not to detonate, by itself.

Link: [Source](https://www.forbes.com/sites/davidhambling/2021/11/04/australian-army-gets-bulletproof-attack-robots/?sh=4857e00e463b)

## 3 – US Air Force MQ-9 Reaper

![](https://futureoflife.org/wp-content/uploads/2021/11/https___specials-images.forbesimg.com_imageserve_5fd3ae6599ea4d062fab0404_Reaper-drone_960x0.jpg)

In December 2020, Forbes ran this headline:

> U.S. To Equip MQ-9 Reaper Drones With Artificial Intelligence

This caused a bit of a stir in the existential risk community.

> The Pentagon’s Joint Artificial Intelligence Center has [awarded a $93.3 million contract](https://www.ga.com/ga-asi-awarded-smart-sensor-contract) to General Atomics Aeronautical Systems Inc (GA-ASI), makers of the MQ-9 Reaper, to equip the drone with new AI technology. The aim is for the Reaper to be able to carry out autonomous flight, decide where to direct its battery of sensors, and to recognize objects on the ground.
> 
> In September, the Air Force announced that General Atomics had [flown a Reaper](https://www.airforce-technology.com/news/ga-asis-mq-9-rpa-flies-with-afrls-agile-condor-pod/) fitted with a new device known as an Agile Condor pod under its wing for the first time. [Agile Condor](https://www.srcinc.com/pdf/Intelligence-Surveillance-Reconnaissance-Agile-Condor.pdf), which has been in development by the Air Force Research Laboratory for some years, is effectively a flying supercomputer – ‘high-performance embedded computing ‘ — optimized for artificial intelligence applications. Built by SRC Inc, it packs the maximum computing capacity into the minimum space, with the lowest possible power requirements. Its modular architecture is built around machine learning (suggesting a lot of GPUs or other processors optimized for parallel processing) and the makers anticipate upgrades to neuromorphic computing hardware which mimics the human brain.

In short, this new ‘smart’ drone promises to reduce the amount of human-hours required to review the incoming data, and make critical decisions.

> “Instead of taking hours, sometimes days or even weeks – decisions can now be made in near real-time. If the system detects an anomaly on the ground, warfighters are alerted within minutes, allowing them to investigate and act while it’s still relevant,” according to [SRC’s page on Agile Condor](https://www.srcinc.com/products/intel-collection-and-analysis/agile-condor-high-performance-embeded-computing.html).

However, this also opens up the capability for the drone to act autonomously, and make decisions by itself.

> It also opens up the possibility of the Reaper operating on its own. An Air Force slide of the Agile Condor concept of operations shows the drone losing both its communications link and GPS navigation at the start of its mission. An existing Reaper would circle in place or fly back to try and re-establish communications; the AI-boosted version uses its AI to navigate using landmarks and find the target area – as well as spotting threats on the ground and changing its flight path to avoid them.

Though it may seem harmless for an autonomous drone to use its new-found intelligence to avoid obstacles, it will be extremely tempting for military personnel to rely more and more on their drones’ autonomous capabilities, especially when there is a communications or GPS disconnection at critical moments. Eventually, they might even delegate the task of deciding whether or not to strike to the drones’ onboard system.

Unfortunately, the Pentagon’s policy on ‘human judgement’ is sufficiently vague to allow it to mean whatever they decide is in their best interests at the time:

> When it comes to autonomous weapons, the Pentagon’s stated policy is always that a human operator will always make the firing decision, this [policy has some flexibility](https://crsreports.congress.gov/product/pdf/IF/IF11150): it simply demands “appropriate levels of human judgment,” whatever that means.

It seems that more and more critical decisions will be made ‘on the fly’ from now on.

Link: [Source](https://www.forbes.com/sites/davidhambling/2020/12/11/new-project-will-give-us-mq-9-reaper-drones-artificial-intelligence/?sh=3ae3150a7a8e)

## Should algorithms decide who lives and who dies?

We believe that algorithms should not be empowered to decide who lives and who dies. If you agree, we need your help to demonstrate widespread support for this cause. Will you help us to #BanSlaughterbots, and [take action](https://autonomousweapons.org/take-action) against these weapons?

## Related posts

- [10 Reasons Why Autonomous Weapons Must be Stopped](https://futureoflife.org/2021/11/30/10-reasons-why-autonomous-weapons-must-be-stopped/)
- [Autonomous Weapons: What are they and why does it matter?](https://futureoflife.org/2021/11/23/an-introduction-to-the-issue-of-lethal-autonomous-weapons/)

This content was first published at futureoflife.org on November 22, 2021.

### About the Future of Life Institute

The Future of Life Institute (FLI) is the world’s oldest and largest AI think tank, with a team of 35+ full-time staff operating across the US and Europe. FLI has been working to steer the development of transformative technologies towards benefitting life and away from extreme large-scale risks since its founding in 2014. Find out more about [our mission](https://futureoflife.org/our-mission/) or explore [our work](https://futureoflife.org/our-work/).