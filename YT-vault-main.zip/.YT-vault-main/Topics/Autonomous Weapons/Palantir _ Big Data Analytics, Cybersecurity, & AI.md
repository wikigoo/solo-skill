---
title: "Palantir | Big Data Analytics, Cybersecurity, & AI"
source: "https://www.britannica.com/money/Palantir-Technologies-Inc"
---
Table of Contents

Read More

## Palantir Technologies, Inc.

American company

**Fact-checked by**

Encyclopaedia Britannica's editors oversee subject areas in which they have extensive knowledge, whether from years of experience gained by working on that content or via study for an advanced degree. They write new content and verify and edit content received from contributors.

Updated: Oct. 27, 2026 •Article History

Table of Contents

---

- [Introduction](https://www.britannica.com/money/Palantir-Technologies-Inc#ref__650499)
- [Main products](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428864)
- [2003–2007: Founding and early vision](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428865)
- [2008–2012: Early government contracts and expansion into the commercial sector](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428866)
- [2013–2019: Commercial expansion and technological innovations](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428867)
- [2020: The COVID-19 pandemic](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428868)
- [2021–2025: Strategic partnerships and product growth](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428869)
- [Controversies and public criticism](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428870)
- [Palantir Technologies legacy](https://www.britannica.com/money/Palantir-Technologies-Inc#ref_428871)

Read More

Open full sized image

The seeing stone of Silicon Valley?

© Tada Images/stock.adobe.com

Palantir Technologies is an American-based software company specializing in big data analytics. Headquartered in [Denver](https://www.britannica.com/place/Denver), [Colorado](https://www.britannica.com/place/Colorado-state), the company was founded in 2003 by [Peter Thiel](https://www.britannica.com/money/Peter-Thiel), Alex Karp, Joe Lonsdale, Stephen Cohen, and Nathan Gettings.

[![USA Facts](https://cdn.britannica.com/65/164565-131-90EB726E/Betsy-Ross-patriots-flag-George-Washington-painting.jpg)

Britannica Quiz

USA Facts

](https://www.britannica.com/quiz/usa-facts)

Palantir’s roots trace back to work on [PayPal](https://www.britannica.com/money/PayPal) ’s fraud detection systems, which inspired its founders to develop software capable of identifying suspicious patterns without compromising privacy. The firm gained prominence by working with U.S. intelligence and defense agencies, building tools designed to analyze vast volumes of data. Over time, Palantir expanded into commercial markets, applying its platform to everything from [supply chains](https://www.britannica.com/money/what-is-supply-chain-management) to [health care](https://www.britannica.com/money/health-care-stocks).

## Main products

**Palantir Gotham.** Gotham is Palantir’s flagship platform, designed for intelligence, defense, and law enforcement use. Gotham integrates vast sets of data to detect patterns, identify threats, and derive actionable insights. Initially developed to support counterterrorism, intelligence, and military missions, Gotham has evolved into an [AI-enabled platform](https://www.britannica.com/technology/artificial-intelligence) used by U.S. and allied government agencies for a broad range of national security and law enforcement activities.

**Palantir Foundry.** Tailored for commercial enterprise use, Foundry’s data analytics and predictive modeling capabilities have been adopted across a wide range of industries, including [health care](https://www.britannica.com/money/health-care-stocks), [manufacturing](https://www.britannica.com/money/industrials-stocks), [energy](https://www.britannica.com/money/energy-stocks), and [finance](https://www.britannica.com/money/financial-services-industry). Its customization has found application in several commercial operations such as supply chain management, risk forecasting, and quality assurance. Like all of Palantir’s products, Foundry is now AI-enabled through integration with its artificial intelligence platform (AIP).

**Palantir Apollo.** Launched in 2022, Apollo is like the orchestration engine for Palantir’s platforms. It’s designed to deploy, integrate, and manage platforms across all environments— [cloud](https://www.britannica.com/technology/cloud-computing), on-premises, classified networks, and edge devices ([satellites](https://www.britannica.com/technology/list-of-satellites-2024625), [drones](https://www.britannica.com/art/drone-music), and other disconnected battlefield systems). Apollo is designed for professionals who manage technical infrastructure, including [information technology](https://www.britannica.com/money/information-technology-stocks) (IT) teams, systems administrators, and DevOps engineers—specialists who combine software development with IT operations.

## 2003–2007: Founding and early vision

![Alex Karp, CEO of Palantir Technologies speaks during the Digital X event in Cologne, Germany, 2021.](https://cdn.britannica.com/28/275028-050-4EBA0D60/ceo-of-palantir-techologies-alex-karp-speaks-at-digital-x-event.jpg?w=385)

Open full sized image

Alex Karp helped make Palantir one of the world’s leading data analysis software companies.

© Andreas Rentz/Getty Images

In 2003, Peter Thiel, cofounder of **[PayPal](https://www.britannica.com/money/PayPal)** (PYPL), incorporated Palantir Technologies, bringing on board Stanford Law School colleague Alex Karp as CEO, PayPal engineer Nathan Gettings, and Stanford University students Joe Lonsdale and Stephen Cohen.

The founders’ initial vision was to adapt advanced data analysis technology, initially developed for PayPal’s fraud detection, into a large-scale software platform to enable government agencies to analyze massive amounts of data—particularly for its anti-terrorism efforts—while preserving the civil liberties of American citizens.

Thiel named the company Palantir after the mythical “seeing stones” in [J.R.R. Tolkien](https://www.britannica.com/biography/J-R-R-Tolkien) ’s *[Lord of the Rings](https://www.britannica.com/topic/The-Lord-of-the-Rings)* that allowed its holders to see across great distances. For Thiel, the name symbolized the company’s mission to enable its users to see hidden patterns across immense volumes of data.

During its early [start-up phase](https://www.britannica.com/money/series-funding-explained), Palantir struggled to attract investors. An executive at [venture capital](https://www.britannica.com/money/venture-capitalist-angel-investing) firm Kleiner Perkins reportedly told the founders their company was doomed, a moment that has since become part of Palantir lore. Thiel funded its initial launch, but the company’s first major breakthrough came in 2004 when it secured early backing from In-Q-Tel, the venture capital arm of the [U.S. Central Intelligence Agency](https://www.britannica.com/topic/Central-Intelligence-Agency) (CIA).

## 2008–2012: Early government contracts and expansion into the commercial sector

Palantir launched its first product milestone, Palantir Gotham, in 2008. Designed for large-scale data analysis, integration, and visualization, Gotham was a key platform for the government’s military and intelligence operations. Over time, it would be adopted by law enforcement, as well as become AI-enabled, commercially accessible, and applicable for business use.

Before this, however, Palantir launched a similar data analytics platform that was geared toward the financial sector. In 2010 the company partnered with Thomson Reuters to launch Palantir Metropolis, a finance-oriented analytics platform for financial analytics, risk management, and fraud detection. Although it would be phased out in the mid-2010s, lessons from Metropolis would inform the development of Palantir Foundry, the company’s flagship software for commercial use.

Although still an emerging and privately held company, Palantir’s reputational capital began expanding as rapidly as its adoption and revenue. In 2010, government agencies made up 70% of its clients, the remaining 30% being private financial institutions. Its revenues the following year would hit an estimated $250 million.

## 2013–2019: Commercial expansion and technological innovations

The company’s next product milestone came in 2015 with the introduction of **Palantir Foundry**, a scalable platform designed for private sector companies across a wide range of industries, including [manufacturing](https://www.britannica.com/technology/manufacturing), [supply chain management](https://www.britannica.com/money/what-is-supply-chain-management), [health care](https://www.britannica.com/money/health-care-stocks), [energy](https://www.britannica.com/money/energy-stocks), and [finance](https://www.britannica.com/money/financial-services-industry).

Foundry’s launch marked a pivotal shift, allowing Palantir to expand beyond its traditional government base into global, tech-driven markets. The platform’s success was such that, by its second decade, Palantir had begun opening offices across Europe, Asia, and the Middle East and forming partnerships with major organizations including [**BP**](https://www.britannica.com/money/BP-PLC) (BP), **Merck** (MRK), [**Airbus**](https://www.britannica.com/topic/European-Aeronautic-Defence-and-Space-Company), and the [United Nations](https://www.britannica.com/topic/United-Nations).

Meanwhile, the company continued its acquisition strategy to strengthen its position within the [big data](https://www.britannica.com/technology/big-data) industry. Having made its first acquisition in 2013 with Voicegem, a start-up voice messaging platform, Palantir bought start-ups Kimono Labs and Silk in 2015 and 2016 to strengthen its capabilities in web scraping (automated tools for extracting data from websites) and data visualization (turning complex information into interactive charts and graphics).

In 2018 Morgan Stanley valued the company at $6 billion as Palantir began gearing up for an [initial public offering](https://www.britannica.com/money/ipo-initial-public-offering) (IPO), one that would come to fruition two years later. In the few years leading up to its IPO, there was general skepticism regarding the company’s valuation. Essentially, analysts’ estimates were mixed, but in a perplexed manner that’s best underscored by a Bloomberg opinion piece with the headline “Nobody Knows What Palantir Is Worth.”

As Palantir’s valuations increasingly became a central theme on Wall Street, a global shock that would prove a significant test for the company’s global capacity and adoption would emerge the following year in [China](https://www.britannica.com/place/China) ’s [Wuhan](https://www.britannica.com/place/Wuhan) province.

## 2020: The COVID-19 pandemic

When the COVID-19 pandemic struck, prompting lockdowns in almost every country worldwide, government agencies in the U.S., U.K., the Netherlands, and Colombia tapped Palantir for software to coordinate agency efforts and to gather and assess a wide assortment of up-to-date data such as testing and infection rates, hospitalizations, mortality, and the broader impact of stay-at-home orders. Once vaccines were available, Palantir developed Tiberius, a platform to track vaccine distributions.

The significance of this period lay in more than a technological pivot from intelligence to commercial applications. Palantir’s software filled a critical gap in the ability of governments to collect, analyze, coordinate, and track real-time health data.

By developing tools that enabled agencies to make rapid decisions during the global pandemic, Palantir positioned itself as a key player in public health and emergency response. This visibility, however, would also prove to be a double-edged sword, reinforcing public unease over privacy as governments expanded their data gathering and surveillance capabilities.

At this time, Palantir moved its headquarters to Denver, Colorado, and completed its IPO, with shares listed on the [New York Stock Exchange](https://www.britannica.com/money/New-York-Stock-Exchange) (NYSE) under the ticker symbol PLTR.

## 2021–2025: Strategic partnerships and product growth

Following its high-stakes debut and expansion during the pandemic, Palantir formed partnerships with **[IBM](https://www.britannica.com/money/International-Business-Machines-Corporation)** (IBM) and **[Amazon](https://www.britannica.com/money/Amazoncom) Web Services** (AWS) to integrate its software across hybrid cloud environments. This was a critical move, as it allowed Palantir to capitalize on the business migration trend from on-premises systems to cloud infrastructure. It also increased the company’s scale, not only beyond government contracts and commercial deals, but also into large-scale (“enterprise”) deployments by major corporations.

In 2023 Palantir launched its artificial intelligence platform (AIP), which brought [large language models](https://www.britannica.com/topic/large-language-model) into business operations by connecting them to company-specific data. The goal: to help organizations make faster, smarter decisions using AI tools tailored to their internal systems.

In 2024 the company expanded its partnership with **[Microsoft](https://www.britannica.com/money/Microsoft-Corporation)** (MSFT) Azure to bolster cloud, analytics, and AI services for U.S. governmental and defense agencies. That same year, it switched its stock listing from the NYSE to the [Nasdaq](https://www.britannica.com/money/NASDAQ) exchange (retaining its PLTR ticker symbol), hoping to increase its visibility among tech peers and qualify for the Nasdaq-100 index—a goal it achieved the following year.

While its strengthened relationship with Azure reflects Palantir’s origins in serving government clients, its global expansion intensified long-standing debates over its potential use in public sector surveillance.

## Controversies and public criticism

![A protest march with people holding signs and Palestinian flags, protesting against Palantir’s involvement in the NHS, in an urban setting.](https://cdn.britannica.com/30/275030-050-2C024B7E/people-protesting-palantir-nhs-involvement.jpg?w=385)

Open full sized image

The “No Palantir in our NHS” campaign of the early 2020s.

© Vasile Jechiu/Dreamstime.com

Given the sensitive nature of its work—often involving government surveillance, law enforcement, and national security—it’s not surprising that Palantir has drawn public scrutiny. The same capabilities that make its software powerful for data analysis and intelligence have also raised concerns about privacy, ethics, and civil liberties. Here are a few issues that have drawn the most sustained criticism in the early 2020s.

**The [Russia-Ukraine War](https://www.britannica.com/event/Russia-Ukraine-War).** Palantir’s software aided the Ukrainian military in tracking Russian positions and movements and documenting war crimes. Although the latter can be seen as a constructive use of the company’s technology, critics were suspicious of the broader implications of advanced data analytics in the hands of the military.

**The “No Palantir in our NHS” campaign.** Palantir’s involvement with the U.K.’s National Health Service (NHS) dates back to 2020, but a major contract signed in 2023 sparked widespread controversy. Civil liberties activists raised concerns about the company’s use of predictive analytics, warning it could pave the way for public surveillance and data-driven profiling.

**Palantir’s alleged role in the [Israel-Gaza conflict](https://www.britannica.com/event/Israel-Hamas-War).** In 2024, Palantir partnered with the Israeli Defense Forces (IDF) during a military campaign in Gaza. The IDF’s use of Palantir’s technology drew international backlash, with human rights organizations criticizing Palantir’s advanced surveillance and targeting technologies amid allegations of disproportionate force against Palestinian civilians.

**Racial profiling and predictive policing.** Palantir’s predictive policing software, used by police departments in [Los Angeles](https://www.britannica.com/place/Los-Angeles-California) and [New Orleans](https://www.britannica.com/place/New-Orleans-Louisiana), has faced criticism not only for its implementation but also for the very concept of predictive policing. Critics have expressed concern that Palantir’s technology could reinforce [algorithmic biases](https://www.britannica.com/money/ai-ethical-issues) that may, in turn, contribute to increased racial profiling and disproportionate policing of minority groups.

**Immigration and Customs Enforcement (ICE) operations.** Palantir’s contract with ICE dates back to 2014 and the [Obama administration](https://www.britannica.com/biography/Barack-Obama). It was awarded a $30 million contract in 2025 to build new tools to help in various ICE operations, including its controversial deportation and detention efforts. The company’s involvement sparked national backlash among immigrant rights groups, civil liberties advocates, and concerned citizens.

## Palantir Technologies legacy

Palantir stands as one of the most consequential and controversial data analytics firms of the early 21st century. Straddling the worlds of enterprise software, national security, and AI, its rise highlights a broader tension within the industry: The same tools enabling unprecedented insight and efficiency can also enable digital surveillance and profiling. Palantir’s legacy is one of polarization—celebrated for its technical power, yet persistently questioned for how that power is used.

This article was most recently revised and updated by