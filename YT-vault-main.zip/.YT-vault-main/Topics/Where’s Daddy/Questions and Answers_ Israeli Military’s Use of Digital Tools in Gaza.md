---
title: "Questions and Answers: Israeli Military’s Use of Digital Tools in Gaza"
source: "https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza"
---
[<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 700" preserveAspectRatio="xMinYMin"><title>Human Rights Watch</title><path fill="#0071CE" d="M0 700h700V0H0z"></path><path fill="#fff" d="M177 232v-56h-12v22h-16v-22h-11v56h11v-25h16v25zm94-18v-38h-12v41c0 4-3 6-8 6-4 0-7-1-8-4l-1-6v-37h-11v39c0 5 0 7 2 10 3 5 9 8 18 8 12 0 18-6 19-11l1-8zm110 18l-5-56h-14l-8 28-2 9-2-9-7-28h-15l-5 56h11l2-29 1-11 2 10 8 30h10l8-31 3-8v9l2 30h11zm94 0l-17-56h-12l-19 56h12l4-13h16l4 13h12zm-18-23h-11l3-10 2-11 3 10 3 11zm105 23v-56h-11l1 23 1 15-7-16-10-22h-13v56h11v-24l-1-16 8 18 9 22h12zM178 380l-13-22-2-3c7 0 12-7 12-15 0-10-6-17-16-17h-21v57h11v-24l2 1c2 1 3 3 9 13l5 10h13zm-15-40c0 3 0 5-2 6-1 1-3 2-8 2h-4v-15h10c3 1 4 4 4 7zm70 40v-57h-12v57zm88-5v-27h-22l2 10h8v12l-6 2c-4 0-7-1-9-3-3-3-4-8-4-16 0-9 1-15 5-18 2-2 4-3 8-3s8 1 11 4l6-7c-4-4-11-6-17-6s-10 1-14 4c-8 5-12 13-12 25 0 8 2 14 6 20 5 5 11 8 19 8 7 0 13-1 19-5zm85 5v-57h-11v22h-16v-22h-12v57h12v-25h16v25zm83-57h-41v10h14v47h12v-47h13zm78 39c0-8-5-14-14-17l-7-2c-5-1-6-2-6-5 0-4 3-7 8-7 4 0 8 1 13 5l5-9c-5-3-12-5-19-5-12 0-20 7-20 17l3 9c2 3 5 5 11 7l6 1c5 2 7 4 7 8 0 5-3 7-10 7-5 0-10-1-15-4l-4 9c5 3 13 5 19 5 14 0 23-8 23-19zM199 471h-12l-4 21-3 19-3-15-5-25h-12l-5 23-3 18-3-19-5-22h-12l14 57h12l5-23 3-16 2 16 5 23h13l13-57zm95 56l-17-56h-13l-18 56h12l4-13h16l4 13h12zm-19-22h-10a160 160 0 005-22 1386 1386 0 015 22zm103-34h-40v10h14v46h11v-46h13zm90 52l-5-7c-4 3-7 3-10 3-5 0-8-2-11-6-1-3-2-7-2-15 0-6 1-11 3-14s6-5 10-5l9 3 5-8c-3-2-9-4-15-4-9 0-17 5-21 13-3 5-4 10-4 17 0 9 2 15 7 20 5 6 11 8 18 8s11-1 16-5zm94 4v-56h-11v22h-16v-22h-12v56h12v-25h16v25z"></path></svg>](https://www.hrw.org/)

[Donate Now](https://donate.hrw.org/page/107245/donate/1?ea.tracking.id=EP2022EVpgdonate&promo_id=1000)

![A technologist with the Israeli military's Matzpen operational data and applications unit works at his station, at an Israel Defense Force base in Ramat Gan, Israel, June 11, 2023. ](https://www.hrw.org/sites/default/files/styles/embed_xxl/public/media_2024/09/202409mena_israel_military_technology.JPG?itok=6ebWBb9f)

A technologist with the Israeli military's Matzpen operational data and applications unit works at his station, at an Israel Defense Force base in Ramat Gan, Israel, June 11, 2023. © 2023 Nir Elias/Reuters

Following the attack by Hamas-led Palestinian armed groups in southern Israel on October 7, 2023, there has been [extensive](https://www.nytimes.com/2023/10/16/world/middleeast/gaza-invasion-israel-cellphone-data.html) [reporting](https://www.972mag.com/mass-assassination-factory-israel-calculated-bombing-gaza/) on the Israeli military’s [use of digital](https://www.972mag.com/lavender-ai-israeli-army-gaza/) [tools](https://www.theguardian.com/world/2024/apr/03/israel-gaza-ai-database-hamas-airstrikes) in their operations in the Gaza Strip. The Israeli military reportedly uses surveillance technologies, artificial intelligence (AI), and other digital tools to help determine who or what to attack in Gaza and when.

Human Rights Watch found that four digital tools that the Israeli military is using in Gaza use faulty data and inexact approximations to inform military actions. The Israeli military’s use of these digital tools risk Israeli forces violating international humanitarian law, in particular the laws of war concerning distinction between military targets and civilians, and the need to take all feasible precautions before an attack to minimize civilian harm.

Human Rights Watch research indicates that the tools apparently rely on ongoing and systematic Israeli surveillance of all Palestinian residents of Gaza, including with data collected prior to the current hostilities in a manner that is incompatible with international human rights law. The tools use Palestinians’ personal data to inform military actions like threat predictions, and the identification of targets. Some tools rely on machine learning, which is the use of computerized systems that can draw inferences from data and recognize patterns without explicit instructions.

It has not been possible to document when and where these digital tools are being used or the extent to which these tools have been used in conjunction with other methods of information and intelligence collection. Nonetheless the Israeli military’s use of these tools, instead of helping to provide more accurate targeting and minimize civilian loss of life and property, may be exacerbating the risk to civilians and raises grave ethical, legal, and humanitarian concerns.

This question-and-answer document provides technical and legal analyses of four digital tools; lays out new risks, challenges, and questions raised by these tools; and assesses each against applicable international law.

This document is based on public statements from Israeli officials, media reports, interviews with experts and journalists, and previously unreported material published by the Israeli military, including the personal data of Gaza residents, published online apparently in error.

1. [**What are some of the digital tools that the Israeli military is using in Gaza?**](#_What_are_some)
2. [**What is the Israeli military’s evacuation monitoring tool and how does it work?**](#_What_is_the)
3. [**Is the cell tower triangulation data accurate enough to inform military decisions?**](#_Is_the_cell)
4. [**What else is known about the data the evacuation monitoring system uses?**](#_What_else_is)
5. [**What is “Lavender” and how does it work?**](#_What_is_“Lavender”)
6. [**On which grounds does Lavender assign suspicion?**](#_On_which_grounds)
7. [**Why are Lavender’s ratings problematic and risky?**](#_Why_are_Lavender’s)
8. [**What is “The Gospel” and how does it work?**](#_What_is_“The)
9. [**What is “Where’s Daddy?” and how does it work?**](#_What_is_"Where’s)
10. [**Is mobile phone location data alone sufficiently accurate for targeted strikes?**](#_Is_mobile_phone)
11. [**What are the limitations of systems that rely on big data, machine learning, and AI?**](#_What_are_the)
12. [**What new risks and challenges do data intensive digital tools present in military contexts?**](#_What_new_risks)
13. [**Are the digital tools used by the Israeli military autonomous weapon systems?**](#_Are_the_digital)
14. [**How does international humanitarian law apply to the military use of digital tools?**](#_How_does_international)
1. **What are some of the digital tools that the Israeli military is using in Gaza?**

Human Rights Watch assessed four tools that the Israeli military has used in its ongoing offensive in Gaza related to military planning and targeting. One is based on mobile phone tracking to monitor the evacuation of Palestinians from parts of northern Gaza. Another, which the military calls “The Gospel,” generates lists of buildings or other structural targets to be attacked. Another, which the military calls “Lavender” assigns ratings to people in Gaza related to their suspected affiliation with Palestinian armed groups for purposes of labeling them as military targets. “Where’s Daddy?” purports to determine when a target is in a particular location so they can be attacked there.

2. **What is the Israeli military’s evacuation monitoring tool and how does it work?**

The Israeli military began bombing Gaza on October 7, 2023, shortly after Palestinian armed groups launched an [assault](https://www.hrw.org/news/2024/07/17/october-7-crimes-against-humanity-war-crimes-hamas-led-groups) on southern Israel. On October 13, it issued evacuation orders to all residents of northern Gaza, where more than one million people lived, to evacuate to the south of Wadi Gaza within 24 hours, despite there being [no safe place to go](https://www.hrw.org/news/2023/10/13/nowhere-go-gaza), no safe route to travel, and [no adequate shelter](https://www.hrw.org/news/2023/10/16/why-israels-gaza-evacuation-order-so-alarming).

The Israeli military’s evacuation monitoring tool relies on cell phone location data to monitor people’s movement in Gaza. Based on the [New York Times](https://www.nytimes.com/2023/10/16/world/middleeast/gaza-invasion-israel-cellphone-data.html) reporting published on October 16, one week before the Israeli military began major ground operations in northern Gaza, this system was being used by the military to monitor the evacuation of Palestinians from their homes north of Wadi Gaza. The [*Washington Post*](https://www.washingtonpost.com/world/2023/12/06/israel-gaza-civilians-protection/) and the [Guardian](https://www.theguardian.com/world/2023/dec/01/the-gospel-how-israel-uses-ai-to-select-bombing-targets) both later published additional details about this system.

Journalists described being shown an office in the southern command headquarters in the Israeli city of Beer Sheva, with large screens with a map of Gaza, divided into 620 sections, each colored depending on the degree to which residents had evacuated. The map also included labels for hospitals, mosques, shelters, and other structures. Reports put the number of mobile phones tracked at the time at over one million; before October 2023 the Gaza telecommunications ministry [reported](https://www.pcbs.gov.ps/post.aspx?lang=en&ItemID=5755) a total of 1,041,198 active mobile phone subscriptions in Gaza.

According to these reports, the system uses cell tower triangulation and other surveillance data to provide a live view of Gaza residents’ movements. Israeli military officers told journalists that this information was used to inform what actions the military could take in certain places, and what types of weapons they would use.

3. **Is the cell tower triangulation data accurate enough to inform military decisions?**

Cell tower triangulation data, in which a mobile phone’s location is approximated based on the cell towers it can connect to, is unlikely to give accurate information as to the precise whereabouts of mobile devices and thus the people holding them. The inaccuracy would be exacerbated by lack of electricity to charge phones after Israel cut all power lines to Gaza and Gaza’s sole power station ceased functioning because of the [blockade on fuel imports](https://www.hrw.org/news/2023/11/15/gaza-communications-blackout-imminent-due-fuel-shortage) and by [massive](https://www.npr.org/2024/03/03/1229402063/gaza-communications-cell-phone-internet-service-blackouts-paltel) [damage](https://www.nytimes.com/2024/03/13/world/middleeast/gaza-phone-networks.html) to Gaza’s telephone infrastructure.

Tools that use cell tower triangulation data to calculate civilian presence as a way of informing decisions related to military operations increase the risk of civilian harm in those operations. The tools could lead military commanders to conclude wrongly that there were no or few civilians present in a certain area and that this area could therefore be attacked.

4. **What else is known about the data the evacuation monitoring system uses?**

In May 2024, Human Rights Watch discovered data posted publicly online by the Israeli military, apparently erroneously, that included what appears to be operational data related to systems used for monitoring the evacuation and movement of people through Gaza, as well as for projecting the likely civilian harm that would be caused by attacks in particular areas.

This data was included in the source code of the Israeli military’s evacuation information website. The data contained population figures consistent with 10-year-old census data from Gaza, disaggregated population data, information about civilian population movements, the Israeli military’s presence in Gaza, and a cumulative number of attacks, for each of the 620 blocks dividing the Gaza Strip. The data also included personal information: the surnames of the most populous extended families in each block.

Human Rights Watch analyzed and mapped this data related to Israel’s military presence and found it to be consistent with the state of the Israeli incursion into Gaza in mid-November 2023, when Israeli forces controlled most of northern Gaza and had not yet entered Khan Yunis in the south. While Human Rights Watch could not definitively confirm the origin and use of the information published online, it resembles the data described in media reports related to the evacuation monitoring system, as well as for planning military operations. The evacuation monitoring system may also rely on other sources of data. Human Rights Watch notified the Privacy Protection Authority, Israel’s data protection authority, about the publication of this data.

![The destruction after an Israeli strike on residential buildings and a mosque in Rafah, Gaza Strip, February 22, 2024. ](https://www.hrw.org/sites/default/files/styles/embed_xxl/public/media_2024/09/202409mena_palestine_israel_destruction_gaza.jpg?itok=SIwx9_sN)

The destruction after an Israeli strike on residential buildings and a mosque in Rafah, Gaza Strip, February 22, 2024. © 2024 Fatima Shbair/AP Photo

5. **What is “Lavender” and how does it work?**

Lavender uses machine learning to assign residents of Gaza a numerical score relating to the suspected likelihood that a person is a member of an armed group. Based on reports, Israeli military officers are responsible for setting the threshold beyond which an individual can be marked as a target subject to attack.

The military has acknowledged the existence of a tool like Lavender [in very general terms](https://www.theguardian.com/world/2024/apr/03/israel-defence-forces-response-to-claims-about-use-of-lavender-ai-database-in-gaza), calling it a “database whose purpose is to cross-reference intelligence sources.”

A presentation and book by two Israeli officers provide important technical details. In a February 2023 [presentation](https://www.youtube.com/watch?v=CJvOoX7dK1M), the head of AI and data science at Unit 8200, the military’s signals intelligence division, described a digital tool that uses machine learning “for finding new terrorists.” The system, which the officer says was first used in Gaza in 2021, compiles surveillance data to rate people based on their suspected likelihood of association with a militant group.

The tool described in the presentation, which Human Rights Watch believes to be either Lavender or another tool that relies on the same underlying technology, involves a type of semi-supervised machine learning called [“positive unlabeled learning,”](https://link.springer.com/article/10.1007/s10994-020-05877-5) which trains an algorithm from a dataset containing both labeled (positive) and unlabeled (negative) data. This type of machine learning uses qualities about the labeled data to try to identify patterns in the larger dataset. In this case, the algorithm looks for characteristics in surveillance and other data about individuals whom the Israeli military suspects of having affiliation to a militant group and then uses those same characteristics to identify more suspected people out of the general population. Because many data points would be unconfirmed if this technique were applied to a large population, this process relies to a large degree on unsubstantiated guesswork.

6. **On which grounds does Lavender assign suspicion?**

Without access to Lavender, it is impossible to know fully which data points the tool uses to raise someone’s suspicion score. In general, semi-supervised machine learning relies on an algorithm to process large quantities of data and then establish which types of data are useful to carry out a given task. The 2021 [book by Yossi Sariel, the head of Unit 8200](https://www.amazon.com/Human-Machine-Team-Artificial-Intelligence-Revolutionize/dp/B0948LGS3K), on military uses of AI may provide some insight. Sariel describes a “target machine” with characteristics very similar to Lavender that can be used to identify potential targets by collecting and analyzing their social connections, much like a social media platform.

Qualities described by Sariel that could contribute to someone being assigned a higher degree of suspicion include their social connections or associations, membership of a chat group with someone the Israeli military already believes to be associated with a militant group, or even merely changing phones or addresses repeatedly.

7. **Why are Lavender’s ratings problematic and risky?**

Lavender’s ratings have serious flaws that could put civilians at grave risk during armed conflict. Positive unlabeled learning ([see question 5](#_What_is_“Lavender”)) is not an adequate tool for informing decisions about identifying lawful military targets. Assumptions that lead to a tool assigning suspicion are not rooted in international humanitarian law but rather criteria developed by an algorithm and based on data that is likely biased and incomplete, and technically impossible to scrutinize.

This reliance on likely flawed assumptions to inform military decisions could lead to civilians erroneously being targeted. Lavender compiles data on the behavior and connections of large numbers of individuals to assign them a suspicion score. With [predictive policing tools](https://www.hrw.org/news/2017/11/19/china-police-big-data-systems-violate-privacy-target-dissent), the guilt of the general population is presumed by processing surveillance data on individuals who are not suspected of having committed a crime, violating their right to the presumption of innocence. In a wartime context, this means creating presumptions about their status as military objectives subject to lawful attack, when the laws of war make a presumption of civilian status. Furthermore, the use of semi-supervised machine learning can lead to false positives by identifying people as suspicious based on qualities or behaviors that are not in any way illegal, threatening, or problematic, influencing outputs.

The authorities’ use of broad definitions of terrorism and terrorist groups, and the [reliance on broad provisions of Israeli military law](https://www.hrw.org/report/2019/12/17/born-without-civil-rights/israels-use-draconian-military-orders-repress#6222) in the Occupied Palestinian Territory to ban associations as “hostile organizations” raises additional concerns. In the West Bank, for instance, the military has banned Palestinian human rights organizations as “terrorist groups,” and detained Palestinians for mere membership in, or identification with, such groups or entities affiliated with them.

If similar broad definitions were used in the training of machine learning tools like Lavender, intended to inform targeting decisions, the outputs would face similar biases and could increase the possibility of civilians being targeted for attack.

8. **What is “The Gospel,” and how does it work?**

“The Gospel” uses an algorithm to process surveillance data to generate lists of targets. Based on media reports, The Gospel identifies four categories of nonhuman targets: military targets, including underground targets like tunnels; family homes of suspected militants; and “ [power targets](https://www.hrw.org/news/2023/12/20/joint-ngo-letter-secretary-austin-urging-action-protect-civilians-gaza),” which are civilian structures that are attacked with the stated goal, according to current and former intelligence analysts quoted in media reports, of “creat\[ing\] a shock” that will “lead civilians to put pressure on Hamas." Articles on the Israeli forces’ website from 2020 and 2023 [describe](https://www.idf.il/%D7%90%D7%AA%D7%A8%D7%99-%D7%99%D7%97%D7%99%D7%93%D7%95%D7%AA/%D7%90%D7%92%D7%A3-%D7%94%D7%9E%D7%95%D7%93%D7%99%D7%A2%D7%99%D7%9F/%D7%9B%D7%9C-%D7%94%D7%9B%D7%AA%D7%91%D7%95%D7%AA/2020/%D7%9E%D7%A0%D7%94%D7%9C%D7%AA-%D7%94%D7%9E%D7%98%D7%A8%D7%95%D7%AA-%D7%94%D7%9E%D7%98%D7%9B-%D7%9C%D7%99%D7%AA-%D7%90%D7%9E-%D7%9F/) an algorithm-based tool closely resembling The Gospel, with the latter [mentioning the tool](https://www.idf.il/%D7%90%D7%AA%D7%A8%D7%99-%D7%99%D7%97%D7%99%D7%93%D7%95%D7%AA/%D7%99%D7%95%D7%9E%D7%9F-%D7%94%D7%9E%D7%9C%D7%97%D7%9E%D7%94/%D7%9B%D7%9C-%D7%94%D7%9B%D7%AA%D7%91%D7%95%D7%AA/%D7%94%D7%A4%D7%A6%D7%95%D7%AA/%D7%9E%D7%9C%D7%97%D7%9E%D7%94-%D7%9E%D7%98%D7%A8%D7%95%D7%AA-%D7%A9%D7%94%D7%95%D7%AA%D7%A7%D7%A4%D7%95-%D7%9B%D7%95%D7%97%D7%95%D7%AA-%D7%A6%D7%94-%D7%9C-%D7%90%D7%92%D7%A3-%D7%94%D7%9E%D7%95%D7%93%D7%99%D7%A2%D7%99%D7%9F-%D7%97%D7%99%D7%9C-%D7%94%D7%90%D7%95%D7%95%D7%99%D7%A8-%D7%97%D7%99%D7%9C-%D7%94%D7%99%D7%9D/) by name.

There is less information available about how The Gospel functions than about Lavender, but it is likely that it also uses positive unlabeled learning to make its determinations. The Gospel is, in effect, a tool being used to determine which structures are considered civilian objects and military objectives, a process of distinction that attackers are required to make under the laws of war.

9. **What is** “ **Where’s Daddy?**” **and how does it work?**

Based on media reports, “Where’s Daddy” is a tool that uses mobile phone location tracking to notify Israeli military operators when people who have been marked as military targets enter a specific location – according to reports, often a family home – where they can be attacked. Human Rights Watch was able to confirm that the Israeli military is using a tool with this functionality, but could not confirm any other specific technical details.

10. **Is mobile phone location data alone sufficiently accurate for targeted strikes?**

Mobile phone location data [is not sufficiently accurate](https://www.hrw.org/news/2020/05/13/mobile-location-data-and-covid-19-qa) to establish that a specific person is in a place at a specific time, and could lead to deadly errors if used to inform military attacks. A mobile phone is not a reliable proxy for a human target, as people, especially in conflict zones, may change numbers or devices during an emergency where access to networks and devices may frequently and suddenly change.

In addition, the most common methods for tracking cell phone location are through [triangulating cell tower locations](https://www.researchgate.net/publication/221568410_Accuracy_Characterization_of_Cell_Tower_Localization), called cell site location information, or through gaining access to a [mobile phone's GPS data](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6638960/). Neither of these systems alone [are accurate enough](https://www.gps.gov/systems/gps/performance/accuracy/#speed) to determine a mobile phone’s location for precision attacks, and their use in targeting decisions raises concern about a failure to take all feasible precautions to avoid civilian harm, as required by the laws of war.

11. **What are the limitations of systems that rely on big data, machine learning, and AI?**

These systems are limited by several assumptions and the tendency to reproduce society’s biases.

**“Black box effect”:** Machine learning, AI, and other algorithmic systems, by design, [do not allow for scrutiny](https://www.frontiersin.org/journals/human-dynamics/articles/10.3389/fhumd.2024.1421273/full), or show their work or decision-making processes around how outputs are generated, and they [lack documentation](https://www.hrw.org/news/2023/07/12/eu-artificial-intelligence-regulation-should-protect-peoples-rights) to support apportioning responsibility to relevant actors. It is important for digital tools to allow users to check the systems’ work, to see how outputs were made, and using which data. [This is especially important](https://www.hrw.org/news/2016/04/11/killer-robots-and-concept-meaningful-human-control) in the case of weapons or forms of target generation that use AI.

**“Automation bias”:** Automation bias is when people put excessive trust in the outputs of digital tools, in part because of the perception that they are more neutral than human beings. Studies have found that the use of digital tools, including in military applications, [can lead to reduced scrutiny](https://academic.oup.com/jicj/article/21/5/1077/7281035) over their outputs, and even to trust in, and continue reliance on, automated outputs in the face of contradictory information.

**Problematic assumptions**: All digital systems rely on core assumptions to work; these are the facts upon which calculations are based (for a TV series recommendation tool, that would be like saying if someone often watches science fiction series, then the tool should recommend them more science fiction). While instructions and parameters for machine learning and AI-based systems are set by developers, these assumptions are not explicitly written by programmers, but rather developed by algorithms based on initial training data. Tools based on this technology process large quantities of data with a specific output or goal in mind, and then are able to draw their own conclusions (still, it is the owners, developers and users of this technology who ultimately bear responsibility for how algorithm-based systems are used). This method may work for some low-stakes applications like TV recommendations, but it raises grave concerns when used in military contexts, where there are life and death consequences.

**Reproducing society’s biases:** In addition, while the output of algorithmic systems might seem neutral, machines [are likely to reflect](https://www.hrw.org/news/2023/03/08/expert-panel-social-and-humanitarian-impact-autonomous-weapons-latin-american-and) the biases of their programmers and society. This risk is especially high with the development and use of digital tools that inform decisions whether people or objects can be attacked as a military target. In the context of the Israeli military and the hostilities in the Occupied Palestinian Territory, for example, the International Court of Justice (ICJ) found in July that Israel perpetrates discrimination and [apartheid against Palestinians](https://www.hrw.org/report/2021/04/27/threshold-crossed/israeli-authorities-and-crimes-apartheid-and-persecution). Digital tools developed and used by the Israeli military for targeting people in the occupied territory could reflect such systemic discrimination and biases.

**“Garbage in, garbage out”:** Flawed data make for flawed results. If a digital system is built on data that is inaccurate, dated, incomplete, or not fully representative of the context in which it is seeking to operate, its outputs [will be similarly flawed](https://www.nature.com/articles/d41586-023-03316-8).

12. **What new risks and challenges do data intensive digital tools present in military contexts?**

Digital tools used in a military context [create new risks and challenges](https://www.stopkillerrobots.org/stop-killer-robots/facts-about-autonomous-weapons/) through their reliance on invasive surveillance, digital dehumanization, and the possibility of a military’s overreliance on digital tools, and that those tools could increase the tempo of war.

Tools that employ machine learning and AI rely on enormous quantities of data to produce outputs such as threat predictions, target identification, etc. Palestinians in Gaza and in the West Bank [are](https://7amleh.org/2023/12/19/7amleh-center-issues-a-report-on-israel-s-surveillance-industry-and-its-impact-on-human-rights) [under](https://www.amnesty.org/en/documents/mde15/6701/2023/en/) [constant](https://www.washingtonpost.com/world/middle_east/israel-palestinians-surveillance-facial-recognition/2021/11/05/3787bf42-26b2-11ec-8739-5cb6aba30a30_story.html), [pervasive](https://www.hrw.org/news/2023/06/06/palestinian-forum-highlights-threats-autonomous-weapons) [surveillance](https://www.hrw.org/news/2021/11/08/spyware-used-hack-palestinian-rights-defenders) by Israeli authorities, and some of this data is now being used to inform military operations and planning in Gaza.

Prior to the current hostilities, Israel as an occupying power maintained significant control over aspects of life in Gaza, creating obligations under both international human rights law as well as international humanitarian law to ensure the welfare of the population. Article 17 of the [International Covenant on Civil and Political Rights](https://www.ohchr.org/en/instruments-mechanisms/instruments/international-covenant-civil-and-political-rights) (ICCPR), to which Israel is party, affirms the right to privacy, which may not be subject to arbitrary or unlawful interference.

The United Nations Human Rights Committee, the international expert body that authoritatively interprets the ICCPR, [has held](https://juris.ohchr.org/casedetails/702/en-US) that “any interference with privacy must be proportional to the end sought and be necessary in the circumstances of any given case.” Governments are obligated to respect the privacy rights of individuals, regardless of their nationality or location, given that digital technology enables far-reaching extraterritorial surveillance.

The Israeli government has obtained and stored data from Gaza in ways that appear to violate the internationally protected right to privacy and other human rights. This is particularly problematic as Israel’s surveillance of Palestinians in Gaza is inextricably tied to a system of rights violations that amount to a policy of apartheid.

During armed conflict, human rights law needs to be interpreted against the backdrop of international humanitarian law. Thus, what amounts to “arbitrary or unlawful” interference with privacy prohibited by Article 17 of the ICCPR may be different when taking into account the laws of war, which is the controlling body of law (“lex specialis”) after hostilities are triggered.

[**Digital dehumanization:**](https://www.hrw.org/news/2023/03/03/digital-dehumanization-paves-way-killer-robots) Automated systems reduce humans to a series of data points, to be processed by systems that inherently have bias and limitations based on their programming. Once human beings are reduced to data points, surveilled, sorted, and categorized, it may [make it easier](https://www.stopkillerrobots.org/stop-killer-robots/digital-dehumanisation/identity_2-0-on-digital-dehumanisation/) to decide who should be subjected to harm, including targeting for lethal action, and to carry out those actions. This trajectory from automated surveillance to harm is called “digital dehumanization.”

**Overreliance on digital tools:** In a fast-paced, stressful environment, or where there is pressure to generate large numbers of targets in a short period of time, such as during armed conflict, there is a tendency to over-rely on digital systems that can produce outputs at a fast pace. The International Committee of the Red Cross (ICRC) [has identified this as a risk](https://www.icrc.org/en/document/artificial-intelligence-and-machine-learning-armed-conflict-human-centred-approach) for big data, machine learning, and AI-based systems that are used to inform military options, noting that it could facilitate error-prone decisions, violations of the laws of war, and increase the likelihood of civilian harm.

**Increasing the tempo of war:** The ICRC has also identified the ability for digital systems to speed up the tempo of war as a risk factor for civilians, especially if an increased operational speed prevents thorough analysis and scrutiny of information sources used in military planning. Israeli military officers have said publicly that the digital tools for target generation have allowed officers to generate in a matter of days the same number of targets that, before the use of these tools, would take one year.

13. **Are the digital tools used by the Israeli military autonomous weapon systems?**

The Israeli military’s digital tools are not autonomous weapon systems: weapons that select and engage targets based on sensor processing rather than human inputs, and for which Human Rights Watch has long sought a treaty ban. Instead, they are data processing systems that provide information to Israeli military planners. The decision about whether to attack a recommended target is made and carried out separately by a human and not a machine. Each digital tool requires human input and oversight.

But a [UN Human Rights Council resolution](https://undocs.org/Home/Mobile?FinalSymbol=A%2FHRC%2F51%2FL.25&Language=E&DeviceType=Desktop&LangRequested=False) adopted in October 2022 stresses the central [importance of human decision-making](https://www.hrw.org/news/2022/11/28/future-artificial-intelligence) in the use of force. It warns against relying on nonrepresentative data sets, algorithm-based programming, and machine-learning processes. Such technologies can reproduce and exacerbate existing patterns of discrimination, marginalization, social inequalities, stereotypes, and bias, with unpredictable outcomes.

The Israeli military’s digital tools present similar problems to autonomous weapons systems. They operate in ways that are difficult or, in the case of the machine learning algorithms used by Lavender and The Gospel, impossible to check, source, or verify. At the same time, they encourage overreliance by appearing to be accurate and unbiased.

14. **How does international humanitarian law apply to the military use of digital tools?**

Digital tools are not military weapons. However, their use in military operations subjects them to the restrictions of international humanitarian law. As the ICRC [has noted,](https://www.icrc.org/sites/default/files/document_new/file_list/ai_and_machine_learning_in_armed_conflict-icrc.pdf) “Any new technology of warfare must be used, and must be capable of being used, in compliance with existing rules of international humanitarian law.”

Lavender and The Gospel raise important – and potentially deadly – issues with respect to military targeting, the determination as to whether an intended target can be lawfully attacked and under what circumstances. Two general rules found in international treaty law and customary law are most pertinent: 1) the requirement that attacking forces [distinguish](https://ihl-databases.icrc.org/en/customary-ihl/v1/rule7) between military objectives and civilians and civilian objects, and only attack the former; and 2) the requirement that attacking forces [take all feasible precautions](https://ihl-databases.icrc.org/en/customary-ihl/v1/rule15) to minimize incidental loss of civilian life and damage to civilian objects.

Lavender and The Gospel rely on machine learning to distinguish between military objectives and civilians and civilian objects. If their recommendations or assessments of the digital tools are acted upon without sufficient scrutiny or any additional information, as has been reported, resulting in attacks causing civilian harm, Israeli forces would be violating the laws of war in carrying out attacks, which could amount to war crimes.

The Where’s Daddy? tool purportedly uses mobile phone location tracking to notify military operators when people who have been marked as military targets enter a specific location, such as a family home. The laws of war do not prohibit attacks on valid military targets such as military commanders when they are at home, but all the legal requirements still apply. It’s not clear that these other factors – such as whether the attack is causing disproportionate civilian harm compared to the military advantage of the attack – are being considered.

These tools also raise concerns when standards not found under international law are applied. Using machine learning to label someone a “terrorist” – a term not defined under international human rights or humanitarian law – may subject someone to arrest or lethal attack without meeting the evidentiary requirements of criminal wrongdoing that international law requires. Attacks against so-called power targets – large civilian structures reportedly identified by The Gospel for targeting due to the presumed psychological impact of destroying them – is not an accepted concept under international humanitarian law. Attacking them would still require that they meet the principles of distinction, proportionality, and precaution.

## Every piece on our website is resource intensive. If you donate whatever you can today, we will use it to continue investigating abuses and advocate for change in 100+ countries.

Region / Country

- [Israel/Palestine](https://www.hrw.org/middle-east/north-africa/israel/palestine)

Topic

- [Technology and Rights](https://www.hrw.org/topic/technology-and-rights)

## More Reading

- October 10, 2025 News Release
	### Israel/Palestine: Microsoft Should Avoid Contributing to Rights Abuses
	![A demonstrator holds a Palestinian flag during a protest at the Microsoft Campus in Redmond, Washington, US, August 19, 2025.](https://www.hrw.org/sites/default/files/styles/square/public/media_2025/10/202510tech_us_microsoft.jpg?h=3e43625b&itok=MmMjvP91)
- September 18, 2024 Dispatches
	### Meta’s Oversight Board Rules ‘From the River to the Sea’ Isn’t Hate Speech
	![A person holding a protest sign outside of the Meta headquarters](https://www.hrw.org/sites/default/files/styles/square/public/media_2024/09/202409us_california_meta_censorship_protest.jpg?h=5a96aa8a&itok=L2tn4H9J)

## Reports

- December 21, 2023 Report
	### Meta’s Broken Promises
	Systemic Censorship of Palestine Content on Instagram and Facebook
	![202312mena_ip_meta_covergraphic](https://www.hrw.org/sites/default/files/styles/square/public/media_2023/12/202312mena_ip_meta_covergraphic.jpg?h=10a9c28e&itok=hINuV3YK)

## More Reading

- October 10, 2025 News Release
	### Israel/Palestine: Microsoft Should Avoid Contributing to Rights Abuses
	![A demonstrator holds a Palestinian flag during a protest at the Microsoft Campus in Redmond, Washington, US, August 19, 2025.](https://www.hrw.org/sites/default/files/styles/square/public/media_2025/10/202510tech_us_microsoft.jpg?h=3e43625b&itok=MmMjvP91)
- September 18, 2024 Dispatches
	### Meta’s Oversight Board Rules ‘From the River to the Sea’ Isn’t Hate Speech
	![A person holding a protest sign outside of the Meta headquarters](https://www.hrw.org/sites/default/files/styles/square/public/media_2024/09/202409us_california_meta_censorship_protest.jpg?h=5a96aa8a&itok=L2tn4H9J)

## Most Viewed

1. October 24, 2026 Commentary
	### Japan should stop punishing sex workers
	![The Kabukicho entertainment district in Tokyo, Japan, October 1, 2021.](https://www.hrw.org/sites/default/files/styles/square/public/media_2026/10/202610asia_japan_street.jpg?h=fec8c8ad&itok=UB42WhTo)
2. May 17, 2021 Report
	### “Years Don’t Wait for Them”
	![A young girl wearing a face mask holds up a cell phone](https://www.hrw.org/sites/default/files/styles/square/public/media_2021/05/202105crd_covid_education_main.jpg?h=a141e9ea&itok=DVlyPr13)
3. August 16, 2016 Report
	### “We’re Afraid for Their Future”
	![Syrian children attend class in a school in the Zaatari refugee camp in northern Jordan, October 20, 2015. The school taught Syrian girls in the morning and boys in the afternoon, but lacked electricity, heating, and running water. © 2016 Bill Van Esveld/](https://www.hrw.org/sites/default/files/styles/square/public/multimedia_images_2016/2016-08-mena-jordan-main_1.jpg?itok=GmVq4bl-)
4. October 28, 2026 News Release
	### Brazil: New Evidence of Serious Police Misconduct in Deadly Raid
	![A woman holds up a shirt with a message in Portuguese on it during a protest](https://www.hrw.org/sites/default/files/styles/square/public/media_2026/09/202609americas_brazil_rio_complexodapenha-protest.jpg?h=b6de344b&itok=rByOaVZY)
5. March 31, 2022 News Release
	### Iran: Women Blocked From Entering Stadium
	![Female Iranian spectators cheer as they wave their country's flag during a friendly soccer match between Iran and Bolivia, at the Azadi (Freedom) stadium, in Tehran, Iran, Tuesday, Oct. 16, 2018.](https://www.hrw.org/sites/default/files/styles/square/public/multimedia_images_2019/201910mena_iran_stadiumcap.jpg?itok=j-rQXI5W)

[Share this via Bluesky](https://bsky.app/intent/compose?text=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza%0Ahttps://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza "Share this via Bluesky") [Share this via Facebook](https://www.facebook.com/sharer.php?u=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza "Share this via Facebook") [More sharing options](# "More sharing options")

[Share this via X](https://twitter.com/intent/tweet?text=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza&url=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza "Share this via X") [Share this via WhatsApp](whatsapp://send?text=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza%20-%20https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza "Share this via WhatsApp") [Share this via Email](mailto:?subject=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza&body=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza "Share this via Email") [Share this via LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza&title=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza "Share this via LinkedIn") [Share this via Reddit](http://reddit.com/submit?url=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza&title=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza "Share this via Reddit") [Share this via Telegram](https://telegram.me/share/url?url=https://www.hrw.org/news/2024/09/10/questions-and-answers-israeli-militarys-use-of-digital-tools-in-gaza&text=Questions%20and%20Answers:%20Israeli%20Military%E2%80%99s%20Use%20of%20Digital%20Tools%20in%20Gaza "Share this via Telegram") [Share this via Printer](https://www.hrw.org/node/389052/printable/print "Share this via Printer")### [Protecting Rights, Saving Lives](https://donate.hrw.org/page/107245/donate/1?ea.tracking.id=EP2022EVpgfooter&promo_id=1005)

[

Human Rights Watch defends the rights of people in close to 100 countries worldwide, spotlighting abuses and bringing perpetrators to justice

Donate Now

](https://donate.hrw.org/page/107245/donate/1?ea.tracking.id=EP2022EVpgfooter&promo_id=1005)

Get updates on human rights issues from around the globe. Join our movement today.