---
title: "Israel's 'Where's Daddy?' AI system helps target suspected Hamas militants when they're at home with their families, report says"
source: "https://www.businessinsider.com/israel-ai-system-wheres-daddy-strikes-hamas-family-homes-2024"
---
![Palestinians check the rubble of buildings that were destroyed following overnight Israeli bombardment in Rafah, in the southern Gaza Strip, on March 27, 2024, amid the ongoing conflict between Israel and the Palestinian militant group Hamas.](https://i.insider.com/660f144d16bde8d4ead5ec2c?width=2000&format=jpeg&auto=webp)

Palestinians check the rubble of buildings that were destroyed following an overnight Israeli bombardment in Rafah, Gaza. MOHAMMED ABED

Save Saved

As civilian casualties continue to mount in the wartorn Gaza Strip, reports of Israel's use of artificial intelligence (AI) in its targeting of Hamas militants are facing increasing scrutiny.

A report by the Israeli outlets [+972 Magazine and Local Call](https://www.972mag.com/lavender-ai-israeli-army-gaza/) earlier this month said that Israeli forces had relied heavily on two AI tools so far in the conflict — "Lavender" and "Where's Daddy."

While "Lavender" identifies suspected Hamas and Palestinian Islamic Jihad (PIJ) militants and their homes, "Where's Daddy" tracks these targets and informs Israeli forces when they return home, per the report, which cites six Israeli intelligence officers who had used AI systems for operations in Gaza, including "Where's Daddy?"

"We were not interested in killing \[Hamas\] operatives only when they were in a military building or engaged in a military activity," one of the officers told +972 and Local Call.

"On the contrary, the IDF bombed them in homes without hesitation, as a first option. It's much easier to bomb a family's home. The system is built to look for them in these situations," they added.

Another source told the publications that this method had often led to the deaths of civilians, describing them as "collateral damage."

[The Israel Defense Forces (IDF)](https://www.idf.il/en/mini-sites/hamas-israel-war-24/all-articles/idf-response-as-sent-to-the-guardian/) said in a statement: "The IDF outright rejects the claim regarding any policy to kill tens of thousands of people in their homes."

## Misidentification

The "Lavender" system is also known sometimes to identify targets with tenuous or no links to militant groups, the sources said, adding that it made "errors" in around 10% of cases.

![Smoke rises after Israeli bombings in the southern Gaza Strip city of Khan Younis, on Feb. 14, 2024.](https://i.insider.com/661004fe16bde8d4ead60322?width=700&format=jpeg&auto=webp)

Smoke rises after Israeli bombings in the southern Gaza Strip city of Khan Younis on Feb. 14, 2024. Xinhua News Agency (Getty Images)

Those erroneous identifications have included people with the same name or nickname as a militant or who were in possession of devices previously used by a militant, the sources added.

The cutting edge of warfare, military strategy, and defense tech — delivered weekly.

By clicking "Sign up", you agree to receive emails from Business Insider. In addition, you accept Insider’s [Terms of Service](https://www.businessinsider.com/terms) and [Privacy Policy](https://www.businessinsider.com/privacy-policy).

Brianna Rosen, a senior fellow at Just Security and a strategy and policy fellow at the University of Oxford's Blavatnik School of Government, estimates the margin of error to be even higher.

"Israel's permissive targeting criteria and errors in AI output are likely compounding" the risks to civilians, Rosen said, adding that those risks to civilians increase "as war speeds up."

"So target verification and other precautionary obligations required under international law are much harder to fulfill, implying more civilians will be misidentified and mistakenly killed," she continued.

Officers also told +972 Magazine and Local Call report that human input in the target identification process was minimal, with one saying they essentially "rubber stamp" the machine's picks after little more than "20 seconds" of consideration — which was largely to double-check the target is male.

Heidy Khlaaf, who has worked as a director of engineering of machine learning assurance at the cybersecurity firm Trail of Bits, [told Politico](https://www.politico.com/news/2024/03/03/israel-ai-warfare-gaza-00144491) that "imprecisely and biasedly automating targets is really not far from indiscriminate targeting."

## 'Dumb' bombs

The IDF tries to conserve its more expensive munitions by using unguided "dumb" bombs against junior Hamas operatives, per the sources.

[CNN](https://edition.cnn.com/2023/12/13/politics/intelligence-assessment-dumb-bombs-israel-gaza/index.html) reported in December that nearly half of the Israeli munitions used to strike Gaza had been "dumb" bombs, citing a report by the Office of the Director of National Intelligence.

President Joe Biden, despite having continued to send arms to Israel, warned the country at the time that it may lose international support due to its "indiscriminate bombing" of the Gaza Strip.

## Civilian death toll

The use of such bombs, combined with Israel's seemingly hands-off target identification methods, has seen the civilian death toll climb in Gaza.

Some have called into question whether Israel has been adhering to international law and the [principle of proportionality](https://casebook.icrc.org/a_to_z/glossary/proportionality), which is intended to prohibit attacks that are "expected to cause incidental loss of civilian life, injury to civilians, damage to civilian objects, or a combination thereof, which would be excessive in relation to the concrete and direct military advantage anticipated."

Brianna Rosen told BI that Israel had taken a "very permissive interpretation" of international law and the "need for precautions."

One officer told +972 Magazine and Local Call that "in practice, the principle of proportionality did not exist."

"Every person who wore a Hamas uniform in the past year or two could be bombed with 20 \[civilians killed as\] collateral damage, even without special permission," they added.

## IDF reaction

![Israeli tanks move near Gaza border as Israeli army deploys military vehicles around the Gaza Strip, Israel on October 12, 2023.](https://i.insider.com/661004753f923f7dab04f8d9?width=600&format=jpeg&auto=webp)

Israeli tanks move near the Gaza border as the Israeli army deploys military vehicles around the Gaza Strip, Israel, on October 12, 2023. Anadolu (Getty Images)

In a previous [statement](https://www.businessinsider.com/israel-ai-identify-bombing-targets-gaza-hamas-idf-2024-4) to Business Insider, representatives for the IDF said the report was "misleading and has numerous false claims."

"Analysts must conduct independent examinations, in which they verify that the identified targets meet the relevant definitions in accordance with international law and additional restrictions stipulated in the IDF directives," they added.

The [IDF also released a statement online](https://www.idf.il/en/mini-sites/hamas-israel-war-24/all-articles/idf-response-as-sent-to-the-guardian/) following the investigation, saying: "Contrary to claims, the IDF does not use an artificial intelligence system that identifies terrorist operatives or tries to predict whether a person is a terrorist."

It also noted that "the IDF makes various efforts to reduce harm to civilians to the extent feasible in the operational circumstances ruling at the time of the strike."

Brianna Rosen called the IDF's statement "anodyne," adding that it "didn't say very much at all."

While the +972 Magazine and Local Call may shed some light on how Israel is implementing AI into its operations, much remains unknown.

Sarah Yager, the Washington Director at Human Rights Watch, told Politico that in terms of proportionality and Israel's use of technology, "we just have no idea. It's like a black box."

Since Hamas' October 7 attacks, which killed around 1,200 people in Israel and saw around 240 others taken hostage, the Gazan [health ministry](https://press.un.org/en/2024/sc15653.doc.htm) has said that more than 32,000 Palestinians have been killed in the territory.