---
title: "Israel's Killer AI"
source: "https://stopkiller.ai/"
---
## Killer AI

Palestinians are one of the most surveilled people on the planet.

Israel collects data on where they live, who they know, and how they socialize. For years, it has used its surveillance apparatus to intimidate Palestinians and entrench a system of apartheid.

When Israel launched its genocidal campaign in Gaza in October 2023, it used this data with a number of automated systems to unleash an unprecedented killing spree.

These systems, which rely on artificial intelligence (AI), are closely guarded secrets. But six Israeli intelligence officers have disclosed how Israel used two of these systems to operate an automated killing machine.

One of these tools is called Lavender. It suggests who to kill faster than humanly possible.

Scroll Down to Boot Lavender

Here’s what happened when the U.S. used a similar system in Pakistan.

Some time before 2012, the United States experimented with a similar AI system that had been trained on cell phone metadata.

The software identified a well-respected Pakistani journalist as the top target because he met with and interviewed combatants as part of his job.

[![Screenshot of The Intercept's story about a U.S. intelligence program that identified a journalist as a potential combatant.](https://stopkiller.ai/assets/intercept-us-data-B3TbQG5Z.webp)](https://theintercept.com/2015/05/08/u-s-government-designated-prominent-al-jazeera-journalist-al-qaeda-member-put-watch-list/)

He wasn’t killed, because the U.S. system appears to have been a research project. But his case highlights what can happen when human beings are reduced to data.

In Gaza, Israeli officers routinely acted on Lavender's recommendations without verifying the raw intelligence themselves.

To make things worse, Lavender has learned to detect non-combatants as a threat, because its training data included the profiles of civil defense workers like firefighters and emergency responders.

In spite of these problems, officers reported spending no more than 20 seconds reviewing Lavender’s recommendations, often doing nothing more than checking if the person’s voice sounded masculine.

If it did, they were added to a tracking system called Where’s Daddy? And that’s when the killing began.

Loading Targets

Israel killed about 15,000 Palestinians in the first six weeks of the assault on Gaza, when sources say Israel’s killing machine was generating thousands of targets per day.

Officers understood that civilian casualties were a feature of the killing machine, not a bug. Palestinian families were bombed in their homes because it was the easiest way to automate the killing machine.

In the first month, more than half of the fatalities belonged to just 1,340 families, many of them wiped out entirely while inside their homes.

Israel’s automation of genocide in Gaza is one of the most egregious abuses of technology in modern warfare.

But Lavender and Where’s Daddy? are only two parts of a sprawling network of weaponized surveillance and repression that dominates Palestinian lives.

They use spyware to hack into phones, maintain a web of cameras at military checkpoints and in Palestinian residential areas, and collect photos and other biometric data. The information they capture about Palestinians living under apartheid feeds the databases they use to train new genocidal technologies.

And what happens in Palestine doesn’t stay in Palestine.

Israel is exporting its cyber technology to repressive regimes around the world. Israeli-made spyware has been found on the phones of human rights defenders, journalists and politicians in India, Saudi Arabia, Canada, Mexico, El Salvador and the Dominican Republic, and many other countries.

Learn more about this killing machine, push your government to ban intrusive surveillance, and help us pull the plug on arms sales to Israel.

![](https://stopkiller.ai/assets/circle-us-C_hhiEf3.webp)

Join the [Not My Tax Dollars](https://www.notmytaxdollars.org/) campaign in the U.S.

![](https://stopkiller.ai/assets/circle-uk-Bf4kTLxB.webp)

In the UK, Call on your MP to [stop arming Israel](https://caat.org.uk/call-on-your-mp-to-support-a-two-way-arms-embargo-to-israel/).

![](https://stopkiller.ai/assets/circle-google-DS56-bxE.webp)

Join the global [No Tech for Apartheid](https://www.notechforapartheid.com/) campaign

![](https://stopkiller.ai/assets/circle-access-now--cwKkrYl.webp)

Learn about efforts to [ban mass surveillance](https://www.accessnow.org/publication/artificial-genocidal-intelligence-israel-gaza/)

![](https://stopkiller.ai/assets/circle-eye-Dt85P0KL.webp)

See [Automating Genocide](https://visualizingpalestine.org/visual/automating-genocide-israels-use-of-ai-driven-warfare/), Visualizing Palestine’s infographic

![](https://stopkiller.ai/assets/circle-share-CvSERhpm.webp)