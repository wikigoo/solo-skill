# The Japanese Kamikaze (“divine wind”) Deliberately Crashed Into Ships

The tactic was suggested on October 19, 1944, by Vice-Admiral Onishi in an attempt to balance the technological advantage of invading American forces. Though the numbers are disputed, approximately 2,800 kamikaze pilots died. They sunk 34 U.S. ships, damaged 368, killed 4,900 sailors, and wounded 4,800.[3]