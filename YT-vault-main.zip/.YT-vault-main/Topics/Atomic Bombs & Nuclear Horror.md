# Atomic Bombs & Nuclear Horror

### Survivors Of Both Atomic Bombings Have A Special Name

They are called niju hibakusha, which literally means “explosion-affected people.”[3]