---
name: solo-narration
description: Write Persian voice-over narration scripts (متن نریشن) for the Solo (سولو) YouTube channel's narrative documentaries on any topic, in the channel house style. Use when asked to turn a source or topic into a narration script, or to rewrite, shorten or review one.
---

# Solo Narration

Turn a source or a topic into a Persian narration script for a 14–18 minute narrative documentary on the Solo («سولو») YouTube channel. The script is written to be **heard, not read**: one central character or group, one climactic scene, one two-sided question at the end.

Instructions are in English; the script itself is always Persian. Persian phrases below are templates to reuse verbatim or adapt.

## Before writing: study the Narration-Style folder (mandatory)

The folder `D:\.YT-vault\Skills\solo-narration\Narration-Style` (inside this skill's folder) is the channel's style reference. **Before drafting any narration, read every document in it carefully and in full:**

- `Style-Guide.md`: the complete Persian guide to the house style, tone, structure, formatting and orthography, with annotated examples from both samples.
- `Sample-1.md`: «کاپیتان بایکوت؛ چرا امپراتوری بریتانیا برای برداشت شلغم ارتش فرستاد؟» (about 2,130 words).
- `Sample-2.md`: «سوررئالیسم؛ چگونه رؤیاهای یک شاعر پاریسی دشمن فاشیسم شد؟» (about 2,460 words).
- Any other file later added to the folder.

Read the two samples as a writer, not as a skimmer. Note how each one opens, where it places the «اما» pivots and date slugs, how it returns to the opening scene, and how it builds its ending. Your script should read like a third sibling of these two. List the folder first rather than assuming its contents.

Both samples predate the no-CTA rule: they contain a subscribe line, a related-video plug (Sample-2) and a closing like/comment line, and Sample-1 names the channel «پروفایل». Never imitate those parts. When the samples and this file disagree, this file wins on the rules marked **always** or **never**: no CTAs, no Latin script, no parentheses, Persian digits. Everywhere else, follow the samples and the style guide.

If the folder cannot be reached, for example when the computer isn't linked, say so to the user and continue from the rules in this file.

## Output contract

- One Markdown file: line 1 is `# <title>`, then continuous prose paragraphs separated by blank lines. No subheadings, lists, bold, tables or Latin-script words inside the script.
- **Never write calls to action**: no subscribe request, no promotion of another video, no closing "comment, like and share" line. The script ends on the closing question. The editor adds CTAs later.
- Length: 2,000–2,500 words unless the user gives a target («حدود ۲۰۰۰ کلمه» means 1,900–2,150). Count words, excluding the title, before delivering.
- Filename = the title, minus Windows-forbidden characters (`: ? / \ * " < > |`). Use Persian `؛` instead of `:` and Persian `؟` instead of `?`.
- In the user's vault, save to `D:\.YT-vault\1-Content\4-Narration`.

## Topics: the channel covers anything with a story in it

The channel is not limited to assassinations and espionage. Any subject works if it can be told as a story: a person, a turning point, a conflict and a lasting question. Topic sources usually live in `D:\.YT-vault\Topic-Bank\` (for example `_Several`). Many are long Wikipedia-style dumps, and some are empty stubs that hold only a title.

| Category | Examples from the Topic Bank | Usual human anchor | Usual climactic scene |
|---|---|---|---|
| History and political events | Nanjing massacre, Wounded Knee, Bengal famine of 1943, Battle of Chaldiran | A witness, victim, commander or official who decided | The decisive day or night |
| Biographies and enigmatic figures | Rasputin, Snowden, Socrates, Hassan Sabbah and the Assassins | The person | Death, trial, betrayal, defection |
| Power, punishment and human rights | Gulag, white torture, Japan's death penalty, Ravensbrück, euthanasia, Khabarovsk trials | A prisoner, guard, judge or the condemned | Arrest, interrogation, the morning of execution |
| Movements, art and literature | Surrealism, Frankenstein, Doctor Faustus | The founder or author | The night of creation, a ban, an exile |
| Science, cosmos and the mind | Simulation hypothesis, end of the universe, cosmogony, déjà vu, lucid dreaming, Jonah complex, automatism | The scientist or thinker who proposed it, or a person who lived the phenomenon | The experiment, observation or courtroom where the idea was tested |
| Pseudoscience, conspiracies and mysteries | Homeopathy, HAARP, 9/11 theories, water-fuelled car, doctored "proof" photos, Easter Island, the Sphinx | The inventor, promoter, believer or debunker | The public claim, demonstration or test |
| Technology and society | Dark web, the 2018 privacy scandals, Stuxnet, karoshi, time banks, brain rot, people talking less | A concrete case: an operator, an engineer, a victim | An arrest, a death, a leak, a discovery |
| Myth, religion and culture | Karma, reincarnation, witches, Pandora's box, the Sword of Damocles, Robin Hood, Zoorkhaneh rituals, the Tower of London ravens | The historical figure behind the myth, a practitioner, or a persecuted believer | A ritual, a trial or a moment the myth "came true" |
| Survival stories | The verified survival stories collection | The survivor | The moment of greatest danger |

**Concept topics need a human anchor.** For an idea, phenomenon or theory, never write a lecture. Find a real person and a real moment that carry the idea, and tell the idea through them. Surrealism is told through André Breton waiting for a visa in Marseille. Lucid dreaming could be told through the researcher whose sleeping subject first signalled from inside a dream. If the source has no such person, find one during research or tell the user the topic lacks a narrative anchor.

**Group or anonymous protagonists** are allowed, such as the villagers, the prisoners of a camp, or the crew. Give the group a face: one named member with an age and a human detail.

## Three governing principles

1. **Narrative, not report.** The source is raw material; the script is a story with a character, conflict and scenes.
2. **Suspense before information.** Raise the question first; release the answer gradually.
3. **Two-sided judgment at the end only.** The narrator never delivers a verdict mid-story. The ending sets two views side by side and hands the decision to the viewer.

## Workflow

1. **Study the Narration-Style folder** (`Style-Guide.md`, `Sample-1.md`, `Sample-2.md`) in full, as described above. Do not skip this step, even for a short rewrite.
2. **Check the source.** First look in `D:\.YT-vault\1-Content\3-Research\` for a research dossier on the topic made by the solo-research skill. If one exists, use it as the primary source: section 8 (narration toolkit) gives the anchor, climactic scenes, quote and number banks, ironies and the two closing views, and section 4 gives the characters. Use only material it labels قطعی or پشتوانه قوی as fact, and attribute anything محل مناقشه. If no dossier exists and the source is empty or thin, suggest running solo-research first, or research the topic with web search and tell the user what you used.
3. **Extract raw material** into five working lists: dated timeline, characters with a one-line role each, striking numbers, direct quotes, and ironies or contradictions.
4. **Pick the anchor and the angle.** Name the central character, or the face of the group. Write one central question that the whole script answers; it becomes both the second hook question and the closing question.
5. **Pick the climactic scene** using the criteria under "Cold open".
6. **Outline the 8 stages** with a word budget for each (see the table below).
7. **Select and cut.** Drop anything not tied to the central question or the anchor. Technical detail, historiography and minor characters usually shrink to one sentence or vanish. Cut from stage 6 first; never shorten the climax or the ending.
8. **Draft stages 5–8 first.** Write the cold open and hook last, once the stage-7 scene exists.
9. **Rewrite for the ear.** Read sentences as if aloud, split anything that would leave the narrator breathless, and simplify words that trip.
10. **Final pass:** word count, fact check, and the checklist at the end of this file.

## The 8-stage structure (ring structure)

Start at the climax, jump back, move chronologically, and return to the very same scene. The budgets below are for 2,000–2,500 words.

| # | Stage | Words | Purpose | Template |
|---|---|---|---|---|
| 1 | Cold open | 150–250 | Drop the viewer into the climax | «[مکان]؛» then a present-tense scene |
| 2 | Identity reveal | 40–70 | Name, plus why they matter | «این مرد، [نام] است؛ [چرا مهم است]» |
| 3 | Hook question | 50–80 | Create curiosity | «اما چگونه [تناقض]؟ و آیا/چرا [پرسش اخلاقی یا پیامد]؟» |
| 4 | Promise line | 30–60 | Topic plus a logline with a bitter irony | «این ویدیو، داستان [موضوع] است؛ داستان [شخصیتی که…]» |
| 5 | Background | 350–500 | Birth, family, formation, first encounter with the idea | «[نام] در [سال]، در [مکان] به دنیا آمد…» |
| 6 | Turning point and escalation | 700–900 | Wider context, opposing force, the fatal choice, the chain of events | «اما نقطه عطف [زندگی او / داستان X]، در [سال] رقم خورد.» |
| 7 | Return to the climax | 300–450 | Full retelling of scene 1, then what happened next | «و اینجا، همان صحنه‌ای است که داستان ما از آن آغاز شد.» |
| 8 | Aftermath, legacy, judgment, closing question | 300–400 | Death or ending, legacy to today, two views, one ironic line, the dilemma | «به نظر شما [الف] بود، یا [ب]؟» |

Stage 6 usually has three movements: the wider context (inequality, war, a scientific crisis, a moral panic), the rise of the opposing force, and the chain of events that leads to the climax.

Stage 8 order, as in both samples: the fate of the characters, then the legacy reaching today («اما داستان با مرگ [او] تمام نشد.» or «نام او اما زنده ماند.»), then two attributed views, then a one-line historical irony, then the closing question as the last sentence.

**Transitions without headings** (scripts have no subheadings):
- Open a paragraph with «اما» to pivot the story, about once every 150–250 words.
- End paragraphs on suspense: «…تنها سه روز بعد، مباشر لرد ارن ناخواسته به نخستین هدف این دکترین تبدیل شد.»
- Foreshadow without revealing: «اما طوفانی بزرگ در راه بود.»، «اما آزمایش خیلی زود خطرناک شد.»

## Cold open and hook

The first 200 words decide whether the viewer stays, so polish them last and hardest.

**Choose a climactic scene that is all three:**
- **Visual**: it can be seen and heard, such as soldiers ringing a turnip field or paintings hanging from trees in a refugee villa.
- **Decisive or suspended**: a death, an arrest, a defeat, a discovery, or a moment of waiting where everything hangs in the balance.
- **Contradictory**: something that makes the viewer ask why, such as a thousand soldiers guarding a few acres of turnips, or poets with no weapon but words being banned by a state.

**Write the scene in this order:**
1. Line 1 is the location alone, ending with «؛»: «ایرلند، شهرستان مایو، کرانه دریاچه لوف ماسک؛» or «مارسی، محله لا پوم؛». A blank line follows.
2. Move from wide to close: weather, setting and crowd come before the character.
3. Use the present tense: «می‌بارد»، «می‌وزد»، «تماشا می‌کند».
4. Introduce the character unnamed, with age and one or two physical markers: «مردی ۴۴ ساله با چهره‌ای سنگین و موهای پرپشتی که به عقب شانه شده».
5. Add two or three sensory details: a sound, an image, and a temperature or smell if possible.
6. Cut before the outcome; save the full detail for stage 7.

**Identity reveal**: one sentence that names the person and immediately says why they matter, often closing on an irony or a quote: «این مرد، آندره برتون است؛ بنیان‌گذار سوررئالیسم، شاعری که سلاحی جز کلمه و رؤیا نداشت…»

**Hook**: two questions, no more. The first asks about the contradiction («اما چگونه…؟»). The second asks the moral or interpretive question («و آیا… انقلابی واقعی بود، یا رؤیای مردی که…؟»). The second question returns, almost verbatim, as the closing question.

**Promise line**: «این ویدیو، داستان [موضوع] است؛ داستان [شخصیتی] که [the whole arc with a bitter irony].» Example: «داستان دانشجوی پزشکی که در بخش اعصاب یک بیمارستان جنگی راهی به ناخودآگاه یافت، جنبشی جهانی به نام آزادی مطلق ذهن بنا کرد، و خود بارها یارانش را به جرم سرپیچی از همین جنبش بیرون راند.»

The background (stage 5) follows the promise line directly; there is no CTA between them.

**Alternative opening**: for "double life" stories or concept topics with no visual climax, use direct address: «تصور کنید مردی را که… حالا تصور کنید همان مرد…».

### Example cold open (house voice)

```
ایرلند، شهرستان مایو، کرانه دریاچه لوف ماسک؛

باران سرد نوامبر بی‌وقفه می‌بارد. صدها سرباز سواره‌نظام با شنل‌های خیس، دور یک مزرعه کوچک حلقه زده‌اند. بیش از هزار پلیس مسلح، جاده‌ها و پرچین‌ها را زیر نظر دارند.

در حاشیه جاده، هزاران دهقان ایرلندی در سکوت ایستاده‌اند. هیچ‌کس سنگ پرتاب نمی‌کند، هیچ‌کس شلیک نمی‌کند؛ آن‌ها فقط نگاه می‌کنند. پشت پنجره عمارت اربابی، مردی ۴۸ ساله با ریش پرپشت و چهره‌ای عبوس، این صحنه را تماشا می‌کند.

این مرد، چارلز کانینگهام بایکوت است؛ مباشری انگلیسی که نامش چند هفته بعد به یک فعل تازه در زبان انگلیسی تبدیل شد…
```

### Example ending (house voice)

```
برای ستایشگرانش، از سوزان سزر در مارتینیک تا شاعران زیرزمینی پراگ، سوررئالیسم ثابت کرد که آزادی خیال از مبارزه با سلطه سیاسی جدا نیست…

اما برای منتقدانش، از نویسندگان جزوه «یک جسد» تا پژوهشگران امروزی، تناقض‌ها کم نبود…

مردی که می‌خواست ذهن را از هر نظارتی رها کند، خود سال‌ها نگهبان دروازه آن بود.

به نظر شما سوررئالیسم انقلابی واقعی برای آزادی ذهن انسان بود، یا رؤیای مردی که می‌خواست حتی رؤیا را هم رهبری کند؟ و در روزگاری که ماشین‌ها برای ما رؤیا می‌بینند، آیا هنوز به آن نیاز داریم؟
```

## Narrator voice and tone

| Topic | Do | Don't |
|---|---|---|
| Point of view | Third-person omniscient; enter characters' minds only when the source supports it | First-person narrator, personal opinion |
| Channel presence | «ما» only in the narrative frame: «داستان ما»، «همان صحنه‌ای که داستان ما از آن آغاز شد» | «من»; any CTA |
| Mood | Serious, bitter, suspenseful | Jokes, casual register, promotional hype |
| Humor | Only situational irony: «قدرتمندترین امپراتوری جهان، برای برداشت چند جریب شلغم…» | Joking about characters or victims |
| Value adjectives | Backed by evidence: «منفور» followed by the fines for chickens and gates | Unsupported labels: «ذهن بیمار»، «هیولا» |
| Minor victims | Name, age and one human detail, such as the 12-year-old post boy | Faceless numbers |
| Judgment | Only in stage 8, attributed to groups: «برای ستایشگرانش… اما برای منتقدانش…» | Narrator verdicts mid-story |
| Concepts | Explain an idea in one or two plain sentences at the moment the character meets it | Textbook paragraphs, jargon, equations |

Contemporary Iranian political topics are more sensitive: attribute judgmental words such as «فرقه» or «خائن» to whoever said them, never to the narrator.

## Sentences, vocabulary and figures of speech

The prose is formal and literary, not bureaucratic. Average sentence length is 18–22 words; the rhythm comes from alternating long and short sentences.

**Rhythm**
- Long sentences (25–40 words) carry context and explanation; never go over 45 words.
- Short sentences (3–8 words) deliver impact, especially at the start or end of a paragraph: «آن‌ها فقط نگاه می‌کنند.»
- In climax scenes, chain short fragments: «صدای قدم‌ها در راهروها، صدای بحث‌های شبانه، صدای قلم روی کاغذ.»
- Use «نه‌تنها… بلکه…» and «نه… بلکه…» for contrast, at most three times per script.

**Verbs**: prefer plain verbs. Use bureaucratic forms at most two or three times per script, for variety only.

| Instead of | Write |
|---|---|
| محکوم گردید | محکوم شد |
| منصوب نمود | منصوب کرد |
| تبدیل ساخت | تبدیل کرد |
| به رشته تحریر درآمد | نوشته شد |
| مبادرت به … ورزید | … کرد |

**Superlatives and emphasis**
- Use at most 8 superlatives («…ترین») per script. When everything is "the most", nothing is.
- Use an adjective triad («سرسخت، اقتدارگرا و ستیزه‌جو») once or twice per script.
- Prefer numbers to adjectives: «۱۰ هزار پوند برای محصولی ۵۰۰ پوندی» beats «هزینه سرسام‌آور».

**Metaphor fields**: pick one or two per script and stay consistent.

| Field | Examples |
|---|---|
| Game / chess | شطرنج قدرت، مهره، کیش |
| Machine | ماشین سرکوب، ماشین تشکیلات |
| Slaughterhouse / hell | مسلخ، برزخ، دوزخ |
| Storm / fire | طوفان، گردباد، آتش، شعله‌ور |
| Shadow / ghost | در سایه‌ها، شبح، نامرئی |
| Fortress / siege | دژ، قلعه، سنگر |
| Dream / labyrinth | رؤیا، کابوس، هزارتو، دروازه ذهن |
| Church / faith | کشیش، کلیسای تازه، تکفیر، پاکسازی |

**Other devices**
- **Epithet instead of name** to avoid repetition: «مباشر لرد ارن»، «دانشجوی جوان»، «رهبر جنبش آزادی». Use the full name only at first mention.
- **Direct quotes**: three to six short quotes in «», only from the source, at key moments. A long quote, such as a speech, may be its own paragraph.
- **Historical irony**: one closing line as its own paragraph: «مردی که تمام عمر برای حفظ نظم ارباب‌رعیتی جنگید، ناخواسته نامش را به قدرتمندترین سلاح بی‌خشونت ضعیفان… بخشید.»
- **Precise numbers** for credibility: «هفده پلیس مسلح»، «۳۸۱ روز»، «۲ هزار و ۵۰۰ نفر».
- **Bridge to today**: one short paragraph linking the story to the present, such as AI-generated "dream" images after Surrealism or Gandhi and Montgomery after Boycott.

## Verb tense and narrative techniques

Narrate in the past tense. Use the present tense only for the cold open and the climax scene, and switch tense only at scene boundaries.

| Section | Tense | Example |
|---|---|---|
| Cold open | Simple/continuous present | «باران سرد نوامبر بی‌وقفه می‌بارد.» |
| Background and escalation | Simple, continuous, past perfect | «او قاضی محلی هم بود و…» |
| Return to the climax | Present, after a date slug | «کاروان به لوف ماسک می‌رسد.» |
| Wrap-up and aftermath | Past | «وقتی حساب‌ها بسته شد…» |

Never change tense inside a paragraph. Typical past errors are «فرو رفته‌اند»، «نشانده‌اند» and «نبوده است» in the middle of past narration.

**Techniques**
- **Date/location slugs** on their own line, screenplay-style: «بیست و دوم سپتامبر ۱۸۸۰»، «دهم اکتبر ۱۹۲۱، وین»، «تابستان ۱۸۸۰»، «زمستان ۱۹۴۰، مارسی، ویلای اربل». Use 3–6 per script, only for key moments.
- **Countdown at the climax**, when the source gives times: «ساعت ۳:۲۰… ساعت ۳:۳۰ بعدازظهر…».
- **Sensory detail**: sound, smell, light and temperature, with at least two senses in each main scene.
- **Montage**: a list of short images to show time passing or suffocation.
- **Withheld name**: describe first, name later.
- **Foreshadowing**: announce the disaster without its details.
- **Ring structure**: stage 7 repeats the images and a few exact words of stage 1, such as the hundred-year-old trees, the rain or the silent crowd.
- **Reconstructed scenes**: use dialogue only when the source records it. When accounts differ, write «در یک روایت… در روایت دیگری…». For a doubtful but famous anecdote, write «به روایتی که بارها نقل شده…».

## Formatting and orthography

**File structure**
- Line 1: `# <video title>`. Nothing after it may be a heading, list, bold text or table.
- Paragraphs are separated by one blank line. Aim for 40–90 words each (the samples average about 50); 120 is the maximum.
- Date slugs and the cold-open location line sit on their own line, with a blank line before and after.

**Title patterns** (the subject, then «؛», then a question, as in both samples)

| Pattern | Example |
|---|---|
| Subject + question | کاپیتان بایکوت؛ چرا امپراتوری بریتانیا برای برداشت شلغم ارتش فرستاد؟ |
| Subject + "how" paradox | سوررئالیسم؛ چگونه رؤیاهای یک شاعر پاریسی دشمن فاشیسم شد؟ |
| Secret/superlative + life story | خطرناک‌ترین جاسوس دوجانبه؛ داستان زندگی کیم فیلبی |
| Contradictory role | چریکی که شوهرش را به جوخه ترور سپرد |

Write the title last so its promise matches the content.

**Punctuation**
- **«؛»** goes only between two complete, related clauses, or before an explanatory appositive: «این مرد، X است؛ مباشری که…». Never put it between subject and verb.
- **«،»** may also mark a narrator pause, but never between a short subject and its verb.
- **«»** marks quotes, nicknames, titles of works, operation names and mentioned words.
- **Never use parentheses**: the narrator cannot read them aloud. Write «، دانشگاه شریف امروز،» instead of «(دانشگاه شریف فعلی)».
- **No em dash (—)**: use a comma or «؛».
- **Ellipsis «…»** only inside quotes, to mark an omission.

**Spelling and consistency**

| Topic | Rule |
|---|---|
| Digits | **Always** Persian digits (۱۲۳). Use digits for years, ages, sums and counts; write large numbers as «۴ هزار»، «۲ هزار و ۵۰۰»، «هشت میلیون». Spell out the day in date slugs («بیست و دوم سپتامبر ۱۸۸۰») |
| Gregorian months | ژانویه، فوریه، مارس، آوریل، مه، ژوئن، ژوئیه، اوت، سپتامبر، اکتبر، نوامبر، دسامبر (not جولای، می، آگوست) |
| Iranian topics | Solar Hijri dates («اردیبهشت ۱۳۵۴») |
| Half-space (ZWNJ) | می‌، نمی‌، …‌ها، …‌تر، …‌ترین and …‌ای take a ZWNJ; separate words take a normal space |
| Ezafe | No explicit mark: «خانواده بایکوت», not «خانواده‌ی» or «خانوادهٔ» |
| Latin script | **Never** inside the script; English names belong only in delivery notes |
| Names | One transliteration per name for the whole script; use the established Persian form where one exists (کا‌گ‌ب، سیا، فروید) |

## Factual accuracy and neutrality

Every number, date, name and quote comes from the source or from your verification searches, never from memory alone. The telling is dramatic; the facts are not.

1. **Verify key facts against two sources**: death dates, headline figures and central quotes. If you cannot verify one, say so to the user.
2. **Keep it internally consistent**: dates must agree (for example, the character's age in scene 1 = event year − birth year).
3. **No anachronisms**: organisation names and titles must belong to the period (the KGB did not exist before 1954).
4. **Title promise = content**: if the title says "the final 48 hours", narrate those 48 hours.
5. **Don't hide conflicting accounts**: give both, attributed.
6. **Limited reconstruction**: atmospheric detail (rain, light) is allowed if it doesn't contradict the source; invented dialogue or numbers are not.
7. **Doubtful figures**, such as a source mixing acres and hectares: drop them or soften them with «حدود».

**Neutrality in the ending**: always present two views, named by group or author, with similar weight (about 40–80 words each): «برای ملی‌گرایان و نویسندگانی چون مایکل داویت… اما مورخان امروزی…».

**Science, pseudoscience and conspiracy topics**: two-sided does not mean false balance. State settled scientific findings plainly; for example, homeopathic remedies perform no better than placebo in controlled trials. Attribute the claims to their believers. Move the closing dilemma to a genuinely open question, such as why people believe, who is harmed, or whether it should be regulated, banned or tolerated.

## Common mistakes (seen in earlier channel scripts)

| Mistake | Example | Fix |
|---|---|---|
| CTA left in | A subscribe line after the promise, or "comment and like" at the end | Delete it; the script ends on the closing question |
| Lecture instead of story | A concept topic opened with a definition | Open on a person in a scene; explain the idea when the character meets it |
| Superlative inflation | 22 «…ترین» in one script | Max 8; replace the rest with numbers |
| Giant paragraphs | A 243-word paragraph | Split anything over 120 words |
| Tense slips | «فرو رفته‌اند» in past narration | Change tense only after a date slug |
| Inconsistent transliteration | مسالونی/مسولانی | One form for the whole script |
| Latin/foreign words | «مغز lavado» | Persian equivalent |
| Narrative gap | Jumping from 1951 to "final years" | At least one sentence per important period |
| Title/content mismatch | "48 hours" covering five days | Write the title last |
| Bureaucratic verbs | «تبدیل ساخت»، «منصوب نمود» | «کرد»، «شد» |
| Hook and ending disconnected | The closing question asks something the hook never raised | Reuse the second hook question almost verbatim |

## Word count check

Run this before delivering (on Windows use `python` instead of `python3`). It prints the word count excluding the H1, the longest paragraph, the superlative count, and paragraphs that open with «اما»:

```bash
python3 -I -c "import re,sys;t=open(sys.argv[1],encoding='utf-8').read();b=re.sub(r'^#.*\n','',t);p=[x for x in re.split(r'\n\s*\n',b) if x.strip()];print('words',len(b.split()),'max_para',max(len(x.split()) for x in p),'superlatives',len(re.findall(r'\S+ترین',b)),'ama_paras',sum(x.strip().startswith('اما') for x in p))" "<file.md>"
```

Reference values from Sample-1 and Sample-2: about 2,130 and 2,460 words, 43–49 paragraphs, longest paragraph about 90 words, 3–6 superlatives.

## Final checklist

- [ ] The Narration-Style folder was read in full before drafting
- [ ] Opens with a location line and the present tense; the character is unnamed at first
- [ ] The second hook question returns as the closing question
- [ ] Contains «این ویدیو، داستان… است»
- [ ] Stage 7 opens with «و اینجا، همان صحنه‌ای است که داستان ما از آن آغاز شد» and fully returns to the opening scene
- [ ] **No CTA anywhere**: no subscribe, no related-video plug, no like/comment line
- [ ] 2,000–2,500 words (or the user's target); every paragraph under 120 words
- [ ] At most 8 superlatives
- [ ] Tense changes only at scene boundaries
- [ ] Every number, date and quote checked against the source
- [ ] Names and months consistent; no Latin-script words; no parentheses; Persian digits
- [ ] The ending presents two attributed views, one ironic line, then the closing question as the last sentence
- [ ] The title matches the content; the filename has no forbidden characters
- [ ] Script read through once "aloud" for breath and rhythm

When delivering, tell the user in a few lines: the word count, the anchor character and the climactic scene you opened with, which source or research you used, and any facts you could not verify.
