#!/usr/bin/env python3
"""
check_structure.py: quality gate for a Solo script-structure document.

Usage:
  python check_structure.py <structure.md>

ERROR = must fix before delivering. WARN = review and fix unless clearly justified.
Checks:
  - Header fields: قالب, مدت زمان پیشنهادی, سوال اصلی, استدلال اصلی.
  - Every "## n." section has a timestamp, a "###" title, هدف, استدلال, موضوعات;
    «سوال آغازین» only in section 1; no other bold fields (scene, evidence, notes...).
  - Timestamps on 30-second marks.
  - Topics: one line each; length (WARN > 22 words, ERROR > 35 words);
    no source mechanics («به گفته…», «گفت‌وگو», «منبع می‌گوید», «پادکست»);
    no hypothetical cases; no narration or rhetoric («تصور کنید», «این صحنه», «همین حالا»);
    no analogies («شبیه …», «مقایسه با …», «همان‌طور که …»); no long quotations; no Latin-letter
    parentheticals longer than an acronym.
"""
import re
import sys

FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")
ALLOWED_FIELDS = {"هدف", "استدلال", "موضوعات", "سوال آغازین", "قالب", "مدت زمان پیشنهادی", "سوال اصلی", "استدلال اصلی"}
SOURCE_MECH = r"به گفته‌?ی? ?(گفت‌وگو|منبع|ویدیو|پادکست|مستند)|گفت‌وگو|پادکست|منبع (می‌گوید|اشاره)|طبق متن|در این منبع"
HYPO = r"فرضی|سناریوی خیالی|فرض کنید"
NARR = r"تصور کنید|این صحنه|همین حالا|در کسری از ثانیه|بیایید|ما در این ویدیو"
ANALOGY = r"(^|[\s،:])(شبیه|مقایسه با|همان‌طور که|درست مثل|انگار|گویی)(?=[\s،.]|$)"


def secs(ts):
    m, s = ts.translate(FA).split(":")
    return int(m) * 60 + int(s)


def main():
    t = open(sys.argv[1], encoding="utf-8").read()
    lines = t.splitlines()
    err, warn = [], []

    head = t.split("\n## ")[0]
    for f in ("قالب", "مدت زمان پیشنهادی", "سوال اصلی", "استدلال اصلی"):
        if f"**{f}:**" not in head:
            err.append(f"header: missing «{f}»")

    for f in re.findall(r"\*\*([^*]+?):\*\*", t):
        if f.strip() not in ALLOWED_FIELDS:
            err.append(f"extra field «{f.strip()}»: only هدف / استدلال / موضوعات (+ سوال آغازین in the Hook)")

    sections = re.split(r"\n(?=## )", t)[1:]
    for i, sec in enumerate(sections, 1):
        h = sec.splitlines()[0]
        name = h[:40]
        ts = re.findall(r"([۰-۹0-9]+:[۰-۹0-9]{2})", h)
        if len(ts) == 2:
            for x in ts:
                if secs(x) % 30:
                    warn.append(f"{name}: timestamp {x} is not on a 30-second mark")
        elif "ثانیه" not in h:
            err.append(f"{name}: timestamp missing")
        if not re.search(r"\n### \S", sec):
            err.append(f"{name}: ### title missing")
        for f in ("هدف", "استدلال", "موضوعات"):
            if f"**{f}:**" not in sec:
                err.append(f"{name}: field «{f}» missing")
        if ("**سوال آغازین:**" in sec) != (i == 1):
            err.append(f"{name}: «سوال آغازین» must appear in the Hook only")

        topics = [l.strip()[1:].strip() for l in sec.splitlines() if re.match(r"\s*[-*]\s+\S", l)]
        if not topics:
            err.append(f"{name}: no topics")
        for tp in topics:
            n = len(tp.split())
            short = tp[:70] + ("…" if len(tp) > 70 else "")
            if n > 35:
                err.append(f"{name}: topic too long ({n} words), it explains instead of naming: {short}")
            elif n > 22:
                warn.append(f"{name}: long topic ({n} words): {short}")
            if re.search(SOURCE_MECH, tp):
                err.append(f"{name}: source mechanics in topic: {short}")
            if re.search(HYPO, tp):
                err.append(f"{name}: hypothetical case in topic: {short}")
            if re.search(NARR, tp):
                err.append(f"{name}: narration/rhetoric in topic: {short}")
            if re.search(ANALOGY, tp):
                warn.append(f"{name}: analogy in topic (belongs in narration): {short}")
            for q in re.findall(r"«([^»]+)»", tp):
                if len(q.split()) > 4:
                    warn.append(f"{name}: quotation in topic (belongs in narration): {short}")
            if re.search(r"\([A-Za-z][A-Za-z .\-]{7,}\)", tp):
                warn.append(f"{name}: Latin term in parentheses: {short}")

    for w in warn:
        print("WARN  " + w)
    for e in err:
        print("ERROR " + e)
    print(f"sections: {len(sections)}  RESULT: " + ("PASS" if not err else f"FAIL ({len(err)} errors)") + f", {len(warn)} warnings")
    sys.exit(1 if err else 0)


if __name__ == "__main__":
    main()
