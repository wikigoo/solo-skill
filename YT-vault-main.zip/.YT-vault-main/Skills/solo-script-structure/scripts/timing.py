#!/usr/bin/env python3
"""
timing.py: timestamps for the 9-section video-essay template, on clean 30-second marks.

Usage:
  python timing.py <target_minutes> [--problems 3]

Keeps the proportions of the master template (Hook 0:00-0:30, Intro 0:30, Background 1:30,
Problem 1 3:00, Problem 2 5:00, Problem 3 7:30, Implications 10:00, Conclusion 11:30-13:00,
then the Call to Action in the final 10-20 seconds). The Hook always stays 0:00-0:30.
Every boundary is rounded to the nearest 30 seconds. --problems may be 2, 3 or 4.
"""
import argparse

BASE = [("هوک", 30), ("مقدمه", 60), ("بخش اول: پیشینه", 90),
        ("مسئله", 120), ("مسئله", 150), ("مسئله", 150),
        ("پیامدهای گسترده‌تر", 90), ("نتیجه‌گیری", 90)]
FA = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")


def fmt(sec):
    return f"{sec // 60}:{sec % 60:02d}".translate(FA)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("minutes", type=float)
    ap.add_argument("--problems", type=int, default=3, choices=[2, 3, 4])
    a = ap.parse_args()
    head, probs, tail = BASE[:3], BASE[3:6], BASE[6:]
    share = sum(w for _, w in probs) / a.problems
    secs = head + [("مسئله", share)] * a.problems + tail
    target = round(a.minutes * 60 / 30) * 30
    rest = sum(w for _, w in secs[1:])
    bounds, acc = [0, 30], 30.0
    for _, w in secs[1:]:
        acc += w * (target - 30) / rest
        bounds.append(int(round(acc / 30) * 30))
    bounds[-1] = target
    n = 0
    for i, (name, _) in enumerate(secs):
        if name == "مسئله":
            n += 1
            name = f"مسئله {n}"
        print(f"{name:<20} ({fmt(bounds[i])}–{fmt(bounds[i + 1])})")
    print("فراخوان برای اقدام   (۱۰ تا ۲۰ ثانیه پایانی)")


if __name__ == "__main__":
    main()
