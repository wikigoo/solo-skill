---
name: solo-script-structure
description: Build the section-by-section structure of an analytical, critical video essay for the Solo (سولو) YouTube channel by extracting topics from the provided sources and placing them in the sections of the channel's master Script Structure template. Use when asked for a script structure, outline or video plan (ساختار اسکریپت، ساختار ویدیو، ساختار نریشن) for a topic or a set of sources, before writing the narration.
---

# Solo Script Structure

Turn the user's sources into the structure of a video essay. The document has a header, then nine sections, each with a title, «هدف»، «استدلال» and «موضوعات». Nothing else.

**A topic («موضوع») is a single sentence about one point that will be explained.** It names the point and never explains it. Facts, numbers, scenes, quotes and analogies belong to the narration, not to the structure. The structure is a map of points arranged into an argument, not a summary of the sources.

Pipeline: solo-research → **solo-script-structure** → solo-narration → solo-fact-check → solo-text-editing.

## Master template

Use `D:\.YT-vault\Script Structure\Script Structure (Template).md` as the pattern. Read it fresh each time, and follow its nine sections and roles. A copy is bundled at `references/Script Structure (Template).md`; use it only if the vault file cannot be reached.

## Resources

The skill folder is `D:\.YT-vault\Skills\solo-script-structure\`.

| File | Use |
|---|---|
| `references/topic-craft.md` | **Read in full every time.** Topic definition, bad → good examples, synthesis, section roles, fields |
| `references/example.md` | Two approved sections: the exact style to match |
| `references/output-format.md` | Exact layout |
| `scripts/timing.py` | Timestamps on 30-second marks: `python scripts/timing.py <minutes> [--problems 3]` |
| `scripts/check_structure.py` | Quality gate: `python scripts/check_structure.py <structure.md>` |

## Workflow

1. **Read** the master template, `topic-craft.md` and `example.md`, then every source in full. Sources are usually the user's files in `D:\.YT-vault\Topics\<topic>\`, a dossier in `D:\.YT-vault\Research\`, or attachments.
2. **List the points** the sources establish: mechanisms, distinctions, causes, documented cases, disputes, consequences and responses. List points, not sentences, and merge duplicates across sources.
3. **Decide the central question and central argument.** Every later choice serves this argument.
4. **Choose two to four problems** with distinct mechanisms, escalating from the visible failure, to the amplifier, to the hidden mechanism.
5. **Place the points** in the sections (`topic-craft.md` section 4), in argument order, never in the order of a source. Drop points that don't serve the argument.
6. **Write each topic** as one short naming sentence (usually 5–18 words), then write the fields:
   - the title;
   - «هدف» in the imperative;
   - «استدلال» as an analytical claim, never rhetoric;
   - «سوال آغازین» in the Hook only.
7. **Add timestamps** from `timing.py` for the target duration (default 13–15 minutes).
8. **Run `check_structure.py`.**
   - Fix every ERROR.
   - Fix every WARN unless it is clearly justified, for example a long closing question.
   - Then re-read the whole document and check what the script cannot:
     - each topic names a point and does not explain it;
     - no section, especially Broader Implications, drifts to a new subject;
     - no case, opposing view or "today" bridge has been forced in without a real source.
9. **Save** to `D:\.YT-vault\Script Structure\<working title>.md`. Remove Windows-forbidden characters from the filename; use «؛» for `:` and «؟» for `?`.
10. **Reply in a few lines:**
    - the central question;
    - the central argument;
    - one line per problem;
    - any weakness in the sources, such as missing documented cases or reliance on a single secondary source.

## Rules

- **Language:** Persian, with Persian digits.
- **Nothing beyond the format:** no notes, scenes, visual plans, source lists, scores or comments.
- **Sources stay invisible:** never mention the source's medium («گفت‌وگو»، «ویدیو»، «پادکست»). Name a report only when the report itself is a subject.
- **No invention:** every topic must come from the sources. If the sources cannot support a section, say so instead of filling it with generic or hypothetical topics.
- **Single-source warning:** if the sources are one secondary piece (a podcast, video or conversation transcript), warn the user that the structure may copy another creator's argument, and suggest solo-research.
- **Narration and CTA:** the narration itself never contains a CTA. Section 9's topics are the closing question plus production items.
