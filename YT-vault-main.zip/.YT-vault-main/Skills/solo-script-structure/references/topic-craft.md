# Topic Craft

## 1. What a topic is

**A topic («موضوع») is a single sentence about one point that will be explained.** It names the point; it never explains it. The explanation (the facts, numbers, scenes, quotes and examples) is written later by the narration, straight from the sources.

Think of a topic as **the heading of a paragraph the narrator will speak**, not a sentence from that paragraph.

**Typical forms**

| Form | Example |
|---|---|
| A process or mechanism | «چگونگی آموزش مدل‌های زبانی برای کاربردهای نظامی.» |
| An explanation of something | «توضیح اتصال تسلیحات به ماهواره‌ها و مسیریابی.» |
| A distinction | «تفاوت بین سلاح‌های خودمختار و سیستم‌های پشتیبانی تصمیم‌گیری.» |
| A tension | «تضاد بین پردازش سریع داده‌ها و نیاز به قضاوت حساس به شرایط.» |
| A cause | «چرا روش‌های تست مرسوم برای سیستم‌های پیچیده هوش مصنوعی ناکافی‌اند.» |
| A risk | «خطر تلقی پیش‌بینی‌های آماری به عنوان ارزیابی‌های قطعی.» |
| A labelled point | «پارادوکس اصلی: …»، «مسئله مسئولیت: …»، «تمرکز ویدئو: …» |
| A case, named only | «مطالعه موردی: گزارش استفاده از سامانه لوندر در غزه.» |
| A closing question | «سوال اصلی: …؟» |

**Length:** usually 5–18 words; questions may be longer. A topic over about 22 words is almost always an explanation in disguise.

## 2. What never goes in a topic

| Never | Bad (from a failed test) | Good |
|---|---|---|
| Narration or scene-writing | «پهپادی که ارتباط رادیویی‌اش با پایگاه قطع شده و سیگنال جی‌پی‌اس آن مختل شده، همچنان مسیرش را پیدا می‌کند، محیط را اسکن می‌کند و هدف را تشخیص می‌دهد.» | «توانایی پهپاد برای یافتن و انتخاب هدف پس از قطع ارتباط با اپراتور.» |
| Rhetoric | «این صحنه از فیلم‌های ترمیناتور نیست و همین حالا در میدان‌های نبرد واقعی در حال وقوع است.» | «فاصله میان تصویر علمی‌تخیلی ربات قاتل و سلاح‌های خودمختاری که امروز به کار می‌روند.» |
| Source mechanics | «مسئله جعبه سیاه: به گفته‌ی گفت‌وگو، حتی تیم سازنده هم نمی‌تواند در لحظه توضیح دهد…» | «مسئله جعبه سیاه: ناتوانی سازندگان در توضیح دلیل انتخاب یک هدف.» |
| Analogies | «مقایسه با قفل چهره گوشی هوشمند…»، «شبیه کیبورد گوشی…» | Delete. Analogies are the narrator's tools, not structure. |
| Colourful quotes | «…تنها یک تکه آهن بی‌مصرف در آسمان است.» | «قطع ارتباط و جنگ الکترونیک به‌عنوان انگیزه ارتش‌ها برای خودمختاری کامل.» |
| Hypotheticals presented as cases | «مطالعه موردی: پهپادی که… به اتوبوس غیرنظامیان شلیک می‌کند (سناریوی فرضی)» | A documented case, such as «مطالعه موردی: گزارش هیئت کارشناسان سازمان ملل درباره پهپاد کارگو-۲ در لیبی.», or no case at all |
| Strings of details | Several numbers, names and dates in one line | One point per line; the details stay in the sources for the narration |

Two more rules:
- **The source's medium is never mentioned:** no «گفت‌وگو»، «ویدیو»، «پادکست»، «منبع می‌گوید». Name a source only when the source itself is the subject, as in «گزارش دیده‌بان حقوق بشر به عنوان منبع اصلی.»
- **Disputed or reported matters are named as such, briefly:** «ادعای ارتش اسرائیل درباره نقش "ابزار کمکی" لوندر.»، «گزارش‌ها درباره زمان بررسی هر هدف.»

## 3. From sources to topics: synthesise, don't summarise

1. **Read every source in full.**
2. **List the points**, not the sentences: the mechanisms, distinctions, causes, cases, disputes, consequences and responses that the sources establish. Merge the same point found in several sources into one.
3. **Decide the central argument first,** then keep only the points that serve it. A fascinating point that doesn't serve the argument is dropped, however good it is.
4. **Never follow a source's order.** The structure follows the argument; the sources only supply points. If the output reads like a summary of one source, start again.
5. **Watch for thin sourcing.** If almost everything comes from one secondary source (a podcast, video or conversation transcript), tell the user. That structure risks copying another creator's argument, and its claims still need primary sources.

## 4. Sections: roles and topic order

Use the master template's per-section "Topics" checklist to know which kinds of points belong where.

- **Hook:** the concrete event or fact that opens the tension; the central tension; the human stakes; the main paradox; the responsibility or moral question.
- **Introduction:** what exactly is examined; essential distinctions; the video's focus; the main sources.
- **Background (بخش اول):** origins; key actors and systems; how it works; the gap between intended and actual operation.
- **Major problems:** the problem; its conditions and mechanism; a case, **only if a real documented one exists**; the gap between intention and outcome; the strongest opposing view, **where a real one exists**; a closing «سوال اصلی:».
- **Broader implications:** the wider consequences **of the same argument** (rights, law, responsibility, transparency, who bears the risk). **Never introduce a new subject here.**
- **Conclusion:**
  - one topic per problem, restated as a finding;
  - the connection between the problems;
  - the paradox revisited;
  - the answer to the «سوال آغازین» as far as the evidence allows;
  - a final principle.
- **Call to action:**
  - the question for viewers;
  - what to debate;
  - the invitation to the sources;
  - a related video and subscribe (production items).

Inside each section, order the topics from setup to question: context → claim → mechanism → case → opposing view → implication → closing question.

**Counts:** 4–8 topics per section; up to 10 in a problem section; Hook and CTA usually 4–6.

## 5. The other fields

- **Title (###):** a short claim or tension, such as «اولین شکست: هوش مصنوعی قبل از اینکه به طور کافی آزمایش شود، مورد استفاده قرار می‌گیرد».
- **«هدف»:** an instruction to the writer, in the imperative, saying what the section does: «…را بررسی کنید و نشان دهید که…».
- **«استدلال»:** the section's analytical claim in one to three sentences. Never rhetoric; never narration («این صحنه دیگر داستان علمی‌تخیلی نیست» is narration, not an argument).
- **«سوال آغازین»** (Hook only): the question the whole video investigates.
- **Header:** «سوال اصلی» is specific and not obviously answerable; «استدلال اصلی» is arguable and names a mechanism and its stakes.

## 6. What makes the structure strong

- **One argument:** every section advances the central argument, and no section changes the subject.
- **Escalating problems:** each problem has a distinct mechanism, ordered from the visible failure, to the amplifier, to the hidden mechanism. Use two to four problems.
- **A concrete start:** the Hook opens on a real event or striking fact, named as a topic.
- **Nothing forced:** no invented case, no token opposing view, and no forced "today" bridge. A bridge to today's Iran belongs only where the sources support it honestly.
- **A refining conclusion:** it answers the opening question and does not just list the problems again.
