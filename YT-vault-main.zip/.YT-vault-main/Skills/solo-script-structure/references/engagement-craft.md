# Engagement Craft for Video-Essay Structures

How to make each section of the template compelling, not just complete. Read this in full before outlining.

## Contents
1. The two engines: argument and story
2. The thesis and the central question
3. The first 30 seconds
4. Introduction: thesis on the table
5. Background without the lecture
6. The escalation ladder (major problems)
7. Anatomy of a strong section
8. Retention architecture
9. Showing the evidence
10. Counterarguments
11. Broader implications and the bridge to today
12. Conclusion: refine, don't repeat
13. The closing question and CTA
14. Failure patterns to avoid

---

## 1. The two engines: argument and story

A Solo video essay runs on two engines at once:

- **The argument engine** (the template): a central question, a defensible thesis, distinct problems, evidence, counterarguments, and a conclusion that refines the thesis.
- **The story engine** (the channel's narrations): a human anchor, a concrete opening scene, suspense, open questions, and a return to the opening scene.

A structure with only the argument engine reads like a report outline: every bullet is correct, but nobody watches. One with only the story engine is a documentary without a point. Every section must serve both: advance a claim, **and** move the story or the viewer's curiosity.

## 2. The thesis and the central question

**Central question tests**
- It is specific, with a who, what and when, not a vague "what about AI and war".
- Its answer is not obvious, and a smart viewer could guess wrong.
- It contains a tension: speed vs judgment, intention vs outcome, rule vs practice.
- It can be asked in one breath, so it fits on a thumbnail or in a title.

**Thesis (central argument) tests**
- It is **arguable**: a reasonable, informed person could disagree.
- It is **specific**: it names the mechanism, not just "this is dangerous".
- It has **stakes**: it says what is lost or who is harmed if it is true.
- It is **supported** by the research dossier, not by intuition.
- It **can be refined** by the end: the conclusion should sharpen it, not repeat it.

Weak: «هوش مصنوعی در جنگ خطرناک است.»
Strong: «خطر اصلی این نیست که ماشین اشتباه کند؛ این است که سرعت ماشین، قضاوت انسانی را به مهر تأیید تبدیل می‌کند و مسئولیت را بی‌صاحب می‌گذارد.»

## 3. The first 30 seconds

- **Open on the most visual, consequential moment**, a concrete scene with place, time and people, or on a contradiction carried by a number. Never open on a definition, a date-ordered history or "in this video".
- **Choose a scene that is visual, decisive (or suspended) and contradictory**, as in the channel's narrations.
- **State the stakes within about 20 seconds.**
- **End with two questions:** the contradiction («اما چگونه…؟») and the moral or interpretive question («و آیا…؟»). The second one returns at the very end.
- **The promise line comes at the start of the introduction:** «این ویدیو، داستان … است؛ داستان …».
- **Make the title, thumbnail and hook carry the same promise.** A mismatch costs viewers in the first minute.

## 4. Introduction: thesis on the table

- State the thesis plainly by about 1:30. Video essays argue openly; withholding the thesis is a documentary habit, not an essay one.
- Define only the terms the viewer needs to follow (one or two), and draw the distinctions that prevent confusion later, for example "autonomous weapon" vs "decision-support system".
- Give a credibility marker: the main sources and why they can be trusted.
- Preview the path as a sequence of escalating questions, not a table of contents, and don't spoil the turn.

## 5. Background without the lecture

- Include only the context the problems need. Ask of every background item: which later section uses this? If none, cut it.
- Tell the background through **one compact story** with a dated scene (a slug moment), not a timeline dump. Example: Petrov in 1983, a human who refused to trust the machine.
- End the background with a **turn** that sets up Problem 1: «اما ارتش‌ها درس دیگری گرفتند…»

## 6. The escalation ladder (major problems)

The template's three problems must climb, not repeat.

| Rung | Typical content | Viewer's experience |
|---|---|---|
| Problem 1: the visible failure | What goes wrong, documented | "That's worrying." |
| Problem 2: the amplifier | Scale, speed, incentives or pressure that make it worse | "It's bigger than I thought." |
| Problem 3: the hidden mechanism | Why safeguards fail, the human or institutional dynamic, the contradiction between principle and practice | "Oh. That's why it keeps happening." |

**Rules**
- **Test distinctness:** each problem must have a different mechanism. If two problems could share one title, merge them and use the template's flexibility (two to four problems).
- **Link sections causally.** Use "but" and "therefore", never "and then": «اما…»، «و درست به همین دلیل…».
- **Put a midpoint turn near 50% of the runtime:** a reveal that recontextualises what came before, often at the start of Problem 2 or 3.
- **Build Problem 3 around the strongest case study,** often the anchor's story, which returns to the opening scene.

## 7. Anatomy of a strong section

Each major section works as a mini-essay in six beats:

1. **Entry turn:** a sentence that pivots from the previous section's open question.
2. **Claim:** the section's argument in one sentence.
3. **Scene or case:** a concrete, human-scale example, with a name, a date and a place.
4. **Evidence shown:** what the viewer sees that proves the claim (see section 9).
5. **Counterpoint:** the strongest objection, attributed, and why the claim survives it, or how it narrows the claim.
6. **Exit loop:** a question or reveal that makes the next section necessary.

## 8. Retention architecture

- **Reset the viewer's attention every 60–90 seconds** with one of: a new scene, a reveal, a striking number, a direct question, a tonal shift or a change of visual mode (archive → document → map → data). Mark each reset in the outline.
- **Keep an open-loop ledger:**
  - Plant 3–5 questions in the first third.
  - Pay each one off later.
  - List them in the header.
  - Every loop must close by the conclusion.
- **Run an anchor thread:** the opening character or scene reappears at least once mid-video and fully in the return.
- **Vary density:** after a dense evidence passage, give a short human beat or a single-sentence paragraph.
- **Avoid dead zones:** no stretch of more than about 2 minutes without a scene, a case or a question.

## 9. Showing the evidence

A video essay shows rather than describes. For every key claim, plan **what is on screen**:

| Evidence | On-screen form |
|---|---|
| Official document or report | A scan with the key line highlighted, and the source and date on screen |
| A quote | On-screen text in the original language plus Persian, attributed |
| Numbers | A simple chart or a single large number; never more than one idea per graphic |
| Places and movement | A map with time stamps |
| Historical moment | Archival footage or photographs, with provenance |
| Mechanism | A diagram or animation of the process, for example the targeting chain |
| Human impact | Photographs of the place and objects, used with dignity; no gratuitous imagery of victims |

**Video-essay integrity:** clips and images must demonstrate, not decorate. Don't let a well-chosen image overstate the evidence.

## 10. Counterarguments

- Include at least one steelmanned counterargument in each major problem section, and one in the broader implications.
- Attribute it to real groups or authors: «مدافعان، از پنتاگون تا…».
- Present the strongest version, then show what survives. If the counterargument wins on a point, narrow the thesis; this is what makes the conclusion a refinement.
- Avoid false balance on settled facts; attribute disputes; never invent a strawman.

## 11. Broader implications and the bridge to today

- Move from cases to the system: who bears the risks, who holds the responsibility, and what blocks accountability.
- **Bridge to today:** the channel's strategy is to find concepts in history that speak to Iran today. Where the connection is real, draw it explicitly and concretely, for example civilian resilience, propaganda and crisis management. Keep it evidence-based and politically even-handed. Never force a parallel; if none is honest, bridge to the viewer's present in general.

## 12. Conclusion: refine, don't repeat

- Return to the central question, and answer it **as far as the evidence allows**.
- Show how the problems connect: one sentence that ties the three mechanisms together.
- Present the refined thesis: what the investigation revealed that wasn't obvious at the start.
- Return to the opening scene (the ring), and give it its full weight now that the viewer understands it.
- Offer two attributed perspectives, of similar weight.
- Close on one memorable line, usually a historical irony: «در صبحی که… تنها کسی که تردید کرد، معلمی بود با یک تلفن همراه.»
- Treat solutions and safeguards briefly and with their limits; never end on a bullet list of recommendations.

## 13. The closing question and CTA

- The closing question is the hook's second question, now harder to answer, and a genuine dilemma where both sides are defensible.
- **Channel rule:** the narration ends on the closing question. Subscribe requests, related-video plugs and source pointers belong to the editor and the video description, not the narrated text. In the structure, list them under Section 9 as production notes.

## 14. Failure patterns to avoid

| Pattern | Symptom | Fix |
|---|---|---|
| Topic list | Sections are bullet lists of subtopics with no claim | Give each section a one-sentence argument and a case |
| Lecture opening | Starts with a definition or "since ancient times" | Open on a scene or contradiction |
| Background bloat | More than 15% of the runtime before Problem 1 | Cut to what later sections use |
| Same problem three times | Problems 1–3 share one mechanism | Use the escalation ladder; merge |
| Floating claims | No case, no evidence, no visual | Add scene and evidence beats |
| Reported = proven | Investigative reports stated as fact | Label: reported, documented, official claim, disputed |
| Summary ending | Conclusion repeats the problems | Refine the thesis, return to the scene, end on irony |
| Promise drift | Title or hook promises what the body doesn't deliver | Rewrite the title last |
| Unclosed loops | Questions planted and forgotten | Check the open-loop ledger |
