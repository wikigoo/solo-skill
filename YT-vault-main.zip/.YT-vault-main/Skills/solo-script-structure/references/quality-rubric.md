# Quality Rubric

Score the finished structure honestly before delivering it. **Deliver only if every criterion scores at least 4 and the total is at least 42 out of 50.** Otherwise revise the weak sections and score again. Report the final scores to the user in one compact table.

| # | Criterion | 5: excellent | 3: weak | 1: failing |
|---|---|---|---|---|
| 1 | **Central question and thesis** | Specific, arguable, with stakes; the conclusion refines it | Clear but generic or obvious | Missing, or a topic instead of a claim |
| 2 | **First 30 seconds** | Concrete scene or contradiction, stakes, two questions, promise matches the title | Interesting but abstract or slow | Opens on a definition, history or "in this video" |
| 3 | **Escalation** | Problems climb from visible to amplifier to hidden mechanism; there is a midpoint turn | Distinct but flat | Repetitive or unordered |
| 4 | **Section distinctness and logic** | Each section has one claim; causal "but/therefore" transitions | Some sections are lists | Sections are topic dumps |
| 5 | **Human anchor and scenes** | An anchor recurs; every major section has a named case; the ring closes | Cases present but abstract | No people, no scenes |
| 6 | **Evidence and visual plan** | Every key claim has a source and an on-screen form | Evidence named but not visualised | Claims without evidence |
| 7 | **Counterarguments** | Steelmanned and attributed in every problem section and the implications | Present but weak or token | Absent or strawmen |
| 8 | **Retention architecture** | A reset every 60–90 s; 3–5 open loops, all closed; no dead zones | Some resets; loops left open | Long flat stretches |
| 9 | **Conclusion and closing question** | Refines the thesis, returns to the scene, memorable line, genuine dilemma | Summary plus a question | Repeats the opening or ends on a list |
| 10 | **Factual hygiene and fit** | Every fact traceable to the dossier; reported vs proven labelled; timing matches `timing.py` | Mostly sourced; some loose timings | Unsourced claims; wrong lengths |
