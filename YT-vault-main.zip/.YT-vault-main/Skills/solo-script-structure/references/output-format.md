# Output Format

Write the document in Persian, with Persian digits. Use exactly the fields below and nothing else: no notes, scores, source lists, tables or commentary.

```markdown
# [عنوان کاری]

**قالب:** ساختار فیلمنامه تحلیلی و انتقادی

**مدت زمان پیشنهادی:** [مثلاً ۱۲ تا ۱۵ دقیقه]

**سوال اصلی:** [یک پرسش]

**استدلال اصلی:** [تز اصلی در یک یا دو جمله]

---

## ۱. هوک (۰:۰۰–۰:۳۰)

### [عنوان بخش]

**هدف:**
[یک یا دو جمله: این بخش چه کاری با بیننده می‌کند]

**استدلال:**
[ادعای این بخش، در یک تا سه جمله]

**سوال آغازین:**
[پرسشی که کل ویدیو به آن می‌پردازد]

**موضوعات:**
- [یک جمله]
- [یک جمله]

## ۲. مقدمه (…–…)

### [عنوان بخش]

**هدف:** …
**استدلال:** …
**موضوعات:**
- …

## ۳. بخش اول (…–…)            ← Background and Context
## ۴. بخش دوم (…–…)            ← Major Problem 1
## ۵. بخش سوم (…–…)            ← Major Problem 2
## ۶. بخش چهارم (…–…)          ← Major Problem 3
## ۷. بخش پنجم (…–…)           ← Broader Implications
## ۸. نتیجه‌گیری (…–…)
## ۹. فراخوان برای اقدام (۱۰ تا ۲۰ ثانیه پایانی)
```

The `←` notes above are for you, the writer only; never write them in the document.

**Rules**
- **Section order and roles** follow the master template. With two or four problems, renumber the sections and keep the same naming pattern («بخش …»).
- **Every section has** «هدف»، «استدلال» and «موضوعات». «سوال آغازین» appears only in the Hook.
- **Timestamps** come from `scripts/timing.py`, written as `(۰:۰۰–۰:۳۰)` in Persian digits; Section 9 is written as «(۱۰ تا ۲۰ ثانیه پایانی)».
- **The section title (###)** is a short claim or tension, such as «اولین شکست: هوش مصنوعی قبل از اینکه به طور کافی آزمایش شود، مورد استفاده قرار می‌گیرد», not a label.
- **Each topic** is one bullet holding one sentence or phrase that ends with «.» or «؟». A short label prefix is allowed: «پارادوکس اصلی:»، «مطالعه موردی:»، «سوال اصلی:»، «تمرکز ویدئو:».
- **Sub-bullets** are allowed only when a source gives a list, such as the five capabilities named in a report; each sub-bullet is still one sentence.
- Use a horizontal rule (`---`) only after the header block.
