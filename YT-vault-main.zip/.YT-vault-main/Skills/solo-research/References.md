
## Encyclopedias
https://www.wikipedia.org/
https://www.britannica.com/
https://www.encyclopedia.com/
https://www.worldhistory.org/
## Article 
https://scholar.google.com/
https://www.researchgate.net/
https://www.jstor.org/

## News Agencies
https://apnews.com/
https://www.bbc.com/
https://www.nytimes.com/
https://www.theguardian.com/
https://www.washingtonpost.com/

## Magazine
https://www.ted.com/
https://ed.ted.com/
https://wire.com/en/
https://bigthink.com/
https://www.scientificamerican.com/

## YouTube channels
https://www.youtube.com/@premodernist_history/videos
https://www.youtube.com/@PeopleProfiles/videos
## History
https://ahf.nuclearmuseum.org/ahf/nuc-history/

## Fact
https://www.factretriever.com/
https://kids.kiddle.co/
## war
https://autonomousweaponswatch.org/