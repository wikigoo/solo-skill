#!/usr/bin/env python3
"""
tts_lint.py — pre-TTS checks for Solo channel Persian narration scripts.

Usage:
  python tts_lint.py <script.md> [--glossary glossary.md] [--original original.md]

What it checks (report only; it never edits the file):
  1. Orthography: Arabic ي/ك, Arabic-Indic or Latin digits, Latin letters, tatweel,
     spacing around punctuation, ZWNJ misuse, ezafe hamza «ه\u0654», separated «ه ی».
  2. TTS hazards: "...", parentheses, brackets, dashes, straight/curly quotes, %, :, /.
  3. Diacritics: total count, density per 1,000 words, every marked word, and words
     carrying more than one mark (likely over-vocalised).
  4. Glossary: every unmarked occurrence of a glossary headword (homographs, names).
  5. Breath and rhythm: very long sentences without an internal pause, comma pile-ups,
     ellipsis count.
  6. Fidelity (with --original): compares the letters of both files after removing
     diacritics, punctuation, spaces and ZWNJ, and lists every place where the
     wording differs. Expected differences are only number/symbol normalisations.
"""
import re
import sys
import difflib
import argparse
import unicodedata

DIAC = "\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652\u0654\u0670"
DIAC_RE = re.compile("[" + DIAC + "]")
ZWNJ = "\u200c"
# Persian/Arabic letters and digits only (excludes punctuation such as ، ؛ ؟)
PL = "\u0621-\u063A\u0641-\u064A\u0660-\u0669\u0671-\u06D3\u06D5\u06F0-\u06F9"
WORD_RE = re.compile("[" + PL + "\u200c" + DIAC + "]+")
SENT_SPLIT = re.compile(r"(?<=[.!؟?])\s+|\n+")


def strip_diac(s):
    return DIAC_RE.sub("", s)


def body_lines(text):
    """Return (line_no, line) pairs, skipping fenced code blocks."""
    out, fenced = [], False
    for i, line in enumerate(text.splitlines(), 1):
        if line.strip().startswith("```"):
            fenced = not fenced
            continue
        if not fenced:
            out.append((i, line))
    return out


def find(pattern, lines, flags=0, limit=8):
    rx = re.compile(pattern, flags)
    hits = []
    for n, line in lines:
        for m in rx.finditer(line):
            a, b = max(0, m.start() - 12), min(len(line), m.end() + 12)
            hits.append((n, line[a:b].replace("\n", " ")))
    return hits[:limit], len(hits)


def report(title, hits_total, note=""):
    hits, total = hits_total
    if total == 0:
        return
    print(f"  ! {title}: {total}" + (f"  ({note})" if note else ""))
    for n, ctx in hits:
        print(f"      line {n}: …{ctx}…")


def load_glossary(path):
    """Headwords = first cell of rows in tables whose header's first cell is «نوشتار»."""
    words, in_table = [], False
    for line in open(path, encoding="utf-8"):
        s = line.strip()
        if not s.startswith("|"):
            in_table = False
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if not cells:
            continue
        first = cells[0]
        if first == "نوشتار":
            in_table = True
            continue
        if not in_table or set(first) <= set("-: "):
            continue
        w = strip_diac(first.strip("«» "))
        if w and re.fullmatch(r"[\u0600-\u06ff\u200c ]+", w):
            words.append(w)
    return sorted(set(words), key=len, reverse=True)


def letters_only(text):
    t = strip_diac(text)
    t = t.replace("ي", "ی").replace("ك", "ک").replace("ۀ", "ه")
    t = re.sub(r"^#.*$", "", t, flags=re.M)
    return "".join(ch for ch in t if unicodedata.category(ch)[0] in "LN")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--glossary")
    ap.add_argument("--original")
    a = ap.parse_args()

    text = open(a.file, encoding="utf-8").read()
    lines = body_lines(text)
    body = "\n".join(l for _, l in lines if not l.startswith("#"))
    words = WORD_RE.findall(body)
    nwords = len(words)
    print(f"== tts_lint: {a.file}")
    print(f"   words: {nwords}")

    print("\n[1] Orthography")
    report("Arabic yeh/kaf (ي ك) — use ی ک", find(r"[يك]", lines))
    report("Arabic-Indic digits (\u0660-\u0669) — use ۰-۹", find(r"[\u0660-\u0669]", lines))
    report("Latin digits — use Persian digits", find(r"[0-9]", lines))
    report("Latin letters", find(r"[A-Za-z]+", lines))
    report("Tatweel ـ", find(r"ـ", lines))
    report("Space before punctuation", find(r" [،؛.؟!:»]", lines))
    report("No space after punctuation", find(r"[،؛؟!][^\s»\]\)]", lines))
    report("Double spaces", find(r"\S  +\S", lines))
    report("ZWNJ next to a space or doubled", find(r"\u200c[ \u200c]|[ ]\u200c", lines))
    report("Ezafe hamza mark «ه\u0654» (house style: no explicit ezafe)", find(r"ه\u0654|ۀ", lines))
    report("Separated «ه ی» ezafe", find(r"ه ی(?=[\s،.؛])", lines))
    report("Detached «می »/«نمی » prefix (needs ZWNJ)", find("(?<![" + PL + "])ن?می (?=[" + PL + "])", lines))
    report("Detached plural «ها» (needs ZWNJ)", find("[" + PL + r"] ها(?=[\s،.؛؟]|ی)", lines))

    print("\n[2] TTS hazards")
    report("Three dots «...» — use «…» only where intended", find(r"\.\.\.", lines))
    report("Parentheses", find(r"[()]", lines))
    report("Square brackets (audio tags?)", find(r"\[[^\]]*\]", lines))
    report("Dashes", find(r"[—–]| - ", lines))
    report("Non-Persian quotes", find(r"[\"“”']", lines))
    report("Percent sign", find(r"[%٪]", lines), "write «درصد»")
    report("Colon or slash between digits", find(r"[۰-۹0-9][:/][۰-۹0-9]", lines), "write the spoken form")
    report("Abbreviation with a dot", find("(?<![" + PL + "])[" + PL + r"]\.[" + PL + r"]\.?", lines), "expand: ق.م → پیش از میلاد")

    print("\n[3] Diacritics")
    marked = [w for w in words if DIAC_RE.search(w)]
    tanvin_alef = [w for w in marked if strip_diac(w).endswith("ا") and "\u064b" in w and len(DIAC_RE.findall(w)) == 1]
    added = [w for w in marked if w not in tanvin_alef]
    dens = (len(added) / nwords * 1000) if nwords else 0
    print(f"   marked words (excluding standard «ـا\u064b» tanvin): {len(added)}  |  per 1,000 words: {dens:.1f}")
    if dens > 15:
        print("  ! Density above 15 per 1,000 words: review for over-vocalisation")
    multi = [w for w in added if len(DIAC_RE.findall(w)) > 1]
    if multi:
        print(f"  ! Words with more than one mark ({len(multi)}): " + "، ".join(sorted(set(multi))[:30]))
    if added:
        freq = {}
        for w in added:
            freq[w] = freq.get(w, 0) + 1
        print("   marked: " + "، ".join(f"{w}×{c}" if c > 1 else w for w, c in sorted(freq.items(), key=lambda x: -x[1])))

    if a.glossary:
        print("\n[4] Glossary headwords found UNMARKED (decide one by one)")
        heads = load_glossary(a.glossary)
        any_hit = False
        for h in heads:
            rx = re.compile("(?<![" + PL + "\u200c" + DIAC + "])" + re.escape(h) + "(?=$|[^" + PL + DIAC + "]|\u200c)")
            hits = []
            for n, line in lines:
                if line.startswith("#"):
                    continue
                for m in rx.finditer(line):
                    s, e = max(0, m.start() - 15), min(len(line), m.end() + 15)
                    hits.append(f"line {n}: …{line[s:e]}…")
            if hits:
                any_hit = True
                print(f"   «{h}» ×{len(hits)}")
                for x in hits[:6]:
                    print("      " + x)
        if not any_hit:
            print("   none")

    print("\n[5] Breath and rhythm")
    sentences = [s for s in SENT_SPLIT.split(body) if s.strip()]
    long_np = [s for s in sentences if len(s.split()) > 40 and not re.search(r"[،؛:]", s)]
    piles = [s for s in sentences if s.count("،") >= 5]
    print(f"   sentences: {len(sentences)}  |  ellipses «…»: {body.count('…')}  |  commas: {body.count('،')}")
    for s in long_np[:5]:
        print(f"  ! >40 words without an internal pause: {s.strip()[:90]}…")
    for s in piles[:5]:
        print(f"  ! 5+ commas in one sentence: {s.strip()[:90]}…")

    if a.original:
        print("\n[6] Fidelity vs original (letters only; diacritics, punctuation, spaces ignored)")
        o = letters_only(open(a.original, encoding="utf-8").read())
        e = letters_only(text)
        if o == e:
            print("   IDENTICAL wording: only diacritics, punctuation, spacing or ZWNJ changed")
        else:
            sm = difflib.SequenceMatcher(None, o, e, autojunk=False)
            n = 0
            for tag, i1, i2, j1, j2 in sm.get_opcodes():
                if tag == "equal":
                    continue
                n += 1
                if n <= 40:
                    print(f"  ! {tag}: «{o[max(0,i1-10):i2+10]}» → «{e[max(0,j1-10):j2+10]}»")
            print(f"   {n} difference(s). Each must be an intended normalisation or a spelling fix; anything else is a fidelity violation.")

    print("\n== end")


if __name__ == "__main__":
    main()
