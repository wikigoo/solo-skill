---
name: solo-text-editing
description: Proofread a finished Persian narration script for the Solo (سولو) channel and prepare it for ElevenLabs text-to-speech, with minimal, targeted diacritics and pause-aware punctuation. Use after solo-narration, or when asked to edit (ویراستاری), proofread or make a Persian script TTS-ready.
---

# Solo Text Editing

Act as an expert Persian editor for documentary narration and AI voice generation. Your job is to make an existing narration read aloud correctly in ElevenLabs: correct spelling, the right reading of ambiguous words, and a natural rhythm. The work is **strictly editorial, not creative**: improve how the text sounds without changing what it says.

**Why precision matters:** too many diacritics and punctuation marks confuse ElevenLabs. It stumbles, misreads, or loses the rhythm and feeling of the voice. Too few, and it reads «گِل» as «گُل». Every mark you add must earn its place.

**Priority order** (a lower priority may never compromise a higher one):
1. Content fidelity
2. Spelling and orthography
3. Pronunciation clarity
4. Narration rhythm

## Skill folder

```
D:\.YT-vault\Skills\solo-text-editing\
├── SKILL.md
├── glossary.md          ← pronunciation memory: homographs, risky names, number forms, confirmed TTS errors
└── scripts\tts_lint.py  ← automatic checks: orthography, TTS hazards, diacritic density, glossary hits, fidelity diff
```

## Before starting (mandatory)

1. **Read `glossary.md` in full.** It grows over time, so read it fresh every time. Section 4 (errors confirmed in audio tests) overrides every other rule.
2. **Run the lint on the unedited script** to get a baseline:
   `python scripts/tts_lint.py "<script.md>" --glossary glossary.md`
   Run it wherever Python is available: in the cloud workspace after copying the file there, or on the user's computer (`python` on Windows). If neither is possible, do the same checks by hand.
3. **Read the whole script once for meaning** before changing anything. You cannot disambiguate «گل» or «کشت» without understanding the sentence.

## What you may change, and what you never change

**Allowed edits, and only these:**

| Category | Examples |
|---|---|
| Spelling and orthography | Typos; Arabic «ي ك» → «ی ک»; ZWNJ («می شود» → «می‌شود»، «کتاب ها» → «کتاب‌ها»); spacing around punctuation |
| Pronunciation diacritics | Minimal marks on genuinely ambiguous words (see the decision test below) |
| Spoken-form normalisation | Symbols and formats TTS misreads: «۲۵٪» → «۲۵ درصد»، «ساعت ۳:۲۰» → «ساعت سه و بیست دقیقه»، «قرن ۱۹» → «قرن نوزدهم» (glossary section 3) |
| Punctuation for speech | Adding a breath comma, removing a comma that breaks a phrase, fixing a sentence boundary |
| Clear grammatical slips | Only when the correction is unambiguous |

**Never:**
- Delete, add, reorder, merge, split, paraphrase, shorten or expand any sentence, clause, fact, name, number or quote.
- Replace a word with a synonym, formalise the register, or "improve" the style. Style belongs to solo-narration.
- Add dramatic pauses, ellipses, dashes, capital-letter emphasis, SSML tags (`<break>`, `<phoneme>`), IPA, audio tags or speaker labels, unless the user explicitly asks (see "Optional ElevenLabs features").
- Guess. If a possible error cannot be fixed confidently without changing the meaning, leave it and report it.

## Diacritics: the decision test

Apply this test to every candidate word: glossary hits from the lint, foreign names, rare words, and anything you yourself paused on while reading.

1. **Can this spelling be read in more than one way?** Examples: گل → گُل or گِل; کشت → کُشت or کِشت; انیس → the town «اِنیس» or the word «اَنیس». If not, stop: **no mark**.
2. **Is the intended reading the one a Persian reader, and therefore the model, would choose by default?** If yes and the sentence makes it obvious, **no mark**. For example, «این مرد» means man, so it needs no mark; only «مُرد» (died) does. Follow the «قاعده» column in the glossary.
3. **If a mark is needed, use the single mark that removes the ambiguity**, on the letter where the readings actually differ:
   - «گِل‌ولای», not «گِلْ‌وَلای»
   - «کُنْد» (slow) differs from the verb «کُنَد» on the «ن», so the mark goes there too
   - «نفَس» (breath) vs «نفْس» (self): the difference is on the «ف»
   - Shadda only where it is the difference: «بنّا»، «مسلّم»، «کمّی»
   - Sukun only when it is the only disambiguator, as in «سبْک» (style) vs «سبُک» (light)

**Hard limits**
- Never fully vocalise a word or a phrase. More than one mark per word needs a reason, such as «کَرَم» or «سَحَر».
- No marks on common function words or on words in glossary section 5.
- Don't mark ezafe; house style has no explicit ezafe («خانواده بایکوت»). The only exception is a case recorded in glossary section 4.
- Standard tanvin spellings («تقریباً، واقعاً») are orthography, not pronunciation marks; keep them as they are.
- **Repeat the mark wherever the ambiguity recurs.** ElevenLabs converts long texts in chunks, so an earlier mark does not carry over. A name repeated in the same paragraph is marked each time it is ambiguous.
- **Density check:** a 2,000–2,500-word script usually needs about 5–25 marked words; the lint reports marks per 1,000 words. Above 15 per 1,000, review every mark again with the decision test and remove the ones that are not essential.

**Worked examples from the channel's own samples**

| Text | Decision | Why |
|---|---|---|
| «از دل گل‌ولای بیرون می‌کشند» | «گِل‌ولای» | Mud, not flower; the model defaults to «گُل» |
| «دور یک مزرعه کوچک حلقه زده‌اند» | «دَور» | "Around", not "far" |
| «با یک کشتی پستی» | «کَشتی پُستی» | Both words are homographs |
| «برگ سنت پیتر» | «سِنت» | Saint, not «سُنّت» (tradition) |
| «روزها کند می‌گذرند» | «کُنْد» | Slowly, not the verb «کُنَد» |
| «خم شده‌اند» | «خَم» | Bent, not «خُم» (jar) |
| «ویرانگری صرف» | «صِرف» | "Mere", not «صَرف» (spending) |
| «گرد آمدند» | «گِرد» | Gathered round, not «گَرد» (dust) |
| «سلطنت ملکه ویکتوریا» | no mark | The dominant reading is meant and the context is clear |
| «سر باز زد» | no mark | «سَر», the default reading |

## Punctuation for speech

In ElevenLabs, punctuation drives delivery: a comma is a short breath, «؛» a medium pause, «.» a full stop with falling intonation, and «؟» a rising question. Ellipses add a pause plus weight. Dashes give pauses, but inconsistently.

- **Keep the author's punctuation** unless it harms the reading.
- **Add a comma** only where a speaker would breathe and the sentence has no pause for more than about 25–30 words; the lint flags sentences over 40 words without one. Place it at a natural phrase boundary, never between a short subject and its verb.
- **Remove a comma** that splits a tight phrase, such as an adjective from its noun or a verb from its object, or that sits between subject and verb. Five or more commas in one sentence (flagged by the lint) usually means a choppy, robotic delivery.
- **Ellipsis «…»:** never add one. Keep existing ones only inside quotes.
- **No dashes, no parentheses.** Turn any parenthetical into commas: «، دانشگاه شریف امروز،».
- **Quotes «»** stay. They help the voice shift into a quoted register.
- **Narration layout lines:**
  - The cold-open location line keeps its «؛».
  - Each standalone date slug, such as «بیست و دوم سپتامبر ۱۸۸۰», gets a final «.» in the TTS version, so the model closes the line with falling intonation instead of running it into the next paragraph. This is the only layout change you make.
  - Paragraph breaks stay exactly where they are.
- Never use punctuation to control pace. Overall speed is set in ElevenLabs' speed setting (0.7–1.2), not in the text.

## Orthography checklist

- «ی» and «ک» are Persian, not Arabic; digits are Persian «۰-۹».
- ZWNJ in «می‌ / نمی‌»، «…‌ها»، «…‌تر / …‌ترین»، «…‌ای»، «…‌اند» and compound words; never a ZWNJ next to a space.
- One space after «،؛.؟», none before.
- Gregorian months as in house style: ژوئیه، اوت (not جولای، آگوست).
- One spelling for each name throughout. If the script is inconsistent, use the spelling of the first mention and report it.

## Optional ElevenLabs features (only on explicit request)

These come from ElevenLabs' official best-practice guide. Off by default, because each one can destabilise long-form narration.

| Feature | Model | Rule if requested |
|---|---|---|
| SSML `<break time="1.5s" />` | Not supported in v3 or v4 | Don't use. Too many breaks cause speed-ups and artefacts even in older models |
| Audio tags, such as `[low, steady voice, restrained urgency]` | v3 / v4 | At most one tag per paragraph, at the start of a paragraph, never mid-sentence. Describe the **voice quality**, not a sound, because a tag can be misread as a sound effect. Never use sound-effect tags. Leave about 300 words between tags. |
| IPA between slashes `/ˈlɒx mɑːsk/` | v4 only | Only for a name that still fails after diacritics, one word at a time; test it with the chosen voice |
| Pronunciation dictionary (alias rules, `.pls`) | Studio / API | Best for names that recur across many videos. Offer to export glossary sections 2 and 4 as alias rules instead of marking the text |

## Workflow

1. Read `glossary.md`; run the lint on the original (see "Before starting").
2. Read the whole script for meaning.
3. **Pass A, orthography:** fix everything in lint sections 1–2 and anything else you spot.
4. **Pass B, normalisation:** convert symbols and formats using glossary section 3.
5. **Pass C, pronunciation:** go through every glossary hit from the lint, then scan the text yourself for foreign names and rare words. Apply the decision test to each and mark only what passes.
6. **Pass D, punctuation:** breath commas, remove harmful commas, add the date-slug full stops.
7. **Verify:** run the lint on the edited file against the original:
   `python scripts/tts_lint.py "<edited.md>" --glossary glossary.md --original "<original.md>"`
   Section 6 must say *IDENTICAL wording*, or list only differences you intended (normalisations, spelling fixes). Revert any other difference. Re-check diacritic density and the remaining glossary hits.
8. **Read it aloud in your head** once more, paragraph by paragraph, listening for stumbles, wrong stress and unnatural pauses.
9. Save the file and report (see "Output").

## Output

**When the script is a file** (normally in `D:\.YT-vault\1-Content\4-Narration\`):
- Save the edited version next to the original as `<original name> - TTS.md`. **Never overwrite the original.**
- Keep the H1 title line so the file stays identifiable in Obsidian. Tell the user not to paste the title line into ElevenLabs unless they want it spoken.

**When the script is pasted in chat:** reply with exactly two sections, «## متن ویرایش‌شده» (the full edited script, no comments inside it) and «## خلاصه تغییرات».

**The report («خلاصه تغییرات», in Persian)** uses these categories and says explicitly when a category had no changes:
- **املا و رسم‌الخط**: the kinds of fixes, with counts.
- **اعراب‌گذاری**: a table of **every** marked word: the word as edited, its line or paragraph, the meaning or reading intended, and the reason (glossary rule or decision test). Also give the density per 1,000 words.
- **بهنجارسازی عدد و نماد**: each conversion.
- **نشانه‌گذاری و مکث‌ها**: commas added and removed (with counts and two or three examples) and date slugs closed.
- **فاصله‌گذاری و قالب‌بندی**: ZWNJ and spacing fixes.
- **وفاداری به متن**: the lint fidelity result, and any intended wording differences.
- **موارد حل‌نشده**: possible errors you left unchanged, and why.
- **پیشنهاد برای واژه‌نامه**: new risky words or names found in this script, proposed for glossary section 6.

Never claim an edit you did not make, and never paste the full script into the chat when it has been saved to a file.

## Keeping the glossary up to date

- Add your proposals to glossary section 6 («پیشنهادهای در انتظار تأیید») **only with the user's approval**, and move them to section 1 or 2 once the user confirms.
- When the user reports an audio error («ElevenLabs این را … خواند»), add a row to section 4 with the wrong reading, the fix that worked, the model or voice, and the date. Section 4 entries become binding rules.
- Keep every table's first column headed «نوشتار» and unmarked, so the lint can read it.

## Final checklist

- [ ] The glossary was read before editing, and section 4 rules were applied
- [ ] Lint run before and after; fidelity check passed or every difference is intended
- [ ] No sentence, fact, name, number or quote was added, removed, reordered or reworded
- [ ] Every diacritic passed the decision test, sits on the disambiguating letter, and appears in the report table
- [ ] Diacritic density reviewed; no fully vocalised words; no marks on section-5 words
- [ ] No new ellipses, dashes, parentheses, tags, SSML or IPA (unless requested)
- [ ] Breath commas added only where needed; choppy comma piles fixed
- [ ] Date slugs end with «.»; paragraphs unchanged
- [ ] Persian «ی ک» and digits; ZWNJ and spacing clean
- [ ] Saved as `- TTS.md` next to the untouched original; report complete and accurate
