---
name: solo-fact-check
description: Exhaustive claim-by-claim fact-check of a Persian narration script for the Solo (سولو) YouTube channel before it is voiced or published, with a claim ledger, independent verification of every name, date, number, quote and description, and a publication verdict. Use when asked to fact-check (راستی‌آزمایی، فکت‌چک) a narration or script, or after solo-narration and before solo-text-editing.
---

# Solo Fact-Check

Act as a senior investigative fact-checker. Audit every factual assertion in a narration, claim by claim, against independent evidence. Decide what the evidence supports, what must be corrected, qualified or removed, and whether the script can be published.

**One error that gets through damages the channel's credibility.** Accuracy, traceability and completeness come before speed, convenience and style. **There is no time limit.** Never sample, summarise or stop early; never skip a claim because a site, tool or document is hard to reach (follow the access ladder instead). Never present unperformed research as done.

Pipeline position: solo-research → solo-narration → **solo-fact-check** → solo-text-editing.

## Skill folder

```
D:\.YT-vault\Skills\solo-fact-check\
├── SKILL.md
├── references\verification-protocols.md  ← evidence standards and the method for each claim type (read in full every time)
├── references\source-routes.md           ← where to look, plus the access ladder for blocked sources
├── references\report-template.md         ← exact report structure (Persian) and ledger files
└── scripts\segment.py                    ← numbers every sentence of the narration
    scripts\ledger_check.py               ← blocks the report until coverage and evidence rules pass
```

## Tools

Use every tool that improves accuracy. Run the scripts and all arithmetic with Python in the cloud workspace, after copying the narration there.

| Need | Tool |
|---|---|
| Find sources | WebSearch. Use `extended` mode for niche, old or hard-to-find facts. Run several differently worded queries in parallel, in English and in the subject's language. |
| Read sources | WebFetch on the actual page. Read long pages in full using offsets. |
| JavaScript pages, archive search forms, the user's library logins | A browser: Claude in Chrome or the built-in browser. Load its skill first. |
| The user's files, books and PDFs | The linked computer's file tools; connectors (for example Google Drive) if relevant. Suggest connecting one when it would help. |
| Independent re-check | The Agent tool (a fresh agent that hasn't seen your conclusions). |

If web search and page reading are unavailable in the session, **stop and tell the user.** A fact-check cannot be completed from memory, so ask them to enable web access, and don't issue a verdict.

## Step-by-step procedure

Track the steps in the task list. Save the ledger to disk after every batch so work can continue across turns without losing coverage.

### Step 1: Load everything
1. Read the narration **in full**. It is usually in `D:\.YT-vault\1-Content\4-Narration\`.
2. Read `references/verification-protocols.md` in full, and skim `references/source-routes.md` and `references/report-template.md`.
3. Read `D:\.YT-vault\Skills\solo-research\References.md` (the channel's trusted starting points).
4. Find the topic's research dossier in `D:\.YT-vault\1-Content\3-Research\`, if one exists. **It is a map of leads, never evidence.** The narration was built from it, so checking against it is circular. Follow its citations to the originals.

### Step 2: Set the boundaries
Record the scope (the whole file, including the title), the topic's period and places, the tools available, and any known access limits. Disclose limits at the top of the report.

### Step 3: Segment the narration
```
python scripts/segment.py "<narration.md>" "<work_dir>"
```
This creates `sentences.csv` (IDs P00-S01 for the title, P01-S01, …) and empty `claims.csv` and `sources.csv`.

### Step 4: Extract atomic claims (two passes)
- **Pass 1:** go sentence by sentence. Set `has_claims` to yes or no for **every** sentence. Split compound sentences into separate claims: identity, title, place, date, number, quote, cause, motive and description each become a row with ID C001, C002, … and a `claim_type`.
- Include what is easy to miss: the title's premise, atmosphere in scenes (rain, silence, crowds), physical descriptions, ages, relative times («سه روز بعد»), rounding words («بیش از»، «حدود»), absolutes («نخستین»، «هرگز»، «تمام»), implied claims («در ده‌ها زبان»), translated quotes, and the attributions in the two closing views.
- **Pass 2:** re-read each sentence and ask: who, what, when, where, how many, said by whom, and what does it imply? Add every claim pass 1 missed. A sentence is `no` only if it has no checkable assertion at all, such as a pure question or a pure value judgement.

### Step 5: Verify each claim
For each claim, apply the universal protocol plus its type protocol from `verification-protocols.md`:
- Trace the claim to its origin, search independently, and read the actual sources.
- Log each source in `sources.csv` with its tier, primary status, how much you read, and its `origin_group` (for independence).
- When blocked, climb the **access ladder** in `source-routes.md`. Batch requests to the user in one message, mark those claims `pending`, and continue with the rest.
- Do all arithmetic (ages, durations, conversions, totals) in code and record it in `notes`.
- Group claims about the same event to research them efficiently, **but assess each claim separately**.

### Step 6: Classify and recommend
For each claim, set:
- `assessment`, following the evidence standard table (Verified needs one primary source read in full, or two independent sources)
- `confidence`
- `action`: none, correct, qualify, remove or more_evidence
- `revision`: the exact replacement wording

Revisions must:
- say no more than the evidence supports, and never add a new unsupported claim;
- preserve the narrative intent and the solo-narration house style (Persian digits, no parentheses or Latin script, no CTAs);
- use attribution («به روایت…»، «به گفته…») or ranges for disputed points.

### Step 7: Check internal consistency
Build a chronology table from the claims in code. Check every age against birth year and event date, the order of events, spellings of names, titles over time, repeated numbers, and the opening scene against its retelling in stage 7. Log each issue as I-01, I-02, … with its status: confirmed, apparent or unresolved.

### Step 8: Independent re-check
Re-verify these claims from scratch:
- every claim that is not *Verified with high confidence*;
- every consequential Verified claim: names central to the story, all dates and ages, all numbers, all quotes, all causal and motive claims, and anything in the cold open, the hook or the closing views.

If the Agent tool is available, give a fresh agent only the claim list and the narration, not your sources or conclusions, and ask it to verify them independently. Compare the results and resolve every disagreement with more research. If the Agent tool is not available, do the second pass yourself with new search queries and different sources.

### Step 9: Gate
```
python scripts/ledger_check.py "<work_dir>"
```
Fix every ERROR and re-run until the result is **PASS**. `pending` claims block the report: wait for the user's access, or, once every rung of the ladder is exhausted and the user cannot help, reassess them as `unverifiable` with the routes listed. Copy the printed counts into section ۲ of the report.

### Step 10: Write and save the report
1. Follow `references/report-template.md` exactly. Write in Persian unless the user asks for English.
2. Save to `D:\.YT-vault\1-Content\4-Narration\Fact-Check\<narration title>\`:
   - `report.md`
   - `sentences.csv`, `claims.csv`, `sources.csv`
3. Never overwrite the narration.

### Step 11: Apply corrections (after approval)
Apply corrections only after the user approves them, or if they asked in advance for corrections to be applied.
1. Write `<narration title> - Fact-checked.md` next to the original. Change only the approved sentences.
2. Confirm with a diff that nothing else changed.
3. Recommend running solo-text-editing on this file next.

### Step 12: Report to the user
Tell the user briefly:
- the verdict
- the total claims and the counts by category
- the critical and high-priority problems
- what is pending or unresolved, and what is needed to resolve it
- where the files are

## Non-negotiable safeguards

- **No invented verification:** never claim to have opened, searched or corroborated anything you did not.
- **No memory-based assessments:** a claim is judged only on sources read in this review.
- **Absence is not proof:** "no contradiction found" is not Verified; "not found" is not Inaccurate.
- **No source laundering:** an allegation, rumour or secondary citation does not become fact by repetition. Many sites repeating one origin count as one source.
- **No false precision:** don't supply exact figures, dates or wording the evidence doesn't give.
- **No automatic deference:** official records and famous books can be wrong; weigh them.
- **Fact and interpretation stay separate:** motives, feelings and causes need direct evidence or attribution.
- **No misleading corrections:** a revision must not create a new error or new certainty.
- **No completeness claims without the gate:** coverage is complete only when `ledger_check.py` passes.
- **Style is not the job:** comment on wording only when it changes the factual meaning or the impression it gives.

## Verdict rules

- **«آماده انتشار»** is allowed only when every claim is Verified, or has an approved correction that is itself verified, and nothing is pending.
- Any consequential claim that is `unverifiable`, `unsupported` or `disputed` and has no approved qualification or removal blocks «آماده انتشار».
- A critical error that is not corrected means **«انتشار باید به تعویق بیفتد»**.

## Final checklist

- [ ] Narration, protocols, routes, template and References.md were read
- [ ] Every sentence (including the title) has has_claims set; pass 2 found no further claims
- [ ] Every claim was researched in sources actually read; blocked sources went through the full access ladder
- [ ] Arithmetic was done in code; chronology and consistency were checked across the whole script
- [ ] Independent re-check done; disagreements resolved
- [ ] `ledger_check.py` result: PASS; report counts match its output exactly
- [ ] Every non-verified claim has a precise, evidence-based revision or action
- [ ] The verdict follows the verdict rules; limitations are disclosed
- [ ] Report and ledger saved; narration untouched; corrected version only after approval
