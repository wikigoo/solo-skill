#!/usr/bin/env python3
"""
segment.py: split a Persian narration (Markdown) into numbered sentences for the claim ledger.

Usage:
  python segment.py <narration.md> <out_dir>

Writes <out_dir>/sentences.csv with columns:
  sentence_id, paragraph, text, has_claims
IDs look like P00-S01 (P00 = the H1 title), P01-S01, P01-S02, ...
`has_claims` is left empty; the fact-checker fills it with yes/no for EVERY row.
Also writes empty claims.csv and sources.csv with the correct headers if they do not exist yet.
"""
import csv
import os
import re
import sys

SPLIT = re.compile(r"(?<=[.!?؟])\s+")

CLAIMS_HEADER = ["claim_id", "sentence_id", "atomic_claim", "claim_type", "assessment",
                 "confidence", "sources", "action", "revision", "notes"]
SOURCES_HEADER = ["source_id", "tier", "primary", "title", "author", "date",
                  "url_or_locator", "accessed", "origin_group", "establishes"]


def paragraphs(text):
    lines = text.splitlines()
    title, body, cur = None, [], []
    for line in lines:
        s = line.strip()
        if s.startswith("# ") and title is None:
            title = s[2:].strip()
            continue
        if not s:
            if cur:
                body.append(" ".join(cur))
                cur = []
            continue
        cur.append(s)
    if cur:
        body.append(" ".join(cur))
    return title, body


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    src, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    title, body = paragraphs(open(src, encoding="utf-8").read())
    rows = []
    if title:
        rows.append(["P00-S01", "0", title, ""])
    for pi, para in enumerate(body, 1):
        sents = [s.strip() for s in SPLIT.split(para) if s.strip()]
        for si, s in enumerate(sents, 1):
            rows.append([f"P{pi:02d}-S{si:02d}", str(pi), s, ""])
    with open(os.path.join(out, "sentences.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["sentence_id", "paragraph", "text", "has_claims"])
        w.writerows(rows)
    for name, header in (("claims.csv", CLAIMS_HEADER), ("sources.csv", SOURCES_HEADER)):
        p = os.path.join(out, name)
        if not os.path.exists(p):
            with open(p, "w", encoding="utf-8-sig", newline="") as f:
                csv.writer(f).writerow(header)
    print(f"paragraphs: {len(body)}  sentences: {len(rows)}  -> {out}")


if __name__ == "__main__":
    main()
