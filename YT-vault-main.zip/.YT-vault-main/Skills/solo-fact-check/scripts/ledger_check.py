#!/usr/bin/env python3
"""
ledger_check.py: validate the fact-check ledger before any report is written.

Usage:
  python ledger_check.py <ledger_dir>

Reads sentences.csv, claims.csv and sources.csv (see segment.py for headers) and enforces:
  Coverage   - every sentence has has_claims = yes|no; every "yes" sentence has >= 1 claim;
               every claim points to an existing sentence.
  Fields     - valid enums; confidence present; source ids exist.
  Evidence   - "verified" needs EITHER one primary source read in full,
               OR two sources read (full/excerpt) from different origin_groups, tier <= 5.
               "verified" quotes need a primary source (original or reliable edition) read in full.
               Sources marked not-accessed never count as evidence.
  Actions    - partial/inaccurate/misleading need action=correct|qualify|remove plus revision text
               (or action=remove); unsupported/disputed/unverifiable need action other than none.
  Pending    - any "pending" claim blocks a final report.
Prints the category counts for section II of the report. Exit code 1 if any ERROR.
"""
import csv
import os
import sys
from collections import Counter

ASSESS = ["verified", "partial", "inaccurate", "misleading", "unsupported", "disputed", "unverifiable", "pending"]
TYPES = ["person", "title_role", "date", "age_duration", "place", "number", "quote", "event",
         "causal", "motive", "superlative_absence", "description", "atmosphere", "translation", "other"]
CONF = ["high", "medium", "low"]
ACTIONS = ["none", "correct", "qualify", "remove", "more_evidence"]
ACCESS = ["full", "excerpt", "abstract", "secondary", "not_accessed"]
LABEL_FA = {"verified": "تأییدشده", "partial": "نیمه‌درست", "inaccurate": "نادرست", "misleading": "گمراه‌کننده",
            "unsupported": "بی‌پشتوانه", "disputed": "محل مناقشه", "unverifiable": "راستی‌آزمایی‌ناپذیر",
            "pending": "در انتظار دسترسی"}


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return [{k.strip(): (v or "").strip() for k, v in r.items()} for r in csv.DictReader(f)]


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    d = sys.argv[1]
    sents = read(os.path.join(d, "sentences.csv"))
    claims = read(os.path.join(d, "claims.csv"))
    sources = read(os.path.join(d, "sources.csv"))
    errors, warns = [], []
    src = {s["source_id"]: s for s in sources}
    sid_set = {s["sentence_id"] for s in sents}
    by_sent = Counter(c["sentence_id"] for c in claims)

    # Coverage
    for s in sents:
        hc = s.get("has_claims", "").lower()
        if hc not in ("yes", "no"):
            errors.append(f"{s['sentence_id']}: has_claims not set (yes/no): {s['text'][:60]}")
        elif hc == "yes" and by_sent[s["sentence_id"]] == 0:
            errors.append(f"{s['sentence_id']}: marked yes but no claims in ledger")
        elif hc == "no" and by_sent[s["sentence_id"]] > 0:
            warns.append(f"{s['sentence_id']}: marked no but has claims")

    ids = Counter(c["claim_id"] for c in claims)
    for cid, n in ids.items():
        if n > 1:
            errors.append(f"{cid}: duplicate claim_id")

    # Sources
    for s in sources:
        if s.get("accessed") not in ACCESS:
            errors.append(f"{s['source_id']}: accessed must be one of {ACCESS}")
        if s.get("primary") not in ("yes", "no"):
            errors.append(f"{s['source_id']}: primary must be yes/no")
        if not s.get("tier", "").isdigit() or not 1 <= int(s["tier"]) <= 6:
            errors.append(f"{s['source_id']}: tier must be 1-6")
        if not s.get("url_or_locator"):
            errors.append(f"{s['source_id']}: url_or_locator missing")
        if not s.get("origin_group"):
            errors.append(f"{s['source_id']}: origin_group missing (needed to judge independence)")

    # Claims
    for c in claims:
        cid, a, t = c["claim_id"], c.get("assessment", ""), c.get("claim_type", "")
        if c["sentence_id"] not in sid_set:
            errors.append(f"{cid}: sentence_id {c['sentence_id']} does not exist")
        if a not in ASSESS:
            errors.append(f"{cid}: assessment '{a}' invalid")
            continue
        if t not in TYPES:
            errors.append(f"{cid}: claim_type '{t}' invalid")
        if c.get("confidence") not in CONF and a != "pending":
            errors.append(f"{cid}: confidence missing")
        act = c.get("action", "")
        if act not in ACTIONS:
            errors.append(f"{cid}: action '{act}' invalid")
        cited = [x.strip() for x in c.get("sources", "").split(";") if x.strip()]
        for x in cited:
            if x not in src:
                errors.append(f"{cid}: source {x} not in sources.csv")
        usable = [src[x] for x in cited if x in src and src[x].get("accessed") not in ("not_accessed", "")]
        if a == "verified":
            primary_full = [s for s in usable if s.get("primary") == "yes" and s.get("accessed") == "full"]
            read_ok = [s for s in usable if s.get("accessed") in ("full", "excerpt")
                       and s.get("tier", "9").isdigit() and int(s["tier"]) <= 5]
            groups = {s["origin_group"] for s in read_ok}
            if t == "quote" and not primary_full:
                errors.append(f"{cid}: verified quote needs a primary source read in full")
            elif not primary_full and len(groups) < 2:
                errors.append(f"{cid}: verified needs 1 primary source read in full OR 2 independent sources read")
            if act not in ("none", ""):
                warns.append(f"{cid}: verified but action={act}")
        else:
            if a in ("partial", "inaccurate", "misleading"):
                if act not in ("correct", "qualify", "remove"):
                    errors.append(f"{cid}: {a} needs action correct|qualify|remove")
                if act in ("correct", "qualify") and not c.get("revision"):
                    errors.append(f"{cid}: revision text missing")
            if a in ("unsupported", "disputed", "unverifiable") and act in ("none", ""):
                errors.append(f"{cid}: {a} needs an action (qualify/remove/more_evidence)")
            if a in ("inaccurate", "partial", "misleading", "disputed") and not usable:
                errors.append(f"{cid}: {a} must cite the evidence it rests on")
            if a == "unverifiable" and not c.get("notes"):
                errors.append(f"{cid}: unverifiable must list in notes every route tried")
            if a == "pending":
                errors.append(f"{cid}: PENDING (waiting for access): resolve before the final report")

    cnt = Counter(c.get("assessment") for c in claims)
    yes = sum(1 for s in sents if s.get("has_claims", "").lower() == "yes")
    print(f"sentences: {len(sents)} (with claims: {yes})   claims: {len(claims)}   sources: {len(sources)}")
    print("assessment counts:")
    for k in ASSESS:
        print(f"  {LABEL_FA[k]} ({k}): {cnt.get(k, 0)}")
    print(f"  total: {sum(cnt.values())}  (must equal claims: {len(claims)})")
    acts = Counter(c.get("action") for c in claims)
    print("actions: " + ", ".join(f"{k}={acts.get(k, 0)}" for k in ACTIONS))
    for w in warns:
        print("WARN  " + w)
    for e in errors:
        print("ERROR " + e)
    print("RESULT: " + ("PASS" if not errors else f"FAIL ({len(errors)} errors)"))
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
