# Verification Protocols

Standard methods for each claim type. Every claim in the ledger has a `claim_type`; apply the matching protocol in full. Several protocols can apply to one claim (a dated quote uses `quote` and `date`).

## Contents
1. Universal protocol (every claim)
2. Evidence standard for each assessment
3. person · title_role
4. date · age_duration
5. place
6. number
7. quote
8. event
9. causal · motive
10. superlative_absence
11. description · atmosphere
12. translation (Persian rendering)
13. Resolving conflicting sources
14. Arithmetic and recalculation

---

## 1. Universal protocol (every claim)

1. **Restate the claim** as one precise proposition, as the narration words it, including its implied certainty («بیش از هزار»، «حدود»، «نخستین»).
2. **Trace it to its origin.** Which source did the narration take it from? The research dossier in `1-Content/3-Research` tells you where to start, but **the dossier is never evidence**. Follow its citation to the original and judge the original.
3. **Search independently** with at least two differently worded queries, one in English and one in the subject's own language where relevant (French for French history, German for German history, Persian for Iranian topics). Add the person's full name, the year and the place.
4. **Read the actual page or document.** A search snippet is never evidence. Record each source in `sources.csv` with its tier, whether it is primary, how much you read, and its `origin_group`.
5. **Assess independence.** Two sources share an `origin_group` if one cites the other or both cite the same original (for example two websites copying Wikipedia, or a book and an article both quoting the same newspaper). Only different groups count as independent corroboration.
6. **Compare word for word** with the narration: names, numbers, units, dates, scope, qualifiers.
7. **Assign one assessment** using section 2, with a confidence level and a documented rationale.
8. **If you are blocked**, follow the access ladder in `source-routes.md`. Never assess a claim from memory, and never downgrade effort because a site is closed.

## 2. Evidence standard for each assessment

| Assessment | Ledger value | Minimum evidence |
|---|---|---|
| تأییدشده (Verified) | `verified` | One authoritative **primary** source read in full that matches the claim as worded, **or** two **independent** reliable sources (tier ≤ 5, different origin groups) read in full or in relevant excerpt, both matching. Quotes: always the original or a reliable edition. |
| نیمه‌درست (Partially accurate) | `partial` | Evidence confirms the core but shows a material error in a detail (date, number, title, scope) |
| نادرست (Inaccurate) | `inaccurate` | Reliable evidence contradicts the claim or a material detail |
| گمراه‌کننده (Misleading) | `misleading` | Technically defensible, but framing, omission or exaggeration creates a false impression |
| بی‌پشتوانه (Unsupported) | `unsupported` | After the full search, no adequate evidence supports it (not proven false) |
| محل مناقشه (Disputed) | `disputed` | Credible sources conflict on a point that changes the conclusion |
| راستی‌آزمایی‌ناپذیر (Unverifiable) | `unverifiable` | Assessment is impossible even after the **entire** access ladder; `notes` lists every route tried |
| در انتظار دسترسی (Pending) | `pending` | Temporary only: waiting for the user to provide access. Blocks the final report |

**Not enough for Verified:** absence of contradiction; plausibility; many websites repeating one claim; the research dossier; an encyclopedia alone for a consequential claim; your own memory.

**Confidence** is your confidence in the assessment itself. *High:* strong direct evidence and no credible conflict. *Medium:* good evidence with a gap, or minor unresolved variation. *Low:* thin, indirect or conflicting evidence.

## 3. person · title_role

- Confirm identity: full name, life dates, nationality, and the right individual (watch for namesakes, fathers and sons, and title holders such as "3rd Earl Erne" versus "4th").
- Confirm the role **at the time of the event**: rank, office, employer, membership. Titles change; check the year.
- Check the Persian transliteration refers unambiguously to that person and is used consistently.
- Sources: national biography dictionaries, official registers, obituaries in reliable papers, scholarly biographies.

## 4. date · age_duration

- Find the date in at least one contemporaneous or primary record when possible; otherwise in two independent scholarly sources.
- Check the calendar: Julian or Gregorian (Russia before February 1918, Britain before 1752), Solar Hijri ↔ Gregorian conversions for Iranian topics, and time-zone effects on dates of death.
- **Recompute every age and duration** with code (section 14): age at the event = event date − birth date, taking the birthday into account. Check every "X days later", «سه روز بعد» and «هفت سال».
- Check internal chronology: no effect before its cause; people alive and present where stated.

## 5. place

- Confirm the place name for the period (historical vs modern names and borders), its administrative unit (county, province) and its spatial relations («در کنار دریاچه»، «نزدیک شهر»).
- Check that people could be there at that time (travel, imprisonment, exile).
- Sources: gazetteers, historical maps, official place-name databases, scholarly works.

## 6. number

- Identify the number's original source, unit, date, denominator, population and method.
- Check rounding words against the figure: «بیش از هزار» needs a figure above 1,000; «حدود» needs a defensible range; «تقریباً تمام» needs support for near-totality.
- Convert units and currencies yourself (acres ↔ hectares, pounds then vs now, tons) and check the narration's conversion.
- When sources give different figures, report the range and the reason (different counts, dates or definitions). Never choose the most dramatic figure.
- Casualty, crowd and cost figures are often disputed: always give at least two independent sources, and give the range if they differ.

## 7. quote

The highest-risk claim type. Famous quotes are often misattributed, paraphrased or invented.

1. Locate the **original**: the speech text, letter, book page, newspaper report, recording or court transcript. A reliable critical edition or archive scan counts as primary.
2. Confirm the **speaker**, **date**, **occasion** and **audience**.
3. Compare the **wording**. Has it been shortened? Were words added, or two passages merged? Do omissions change the meaning?
4. Check the **context**: was it said ironically, quoted from someone else, or later retracted?
5. Check the **Persian translation** against the original language (section 12).
6. Check known misattribution sources (Quote Investigator, Wikiquote's "Disputed" and "Misattributed" sections), but **trace them to the original**; they are only leads.
7. If the original cannot be found, the quote is at best `unsupported`. Recommend attribution wording such as «به روایت …» or «نقل است که…» naming the earliest source, or removal.

## 8. event

- Break the event into who, what, when, where, how many and outcome; each is a separate claim if the narration states it.
- Use contemporaneous reports for what was reported at the time, and later scholarship for what is established; note where they differ.
- Check the sequence and the claimed consequences.

## 9. causal · motive

- **Causal claims** («این نامه، بریتانیا را تکان داد»، «باعث سقوط … شد»): require evidence of the causal link from scholarship, not just a sequence in time. If historians debate the cause, the claim is `disputed`; recommend wording that attributes it.
- **Motives, thoughts, feelings, knowledge** («او می‌دانست»، «امید خود را بسته بودند»، «سرخوردگی او»): require direct evidence such as the person's own words, diaries, letters or testimony. Otherwise classify as `unsupported` and recommend attributed or softened wording («به نوشته زندگی‌نامه‌نویسش…»).

## 10. superlative_absence

Claims of firsts, onlys, mosts, nevers and absolutes («نخستین»، «تنها»، «هرگز»، «هیچ‌کس»، «قدرتمندترین»، «تمام»).

- Require a source that **explicitly** makes the claim, preferably scholarly, and search actively for counterexamples.
- «هیچ‌کس…» or «هرگز…» about historical behaviour usually cannot be proven. Recommend narrower wording unless a source supports the absolute.
- Rhetorical superlatives («قدرتمندترین امپراتوری جهان») must still be defensible for the period; flag them if they are contestable.

## 11. description · atmosphere

The narration reconstructs scenes: weather, clothing, light, crowd behaviour, physical appearance.

- **Physical descriptions of real people** (age, beard, clothing) need sources: photographs, contemporary descriptions or biographies.
- **Atmosphere** (rain, cold, wind, darkness) is a factual claim too. Check contemporaneous reports, diaries and weather records. If it is unsupported and not certain from the season and place, recommend removing it or making it neutral. Atmosphere may never contradict a source; a sunny day narrated as rainy is `inaccurate`.
- **Crowd behaviour and silence** («هزاران دهقان در سکوت ایستاده‌اند») needs contemporary accounts.
- Keep in mind that the house style allows atmosphere only "if it does not contradict the source". Your job is to establish whether it does.

## 12. translation (Persian rendering)

- Check that the Persian rendering of a quote, title or term preserves its meaning, tone, tense and certainty. Back-translate it mentally and compare with the original.
- Check names of works, organisations and laws: is the Persian name accurate and recognisable?
- Check measurement and currency renderings and conversions.
- Flag added emphasis, softened or strengthened verbs, and lost qualifiers («شاید» dropped, «بخشی از» turned into «همه»).

## 13. Resolving conflicting sources

1. List the competing accounts and cite the strongest evidence for each.
2. Compare provenance: proximity to the event, access, expertise, motive, method, corroboration.
3. Check whether the conflict comes from definitions, dates, calendars or rounding; if so, it can often be reconciled.
4. If reconciled, assess against the reconciled fact. If not, the claim is `disputed`; recommend wording that presents the range or attributes each version.
5. Never resolve a conflict by picking the more dramatic version, or the version the narration already uses.

## 14. Arithmetic and recalculation

Do all arithmetic with code, never mentally. Typical checks:

```python
from datetime import date
born, event = date(1832, 3, 12), date(1880, 11, 11)
age = event.year - born.year - ((event.month, event.day) < (born.month, born.day))   # 48
(date(1880, 11, 27) - date(1880, 11, 11)).days                                        # duration in days
acres_to_ha = lambda a: a * 0.404686
```

Record the computation in the claim's `notes` so it can be re-run.
