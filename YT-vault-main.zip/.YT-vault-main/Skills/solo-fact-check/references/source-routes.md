# Source Routes and the Access Ladder

Where to look for each kind of claim, and what to do when a source is blocked. Also read the channel's `D:\.YT-vault\Skills\solo-research\References.md` for its preferred starting points; read it fresh, because it is updated.

## Contents
1. The access ladder: never skip a claim because a source is closed
2. How to ask the user for access
3. Routes by claim type
4. Routes by domain
5. Source tiers (for `sources.csv`)

---

## 1. The access ladder: never skip a claim because a source is closed

When a needed page or document cannot be read, climb this ladder **in order**. Record every rung you tried in the claim's `notes`. A claim may become `unverifiable` only after the last rung.

1. **Fetch the page directly** with WebFetch. If it is long, read the relevant part with an offset; don't stop at the first screen.
2. **Try an archived or alternate copy:**
   - Wayback Machine: `https://web.archive.org/web/2024*/<url>`, then open the newest capture.
   - The author's own website, a university repository, or a preprint (search for the exact title plus "pdf").
   - Open-access versions through Google Scholar's "All versions", CORE (core.ac.uk), OpenAlex or Unpaywall.
3. **Find the same text in a full-text library:** Internet Archive (archive.org) books, HathiTrust full-text search, Google Books "search inside", Wikisource, Project Gutenberg, Gallica, Chronicling America, Trove, Delpher.
   - HathiTrust search-only and Google Books snippets can confirm that a phrase is on a given page. Record this as `excerpt`, and only when the visible context is enough to judge the claim.
4. **Use a browser** for pages that need JavaScript, a search form, page navigation or the user's own logins (library cards, subscriptions). Use Claude in Chrome or the built-in browser, and load the matching browser skill before the first step.
5. **Ask the user** (see section 2). Mark the claim `pending` and **continue with the other claims**; don't stop the whole review.
6. **Only then** mark it `unverifiable`, with the full list of routes tried in `notes`, and report what would resolve it.

**Rules**
- Never mark a claim as verified, or reject it, from memory because a source was unreachable.
- Don't stop searching just because the first good source agrees; a Verified claim still needs the evidence standard (one primary source read in full, or two independent sources).
- If a web tool declines a site for legal reasons, don't work around it with other tools. Use another source or ask the user to open it.
- There is no time limit. If the review is long, keep the ledger on disk and continue in batches; never sample.

## 2. How to ask the user for access

Send one consolidated request (not one message per claim) as soon as the blocked items are known, while you continue the review. For each item:

- the claim ID and the narration excerpt
- the exact source needed: title, author, edition, page or record number, URL
- why it matters (which assessment depends on it)
- the easiest options: attach a PDF or screenshot; open the page in their Chrome while you read it; log in to a database; connect a connector (for example the Google Drive where they keep books); or confirm that you should drop or soften the claim

Example: «برای ادعای C014 (سخنرانی پارنل در انیس، ۱۹ سپتامبر ۱۸۸۰) متن اصلی گزارش Freeman's Journal همان هفته لازم است. نسخه دیجیتال در Irish Newspaper Archives پشت اشتراک است. اگر دسترسی دارید، در Chrome باز کنید یا اسکرین‌شات صفحه را بفرستید.»

## 3. Routes by claim type

| Claim type | Best evidence | Where to look |
|---|---|---|
| person, title_role | National biography dictionaries, official registers, peerage and army lists, scholarly biographies | Oxford DNB (subscription), Dictionary of Irish Biography (free), Deutsche Biographie, Dictionnaire biographique, American National Biography, Encyclopaedia Iranica, official gazettes (The London Gazette) |
| date, age_duration | Birth, marriage and death records; contemporaneous newspapers; scholarly chronologies | Civil and parish registers, newspapers (below), biography dictionaries; calendar converters for Julian, Gregorian and Solar Hijri dates |
| place | Historical gazetteers and maps | Ordnance Survey historic maps, GeoNames, national place-name databases, Encyclopaedia Iranica for Iran |
| number | The original dataset or official report | National statistics offices, parliamentary papers, UN Data, World Bank, OECD; Our World in Data leads you to the originals |
| quote | The original speech, letter, book, transcript or recording | Hansard (UK Parliament debates), Wikisource, published collected works and letters, newspaper archives, recordings; Quote Investigator and Wikiquote's "Disputed" sections as leads only |
| event | Contemporaneous reports plus later scholarship | Newspaper archives, official inquiries, JSTOR and university-press monographs |
| causal, motive | Scholarship that argues the link; the person's own writings | Peer-reviewed history and science; diaries, letters, memoirs, testimony |
| superlative_absence | A scholarly source making the explicit claim, plus a search for counterexamples | Specialist monographs, reference works, Guinness-type claims only with their documentation |
| description, atmosphere | Photographs, eyewitness descriptions, weather records | Library of Congress Prints & Photographs, Wikimedia Commons (check provenance), contemporaneous reports; Met Office Daily Weather Reports (UK, from 1860s), NOAA (US) |
| translation | The original-language text | The original edition; established translations for comparison |

## 4. Routes by domain

- **Newspapers:** Chronicling America (US, free), British Newspaper Archive (subscription), Irish Newspaper Archives (subscription), Trove (Australia, free), Gallica and Retronews (France), Delpher (Netherlands), Europeana, The Times Digital Archive (library access), and the New York Times TimesMachine (subscription).
- **Government and parliament:** Hansard; the UK National Archives Discovery catalogue; the US National Archives; Foreign Relations of the United States (history.state.gov); the CIA CREST Reading Room; the UN Digital Library; national legislation databases.
- **Scholarship:** Google Scholar, JSTOR (including free early content), Project MUSE, Persée (French journals), Cairn, Semantic Scholar, CORE, OpenAlex; university-press books in Google Books and Internet Archive.
- **Science and medicine:** PubMed and PubMed Central, Cochrane reviews, journal websites, and the original study rather than press releases.
- **Iranian and Persian topics:** Encyclopaedia Iranica, the National Library of Iran (nlai.ir), SID.ir, Magiran and Noormags (journals), Ganjoor (classical poetry texts); check Solar Hijri dates against a converter.
- **Awards and lists:** the official archives, such as the Nobel Prize nomination archive.
- **Words and etymology:** the Oxford English Dictionary (subscription) for first attestations; Etymonline as a lead only.

## 5. Source tiers (for `sources.csv`)

| Tier | Type |
|---|---|
| 1 | Primary: original documents, records, transcripts, recordings, datasets, contemporaneous reports (as evidence of what was reported) |
| 2 | Peer-reviewed scholarship, university-press books, critical editions |
| 3 | Authoritative institutions: archives, museums, government agencies, national biography dictionaries |
| 4 | Reputable journalism with transparent sourcing |
| 5 | Specialist reference works and secondary books with documented method; major encyclopedias |
| 6 | Other: personal sites, forums, social media, unsourced summaries, AI output. Leads only; they never count toward Verified |

`primary = yes` for tier-1 material and for critical editions of original texts. `accessed` records how much you actually read: `full`, `excerpt`, `abstract`, `secondary` (known only through another source's citation) or `not_accessed`.
