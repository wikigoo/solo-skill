# Arguing with Images: What a Video Essay Is and Why It Thrives on YouTube

A film scene slowed to a crawl, a line of dialogue on screen, a narrator explaining why a single cut changes everything: this is the video essay at work. On YouTube, the form covers film, games, history, politics and internet culture. YouTube reported more than 200 million views in 2024 of videos related to video essays ([YouTube Official Blog, 2025](https://blog.youtube/culture-and-trends/the-joy-of-video-essays/)). The label is used loosely, though. In 2025, *Sight and Sound* observed that the form "still escapes definition" ([BFI, 2025](https://www.bfi.org.uk/sight-and-sound/polls/best-video-essays-2025)). The form still has a recognizable core, and that core explains why it has become one of the most effective ways to do analysis and critique online.

## A Working Definition

A video essay makes an argument or offers an interpretation through moving images and sound rather than through written prose alone. Like a written essay, it pursues a question and arrives at a point of view. Unlike a written essay, it can show its evidence instead of describing it. YouTube's own description stresses this difference: video essays examine a subject in depth through the creator's commentary, and unlike a standard explainer, they typically argue a thesis ([YouTube Official Blog, 2025](https://blog.youtube/culture-and-trends/the-joy-of-video-essays/)).

The form is a hybrid. It borrows the structure of the written essay, the factual grounding of documentary, the judgment of criticism, the personal voice of commentary and the craft of audiovisual editing. Most video essays share five traits:

- **A clear subject or question.** The video establishes what it is examining and why it matters.
- **A structured argument or interpretive perspective.** It develops a thesis, a central claim, rather than simply describing.
- **Research, evidence or close reading.** Close reading means examining a small part of a work, such as one shot or one line, in fine detail.
- **Purposeful audiovisual material.** Clips, images and sounds appear because they demonstrate something, not as decoration.
- **Editing as reasoning.** The order, timing and juxtaposition of material form part of the argument itself.

## Roots in Cinema and Scholarship

The idea that film could think like prose is older than the internet. In 1948, the critic Alexandre Astruc proposed the *caméra-stylo*, or "camera-pen": cinema as a language flexible enough to express ideas as directly as writing does ([Wikipedia: Alexandre Astruc](https://en.wikipedia.org/wiki/Alexandre_Astruc)). The essay film tradition that followed builds films around an idea rather than a plot.

Academia later adopted the form as "videographic criticism," meaning scholarship made in video. The journal *[in]Transition* publishes such work alongside signed, open peer reviews, with the aim of establishing it as a legitimate mode of scholarly writing ([MediaCommons](https://mediacommons.org/intransition/about)). Today the field spans several worlds. The 2025 *Sight and Sound* poll grouped its voters into academia and criticism, festivals and galleries, and social media and YouTube. It found little overlap between the three groups ([BFI, 2025](https://www.bfi.org.uk/sight-and-sound/polls/best-video-essays-2025)).

## The Major Forms

The video essay is defined by its method rather than its subject, so its forms vary widely:

- **Media and film analysis** examines how films, television or music create meaning through framing, sound, performance and editing.
- **Literary and cultural criticism** reads books, fashion, memes or online communities as texts that reveal shared values.
- **Historical and political analysis** traces how events, ideologies or institutions developed, often using archival footage and documents.
- **Video game analysis** studies design, mechanics and narrative, using gameplay footage to show how interaction shapes experience.
- **Personal or autobiographical essays** anchor an argument in the creator's own life, making subjectivity part of the evidence.
- **Visual essays** rely mainly on images, sound and editing, sometimes with no narration at all. The supercut, a rapid montage of similar moments, is a familiar example.
- **Educational or explanatory essays** teach a concept or technique while still organizing it around a perspective.

These categories overlap constantly. An essay on a war film can be film analysis, history and political commentary at once. Length, depth of research and production polish vary just as widely.

## How YouTube Shaped the Form

YouTube did not invent the video essay, but it changed the form in lasting ways:

- **Accessibility.** Free viewing and free publishing let analysis that once lived in journals and festivals reach a general audience.
- **Creator-driven publishing.** Without editors or broadcasters, creators can pursue niche subjects, unusual lengths and distinctive voices.
- **Audience interaction.** Comments, community posts and response videos turn single essays into ongoing debates, and sometimes into public corrections.
- **Serialized content.** Channels build recurring formats, so viewers return for a way of thinking as much as for a topic.
- **Platform recommendations.** YouTube says its recommendations weigh clicks, watch time, viewer satisfaction surveys, likes and shares ([YouTube Official Blog, 2021](https://blog.youtube/inside-youtube/on-youtubes-recommendation-system/)). A long essay that keeps viewers engaged can benefit, but creators also face pressure to choose clickable topics and titles.
- **Varied production styles.** A narrated slideshow and a heavily animated production can sit side by side, and both can persuade.

## How Sound and Image Carry the Argument

A written critic must describe a scene before analysing it. A video essayist can simply play it. Each element of the video carries part of the reasoning:

- **Clips and screenshots** work like quotations, letting viewers check a claim against its source.
- **Archival material** grounds historical and political arguments in the record of the period.
- **On-screen quotations** preserve exact wording from critics, interviews and texts.
- **Narration** supplies the line of argument and the essayist's voice.
- **Music and sound** set the tone, and can themselves be the evidence, as in an analysis of a film score.
- **Graphics and text** clarify structure, data and comparisons.
- **Editing** places shots side by side, slows a moment down or repeats a pattern, so viewers see the point for themselves.

Explanation is not the only way to argue. Scholars of the form note that poetic essays, which work through association and rhythm rather than narration, can also communicate a point ([van den Berg & Kiss, *Film Studies in Motion*](https://scalar.usc.edu/works/film-studies-in-motion/1)).

## What a Video Essay Is Not

Several neighbouring formats look similar but aim at something different. The distinctions below are tendencies, not rules, and many videos blend formats.

| Format | Main purpose | How it differs from a video essay |
| --- | --- | --- |
| Review | Judge whether a work is worth watching | Centres on a verdict; an essay centres on interpretation |
| Reaction video | Record a first response in real time | Spontaneous rather than structured and researched |
| Summary or recap | Retell what happens | Describes content; an essay explains meaning or method |
| Documentary | Report on real events, often with original footage | Usually observes and informs; an essay foregrounds a thesis |
| Video podcast | Capture a conversation | Built around talk, with visuals secondary |
| Opinion piece | State a position | May assert a view without sustained evidence |
| Educational explainer | Pass on established knowledge | Explains how something works; an analytical essay argues |

## Strengths and Limits

The form's strengths come from its hybrid nature. It is accessible, drawing viewers who would never open an academic article into sustained analysis. It carries emotional weight, because voice, music and image work on feeling as well as reason. Above all, it demonstrates: viewers see the pattern rather than being told about it.

The same qualities create risks:

- **Oversimplification.** The need to hold attention can flatten complex questions into tidy narratives.
- **Selective evidence.** A well-chosen clip can make a claim look stronger than the full work supports.
- **Copyright.** US fair use law lists criticism, comment, teaching and scholarship among the purposes it may protect. Courts still decide case by case, weighing four factors ([U.S. Copyright Office](https://www.copyright.gov/fair-use/more-info.html)). Automated enforcement adds another constraint. The creators of *Every Frame a Painting* said their clip lengths and audio mixing were "reverse-engineered" from YouTube's copyright detection system ([Zhou, 2017](https://medium.com/@tonyszhou/postmortem-1b338537fabc)).
- **Opinion dressed as analysis.** Polished editing and a confident voice can give personal taste the authority of research.

A useful test is whether an essay shows its sources, engages counterarguments and lets the evidence speak before the conclusion does.

## Conclusion

What distinguishes a video essay is its method, not its subject, length or budget: it uses sound and image to build an argument the viewer can follow and test. Analytical and critical essays thrive on YouTube because the platform suits that method. Creators can quote their subjects directly, publish without gatekeepers and reach audiences who return for a particular way of thinking. At its best, the video essay does what criticism has always tried to do, helping people see familiar things more clearly. It does so by showing as well as telling.

---

### Sources

- Astruc, Alexandre. "Alexandre Astruc." *Wikipedia*. https://en.wikipedia.org/wiki/Alexandre_Astruc
- British Film Institute. "The Best Video Essays of 2025." *Sight and Sound*, 17 December 2025. https://www.bfi.org.uk/sight-and-sound/polls/best-video-essays-2025
- Goodrow, Cristos. "On YouTube's Recommendation System." *YouTube Official Blog*, 15 September 2021. https://blog.youtube/inside-youtube/on-youtubes-recommendation-system/
- MediaCommons. "About [in]Transition." https://mediacommons.org/intransition/about
- U.S. Copyright Office. "More Information on Fair Use." https://www.copyright.gov/fair-use/more-info.html
- van den Berg, Thomas, and Miklós Kiss. *Film Studies in Motion: From Audiovisual Essay to Academic Research Video*. Scalar, 2016. https://scalar.usc.edu/works/film-studies-in-motion/1
- YouTube Culture & Trends. "Hour-long & Lovin' It: The Joy of Video Essays." *YouTube Official Blog*, 16 April 2025. https://blog.youtube/culture-and-trends/the-joy-of-video-essays/
- Zhou, Tony. "Postmortem: Every Frame a Painting." *Medium*, 2017. https://medium.com/@tonyszhou/postmortem-1b338537fabc